(function (lib, img, cjs) {

var p; // shortcut to reference prototypes
var rect; // used to reference frame bounds

// stage content:
(lib.MFDC_SplashScreen_3second_900x600_JavaScript_CS6 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{},true);

	// MFDC-day
	this.instance = new lib.mfdcday();
	this.instance.setTransform(145.6,104.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:100.6,alpha:0.199},13).to({y:94.8,alpha:0.391},11).wait(48));

	// MFDC-night
	this.instance_1 = new lib.mfdcnight();
	this.instance_1.setTransform(145.6,104.8);
	this.instance_1.alpha = 0.852;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:98.4,alpha:0.25},13).to({y:94.3,alpha:0},5).to({_off:true},1).wait(53));

	// box - orange
	this.instance_2 = new lib.boxorange();
	this.instance_2.setTransform(90.5,469.5);
	this.instance_2.alpha = 0.738;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(72));

	// box - red
	this.instance_3 = new lib.boxred();
	this.instance_3.setTransform(232.5,469.5);
	this.instance_3.alpha = 0.738;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(72));

	// box - green
	this.instance_4 = new lib.boxgreen();
	this.instance_4.setTransform(377.5,469.5);
	this.instance_4.alpha = 0.738;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).wait(72));

	// box - blue
	this.instance_5 = new lib.boxblue();
	this.instance_5.setTransform(522.5,469.5);
	this.instance_5.alpha = 0.738;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).wait(72));

	// box - yellow
	this.instance_6 = new lib.boxyellow();
	this.instance_6.setTransform(665.5,469.5);
	this.instance_6.alpha = 0.738;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).wait(72));

	// box - pink
	this.instance_7 = new lib.boxpink();
	this.instance_7.setTransform(810.5,469.5);
	this.instance_7.alpha = 0.738;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7}]}).wait(72));

	// carnegie-day
	this.instance_8 = new lib.carnegieday();
	this.instance_8.setTransform(90.3,487.1);
	this.instance_8.alpha = 0.25;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// carnegie-night
	this.instance_9 = new lib.carnegienight();
	this.instance_9.setTransform(90.3,487.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({alpha:0.488},18).to({_off:true},1).wait(53));

	// games for-day
	this.instance_10 = new lib.gamesforday();
	this.instance_10.setTransform(232.2,487.2);
	this.instance_10.alpha = 0.238;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// learning institute-day
	this.instance_11 = new lib.learninginstituteday();
	this.instance_11.setTransform(232.4,498.1);
	this.instance_11.alpha = 0.238;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// at nyu-day
	this.instance_12 = new lib.atnyuday();
	this.instance_12.setTransform(232.6,524.5);
	this.instance_12.alpha = 0.238;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// games for-night
	this.instance_13 = new lib.gamesfornight();
	this.instance_13.setTransform(232.2,487.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// learning institute-night
	this.instance_14 = new lib.learninginstitutenight();
	this.instance_14.setTransform(232.4,498.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// at nyu-night
	this.instance_15 = new lib.atnyunight();
	this.instance_15.setTransform(232.6,524.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// game2learn-day
	this.instance_16 = new lib.game2learnday();
	this.instance_16.setTransform(377.1,487.3);
	this.instance_16.alpha = 0.25;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// unc charlotte-day
	this.instance_17 = new lib.unccharlotteday();
	this.instance_17.setTransform(376.6,513.5);
	this.instance_17.alpha = 0.25;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// college of computing-day
	this.instance_18 = new lib.collegeofcomputingday();
	this.instance_18.setTransform(376.9,524.5);
	this.instance_18.alpha = 0.25;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// and infomatics-day
	this.instance_19 = new lib.andinfomaticsday();
	this.instance_19.setTransform(377.4,535.6);
	this.instance_19.alpha = 0.25;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// game2learn-night
	this.instance_20 = new lib.game2learnnight();
	this.instance_20.setTransform(377.1,487.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// unc charlotte-night
	this.instance_21 = new lib.unccharlottenight();
	this.instance_21.setTransform(376.6,513.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// college of computing-night
	this.instance_22 = new lib.collegeofcomputingnight();
	this.instance_22.setTransform(376.9,524.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// and infomatics-night
	this.instance_23 = new lib.andinfomaticsnight();
	this.instance_23.setTransform(377.4,535.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// learnlab-day
	this.instance_24 = new lib.learnlabday();
	this.instance_24.setTransform(522,487.3);
	this.instance_24.alpha = 0.25;
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// the phg science-day
	this.instance_25 = new lib.thepghscienceday();
	this.instance_25.setTransform(522.3,513.4);
	this.instance_25.alpha = 0.25;
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// of learning center-day
	this.instance_26 = new lib.oflearningcenterday();
	this.instance_26.setTransform(522.3,524.6);
	this.instance_26.alpha = 0.25;
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// learnlab-night
	this.instance_27 = new lib.learnlabnight();
	this.instance_27.setTransform(522,487.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// the phg science-night
	this.instance_28 = new lib.thepghsciencenight();
	this.instance_28.setTransform(522.3,513.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// of learning center-night
	this.instance_29 = new lib.oflearningcenternight();
	this.instance_29.setTransform(522.3,524.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_29).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// pellissippi-day
	this.instance_30 = new lib.pellissippiday();
	this.instance_30.setTransform(664.9,487.1);
	this.instance_30.alpha = 0.25;
	this.instance_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// community-day
	this.instance_31 = new lib.communityday();
	this.instance_31.setTransform(665.1,513.5);
	this.instance_31.alpha = 0.25;
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// pellissippi-night
	this.instance_32 = new lib.pellissippinight();
	this.instance_32.setTransform(664.9,487.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_32).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// community-night
	this.instance_33 = new lib.communitynight();
	this.instance_33.setTransform(665.1,513.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_33).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// playpower-day
	this.instance_34 = new lib.playpowerday();
	this.instance_34.setTransform(810.6,487.3);
	this.instance_34.alpha = 0.25;
	this.instance_34._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(12).to({_off:false},0).to({alpha:1},12).wait(48));

	// playpower-night
	this.instance_35 = new lib.playpowernight();
	this.instance_35.setTransform(810.6,487.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_35).to({alpha:0.5},18).to({_off:true},1).wait(53));

	// m
	this.instance_36 = new lib.M();
	this.instance_36.setTransform(165,430);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_36}]}).wait(72));

	// ath
	this.instance_37 = new lib.athluencyblack();
	this.instance_37.setTransform(241.7,430);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_37}]}).wait(72));

	// f
	this.instance_38 = new lib.F();
	this.instance_38.setTransform(241.8,429.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_38}]}).wait(72));

	// luency
	this.text = new cjs.Text("luency", "32px Adobe Garamond Pro");
	this.text.textAlign = "center";
	this.text.lineHeight = 34;
	this.text.setTransform(292.6,408.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(72));

	// math shadow
	this.instance_39 = new lib.mathfluencyshadow();
	this.instance_39.setTransform(282.4,438.9,0.991,1);
	this.instance_39.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_39).to({scaleX:0.98,y:439.4,alpha:0.301},13).to({scaleX:0.95,scaleY:1.01,skewX:8.3,x:278.9,alpha:1},11).wait(48));

	// d
	this.instance_40 = new lib.D();
	this.instance_40.setTransform(565.1,429.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_40}]}).wait(72));

	// ata
	this.instance_41 = new lib.atablack();
	this.instance_41.setTransform(665.6,430);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_41}]}).wait(72));

	// c
	this.instance_42 = new lib.C();
	this.instance_42.setTransform(638.4,430);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_42}]}).wait(72));

	// ollaborative
	this.instance_43 = new lib.ollaborativeblack();
	this.instance_43.setTransform(725.6,430);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_43}]}).wait(72));

	// data shadow
	this.instance_44 = new lib.datacollaborativeshadow();
	this.instance_44.setTransform(703.1,435.9,0.988,1);
	this.instance_44.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_44).to({scaleX:0.98,alpha:0.301},13).to({scaleX:0.93,scaleY:1.02,skewX:-11.8,x:697.8,y:435.4,alpha:1},11).wait(48));

	// x
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#C0DEB4").ss(0.7).p("AgxgFQAKAAAGACQANADAMAHQAFADAPALQASAJARgCQARgCAFgLQADgIgDgHQgDgHgJgIQgDgCgCgBQgNgIgQgBQgUgCgcAKQgBAAgBABQgYAHgIAGIAKAA").cp();
	this.shape.setTransform(570,329);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(175,202,164,0.91)").ss(0.6).p("AgygMQAJgCAPgDQAagJAPgCQAFAAAFABQAMADAJAJQAEACADACQAKAIADAHQACADAAADQAAAFgDAFQgGAIgRABQgCAAgDAAQgOABgQgFQgBgBgCAAQgEgDgCgDQgHgGgCgCQgGgGgGgEQgFgBgFgBQgGgDgKgBIgJAAIgBAAQAEgDAFgDIAAAA").cp();
	this.shape_1.setTransform(569.9,329.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(153,177,144,0.796)").ss(0.7).p("Ag9gJQADgDAFgDQALgBAPAAQAYgIAMgFQAIABAAAAQADAAADACQAJAFAGAJQAFACACADQALAHAEAJQABACABACQAAABAAABQAAADgCAEQgBABgBABQgHAFgRgBQgCAAgBgBQgRAEgOgCQAAAAAAAAQgCgBgBAAQgDgDgDgBQgBgBgBgCQgFgGgBgDQgEgGgFgFQgBgBgBAAQgDAAgDgCQgHgEgKgBIgKgCIAAAA");
	this.shape_2.setTransform(570,329.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(131,152,123,0.682)").ss(0.7).p("Ag8gOQAEgDAFgDQAMACAQACQAXgJAOgHQAIACAAAAQACACABACQAGAGADAKQAFADADADQALAHAGAKQABACABACQAAABgBABQgBAEgCADQgBABgBAAQgJACgRgDQgBgBgCAAQgRAGgPABQAAAAAAAAQgBgBgCAAQgDgDgDgCQgBgBAAgBQgEgHAAgDQgBgHgDgFQgBgCgBAAQgDgBgDgBQgHgFgKgDIgKgDIgBgB");
	this.shape_3.setTransform(569.6,329.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(109,126,103,0.569)").ss(0.8).p("Ag6gSQAEgEAFgDQANAFAQAEQAWgKAQgJQAIADABABQAAACABADQACAHAAALQAFADAEAEQALAHAHAKQABACABACQAAACgBABQgBAEgDADQgBAAgCAAQgJgBgRgFQgCgBgBAAQgSAIgPAEQAAAAAAAAQgCgBgBAAQgEgDgDgDQAAgBgBgBQgBgHABgEQAAgHgBgGQAAgBAAgBQgDgBgDgCQgIgGgKgEIgLgFIAAAA");
	this.shape_4.setTransform(569.3,329.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(88,101,82,0.455)").ss(0.8).p("Ag5gWQAFgEAFgEQAOAHAQAHQAXgLAQgLQAJAFABAAQgBADgBAEQgBAIgDAMQAFAEAEACQAMAKAIAKQABACABACQAAACgBABQgCAEgDAEQgBgBgCAAQgLgEgRgIQgBgBgCgBQgRAMgRAGQAAAAAAABQgCgBgBgBQgEgDgDgDQAAgCAAgBQAAgHADgFQACgHABgHQAAgBAAgBQgDgBgDgCQgIgHgLgFIgKgHIgBAA");
	this.shape_5.setTransform(569,330);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(66,76,62,0.341)").ss(0.9).p("Ag4gaQAFgFAGgEQAPAKAQAJQAXgLARgOQAKAGAAABQgCADgCAEQgEALgGAMQAGAEAEACQALALAKALQABACACACQgBACgBABQgDAEgDAEQgCgBgCgBQgMgHgRgKQgBgBgCgBQgRAOgRAJQgBABAAAAQgBgBgCgBQgDgEgEgDQAAgBABgCQACgHAEgFQADgIADgHQABgCABgBQgEgBgDgDQgIgHgLgHIgLgIIgBAA");
	this.shape_6.setTransform(568.7,330.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(44,51,41,0.227)").ss(0.9).p("Ag2gfQAFgEAFgFQARANAQALQAXgMATgQQAKAIAAAAQgDAFgEAEQgHAMgJANQAGADAEAEQAMAMALALQABACACACQgBACgBABQgDAEgEAEQgCgBgCgCQgOgKgQgMQgCgBgBgBQgSAQgSAMQAAABgBAAQgBgBgCgBQgDgEgEgEQAAgBABgBQAEgIAFgGQAGgIAFgIQABgCABgBQgDgCgEgCQgJgJgKgIIgLgJIgBgB");
	this.shape_7.setTransform(568.4,330.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(22,25,21,0.114)").ss().p("Ag2gjQAGgFAFgFQASAPAQAOQAYgNATgSQAKAJABABQgFAFgEAFQgLANgMAOQAGADAFAFQAMAMAMAMQACACABACQgBACgBABQgEAEgEAEQgCgCgCgCQgPgNgRgOQgBgBgCgCQgSATgSAPQgBABAAAAQgCgBgBgBQgEgEgEgEQABgCABgBQAGgIAGgGQAHgJAHgIQACgCACgCQgEgCgDgDQgKgJgKgJIgMgLIgBgB");
	this.shape_8.setTransform(568.1,330.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(0,123,70,0.259)").s().p("AgzgnIApAnIgpAoIAMALIAngoIAoAoIALgLIgogoIAognIgLgMIgoApIgngpIgMAM").cp();
	this.shape_9.setTransform(567.7,331.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},45).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(19));

	// 0
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#DEE999").ss(0.7).p("AhAgFIAJAAQALAAAFACQAOADALAHQAGADAPALQASAJAQgCQARgCAFgLQAEgIgDgHQgDgHgKgIQgOgLgUgBQgSgCgeAKQgZAIgIAGIAAAA").cp();
	this.shape_10.setTransform(492.6,186);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(202,212,139,0.91)").ss(0.6).p("AA1gPQAJAIADAHQABALgBAEQgFALgQAEQgDAAgDABQgNABgPgHQgCgBgCgBQgLgIgFgEQgDgCgEgCQgIgFgJgCQgFgCgKgBQgEAAgFgBQAIgHAXgIQAbgKANAAQASABAJAEQAHAEAGAFIAAAAAA3gQQADADADADQAFAFABAFQACALgCAFQgCAFgEADQgGAFgJACQgBAAAAAAQgJACgKgCQgIgCgHgDQgDgBgCgCQgIgFgFgDQgDgCgBgBQgGgEgGgDQgHgDgGgCQgCAAgDgBQgEgBgGgBQgEAAgEgBIgBAAQAEgEALgGQASgHABgBQAIgDAJgCQAJgDAKAAQAGgBAFABQAFABAEABQAJACAJAFQAEACADADIAAAA").cp();
	this.shape_11.setTransform(492.5,186.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(184,193,126,0.827)").ss(0.6).p("Ag/gDQAEgFAKgHQASgJAAAAQAIgEAJgCQALgDAIAAQAHgBAGABQAEABADABQAKACAHAEQABABACABQAEACADAEQACACACACQABABABABQAEAFACAGQAAACAAACQABAIgCAEQgBAFgEADQgGAGgJADQgBAAAAAAQAAAAAAAAQgJACgKgBQgIgBgIgDQgBgBgCgBQgBAAgBgBQgIgEgFgDQgEgCgBgBQgFgEgGgDQAAgBgBAAQgHgEgGgDQgBgBgCAAQgGgBgFgBQgEAAgDgCQAAAAgBAAAg7gDQAIgJAVgIQAcgLAKgBQATACAJAFQAVARADAIQAAACAAADQAAAHgBADQgFAMgOAEQgCAAgBABQgCAAgBAAQgNACgOgFQgBAAgBAAQgBgBgCgBQgLgIgFgEQgCgBgBgBQgCgBgCgBQgIgGgIgEQgFgBgJgCQgEAAgEgB");
	this.shape_12.setTransform(493.2,186.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(165,173,114,0.744)").ss(0.7).p("Ag/gCQADgHAKgGQASgLAAAAQAIgEAJgCQALgEAIAAQAIgBAGACQAEAAADABQAKADAHAEQACABABACQAEACAEAEQABACACACQABABABABQAEAGABAGQABACAAACQAAAIgBAEQgBAFgEAEQgGAGgJADQAAAAgBABQAAAAAAAAQgJADgKgBQgIgBgIgCQgCgBgCAAQgBgBgBAAQgHgEgHgEQgDgCgCgBQgFgDgFgEQgBgBgBAAQgHgEgFgEQgCgBgBgBQgFgCgGgBQgDAAgDgCQAAAAgBAAAg4gCQAGgKAUgJQAagMALgBQATABAJAGQAUASACAJQABACAAADQAAAGgBAEQgFAMgNAFQgCABgBAAQgBABgCAAQgMADgPgFQgBAAAAAAQgCgBgBgBQgMgHgFgFQgCgBgBgBQgCgBgBgBQgIgGgIgFQgEgDgIAAQgEgBgDgB");
	this.shape_13.setTransform(493.5,186.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(147,154,101,0.662)").ss(0.7).p("Ag/gCQADgHAJgHQARgMAAAAQAIgFAKgCQALgEAJAAQAIAAAGABQAEAAAEACQAKADAHAEQABACACABQAEADADAEQACACABACQABABABACQAEAFABAHQABABAAADQAAAIgBAEQgCAGgDAEQgGAGgIAEQgBAAAAAAQgBABAAAAQgIAEgLgBQgIAAgIgCQgCgBgCAAQgBgBgBAAQgIgDgHgEQgEgCgCgBQgFgEgFgEQgBAAgBgBQgGgEgGgFQgBgBgCgBQgEgDgFgCQgDgBgDgBQAAAAAAgBAg2gCQAGgLASgJQAZgOALAAQATABAJAHQATATACAJQAAACAAADQAAAGgBAEQgEAMgMAGQgCABgBABQgBAAgCABQgMAEgOgFQgBAAgBAAQgBAAgCgBQgLgHgGgFQgCgCgBgBQgBgBgCgBQgHgGgHgFQgEgEgIgCQgDAAgDgB");
	this.shape_14.setTransform(493.8,186.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(129,135,88,0.579)").ss(0.7).p("Ag/gBQADgIAJgIQAQgNAAAAQAIgFAKgDQALgEAJAAQAJAAAGABQAEABAEABQAKADAHAFQACACABABQAEAEADAEQACACACACQAAACABABQAEAGABAHQABABAAADQAAAHgBAFQgCAGgDAFQgFAHgJAEQgBAAAAAAQAAAAAAABQgJAEgLAAQgIABgIgCQgCgBgDAAQgBgBgBAAQgIgDgIgEQgDgBgDgCQgFgEgFgEQgBAAgBgBQgGgEgFgFQgCgCgBgBQgEgEgFgCQgCgCgDgBQAAAAAAgBAg0gBQAGgMAQgKQAYgPAMgBQASABAJAIQARAUACAKQABABAAADQAAAHgBADQgEANgMAHQgBABgBABQgBABgCAAQgLAFgPgDQgBAAgBAAQgBgBgBgBQgMgGgGgGQgBgBgCgCQgBgBgBgBQgHgGgHgGQgDgEgHgDQgDgBgDgB");
	this.shape_15.setTransform(494.1,186.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(110,116,76,0.496)").ss(0.8).p("Ag+AAQACgJAIgJQAPgOAAAAQAIgGAKgDQAMgEAKgBQAJAAAGACQAEABAEABQALAEAHAFQABACACACQAEADADAFQABACACACQABACAAABQAEAGABAHQAAABAAADQABAIgCAFQgBAGgDAFQgFAIgJAFQAAAAgBAAQAAAAAAAAQgJAFgKABQgJABgIgBQgDgBgCAAQgBgBgBAAQgJgDgIgDQgEgCgCgCQgGgDgFgFQgBgBgBAAQgGgFgFgFQgBgCgBgBQgEgEgEgDQgDgDgCgCQAAAAAAAAAgxAAQAEgOAPgKQAXgRAMAAQASABAJAIQAQAVACALQAAABAAADQAAAGgBAEQgDAOgLAHQgBABgBABQgBABgCAAQgLAHgOgDQgBAAgBAAQgCgBgBAAQgLgGgHgHQgBgBgCgBQgBgBgBgBQgGgHgGgHQgEgEgFgEQgDgCgCAA");
	this.shape_16.setTransform(494.4,186.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(92,96,63,0.414)").ss(0.8).p("Ag+AAQABgKAIgJQAPgQAAAAQAIgGAKgDQALgFALAAQAJAAAHACQAEABAEABQALAFAHAFQACACABACQAEAEADAEQACACABADQABACABABQADAGABAIQAAABAAADQAAAHgBAGQgBAGgDAGQgFAIgIAFQgBAAAAABQgBAAAAAAQgIAGgLABQgIABgKgBQgCAAgDAAQgBgBAAAAQgKgCgJgEQgEgCgCgCQgGgDgFgFQgBgBgBAAQgFgFgFgGQgBgCgCgCQgDgEgEgEQgCgDgBgDQgBAAAAAAAgvAAQAEgPANgLQAVgSANAAQARABAJAJQAQAWACALQAAABAAADQAAAGgBAEQgDAPgKAIQgBABgBABQgBABgBABQgLAHgOgCQgCAAgBAAQgBgBgBAAQgMgFgHgIQgBgBgBgBQgBgBgCgBQgGgHgFgHQgDgFgFgFQgCgCgCgB");
	this.shape_17.setTransform(494.7,186.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(73,77,51,0.331)").ss(0.9).p("Ag+AAQABgKAHgKQAOgRABAAQAHgHALgDQALgFAMAAQAJAAAHACQAEAAAFACQALAFAHAGQABACACACQADAEADAFQACACABADQABABABACQADAGAAAIQABACAAACQAAAIgBAFQgBAHgDAGQgFAIgIAHQAAAAgBAAQAAABgBAAQgIAGgLACQgIABgKAAQgCAAgDgBQgBAAAAAAQgLgCgJgEQgEgCgDgBQgGgEgFgGQgBAAgBgBQgFgFgFgHQgBgBgBgCQgDgFgDgEQgCgDgBgFQgBAAAAAAAgsAAQACgPAMgMQAUgTANgBQARABAJALQAPAWABAMQAAABAAADQAAAFAAAFQgDAPgJAIQgBACgBABQgBABgBABQgLAIgOgBQgBAAgBAAQgCAAAAgBQgMgEgIgIQgBgCgBgBQgBgBgBgBQgGgIgEgHQgDgFgEgFQgCgDgBgC");
	this.shape_18.setTransform(495,186.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(55,58,38,0.248)").ss(0.9).p("Ag+AAQABgLAGgKQAOgSAAgBQAIgHALgEQALgEAMgBQAKABAHABQAFABAEACQALAFAHAHQACACABACQAEAEADAFQABADACADQAAABABACQACAGABAIQABADAAACQAAAHgBAGQgBAHgDAGQgFAJgIAHQAAAAgBABQAAAAAAAAQgJAHgLADQgIACgKAAQgDgBgDAAQAAAAAAAAQgMgCgKgEQgEgBgDgCQgGgEgFgGQgBAAAAgBQgGgFgEgIQgBgCgBgCQgDgFgDgEQgBgEgBgFQAAgBgBAAAgqAAQACgQAKgMQATgVANAAQARAAAJAMQAOAXABAMQAAACAAACQAAAGgBAEQgCAPgIAKQgBACgBABQgBABgBABQgKAKgOgBQgCAAgBAAQgBAAAAgBQgNgDgHgJQgCgCgBgCQgBgBgBgBQgFgHgEgIQgCgFgDgGQgCgDgBgD");
	this.shape_19.setTransform(495.4,186.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(37,39,25,0.165)").ss(0.9).p("Ag9AAQAAgLAFgLQANgUABAAQAHgIALgEQAMgFANAAQAKAAAHACQAFABAEACQAMAGAHAHQABACACACQADAEADAGQABACACADQABACAAACQACAGABAIQAAAEAAABQABAHgCAHQgBAHgCAGQgFAKgHAHQgBABAAAAQgBABAAAAQgIAHgLAEQgJACgKAAQgDAAgDAAQAAAAgBgBQgMgBgKgEQgEgBgDgCQgHgEgFgGQgBgBAAAAQgGgGgEgIQgBgCgBgCQgCgGgCgFQgCgEAAgGQAAgBAAAAAgoAAQACgRAIgNQASgWANAAQARAAAJANQANAYAAAMQAAADAAABQAAAGAAAEQgCAQgHALQgBABgBACQgBABgBABQgKALgOAAQgBAAgCAAQAAAAAAgBQgNgCgIgKQgCgCgBgCQgBgBAAgBQgFgHgDgJQgDgGgCgGQgBgDgBgE");
	this.shape_20.setTransform(495.7,187);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(18,19,13,0.083)").ss().p("Ag9AAQgBgMAFgLQANgVAAgBQAIgIALgEQAMgFANgBQALABAHACQAFABAEACQANAGAHAHQABADACACQADAFACAFQACADABADQABACAAACQACAGABAIQAAAEAAABQAAAIgBAGQgBAIgCAHQgFAKgHAIQAAAAgBABQAAAAgBAAQgIAIgLAEQgJADgKABQgDgBgDAAQAAAAgBAAQgNgBgKgEQgFgBgDgCQgHgEgFgHQgBAAAAgBQgFgGgEgIQgBgDgBgCQgCgGgBgFQgCgFAAgGQAAgBAAgBAglAAQAAgSAHgNQAQgYAOAAQARAAAJAOQAMAZAAANQAAACAAABQAAAGgBAFQgBAQgGALQgBACgBACQgBABgBABQgJAMgOABQgBAAgCAAQAAAAgBgBQgNgCgIgKQgCgCgBgCQAAgBgBgBQgEgIgDgJQgCgGgBgHQgBgEAAgE");
	this.shape_21.setTransform(496,187.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(181,218,164,0.447)").s().p("AAAhCQgOAAgMAFQgMAGgIAIQgHALgEALQgFAMABANQAAAOAEAMQAEAOAHAIQAJAKALAEQAMAFAOAAQAOAAALgEQAMgFAIgIQAIgJAFgMQAEgOAAgPQAAgMgDgNQgFgLgHgKQgIgJgLgGQgMgFgQAAIAAAAAAagrQAKAQAAAbQAAAagJARQgKARgRAAQgQAAgJgRQgKgRAAgaQAAgbAKgQQAKgPAPAAQAQAAAKAPIAAAA").cp();
	this.shape_22.setTransform(496.3,187.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10}]}).to({state:[{t:this.shape_11}]},46).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).wait(15));

	// 8
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#DDEFB7").ss(0.7).p("AgxgFQAKAAAGACQANADAMAHQAFADAPALQASAJARgCQARgCAFgLQADgIgDgHQgDgHgJgIQgOgLgUgBQgUgCgcAKQgZAIgJAGIAKAA").cp();
	this.shape_23.setTransform(492,243);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(201,217,166,0.91)").ss(0.6).p("Ag7gBQAFgEAIgFQAAAAgBAAIgBAAQgJAEgEAFQAFABAEAAQAIAAAFABQACAAABABQALADAKAFQABAAAAABQgCgCgDgCQgIgEgIgDQgFAAgKgBQgEAAgEAAIgBAAAgwgKQAAAAgBAAQgEABgEgBIgBAAQAIgHAWgHQASgHANgBQADAAADAAQACgBACAAQABAAACAAQAJAAAJACQALADAIAHQAKAIADAJQACAHgDAHQAAAAAAAAIAAABQAAAEgBADQgEAJgMADQgVAEgRgHQAAgBgBAAQgOgKgGgEQgBgBgCAAQADABADABQAFACAJAFQAEACAEACQAHACAFABQAIAAAGAAQACgBADgBQAFgBAEgDQAHgEAEgGQAAAAAAAAQAAgBAAAAQAAgDAAgCQAAACgCADQgCAGgIAEQgTAEgJgBQgIgCgHgEQgPgKgFgEQgGgDgFgBQgGgEgHgCQgEgCgIgBQAFgCAGgCQASgGAJgDQAPgDAMACQANABAKAFQAMAIACACQAGAGACAEQABACAAABQABgFgCgEQgDgIgJgIQgGgFgIgDQgHgEgWAAQgJACgQAHQgGACgHAEQgKADgIAE");
	this.shape_24.setTransform(491.8,243.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(181,195,149,0.819)").ss(0.6).p("Ag+AEQAEgEAJgDQgIgBAAAAQAEgEAIgEQAEgEAKgFQAGgDAFgDQAKgEAKgCQACgBACAAQADgBACAAQABAAACgBQAFAAAFABQAFAAAEABQAJACAHAFQACACADACQAGAGADAGQACAEABAEQABADgBACQgBAFgCAEQAAAEgCADQAAABAAAAQgBAIgIAEQgBABgBAAQgGACgHACQgLACgLgDQgBgBAAAAQgPgIgIgDQAAAAgBAAQgBgBgBAAQAAgBgBAAQgLgEgKgEQgBAAgBgBQgBAAgCgBQgFgDgHgBQgEgBgDgCAg5gBQAHgIAVgIQARgGAMgCQABADgOAHQgFACgFAEQgJAEgIAEQAAABgBAAQgBABgDAAQgFAAgFgBQgBAAgBgBAgtgKQAEgDAGgCQAWgJAEgBQAJgCAIAAQAVACAKAFQAMAIACADQAEAEACAFQACACAAACQgBACgBACQgCAGgHAEQgCABgCAAQgPAEgIAAQAAAAgBAAQgHgCgHgEQgOgKgGgDQgCgCgDgBQgCgBgDgBQgGgDgGgDQgFgCgGgBAgQAIQABAAABABQAQAHAEACQAHADAGABQAMACAMgBQANgCAEgGQABgDAAgDQgDAFgFAEQgBABgCABQgDADgGACQgCABgDAAQgGAAgHAAQgGgBgGgCQgFgCgEgCQAAgBgBAAQgHgFgFgCQgCgCgCgBAAEgeQACgCACAAQAQgBAEAAQAGABAFADQAFACAEADQAFAEAEAFQADAEACAFQABAGgBADQgBADgBgCQABgDgBgBQAAgBgBgBQgCgEgEgFQgDgCgDgDQgHgFgIgDQgDgCgGgBQgHgCgMgB");
	this.shape_25.setTransform(491.5,243);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(161,174,133,0.728)").ss(0.7).p("Ag+AKQADgGAJgEQgGgBAAAAQAEgEAJgEQACgFAIgFQAEgEAFgEQAJgGAKgEQAEAAABgBQADgBACAAQACAAACgBQAFAAAGAAQAFAAAFACQAJACAHAFQADACACACQAGAHADAHQACAEABAEQAAAEgBACQgBAFgDAEQgBAEgCADQAAABAAAAQABAIgGAEQgBABgBABQgEADgGADQgKAEgMgBQgBAAAAgBQgPgFgKgDQAAAAgBAAQgBgBgBAAQgBAAAAAAQgMgEgLgFQgBgBgBAAQgCgBgBgBQgGgDgGgDQgDgBgDgCAg3ADQAGgGATgIQAQgHAOgDQACAFgLAHQgEACgEAEQgIADgGAEQAAADgCACQgDACgEAAQgGABgGgDQgCgCgBgEAgsgNQAEgDAFgDQAVgJAEgBQAKgDAHAAQAVADAJAFQALAIACADQAEAEACAGQABADAAAAQAAACgBACQgCAHgHADQgBABgCABQgOAEgIABQAAAAgBAAQgHgCgHgEQgNgJgGgEQgDgCgCAAQgDgBgDgCQgFgDgGgDQgEgCgGgCAgSADQABAAABAAQAQAEADACQAHACAGABQANACAMAAQAMAAADgFQACgCgBgCQgCAGgFAEQgBABgCABQgDADgFACQgDABgCABQgGAAgIgBQgFgCgGgBQgFgDgEgCQAAAAAAgBQgJgEgEgEQgCgCgCgBAAAgfQACgCABAAQAQgEAEABQAGAAAFACQAGACAEAEQAFADAEAFQADAEACAFQACAGgBAFQgCADAAgCQAAgBgBgBQAAgBgBgBQgCgDgFgDQgDgCgDgDQgHgFgIgDQgEgCgFgBQgIgDgKgD");
	this.shape_26.setTransform(491.1,243);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(141,152,116,0.637)").ss(0.7).p("Ag9APQADgGAIgGQgEgDAAAAQAFgDAJgEQAAgFAGgGQADgGAEgEQAIgIALgFQAEgBADAAQABgCACAAQACgBADAAQAFgBAGABQAGAAAFABQAJADAIAFQADACACADQAHAHACAIQACAEAAAEQAAAFgBADQgCAEgDAEQgCAEgCADQAAABAAAAQAEAIgFAFQAAABgBABQgEAEgEAEQgJAGgNABQAAAAgBAAQgQgDgKgCQgBgBgBAAQgBAAgBgBQgBAAgBAAQgNgDgLgGQgBgBgBAAQgCgBgBgBQgGgEgGgDQgDgCgDgDAg0AJQAFgJASgGQAOgIAOgDQAGAHgJAGQgCADgEACQgGAEgGAGQAAAEgDADQgDADgGAAQgIAAgGgDQgDgEgBgFAgpgRQADgDAFgDQATgKAEgBQAKgDAHAAQAUADAIAFQALAHACAEQAEAFACAFQABAEAAABQgBADgBAAQgBAGgGAEQgCABgBABQgNAFgIABQAAAAgBAAQgHgCgGgEQgOgJgGgDQgCAAgDgCQgCgCgDgBQgFgEgFgCQgEgDgFgDAgTgBQABAAABAAQARABACAAQAHAAAGABQANACALABQAMABADgCQABgBAAgCQgDAGgEAFQgCABgBABQgDADgFACQgCACgDABQgGgBgHgBQgGgCgGgBQgFgDgCgCQgBgBAAAAQgJgFgFgEQgBgBgCgBAgBggQABgCAAgBQAPgFAEAAQAGAAAGACQAFABAEADQAGAEADAEQAEAFACAFQACAGgBAGQgBAEgBAAQAAgBgBgCQAAAAgBgBQgCgCgGgCQgDgCgDgDQgIgFgHgDQgEgCgFgBQgIgEgHgE");
	this.shape_27.setTransform(490.6,243.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(121,130,100,0.546)").ss(0.8).p("Ag9AUQADgHAIgHQgCgEAAAAQAGgDAJgEQgCgGAEgGQABgHAEgFQAGgKAMgGQAEgBAEgBQADgBABgBQACgBACAAQAGgBAGAAQAGABAGABQAKACAHAGQAEADACADQAHAHACAJQACAEgBAFQAAAEgCAFQgBADgEAEQgDAFgDACQABABAAABQAGAIgDAFQAAABgBABQgCAFgEAFQgHAJgOADQAAAAgBgBQgQgBgMgBQgBgBgBAAQgCAAgBAAQgBAAAAAAQgPgEgMgGQgBgBgBgBQgBAAgCgCQgGgEgFgEQgDgDgCgDAgxAPQAEgKAQgGQANgIAOgEQAKAIgIAFQAAACgDAFQgFAEgEAGQAAAGgFAEQgEAEgHAAQgKAAgGgFQgFgEAAgHAgngUQADgDAEgEQASgLAEgBQAJgDAHAAQAUADAIAFQAKAHACAFQAEAEABAGQABADAAACQAAACgBADQgCAEgFADQgBABgCABQgLAGgIACQgBAAAAAAQgHgCgGgDQgNgJgGgCQgDgCgDgBQgCgCgCgCQgFgDgFgDQgEgDgEgDAgUgHQABAAABAAQAQgDACABQAHABAGAAQANACAMACQALADACgBQABAAAAgBQgCAFgEAFQgCABgBACQgDADgFACQgCABgDABQgGAAgHgCQgGgCgGgBQgEgDgCgCQgCgBAAgBQgJgFgEgCQgCgDgBgCAgFgiQABgCACgBQANgHAEgBQAGAAAGACQAFABAFADQAFADAEAFQAEAEACAFQACAHgBAGQgBAFAAAAQgBAAgBgBQAAAAgBAAQgDgBgFgBQgEgCgDgCQgIgFgIgEQgEgCgFgCQgIgEgGgG");
	this.shape_28.setTransform(490.2,243.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(101,109,83,0.455)").ss(0.8).p("Ag8AZQACgIAIgHQAAgGAAAAQAGgEAKgDQgEgHACgHQAAgHADgHQAFgLAMgHQAFgCADgBQAEgCADgBQABAAACgBQAGgBAHABQAGAAAGABQAKADAIAGQAEADADADQAGAIACAJQABAFAAAFQgBAFgCAEQgCAEgFAEQgDAEgDADQABABAAAAQAIAIgBAHQAAABAAABQgBAGgDAGQgHALgOAFQAAAAgBAAQgQABgOgBQgBgBgCAAQgBAAgBAAQgBAAgBAAQgQgDgMgIQgBAAgBgBQgCgBgBgBQgGgFgFgGQgDgDgCgDAguAUQADgKAOgJQAMgGANgEQAOAJgGAEQAAADgBAFQgDAFgDAGQAAAHgFAFQgFAFgKAAQgKAAgIgGQgFgFAAgJAglgYQADgEADgDQARgMAEgBQAJgEAHABQATACAIAGQAJAHACAFQAEAFABAFQAAAEAAABQAAADgBACQgBAGgFABQgBACgBABQgKAGgJACQAAABgBAAQgGgCgGgEQgNgGgGgEQgDgBgCgCQgDgCgCgBQgEgEgFgDQgDgEgEgDAgVgNQABAAABAAQAPgHAEAAQAFAAAHABQANABALAEQALAEACACQABAAgBAAQgCAHgEADQgBACgBABQgDAEgFACQgCABgDACQgGgBgHgCQgFgCgGgCQgEgCgDgDQgBgBgBgBQgJgDgDgFQgCgDgBgCAgIgjQABgDABgCQANgJAEAAQAGgBAGABQAGACAEACQAGADAEAFQAEAFACAFQACAGgBAHQgBAGAAAAQAAABgCAAQAAAAgBABQgDAAgGAAQgEgCgDgDQgIgEgIgEQgEgCgFgCQgHgFgGgH");
	this.shape_29.setTransform(489.7,243.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(80,87,66,0.364)").ss(0.8).p("Ag7AcQABgIAHgIQADgGAAgBQAGgFALgCQgHgHAAgIQgBgIACgIQAFgMANgJQAEgCAEgCQAEgCADgBQADAAABgBQAGgBAHAAQAHAAAGACQALADAIAGQAEADADADQAGAJACAKQABAFgBAFQgBAFgCAFQgDAGgFACQgEAEgEADQABABABAAQAJAIACAHQAAACAAABQABAGgDAJQgFAMgPAHQgBAAAAAAQgRAEgQgBQgBAAgBAAQgCgBgBAAQgBAAgBAAQgRgCgNgJQgBgBgBAAQgCgCgBgBQgGgGgFgGQgCgDgCgFAgsAYQADgKAMgJQALgGANgFQARAIgDAGQAAAEABAEQgDAFgDAHQAAAIgEAGQgGAHgLgBQgMABgIgHQgHgHAAgLAgjgdQACgEADgDQAQgNAEgBQAIgEAHAAQATADAIAGQAIAHACAFQADAFABAGQABADAAACQgBACAAACQgCAGgEAEQgBABgBACQgJAEgIADQgBABAAAAQgHgCgGgEQgLgFgHgEQgDgCgCgCQgCgBgDgCQgEgEgDgDQgDgEgEgEAgWgUQABAAAAgBQAPgKAEAAQAGgBAGABQAOABAKAFQAKAFACAEQABACgBAAQgBAIgEAFQgBABgBAAQgDAEgFACQgCACgDABQgGgBgHgCQgFgCgGgCQgDgCgEgBQgBgBgCgBQgHgFgEgGQgBgDgBgDAgMgmQABgDABgCQAMgLAFgBQAFgBAHABQAGABAFADQAGADAEAFQAEAEABAFQADAGgBAIQgBAHAAAAQAAACgCABQgBABAAAAQgDACgHABQgEgCgEgDQgIgEgHgEQgFgCgFgDQgGgGgGgI");
	this.shape_30.setTransform(489.2,243.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(60,65,50,0.273)").ss(0.9).p("Ag7AgQACgJAGgJQAFgHAAgBQAHgFALgDQgJgHgCgIQgDgKACgIQADgPAOgJQAFgDADgCQAFgCAEgBQACgBADAAQAEgCAIAAQAHABAHABQALADAJAGQAEAEADAEQAGAIABALQABAGgBAFQgBAFgDAFQgDAGgGAFQgEACgFADQACAAABABQALAIADAIQABABABACQACAHgDAJQgEAPgPAJQgBAAAAAAQgRAGgSAAQgBgBgBAAQgCAAgCAAQAAAAgBAAQgTgCgNgJQgBgBgBgBQgCgBgCgCQgGgGgEgHQgCgEgBgFAgpAdQACgLALgKQAJgIANgDQAVAJgBAFQABAFACAFQgBAFgDAHQAAAKgHAHQgGAHgLAAQgOAAgIgIQgIgIAAgMAgggiQABgEADgDQAOgOAEgCQAIgEAHABQASACAIAGQAHAHACAGQADAFAAAGQABADAAACQAAACgBADQgBAFgDAEQgBABgCACQgHAGgJADQAAAAgBABQgGgDgGgBQgLgHgHgEQgDgCgCgCQgCgBgCgCQgEgEgDgDQgDgFgCgEAgXgbQABgBAAAAQAOgOAFAAQAFgCAHABQANABAKAFQAKAHACAGQAAADAAABQgCAIgDAFQgBADgCABQgCADgFABQgCACgDACQgGgCgGgCQgGgBgGgCQgDgCgEgDQgBgBgCgBQgHgFgDgHQgCgDAAgDAgPgpQAAgDABgCQAOgNACgBQAGgCAHABQAGABAFACQAGADAFAFQADAEACAFQADAHgBAHQAAAIgBABQAAADgCACQgBABgBABQgDADgGACQgFgDgEgCQgIgEgIgEQgFgDgCgCQgJgHgEgK");
	this.shape_31.setTransform(488.8,243.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(40,43,33,0.182)").ss(0.9).p("Ag6AkQABgLAGgIQAGgJABgBQAHgFAMgDQgLgIgEgJQgFgKACgKQACgQAOgLQAFgDAEgCQAEgCAFgCQACAAADgBQAFgBAIAAQAIAAAHACQAMACAJAHQAEAEADAEQAGAJABAMQABAGgBAFQgCAGgDAFQgEAGgGAFQgFADgFACQABAAABABQAOAIAFAIQABACABACQADAIgBAKQgDARgQALQgBAAgBAAQgQAIgWAAQAAAAgBAAQgCAAgBAAQgBAAgBAAQgUgCgOgKQgBgBgBgBQgCgBgBgCQgHgGgDgIQgCgFgBgFAgnAhQACgLAJgKQAIgJAMgEQAZALABAFQADAFADAFQAAAFgCAHQAAAMgIAIQgIAIgMAAQgPAAgJgJQgJgJAAgOAgegnQABgEACgEQANgOAEgCQAHgEAHAAQASADAHAGQAHAHACAGQACAFABAGQAAADAAACQAAACgBADQgBAFgCAEQgBACgBABQgGAIgJAEQgBAAAAAAQgGgBgGgDQgLgGgHgFQgDgCgCgCQgCgBgCgCQgDgEgDgEQgCgEgCgFAgYgiQAAgBABgBQANgRAFgBQAFgCAHABQAOAAAJAHQAKAIABAJQAAADAAACQgCAJgDAFQgBACgBACQgDAEgEACQgCACgDAAQgGAAgGgCQgGgDgEgCQgFgDgEgCQgBgBgCgCQgHgFgDgIQgBgDgBgDAgTgrQABgEABgDQANgOAEgCQAEgCAHABQAHAAAEADQAHACAEAFQAEAEACAGQADAGgBAIQAAAIgBACQAAADgCAEQgBABgBABQgDAEgHADQgFgCgEgCQgJgEgHgEQgEgDgEgDQgJgHgDgL");
	this.shape_32.setTransform(488.3,243.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(20,22,17,0.091)").ss().p("Ag8AnQABgLAGgJQAJgKAAgBQAIgFAMgEQgNgIgGgJQgGgMABgKQABgSAPgMQAFgEAEgCQAFgCAEgCQADgBADAAQAHgCAHAAQAIAAAHACQAMADAKAHQAEAEADAEQAHAKAAAMQABAHgCAFQgCAGgEAFQgDAHgHAFQgGAEgFACQABAAACAAQAQAIAGAJQABABACACQAEAJAAAMQgCATgRANQAAAAgBAAQgQALgYAAQgBAAgBAAQgCAAgBAAQgBAAgBAAQgWgBgOgLQgBgBgBgBQgCgCgBgCQgHgHgDgJQgCgFAAgGAgmAlQABgMAHgKQAHgJAMgGQAdAOAEAFQAEAFADAFQACAGgBAHQAAANgJAJQgJAKgOgBQgQAAgKgKQgKgKAAgQAgegsQABgEABgEQAMgQAEgCQAHgEAHABQASACAGAGQAGAHACAHQACAFABAGQAAADAAACQAAACgBADQgBAFgCAEQAAACgBACQgFAIgJAFQgBAAAAABQgGgDgFgCQgLgGgHgFQgDgCgDgCQgBgBgCgCQgDgEgCgEQgDgFgBgFAgbgqQABgBAAAAQANgVAEgBQAIgDAFAAQAOABAJAHQAJAKABALQAAAEgBADQgBAJgDAFQgBADgBACQgCAEgEACQgDACgDACQgGgCgGgCQgGgDgDgDQgFgCgEgDQgCgBgBgCQgHgFgDgIQgBgEAAgEAgYguQAAgEABgDQANgRAEgCQAGgCAGAAQAGABAFACQAGACAFAFQAEAEACAGQADAGAAAIQgBAKAAACQgBAEgCAEQgBACgBACQgEAFgHAEQgFgCgEgCQgJgEgFgEQgGgEgEgDQgJgIgCgM");
	this.shape_33.setTransform(488,244);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(116,192,86,0.298)").s().p("AgegxQAAgNAKgJQAIgKAMABQAPAAAIAJQAJAKAAAPQAAANgEAKQgDAJgKAGQgYgKgLgJQgJgJgBgNIAAAAAg2grQAAANAIALQAHAKAQAJQgSAFgLALQgIALgBAPQAAAVAQAPQARANAbAAQAbAAASgPQARgPABgUQAAgRgJgKQgKgLgUgGQARgHAHgMQAJgLgBgMQAAgUgOgNQgPgMgYAAQgVAAgSANQgRAOAAAUIAAAAAglApQAAgMAFgLQAHgJALgHIAVALQALAEAHAFIAJALQADAGAAAIQAAAOgKAKQgJALgSgBQgQAAgKgLQgLgLAAgSIAAAA").cp();
	this.shape_34.setTransform(487.8,244.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23}]}).to({state:[{t:this.shape_24}]},40).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).wait(22));

	// 9
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#D8DFB4").ss(0.7).p("AAXgbQgUgCgcAKQgZAIgJAGIAKAAQAKAAAGACQANADAMAHQAFADAPALQASAJARgCQARgCAFgLQADgIgDgHQgDgHgJgIQgOgLgUgBIAAAA").cp();
	this.shape_35.setTransform(536,301);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(196,203,164,0.91)").ss(0.6).p("ABBgHQAAACAAABIAAAAQAAgBAAgCIABgCQgDgLgJgIQgOgMgUgBQAAAAgBAAQgBAAAAAAIgJAAQgFAAgEABQAGAAAGAAQAIABAGACQAGABAFADQAKAEAHAHQABACABABQAFAGADAGQAAABABACQgBACgBACQABgCABgCQAAABAAABQABAFgCAHQgGAJgKAEQgCAAgDAAQgCABgCAAQgIABgKgGQgEgCgEgDQgGgGgEgEQAAAAgBgBQgFgCgDgBQgFgBgFgCQgJgEgJgDQgCgBgCgBQgEgBgFgBQgCAAgBAAQgFgBgEgBIAAAAQAGgHAQgGQASgHAGgBQAHgCAGgBQAEgBAFAAAA/AAIgPAPQgBABgCAAQgPACgQgIQgGgEgFgCAAAgoQAAABAAgBQgEABgEABQAFgBADgBIAAAAAgygOQgDgBgEgBQAIgIAYgIQABgBABAAIAPgFAACADQgEgDgEAAQgLgHgNgEQgHgBgKgC");
	this.shape_36.setTransform(536,302);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("rgba(180,186,150,0.834)").ss(0.6).p("Ag9gNQAFgIAOgHQARgHAIgCQANgCAEAAQAJAAACAAQAFAAAEABQACAAAAAAQAHACAGADQAJAEAGAHQABABABABQAFAHADAHQAAADABADQAAABgBABQgBABAAACQAAABAAABQAAABAAABQgBAGgDAFQgCADgDACQgDADgDABQgBABgBABQAAAAgBAAQgCAAgCAAQgBAAgCABQgEgBgFgDQgDgBgCgCQgDgDgEgDQgEgEgCgFQgCgBgBgBQgBAAAAAAQgEgCgEAAQAAgBgBAAQgFgCgGgCQgKgBgJgFQgBAAgCgBQAAAAgBAAQgEgCgFgBQgCgBgBAAQgFgBgDgCQAAAAgBAAAgvgMQAEAAAEAAQALACAGACQAEABADABQAEACADACQACABACABQADAAAFAEQgDgBgBAAQAAAAgBgBQgCAAgBAAQgDgCgEAAQgEAAgEgCQgGgBgGgDQgBAAgBgBQgHgCgHgDAgEgjQABgDADgBQAEgBACABQACABACACQAAAAAAABQAAAAAAAAQAAABAAAAQgBABgCAAQgBAAgCAAQgCAAgCAAQAAgBgDAAQAAgBgBAAAgDgjQADgCAEgBQAKgCABAAQABAAABAAQAKAAAJAEQAHACAHAGQABABABACQAIAIACAJQAAACgBABQAAACAAABQAAAAAAgBQgBgBAAAAQAAgBgBgCQgBAAAAgBQgBAAAAgBQgCgCgDgCQgBgBgBgCQgBgBgBAAQgEgDgGgDQgDgBgDgCQgGgCgGgCQgBgBgBAAQgFgCgGgBQgGgBgDAAAAAAEQACABAGADQAVAFAKgCQADAAACAAQAEgEAEgDQAEgDADgBQACgCAAABQABAEgBAGQgBABAAABQgBACgBACQgBABgBABQgBABAAAAQgFAFgGACQAAAAAAAAQgCABgDAAQgCAAgCABQAAAAgBAAQgIAAgKgGQAAAAAAAAQgEgCgEgDQgGgHgCgF");
	this.shape_37.setTransform(536.1,301.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("rgba(163,169,137,0.758)").ss(0.7).p("Ag8gMQAFgKAOgIQARgIAJgCQAPgCAFACQAJAAACABQAEABAFACQACAAAAABQAGACAGAEQAIAFAFAJQABABABABQAEAIABAFQAAAEAAAEQgBABgBABQAAACgBACQAAABAAABQgBABAAABQgCAGgEAFQgDADgDACQgCACgDAAQgBABAAABQAAAAgBAAQgBAAgBgBQgBAAgBAAQgDAAgEgEQgCgCgCgCQgCgDgDgEQgDgFgDgEQgBgBgCgBQAAAAgBAAQgFgBgDgBQAAAAgBAAQgGgCgGgBQgLgDgKgDQgBgBgBgBQgBAAgBAAQgEgCgFgCQgBgBgBgBQgFgBgDgDQAAAAgBAAAgtgLQAEgCAEgBQALAAAIACQAEAAADACQAEACAEADQACABABABQACADAGADQgCAAgCAAQgBAAgBABQgCAAAAgBQgDAAgEgBQgFAAgEgCQgGAAgGgCQgCgBgBgBQgHgDgHgEAgFghQABgEADgCQAIgDACADQADACABAEQAAABAAABQAAAAAAABQAAABAAAAQgBACgCAAQgCABgDAAQgDAAgCgCQgCgBgCgCQgBgBAAgBAgFghQAFgCACgBQAKgDAAgBQABAAABAAQAKgBAKADQAIACAGAGQACACABABQAIAJACALQAAABgBABQAAACAAACQAAAAAAgBQgBAAAAgBQAAgBgBAAQgBgBAAAAQgBgBAAAAQgCgCgDgBQgBgBgCgBQgBgBgBgBQgEgCgGgCQgDgCgEgBQgGgDgGgCQAAgBgBAAQgFgCgHgCQgEgCgEgBAgCADQACAAAGACQAUACALgCQADAAACAAQAFgDAEgCQAEgBADgBQACgBAAABQABAEgBAHQgBABAAABQgBACgBACQgBABgBABQAAABgBAAQgEAGgHACQAAAAAAAAQgDABgDAAQgCAAgCABQAAAAgBAAQgJAAgKgHQAAAAAAAAQgDgCgEgDQgGgHgCgG");
	this.shape_38.setTransform(536,301.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("rgba(147,152,123,0.682)").ss(0.7).p("Ag6gMQAEgLAOgJQASgJAKgCQAOgBAHACQAKACACABQAEACAEACQACABABAAQAFADAFAFQAIAIADAJQABACABABQADAGAAAIQgBAEgBAEQAAACgBABQgBACgBABQAAABgBABQAAABgBABQgDAGgEAFQgEADgEACQgCABgDAAQAAABAAAAQABAAAAAAQAAAAgBgBQgBAAAAAAQgCgBgDgFQgBgCgBgDQgCgDgDgEQgCgFgCgFQgCgBgBgBQgBAAAAABQgGgBgEAAQAAAAAAgBQgGgBgHgBQgLgDgLgGQgBAAgCgBQAAAAgBAAQgEgBgFgDQgBgBgCAAQgEgDgDgDQAAAAAAgBAgqgLQADgDAEgCQAMgDAIACQAEABAEACQAEACADADQABABACACQADAEAGAEQgCAAgCABQgBABgBAAQgBABgBAAQgEABgDgBQgFAAgFgBQgHgCgGgCQgBAAgCgBQgHgEgGgGAgHgeQABgGAEgEQALgDADAEQADADACAGQAAABAAABQAAABAAACQAAAAAAABQgCACgDABQgDABgDAAQgFAAgBgDQgDgCgDgDQAAgBgBgBAgGgeQAEgDACgCQAJgFABAAQABAAABgBQAKgCAKADQAIACAHAGQACACABACQAHAJACAMQAAABAAABQAAACAAACQAAAAAAAAQgBgBAAAAQAAAAgBgBQgBAAAAAAQAAAAgBAAQgCgBgDgBQgBgBgCgBQgBAAgBgBQgFgCgGgCQgEgBgDgCQgGgCgGgDQgBgBgBAAQgFgCgGgDQgDgCgEgCAgDABQADAAADAAQAVgBAKAAQAFAAABAAQAFgCAFgBQAEgBADgBQACABAAABQABAEgBAHQgBABAAABQgBADgBACQgBABgBABQAAABAAAAQgFAGgHACQAAAAAAAAQgDABgDAAQgCABgDAAQAAAAAAAAQgLABgJgIQAAAAAAAAQgEgCgEgEQgDgHgDgG");
	this.shape_39.setTransform(535.8,301.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("rgba(131,135,109,0.607)").ss(0.7).p("Ag5gNQADgNAPgKQASgKAMgCQAPAAAIACQAKADACACQAEACAEAEQACABAAAAQAGAEAEAGQAHAJACAKQABACAAACQACAHgBAIQgBAFgCAEQgBABgBABQgBACgBACQgBABAAABQgBABgBABQgDAGgGAFQgEADgEACQgDAAgCgBQAAABABAAQABAAAAAAQABgBgBgBQABAAgBAAQAAgCgCgFQAAgDgBgDQgBgEgCgEQgCgGgBgFQgCgBgCAAQAAAAgBAAQgGABgFAAQgBgBAAAAQgFAAgHgCQgMgCgLgHQgBAAgCgBQgBgBAAAAQgFgBgEgDQgCgBgBgBQgEgDgDgEQAAgBAAAAAgogNQADgEAEgDQANgFAIABQAFABAEACQADADAEADQABACACACQAEAFAFAGQgCAAgBABQgBABgBABQgCABAAAAQgEACgFAAQgEAAgGgBQgHgBgGgEQgCAAgCAAQgHgFgGgIAgIgeQABgIAEgFQAOgEAEAGQAEAEABAIQAAACAAABQAAACAAABQAAABAAABQgCADgEABQgDACgEgBQgGAAgCgDQgEgDgCgFQgBgBAAgCAgIgeQAEgDADgDQAIgGAAAAQABgBABAAQAKgEALADQAJACAHAHQABABACACQAHAKACANQAAABAAACQAAACAAACQAAAAAAAAQgBgBAAAAQAAAAgBAAQAAAAgBABQAAAAgBAAQgCgBgDgBQgCAAgBAAQgBgBgBAAQgGgBgGgDQgEgBgEgBQgGgDgGgDQgBgBgBAAQgFgDgFgDQgDgDgEgDAgFAAQADgCADAAQAUgFALgBQAFAAACABQAFgCAFAAQADAAAEAAQACABAAACQABAGgBAGQgBABAAABQgBACgBACQAAACgBABQgBABAAABQgFAFgHADQAAAAAAAAQgDABgEAAQgCABgCAAQgBAAAAAAQgLAAgKgHQAAgBAAAAQgDgCgEgEQgDgHgDgG");
	this.shape_40.setTransform(535.6,301.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("rgba(114,118,96,0.531)").ss(0.8).p("Ag4gPQADgPAPgLQATgLANgBQAQgBAIAEQAKAEACACQAFADAEAFQABABABAAQAFAFAEAGQAFALACAMQAAABAAABQABAKgDAIQgBAFgCAEQgBACgBABQgCACgCACQAAABgBABQgBABgBABQgFAGgGAFQgFACgFACQgCAAgCgCQABAAACABQABAAABgBQABAAAAgCQABAAAAgBQABgCgBgGQABgCAAgFQgBgDgCgFQAAgGgCgGQgCAAgBAAQgBAAgBAAQgFABgGAAQgBAAgBAAQgEAAgIgBQgNgCgMgIQgBgBgCgBQAAAAgBAAQgFgCgEgDQgBgBgCgCQgDgEgDgFQAAAAAAAAAgmgQQADgFAEgEQANgHAKABQAFAAADADQAEACAEAFQACACABACQAEAGAFAIQgCABgBACQgBAAgBABQgBACAAAAQgFADgGAAQgEABgGgBQgIgCgGgDQgCgBgCgBQgHgFgGgKAgKgfQABgJAFgGQARgGAFAHQAEAGACAKQAAACAAACQAAACAAACQAAAAgBABQgDAFgEABQgEACgEAAQgIAAgCgFQgFgEgCgFQgBgCAAgDAgJgfQADgEADgDQAHgHAAAAQABgBABgBQAKgEALACQAKACAHAHQACACABACQAIAKACAOQAAABgBACQAAACAAACQAAAAAAABQAAgBAAABQgBAAAAAAQgBABAAAAQAAAAgBAAQgCAAgDAAQgCAAgCAAQgBAAgBgBQgGAAgHgCQgEgBgEgBQgGgDgGgEQgBAAgBgBQgFgDgDgEQgEgEgEgEAgHgEQACgDAFgCQASgHALgBQAGAAACAAQAFgBAFACQAEAAADACQACACAAABQABAIgBAFQAAACAAABQgBACgBACQAAACgBABQAAABgBABQgFAGgHADQAAAAAAAAQgEABgEAAQgCABgCAAQgBAAAAAAQgMAAgKgIQAAAAAAgBQgDgDgCgDQgFgIgCgF");
	this.shape_41.setTransform(535.5,301.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("rgba(98,102,82,0.455)").ss(0.8).p("Ag4gSQACgQAQgMQATgMAPgBQARAAAJAEQAKAGACACQAFAEADAFQACACABAAQAEAGADAHQAFANAAAKQAAADAAACQAAAKgEAKQgCAEgDAFQgBABgBACQgCACgCABQAAACgCABQAAABgCABQgGAGgHAEQgFADgFACQgDgCgCgCQACAAACAAQACAAABAAQACgBABgCQABAAABgBQACgDABgGQABgDAAgFQAAgEgBgFQAAgGgBgHQgCAAgCAAQgBAAAAABQgGABgGABQgBAAgBAAQgFAAgIgBQgOgCgMgIQgCgBgBgBQgBAAgBgBQgEgCgFgDQgBgCgBgBQgEgFgCgGQAAAAAAAAAgkgSQACgHAEgFQAOgKAKABQAFABADADQAFACAEAFQACACACADQADAHAEAJQAAACgCADQAAABgBABQgBABgBAAQgFAEgGABQgGABgFgBQgIgBgHgEQgCgBgCgBQgIgGgEgLAgNgfQABgMAGgHQAUgGAGAIQAFAHABAMQAAACAAADQAAACAAACQAAABAAABQgEAGgFABQgEACgGAAQgHAAgFgGQgEgEgCgHQgBgCgBgDAgMgfQACgFAEgEQAGgIAAAAQABgBABgBQAKgGAMACQALABAHAIQABACACACQAHALACAPQAAABAAACQAAACAAADQAAAAAAAAQAAAAgBABQAAAAAAABQgBABAAABQAAAAAAAAQgDABgDAAQgCABgCgBQgCAAAAAAQgHAAgHgCQgEAAgEgCQgHgCgGgFQgBAAgBgBQgDgDgEgFQgEgEgDgFAgKgJQACgEAEgCQASgLAMgBQAGAAACABQAGAAAFACQAEACADADQACADAAABQABAIgBAHQAAAAgBABQAAADgBACQAAACgBABQAAABgBABQgFAGgHADQgBAAAAAAQgDACgEAAQgDAAgCABQAAAAgBAAQgNAAgJgJQAAAAAAgBQgCgDgDgEQgFgGgCgH");
	this.shape_42.setTransform(535.5,301.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("rgba(82,85,68,0.379)").ss(0.8).p("Ag5gUQADgSAQgNQATgNAQgBQATABAJAFQAKAGADADQAEAFAEAGQABACABAAQAEAHACAIQAFAOgCAMQAAACAAADQgBALgFAKQgDAFgEAFQgBABgBABQgCACgCACQgBABgCACQgBABgBABQgHAGgJAEQgFADgGABQgCgCgCgCQADgBACAAQACAAACgBQACgBACgBQABgBACgBQADgEACgHQACgDABgFQABgEgBgGQAAgHAAgHQgCAAgCABQgBAAAAAAQgHADgGABQgBAAgBAAQgGABgHgBQgQgCgMgJQgBgBgCgBQgBAAAAgBQgFgDgEgEQgCgBgBgCQgEgFgBgHQAAAAgBAAAgjgVQACgIAEgGQAOgMAKABQAFAAAEADQAGADAEAGQACACACADQADAIAEAKQgBACgBAEQAAACgBACQgBABAAAAQgFAFgHABQgHACgFgBQgJgBgHgFQgCgBgCgBQgJgHgDgNAgQggQABgNAGgIQAYgIAGAKQAGAJABAOQAAACAAACQAAADAAADQAAABAAABQgEAGgGADQgFACgGAAQgIAAgGgIQgFgFgDgIQAAgCgBgEAgPggQACgFADgFQAIgJAAAAQABgBABgBQAIgHANABQAKABAIAJQACACABACQAIALABAQQAAACAAABQAAADAAADQAAAAAAAAQAAAAAAABQAAABgBABQAAABAAABQgBABAAAAQgCABgEABQgCABgCAAQgBAAgBAAQgHAAgIgBQgEgBgEgBQgIgDgGgFQAAAAAAAAQgEgFgEgEQgEgGgDgGAgOgNQACgFAEgEQARgNANgBQAGAAADABQAGABAFADQAEADADADQACAFAAABQABAIgBAJQAAABAAABQgBABAAACQgBACAAACQgBAAAAABQgFAHgIADQAAAAgBAAQgDABgEABQgDAAgCAAQgBAAgBAAQgNABgHgKQAAAAAAAAQgEgEgDgEQgEgGgDgI");
	this.shape_43.setTransform(535.4,301.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("rgba(65,68,55,0.303)").ss(0.9).p("Ag5gWQABgUARgOQAUgOARAAQAUAAAJAHQALAHADADQAEAGAEAHQABACAAABQAEAHACAJQAEAQgDANQAAACgBADQgCAMgGAKQgDAFgFAFQgBACgCABQgCACgCACQgCABgBACQgBABgCABQgIAGgJAEQgGACgFACQgBgDgCgDQADgBABAAQACAAACgBQAEgBACgCQACgBABgCQAGgEACgHQADgEACgFQABgFAAgGQABgHAAgIQgCABgCABQgBAAgBAAQgGADgHABQgBABgBAAQgHABgHAAQgQgCgNgJQgCgCgCgBQAAAAgBgBQgFgEgEgEQgBgBgBgCQgEgGgBgIQAAAAAAAAAgjgYQACgJAEgHQAOgOAMABQAEAAAGADQAFADAEAGQACADACADQAEAJADALQAAADgBAEQgBADAAADQgBACAAAAQgGAEgHACQgHACgGgBQgJAAgIgFQgCgCgCgBQgJgIgDgPAgTggQABgQAGgIQAbgJAHALQAGAKACAQQAAACAAADQAAADAAADQAAACgBABQgEAHgGADQgHACgGAAQgKAAgGgIQgGgGgCgJQgBgDAAgEAgTggQACgGADgFQAHgLABAAQAAgBABgCQAJgIANABQALABAIAJQABACACADQAIALABARQAAACAAABQAAADAAADQAAABAAAAQAAABAAAAQAAACgBACQAAABAAABQAAAAgBABQgCACgEABQgCAAgDAAQgBAAgBAAQgHABgIgBQgFAAgEAAQgHgDgEgFQgBgBgBAAQgEgFgEgFQgEgGgCgHAgRgRQABgHAEgEQARgRANgBQAHABACABQAHABAFAFQAEADADAFQACAGAAABQABAIgBAJQAAACAAABQAAADgBAAQAAACgBACQAAABAAAAQgGAIgIADQAAAAgBAAQgDABgFABQgCAAgDAAQgBAAAAAAQgOABgIgLQAAAAAAAAQgDgEgDgEQgEgGgCgJ");
	this.shape_44.setTransform(535.5,301.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("rgba(49,51,41,0.227)").ss(0.9).p("Ag6gYQABgWARgPQAUgPATAAQAVABAKAHQALAJADADQAEAGADAIQACADAAABQADAIACAKQADARgEAOQgBADAAADQgEANgHALQgEAFgFAFQgBABgCACQgDACgCACQgCABgBACQgCABgCABQgJAGgKAEQgFACgHABQgBgDgCgEQAEgBAEAAQADgBACAAQACgCADgCQACgBACgCQAHgFAEgHQADgFACgFQACgFABgGQABgIABgJQgDABgCABQgBABAAAAQgHAEgHABQgBAAgBABQgHACgIgBQgRgBgNgKQgCgCgCgBQAAgBgBAAQgFgFgEgEQgBgCgBgCQgEgGgBgJQAAAAAAAAAgigaQABgLAEgHQAPgRAMAAQAFAAAGAEQAFADAFAHQACADACAEQAEAJACAMQAAAEgBAEQAAADAAAEQgBADAAAAQgGAFgIACQgHADgGgBQgLAAgHgGQgDgCgCgBQgJgJgCgQAgWghQAAgRAIgKQAegKAHANQAHALABASQAAADAAADQAAAEAAADQAAACAAABQgFAIgHADQgHABgHAAQgLAAgHgIQgGgHgCgKQgBgDAAgFAgWghQABgGACgGQAIgMAAAAQABgCABgBQAJgJANAAQALABAIAKQACACACACQAHAMACASQAAACAAACQAAADAAADQAAABAAAAQAAABAAAAQAAACAAADQgBABAAACQAAAAAAABQgDACgEABQgCABgDAAQgBAAgBAAQgIACgIgBQgFAAgEgCQgGAAgGgGQgBgBAAAAQgFgFgEgGQgDgHgCgIAgVgVQABgIADgGQARgTANgBQAIABACABQAHACAGAGQAEAEADAGQACAHAAABQABAJgBAJQAAABAAACQAAACgBADQAAABgBABQAAABAAABQgGAHgIADQAAABgBAAQgEABgEABQgDAAgDAAQAAAAgBAAQgNAAgJgKQAAgBAAAAQgEgEgCgCQgEgIgCgK");
	this.shape_45.setTransform(535.5,302.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("rgba(33,34,27,0.152)").ss(0.9).p("Ag7gaQABgXARgQQAVgQAUgBQAWACAKAIQAMAKACADQAFAHADAJQABADABABQADAJABAKQACAUgFAPQgBADgBADQgFAOgIALQgFAGgFAFQgCABgCACQgDACgDACQgBABgCACQgCABgCABQgKAGgJAEQgHACgIABQgBgEgCgFQAFAAAFgBQACgBADgBQAFgBACgDQACgBADgCQAIgGAFgIQAEgEADgHQACgFABgGQACgIABgKQgCACgCABQgBABgBAAQgHAFgHABQgBAAgBABQgIACgIAAQgSgBgOgLQgCgBgCgCQAAgBgBAAQgFgFgEgFQgBgCgBgCQgDgIgBgIQAAgBAAAAAgigdQABgMAEgIQAPgTANAAQAGAAAGAEQAGAEAEAGQACAEACAEQAEAKACANQAAAEAAAGQgBADAAAEQgBAEAAAAQgGAGgIACQgIADgHAAQgKgBgIgFQgDgCgCgBQgJgLgCgSAgaghQAAgTAIgLQAigLAIAOQAHAMACAUQAAAEAAADQAAAEAAAEQAAABgBADQgFAIgIABQgIAEgIgBQgMAAgIgIQgGgIgCgMQgBgDAAgFAgaghQABgHACgHQAHgNAAAAQABgCABgBQAKgLAMABQANAAAIAKQACACABADQAIANACASQAAACAAACQAAADAAAEQAAAAAAABQAAABAAABQAAACgBADQAAABAAACQAAABAAABQgDADgEAAQgDACgDABQgBAAgBAAQgIADgIgBQgGAAgEgCQgGgCgGgFQgBAAAAgBQgFgFgDgHQgDgHgCgJAgZgZQABgJACgHQATgXAMAAQAIABADABQAHADAFAHQAEAFADAHQACAIAAACQACAIgBAKQAAABAAACQAAACgBADQAAACAAACQgBAAAAAAQgGAIgIADQgBABAAAAQgEABgFABQgDAAgCAAQgBAAgBAAQgNAAgKgLQAAAAAAgBQgDgCgDgEQgEgJgBgK");
	this.shape_46.setTransform(535.6,302.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("rgba(16,17,14,0.076)").ss().p("Ag8gcQAAgZASgRQAVgRAVAAQAYACALAJQALAKADAFQAFAHADAKQABADAAABQADAKAAALQABATgGATQgBADgBADQgGAPgKALQgFAGgGAFQgCACgCABQgDADgDACQgCABgCACQgCABgCABQgJAGgMADQgIACgIACQgBgFgCgGQAGAAAFgBQADgBADgBQAGgCAEgDQADgBABgCQAJgGAHgJQAEgFAEgHQADgFACgHQADgJABgJQgDABgCACQgBAAgBABQgGAFgIACQgBAAgCABQgIADgIAAQgTgBgOgMQgCgBgCgCQgBgBAAAAQgGgGgDgFQgBgCgBgCQgDgJgBgJQAAgBAAAAAgigfQABgNAEgKQAQgVANAAQAGAAAGAEQAHAEAEAHQACAEACAEQAEALACAOQAAAFAAAGQAAAEAAAEQgBAFAAAAQgGAHgJADQgIADgJAAQgKgBgIgGQgDgCgCgBQgJgMgCgTAgeghQAAgVAJgMQAlgMAIAPQAJANABAWQAAAEAAAEQAAAEAAAFQAAABgBADQgGAHgIADQgIAEgJAAQgNAAgJgKQgHgIgCgNQgBgEAAgFAgeghQABgIACgHQAGgOAAgBQABgCABgCQAKgLANAAQANAAAIALQACACACADQAIANABAUQAAABAAACQAAAEAAADQAAABAAABQAAABAAABQAAADAAADQAAACAAACQAAABAAABQgDADgEABQgDACgDABQgBABgBAAQgJADgJAAQgFgBgDgBQgIgDgGgFQgBAAAAgBQgFgFgDgIQgDgHgBgKAgdgeQAAgJACgIQATgaAMAAQAJAAADACQAHADAGAJQAEAGADAIQACAJAAACQABAIgBAKQAAACAAABQAAADAAADQAAACAAACQAAABgBABQgGAHgJADQAAAAAAAAQgFACgFABQgDAAgCAAQgBAAgBAAQgOAAgKgMQAAAAAAAAQgDgCgCgFQgEgJgBgL");
	this.shape_47.setTransform(535.6,302.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(92,124,65,0.247)").s().p("AAAhcQgaAAgSASQgSASAAAaQAAAZAQAOQAQAQAVABQALAAAKgFQAMgDAKgKQgFAcgQARQgNATgcAIIgMACIADAMQAXgDARgKQATgKANgOQANgPAHgTQAIgUgBgUQAAgjgRgUQgRgUgcAAIAAAAAAAhSQAPAAAKAQQAKARAAAeIAAAKQAAACgBACIAAACQgGAHgJADQgJAEgKAAQgOAAgKgLQgJgMgBgWQAAgWAKgNQAKgNAOAAIAAAA").cp();
	this.shape_48.setTransform(535.7,302.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35}]}).to({state:[{t:this.shape_36}]},42).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).wait(18));

	// 6
	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#DCEFC4").ss(0.7).p("AhFAPQgDgIADgHQADgHAJgIQAOgLAUgBQAUgCAcAKQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFQgSAJgRgCQgRgCgFgLIAAAA").cp();
	this.shape_49.setTransform(406.2,332);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("rgba(200,217,178,0.91)").ss(0.6).p("AgdgZQATgCAaAJQAMADAIADQgGgEgJgEQgCgCgCgBQgHgEgNgGQgNgBgKABQgLACgJAEQgJAEgHAHQgJAJgDAIIAAABQgDAIAEAIQADAGAGAFQAFADAIACQABAAAAAAQAGAAAGAAQAGAAAHgCQAGgCAHgEQAFgDAFgEQACgDAEgFQACgBACgCQABgCABgBQgBABgCABIgCACQgKALgJAGQgRAJgRgCQgRgCgFgLQgEgJADgKQACgGAJgIQANgKASgCIAAAAAAPACQgCACgDABIAAAAQACgBADgCIAhgIQgEgDgIgDQACACACACQAEABACABQgDgBgCAAQgEgBgDABQgEAAgDACQgDACgEACQgFACgFAEQgBABgCAB");
	this.shape_50.setTransform(406.5,332.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("rgba(180,195,160,0.819)").ss(0.6).p("Ag8ADQACgKAKgLQAOgLABgBQAKgFAMgDQAIgBAHAAQADAAAEABQAAAAAAAAQABABABAAQAJAGAEAFQAAAAABABQABABABABQAHAGAFAGQAIACAEACQgBAAgBABQgDABgDABQgGACgGADQgBAAgBABQgCACgCACQAAACgCABQgBACgBABQAAABgBABQgDAFgEAEQAAAAgBAAQgFAFgFADQgFAEgHADQgGACgHAAQgBAAAAAAQgGAAgGgBQgBAAAAAAQgBAAgBAAQgGgCgFgDQgBAAgBgBQgGgFgDgGQAAgBAAAAQgEgIADgJAASAHQAEgFAFgCQAKgGAEgBQAMAAADACQgBAAgDABQgCABgDAAQAGADACACQgQAEgPADQgEAAgCgC");
	this.shape_51.setTransform(405,332.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("rgba(160,174,142,0.728)").ss(0.7).p("Ag9AFQACgMAKgMQAPgOABAAQAKgHAOgDQAIgCAJgBQACACADABQAAAAAAAAQAAABABAAQAFAGACAGQAAABAAABQABABABACQAFAHAEAIQAIABAFABQgBAAgBAAQgBABgBABQgDACgEAEQgBAAAAABQgBACgCADQAAADgBABQgBADgBACQgBABAAABQgDAFgEAFQAAAAgBAAQgFAGgFADQgIAFgFADQgHACgHABQgBAAgBAAQgGgBgGgBQgBAAgBAAQgBAAAAAAQgHgCgFgEQgBgBgBAAQgGgFgEgIQAAAAAAgBQgDgJACgKAAMAJQADgFAEgEQAKgGAFgBQAOAAAEADQAAACgDACQgBADgEABQAEAFAAACQgQAEgOABQgFgDgBgE");
	this.shape_52.setTransform(404.9,332.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("rgba(140,152,125,0.637)").ss(0.7).p("Ag3AHQABgOAKgNQAQgQABgBQALgHAOgFQAIgCALgBQACACADACQAAAAgBABQAAAAABABQABAGgBAHQAAABAAABQABACAAACQADAIADAJQAIAAAFABQAAAAAAAAQAAAAAAABQABABgCAHQAAAAAAAAQgBADgBAEQAAACgBADQAAACgBADQAAABgBABQgDAGgDAGQgBAAAAAAQgFAGgGAEQgIAGgHADQgGACgIABQgBAAAAAAQgIAAgHgCQgBAAAAAAQgBAAgBgBQgHgCgFgEQgBgBgBgBQgGgFgEgIQAAgBAAAAQgEgKADgLAALAKQADgEAEgEQAJgHAGgCQAQAAAFAEQABADgCAEQgBAGgFADQADAFgCADQgQADgOgBQgFgFgCgI");
	this.shape_53.setTransform(404.1,333.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("rgba(120,130,107,0.546)").ss(0.8).p("Ag1AJQACgQAJgPQAQgRACgBQAMgJANgFQAKgDAMgBQADADACACQgBAAgBABQAAAAAAABQgDAGgCAJQgBABAAABQAAACAAADQABAJADALQAIgBAFAAQAAAAABgBQABAAACABQAEABAAAIQAAABAAAAQABADgBAEQABADgBADQgBADAAADQAAACgBABQgDAHgDAGQgBAAAAAAQgFAHgGAFQgIAGgIADQgIADgHAAQgBAAAAAAQgIAAgIgCQgBAAgBgBQAAAAgBAAQgIgDgFgFQgBAAgBgBQgGgGgEgIQAAgBAAgBQgEgKACgMAAIAMQADgFADgEQAJgHAFgCQAUgBAFAFQADADgCAHQgCAJgFAEQABAHgEACQgPADgOgEQgGgGgBgL");
	this.shape_54.setTransform(403.7,333.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("rgba(100,109,89,0.455)").ss(0.8).p("Ag0AKQABgRAKgQQARgTABgBQANgLAOgFQALgEANgBQACADADADQgCAAgBABQgBAAAAABQgHAGgFALQAAABAAABQgBACgBADQAAALABAMQAIgCAGAAQABgBABAAQADgBADAAQAHABADAKQAAABABABQABADAAAFQABADgBADQAAAEgBADQAAACAAABQgDAIgDAGQgBABAAAAQgFAIgGAFQgIAGgJAEQgJADgHAAQgBAAgBAAQgJAAgIgDQgBAAgBAAQAAAAgBgBQgIgDgFgFQgBgBgBgBQgHgGgDgJQAAgBgBAAQgDgLABgNAADANQACgEADgEQAJgJAGgCQAWgCAGAHQADAEgBAKQgBALgGAGQgBAIgGABQgPADgOgGQgGgIgBgP");
	this.shape_55.setTransform(403.4,333.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("rgba(80,87,71,0.364)").ss(0.8).p("Ag1AMQABgTALgSQAQgUABgBQAOgMAPgHQAMgEAOgBQACADACAEQgBABgCAAQgBAAgBABQgKAHgIAMQAAABAAABQgCADgBADQgCAMAAAOQAIgDAHgBQABgBABAAQAEgCAGAAQAJABAGALQABACAAABQACADABAGQABADAAAEQAAAEgBAEQAAABAAACQgCAIgEAHQAAABgBABQgEAIgHAFQgJAHgJAEQgJADgIAAQgBAAgBAAQgKAAgIgDQgBAAgCAAQAAgBgBAAQgIgDgGgGQgBgBgBgBQgGgHgDgJQgBgBAAgBQgEgLABgOAgCAPQACgEAAgFQAJgJAHgDQAYgCAHAIQAEAFgBAMQAAAOgHAIQgCAIgIACQgQACgNgIQgFgKgBgS");
	this.shape_56.setTransform(403.3,333.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("rgba(60,65,53,0.273)").ss(0.9).p("Ag3AOQABgVAKgTQARgWACgBQAOgOAQgHQANgFAPgBQACAEACAEQgCABgDAAQgBAAgBABQgPAHgJANQAAACgBABQgCADgCAEQgCANAAAPQAGgDAHgCQABgBACgBQAGgCAHAAQANABAIAMQAAACABABQADAEACAGQABAEAAAEQAAAFgBAEQAAACAAACQgCAJgDAHQgBABAAABQgFAJgHAFQgIAIgKAEQgKAEgJAAQgBAAgBAAQgKgBgJgDQgBAAgCgBQAAAAgBAAQgJgEgFgHQgBgBgBAAQgHgIgDgKQAAAAgBgBQgEgMABgPAgKARQACgFABgEQAHgLAHgCQAbgDAHAIQAGAIgBAOQAAAQgHAJQgFAKgKABQgPACgKgLQgIgLgBgV");
	this.shape_57.setTransform(403.4,334.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("rgba(40,43,36,0.182)").ss(0.9).p("Ag5AQQABgXAKgUQARgYACgCQAPgOARgIQAOgFAQgCQABAEACAFQgCABgDAAQgCABgCAAQgSAIgLAOQAAABAAACQgCAEgCAEQgGAOgCARQAIgFAFgDQADgBACAAQAHgDAJAAQAQAAAKAOQABACABABQAEAFACAHQABAEABAFQAAAEAAAFQAAACAAACQgCAKgEAIQAAABgBABQgEAJgHAGQgJAJgLAEQgKAEgKAAQAAAAgBAAQgLgBgKgDQgCgBgBAAQAAAAgBgBQgJgEgGgHQgBgBgBgBQgGgIgEgKQAAgBgBgBQgDgMAAgQAgSASQABgEABgFQAIgLAIgDQAcgDAIAIQAHAKgBARQAAASgIALQgGALgMABQgPABgKgNQgIgNgBgZ");
	this.shape_58.setTransform(403.4,334.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("rgba(20,22,18,0.091)").ss().p("Ag7ASQAAgZALgWQARgaACgBQAPgQATgIQAPgGAQgDQACAGABAFQgDABgDAAQgCABgCAAQgWAIgMAQQgBABAAACQgDAEgDAFQgIAPgCASQAIgFAHgEQADgBACgBQAHgDALAAQATAAANAPQABACABACQAFAEACAIQACAFABAFQAAAFAAAGQAAACAAACQgBAKgEAJQAAABgBABQgEAKgIAHQgJAJgLAEQgKAEgMAAQAAAAgBAAQgMgBgKgDQgCgBgBAAQgBgBAAAAQgKgEgGgIQgBgBgBgBQgGgIgDgLQgBgBAAgBQgEgOAAgRAgaAUQABgEAAgFQAIgMAIgEQAfgDAIAJQAIAMAAASQAAAWgJAMQgHAMgOAAQgOABgLgPQgIgQgBgb");
	this.shape_59.setTransform(403.5,334.6);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(112,191,86,0.247)").s().p("AgLgUQgLAEgLAKQAFgbAPgUQAOgTAcgJIALgDIgCgLQgsAHgcAfQgbAgAAAtQAAASAEAOQAEAOAJAKQAHAKANAFQALAEANABQANAAALgEQALgFAKgKQAIgHAFgNQAEgLAAgOQAAgYgPgQQgPgQgWAAQgKAAgLAEIAAAAAghAFQAHgGAIgEQAJgFAJABQAPAAAKALQAJANAAAUQAAAZgJANQgJANgQAAQgOAAgKgRQgKgRAAgfIAAgJQAAgEABgDIAAAA").cp();
	this.shape_60.setTransform(403.5,334.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49}]}).to({state:[{t:this.shape_50}]},42).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).wait(20));

	// 7
	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#E1F1BB").ss(0.7).p("Ag5gPQAOgLAUgBQAUgCAcAKQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFQgSAJgRgCQgRgCgFgLQgDgIADgHQADgHAJgIIAAAA").cp();
	this.shape_61.setTransform(374.2,291);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("rgba(205,219,170,0.91)").ss(0.6).p("AgrgPQAPgIATgDQASAFAYAOQAUAIAGAJQgDABgDAAQgKgDgGABQgLABgJAEQgKAGgHABQgBACgDAAQgQAFgPgCQgBAAgCAAQgCAAgDAAQgCgBgCAAQgDAAgDgBQgCgCgCgBQgBgCgBgDQgDgJADgHQAFgIALgHIAAAA").cp();
	this.shape_62.setTransform(373.1,290.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("rgba(188,201,156,0.834)").ss(0.6).p("Ag2gCQAHgHAOgGQANgGAQgDQAVAJAUAQQAOAMAEAKQABABAAABQgCAAgBAAQgBAAgBAAQgJgFgEgBQgJgBgHADQgJADgGgBQgCABgCAAQgDAAgEAAQgMABgLgBQgCAAgBAAQgDAAgCAAQAAAAgBAAQgCgBgCAAQAAAAgBABQgBAAgBAAQgDAAgCAAQgBgBgBAAQAAAAgBgBQgBgBgBgBQAAgBgBgCQgDgKADgJ");
	this.shape_63.setTransform(372.5,290.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("rgba(171,183,142,0.758)").ss(0.7).p("AgygLQAKgGAPgGQAPgGAPgCQASAPAQAUQALAOACAMQAAABAAABQgCAAgCAAQgBAAgBgBQgGgGgDgDQgHgCgGAAQgHAAgDgCQgCAAgCgBQgDgBgDgCQgMACgNgBQgBAAgCAAQgDAAgDgBQAAAAgBAAQgCAAgCAAQgBAAAAABQgCAAgBAAQgCABgCABQgBAAgCAAQAAgBgBAAQgBgBgBgBQgBgCAAgBQgDgLADgL");
	this.shape_64.setTransform(372.1,290.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("rgba(154,164,128,0.682)").ss(0.7).p("AgvgUQANgGARgFQARgFARgCQAMAWALAXQAIAQABAPQgBABgBAAQgCABgCAAQAAgBgBgBQgFgIgBgEQgGgFgDgCQgFgCgDgEQgBgBgBgCQgCgCgCgDQgNABgPgBQgCAAgBAAQgEAAgDAAQAAAAgBAAQgDAAgCAAQAAAAgBABQgCAAgBABQgDABgBACQgBAAgCAAQAAAAgBAAQgBgBgBgBQgBgCgBgCQgCgLACgN");
	this.shape_65.setTransform(371.7,290.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("rgba(137,146,113,0.607)").ss(0.7).p("AgrgdQAOgFATgFQARgEAVgCQAHAcAGAbQAFASgBARQgBABgBABQgDAAgCAAQAAgBgBgCQgDgJAAgGQgDgHgCgEQgDgEgBgGQgBgCAAgDQgBgDgBgDQgRACgOgBQgCAAgCAAQgDAAgEAAQAAAAgBAAQgDAAgDAAQAAAAgBABQgCAAgBABQgDAAgCADQgBAAgBABQgBAAAAgBQgCAAgBgBQgBgCAAAAQgCgPACgO");
	this.shape_66.setTransform(371.3,291.3);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("rgba(120,128,99,0.531)").ss(0.8).p("AgpgnQARgEAVgEQATgEAXgCQABAjACAeQACAVgEAUQgBAAgCABQgDAAgCAAQAAgCAAgBQgCgLACgIQgBgJgBgHQgBgFABgJQAAgCAAgCQAAgFAAgFQgSABgQgBQgCAAgCAAQgEAAgEAAQAAAAgBAAQgEAAgDABQAAAAgBAAQgCACgCACQgCACgCACQgBABgBABQgBAAAAAAQgCgBgCAAQAAgDgBgCQgCgQACgQ");
	this.shape_67.setTransform(371,291.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("rgba(103,110,85,0.455)").ss(0.8).p("AgrgwQATgEAXgDQAVgDAYgCQgEApgCAiQgBAXgGAWQgCAAgCABQgDAAgDAAQAAgCAAgCQABgMADgKQAAgLACgJQAAgIADgIQAAgEABgEQABgGABgHQgUABgRAAQgCAAgCAAQgFAAgEAAQAAAAgBAAQgEAAgDABQgBAAgBAAQgCACgCACQgCADgCADQgBABgBACQgBAAAAgBQgCAAgCgBQgBgCAAgDQgCgRACgR");
	this.shape_68.setTransform(371.1,292);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("rgba(85,91,71,0.379)").ss(0.8).p("Agvg5QAVgDAZgDQAXgDAagBQgJAvgIAmQgEAZgIAYQgCABgDAAQgDAAgDAAQABgCAAgCQACgOAFgMQACgMAEgMQACgKAEgKQABgFACgEQACgIACgIQgWABgTgBQgCAAgCAAQgFAAgFAAQAAAAgBAAQgEABgEAAQAAABgBAAQgDACgCADQgCADgCAEQgBACgBABQAAAAgBAAQgCAAgDgBQAAgCAAgDQgCgSACgT");
	this.shape_69.setTransform(371.5,292.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("rgba(68,73,57,0.303)").ss(0.9).p("Ag0hCQAYgDAbgCQAZgCAcgBQgPA1gMApQgHAcgKAbQgDAAgDAAQgCAAgDAAQABgCABgDQACgPAGgOQAEgOAFgOQAEgNAGgMQACgFACgFQADgJADgKQgXABgVAAQgCAAgCAAQgFAAgFAAQgBAAgBAAQgEABgEAAQgBABgBAAQgCACgCADQgDAEgCAFQgBACgBACQAAAAgBAAQgDgBgCAAQAAgDgBgDQgBgTABgU");
	this.shape_70.setTransform(371.9,292.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("rgba(51,55,43,0.227)").ss(0.9).p("Ag4hLQAbgCAcgCQAbgCAdAAQgUA7gQAtQgKAegKAdQgEAAgDAAQgEABgEAAQACgDABgDQAGgRAHgPQAEgRAHgQQAGgNAHgQQACgGADgGQAEgKAFgLQgZABgXgBQgCAAgCAAQgGAAgFAAQgBAAgBAAQgEABgFABQAAAAgBABQgDACgCAEQgDAEgBAGQgBACgCACQAAAAgBAAQgDAAgCAAQgBgDAAgDQgBgVABgV");
	this.shape_71.setTransform(372.2,293.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("rgba(34,36,28,0.152)").ss(0.9).p("Ag8hVQAdgBAegBQAdgBAfgBQgZBCgVAxQgNAggNAfQgDAAgEABQgEAAgEAAQABgEABgDQAIgSAJgRQAIgTAHgSQAHgPAJgSQADgHADgHQAGgMAFgMQgaABgYAAQgDAAgCAAQgGAAgGAAQAAAAgBAAQgFABgFABQgBAAgBABQgDACgCAFQgDAEgBAGQgBADgBADQgBAAgBAAQgDAAgDgBQAAgDAAgDQgBgWABgX");
	this.shape_72.setTransform(372.6,293.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("rgba(17,18,14,0.076)").ss().p("AhAheQAfAAAggBQAfgBAhAAQgfBIgZA0QgOAjgRAiQgEAAgFAAQgEAAgEAAQACgEABgDQAKgUAKgTQAKgVAIgUQAKgSAKgUQAEgHAEgIQAGgNAHgNQgcABgagBQgDAAgCAAQgHAAgGAAQAAAAgBAAQgFACgFABQgBAAgBABQgEACgCAFQgDAFgBAHQgBADgBADQgBAAgBAAQgDAAgDAAQAAgDAAgDQAAgYAAgY");
	this.shape_73.setTransform(372.9,293.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(133,197,85,0.247)").s().p("AhDhnIAAA5IAIAAQADgMAEgIQADgIAFgBIAMgDIBMgBIhgC3IASAAIBmjGIAAgJIiHAA").cp();
	this.shape_74.setTransform(373.2,294.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_61}]}).to({state:[{t:this.shape_62}]},45).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).wait(15));

	// 4
	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#D9E6BE").ss(0.7).p("ABBgFQgQgCgJAEQgOADgLAHQgNAJgIAFQgSAJgQgCQgRgCgFgLQgEgIADgHQADgHAKgIQAOgLAUgBQASgCAeAKQAZAIAIAGIAAAA").cp();
	this.shape_75.setTransform(417.5,226);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("rgba(197,209,173,0.91)").ss(0.6).p("AABgdQALAEANAGQAAABAAAAQAGABAEACIARAIQABAAAAAAQgEAAgDAAQADADADACQACABACABQgDgBgDAAQgEABgEAAQgFAAgEAAQgDABgEABQgJAGgIAHQgEAEgDADQgFADgFADQgCABgCAAQgLADgKgBQgGAAgGAAQgSgCgHgKQgBgCgBgCQgBgGACgFIAAgBQAEgIAKgIQAPgMAUgEQAUgBADABIAAAAAAagSIgBAAQgBgBgBAAQABAAACABQAFACAEABAAugHQgKABgGADQgNADgKAIQgJAJgIAFQgTAJgRgCQgQgCgGgJQgEgIACgHQAEgGAJgIQANgLATgDQAUgCAaAHIACABAAagSQAMAGAIAF");
	this.shape_76.setTransform(418.2,225.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("rgba(177,188,156,0.819)").ss(0.6).p("AhEARQAAgFACgGQAFgJAKgJQAQgOAUgGQANgCADAAQAFABACACQAKAGALAIQAGADADACIANAIQAEACAAABQgCAAgCAAQAEABABABQADACABABQgDAAgDAAQgFAAgEABQAAAAgBAAQgEABgDACQgDACgDABQgGAFgFAGQgDABgDACQgEADgCADQgIACgDACQgBAAgCgBQgFABgFgBQgFAAgGAAQgGAAgGAAQgPgCgJgFQgCgCgBgDQgBgCgBgDAAVgMQAGAAAFgBIAQABQAEAEAAAAQgDACgDABQgCAAgEAAQgIgDgLgE");
	this.shape_77.setTransform(417.6,225.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("rgba(158,167,138,0.728)").ss(0.7).p("AhDATQABgGADgGQAGgKAKgKQAQgPAVgIQALgDAFAAQAFACACACQAIAIALAKQAFAEADADIALAKQAFAAAAAAQgBAAgCAAQAFAEABACQACABABACQgDAAgEAAQgEAAgFABQAAAAgBAAQgEACgDADQgCACgDACQgFAGgFAGQgDACgDABQgEADgDACQgHABgDAAQgBgBgBgBQgFAAgEgCQgGAAgGgBQgHABgGgBQgQgBgKgFQgCgCgBgDQgBgDgBgCAAOgHQAHgCAGgCIATgGQADAGAAABQgCADgDADQgCACgDABQgMgDgNgD");
	this.shape_78.setTransform(417.3,225.3);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("rgba(138,146,121,0.637)").ss(0.7).p("AhCASQABgGAEgGQAHgLAKgKQARgQAVgLQAMgDAFAAQAEACACADQAHAKAJAMQAFAFACAEIAKAKQAFACABAAQgBAAAAAAQAEAEABABQACACABADQgDgBgEAAQgFABgEAAQgBAAgBAAQgDADgDAEQgCACgCADQgFAHgEAHQgDACgEABQgEACgEACQgGgBgDgCQgCgBAAgBQgDgCgEgDQgGAAgGAAQgIAAgHAAQgQgBgMgFQgBgDgBgCQgBgEgBgCAAGgDQAIgEAHgFIAWgKQACAHABABQgDAEgCAFQgCAEgCABQgPAAgQgD");
	this.shape_79.setTransform(417.1,225.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("rgba(118,125,104,0.546)").ss(0.8).p("AhCASQACgGAEgHQAIgLALgLQASgSAUgNQANgEAGAAQADADABAEQAHAMAIAOQADAFADAFIAIAMQAGACAAAAQABAAAAAAQAFAEABACQABACABADQgEgBgDAAQgGABgFAAQAAAAgBAAQgDAEgCAEQgCAEgCADQgEAIgEAIQgDABgEABQgFACgEACQgFgDgDgEQgBgBgBgCQgCgDgDgEQgHAAgGgBQgIABgIgBQgRAAgNgEQgBgDgBgDQgBgEgBgDAgBAAQAHgGAIgGIAZgRQACAKABAAQgCAHgCAGQgCAFgCAEQgSgDgQAA");
	this.shape_80.setTransform(416.9,225.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("rgba(99,105,87,0.455)").ss(0.8).p("AhBARQACgGAFgHQAJgMALgMQASgTAUgPQAOgFAGAAQADAEABAEQAFAPAHAQQADAGACAFIAHAPQAGABAAAAQACAAACAAQAEAEABACQABADABADQgEAAgEAAQgGAAgFAAQgBAAgBAAQgCAFgCAFQgCAEgBAEQgDAJgDAJQgFABgEABQgFABgEACQgEgFgDgFQgBgCgBgDQgDgEgBgFQgGAAgIgBQgIABgIgBQgSAAgPgDQgBgEAAgDQgBgEAAgDAgJABQAJgGAIgIIAbgWQACAMABAAQgCAIgCAIQgBAHgCAFQgUgCgUgC");
	this.shape_81.setTransform(416.7,225.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("rgba(79,84,69,0.364)").ss(0.8).p("AhBARQADgHAFgGQAKgNAMgNQASgVATgRQAQgGAGAAQACAFABAFQAFARAFARQACAHACAHIAFAQQAHABAAAAQADAAADAAQAEAEABADQABADAAADQgEAAgEAAQgGAAgFABQgCAAgBAAQgCAFgBAGQgBAEgCAFQgCAKgCAKQgFAAgFABQgFACgFABQgDgHgCgHQgBgCAAgDQgDgGgCgGQgFAAgIgBQgJABgJgBQgSAAgQgDQgBgDgBgEQAAgEAAgDAgSAFQALgIAIgKIAegcQACAOAAAAQgBAKgBAJQgCAIgBAIQgXgCgXgB");
	this.shape_82.setTransform(416.6,225.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("rgba(59,63,52,0.273)").ss(0.9).p("AhCARQAFgHAFgHQALgOAMgNQATgWATgUQAQgHAHAAQACAGAAAGQAEATAEATQABAIACAHIAEATQAHABAAAAQAEAAADAAQAFAEABADQAAADABAEQgFgBgEAAQgGABgGAAQgBAAgBAAQgCAGgBAHQgBAFgBAFQgCALgCAKQgEABgFABQgGABgFAAQgCgIgCgJQgBgDAAgDQgCgHgCgHQgFAAgIgBQgKABgJgBQgUAAgRgCQAAgEgBgEQAAgEgBgEAgbAIQAMgKALgLIAggiQABAQAAAAQgBALgBALQgBAJgBALQgZgCgagB");
	this.shape_83.setTransform(416.4,225.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("rgba(39,42,35,0.182)").ss(0.9).p("AhCAQQAFgHAGgHQAMgOANgPQATgXATgWQARgIAHAAQABAHABAHQACAVACAVQACAIAAAJIADAVQAIAAAAAAQAFAAAEAAQAFAEAAADQABAEAAAEQgEAAgFAAQgGAAgHAAQgBAAgBAAQgBAHgBAHQgBAGAAAGQgBAMgCALQgFABgFAAQgGABgFAAQgCgKgBgKQgBgEAAgDQgBgJgBgIQgIAAgHAAQgKAAgKAAQgUgBgTgBQAAgEAAgFQAAgEgBgEAgjAMQAMgMANgOIAigmQAAARAAAAQAAANgBAMQAAALgBAMQgbAAgegB");
	this.shape_84.setTransform(416.2,225.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("rgba(20,21,17,0.091)").ss().p("AhCAQQAGgHAGgIQANgPANgPQAUgZATgXQARgJAIAAQABAHAAAIQABAXABAXQABAJAAAJIACAXQAIAAAAAAQAGAAAFAAQAFAEAAAEQAAAEABAEQgFAAgFAAQgHAAgGAAQgCAAgBAAQgBAJAAAHQAAAHgBAGQAAANgBAMQgFABgGAAQgGAAgGAAQgBgMAAgMQgBgEAAgEQAAgJgBgKQgIAAgHAAQgLAAgKAAQgVAAgUgBQAAgFgBgEQAAgFAAgEAgsAPQANgPAOgOIAlgsQAAATAAAAQAAAOgBAPQAAAMAAAOQgeAAghgB");
	this.shape_85.setTransform(416.1,225.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(61,122,82,0.247)").s().p("AAYhdIhaBtIAAAUIBSAAIAAA6IAYAAIAAg6IAbAAIAAgRIgbAAIAAhwIgQAAAg1ATIBFhTIAABTIhFAA").cp();
	this.shape_86.setTransform(416,225.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_75}]}).to({state:[{t:this.shape_76}]},38).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).wait(24));

	// 5
	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#C0EBC0").ss(0.7).p("AhAgFIAJAAQALAAAFACQAOADALAHQAGADAPALQAIAEAHACQAKACAJgBQARgCAFgLQAEgIgDgHQgDgHgKgIQgMgJgRgDQgCAAgDAAQgSgCgeAKQgZAIgIAGIAAAA").cp();
	this.shape_87.setTransform(523.6,354);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("rgba(175,214,175,0.91)").ss(0.6).p("AASgXQAOgCALADQACABACAAQALAHAGAIQACAEABACQAAAEgCAFQgIAJgTADQAAAAgBAAQgHADgIABQgBAAgBAAQgBgBgBgBQgCgBgCgBQgBgBgCgBQgBgBgCgBQgBgBgCAAQgDgBgCgBQgCgBgCgBQgEgBgGgBQgIgCgLgCIAAAAQgHgBgJgCQgBAAgCAAQgFgBgEgBIgBAAQABgBACAAQAHgDACAAQAGgBADAAQADAAACgBQABAAACAAQACgBACAAQACgBACAAQAEgBACgBQAEgCADgCQAEgCADgCQAFgDACgCQAEgCADAAQACgBACABQABABAAABQABgBABABQABgBABAAIAAAA").cp();
	this.shape_88.setTransform(522.9,354.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("rgba(160,196,160,0.834)").ss(0.6).p("AhAALQABgCABgBQAHgDACAAQACgBAAABQADAAACABQACAAAAAAQADAAAAAAQACAAABAAQABAAABAAQAAAAAAAAQACgBADAAQABAAAAAAQACgBABgBQABAAAAAAQACgBACgBQABgBABAAQACAAACgBQABAAABgBQACgCACgCQACgCABgBQABgBABgBQADgDABgBQABgBAAAAQAAgBAAAAQABgBACAAQABABAAAAQABAAAAAAQABAAABABQABgBABAAQABgBABAAQAMgGAKAAQABAAAAAAQADABACAAQAOAHAIAHQAAAAAAAAQACAEACAEQgBAAAAABQgBACgDAEQgHAFgJADQgGAEgIADQAAAAgBAAQgBABgBABQgBABgCAAQgCABgCAAQAAAAgBAAQgBAAAAAAQgBgBgBgBQAAAAAAAAQgBgBgBAAQgBgBgBgBQgBAAgBgBQgBAAgCAAQgBgBgBABQgBAAgBgBQgDAAAAAAQAAAAAAAAQgEABgFAAQgFAAgEAAQgGAAgGgBQAAAAgBAAQgDAAgFgBQgFAAgGgCQgBAAgCgBQAAAAAAAAQgGgBgEgCQAAAAAAAA");
	this.shape_89.setTransform(522.7,353.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("rgba(146,178,146,0.758)").ss(0.7).p("AhAATQABgCABgCQAIgDADAAQACABAAAAQADABABACQACAAAAAAQADABABAAQABAAACAAQACAAABAAQAAAAAAAAQACgBADAAQABAAABgBQACAAABgBQABgBABAAQACgBACgCQABgBABgBQACgBACgCQABgBAAgCQADgCABAAQABgDABgCQABgBAAgBQACgDAAgBQAAgBAAAAQABgBAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAABAAQABgBAAAAQABgCABAAQAMgJAJgDQABAAABAAQADABACAAQARAGALAGQAAAAAAAAQACAFABAFQAAAAgBAAQgCAEgFACQgIAFgKACQgGAGgIAFQAAAAgBABQgBABAAABQgBAAgBAAQgBAAAAABQgBAAAAAAQgBAAAAgBQAAAAAAgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgCAAQAAAAgBABQAAAAgBAAQgDABgBABQgBAAAAAAQgEACgDABQgEABgFABQgGABgHgBQAAAAgBAAQgEAAgGAAQgGAAgGgCQgCgBgCAAQgBgBAAAAQgGgCgEgDQAAAAAAAA");
	this.shape_90.setTransform(522.4,353.7);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("rgba(131,161,131,0.682)").ss(0.7).p("Ag/ASQAAgCABgCQAKgEACABQADACAAAAQACACABACQACABABAAQADABAAAAQACAAACAAQACAAACAAQAAAAAAAAQADAAADgBQABAAABAAQACgBACgCQABAAABgBQACgBACgCQABgBABgCQADgCABgDQABgBAAgBQACgBABgEQABgCAAgDQAAgCAAgBQABgDgBgBQAAgBgBAAQAAAAAAAAQgBAAAAABQABABAAAAQAAAAgBAAQABgBABAAQAAgBABgBQAAgCAAgBQALgLAJgHQABAAABAAQADABADAAQATAFAOAGQAAAAAAAAQACAGABAFQgBAAAAABQgEAEgGADQgKAEgMACQgFAGgHAGQgBABAAAAQgBACgBABQAAAAAAAAQABgBAAABQAAAAgBAAQABAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAgBABQAAAAgBABQAAABgBABQgCABgBACQAAAAgBAAQgDADgFACQgDADgFABQgHACgHAAQAAAAgBAAQgFABgHgBQgHAAgHgCQgCgBgDgBQAAAAAAAAQgHgDgEgEQAAgBAAAA");
	this.shape_91.setTransform(522,354.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("rgba(117,143,117,0.607)").ss(0.7).p("Ag/AbQAAgDACgCQALgEACABQADADAAAAQACADABADQABABABAAQADABABAAQACABACAAQADAAACAAQAAAAAAAAQADgBADAAQACAAABgBQADgBACgCQABAAABgBQACgCACgCQACgCABgBQACgDABgEQABgBAAgCQAAgEAAgDQABgCAAgDQgBgCAAgBQAAgDgBgBQgBgBgBAAQgBAAAAAAQgBAAgBACQAAABAAABQgBgBgBAAQABgBABAAQAAgCABgBQABgCABgCQAIgOAIgKQACAAABAAQADAAAEABQAVAEARAFQAAAAAAABQACAGABAGQgBAAgBABQgFADgHADQgMADgNACQgFAIgHAIQAAABgBAAQgBACgBACQACgBABAAQABgBACAAQAAAAgBAAQABAAAAAAQABAAAAgBQABAAABAAQAAAAABAAQABABAAAAQAAAAAAAAQAAABAAABQAAABAAABQgBABAAABQgBADgCACQAAABAAAAQgDAEgGADQgEAEgEACQgHADgIAAQAAAAgBAAQgGACgHgBQgJAAgHgDQgDgBgDgBQAAAAAAAAQgIgEgDgFQAAgBAAAA");
	this.shape_92.setTransform(521.6,354.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("rgba(102,125,102,0.531)").ss(0.8).p("Ag/AfQABgDABgDQAMgEADACQADADAAABQABAEABADQABABABABQAEABAAAAQADAAACABQADAAADAAQAAAAAAAAQAEAAADgBQACAAABgBQADgBACgCQACgBAAgBQADgCACgDQACgCAAgBQABgDABgFQABgCAAgCQACgEAAgFQAAgCgBgDQgBgCgBgCQgBgEgCAAQgBgBgCAAQgBAAgBABQgCAAgCADQAAABAAABQgBgBgCgBQABgBABAAQAAgDABgBQABgDABgCQAIgRAHgNQABAAACAAQAEAAADAAQAYAFAUAEQAAAAAAAAQABAHABAHQgBAAAAABQgHADgIACQgOADgPACQgFALgGAIQAAABgBABQAAACgBACQACgBACgBQACgCAEABQAAAAgBAAQABAAABAAQABgBABAAQABAAABABQABgBABABQABABABABQABAAAAAAQAAACAAABQABABAAABQAAACAAABQgBADgBAEQgBABAAAAQgDAFgFAFQgEAEgHADQgFAEgJABQAAAAgBAAQgHACgIgBQgKAAgIgDQgDgBgDgBQAAgBAAAAQgJgEgDgHQAAAAAAgB");
	this.shape_93.setTransform(521.2,354.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("rgba(88,107,88,0.455)").ss(0.8).p("Ag+AjQAAgEACgDQANgEADACQADAFAAABQABAEAAAEQABABACABQADABABAAQADABACABQAEAAADAAQAAAAAAAAQAEAAAEgBQACgBABAAQAEgCACgCQABgBABgBQACgDABgDQACgCABgCQACgDABgGQABgCAAgCQABgFAAgFQAAgEgCgDQgBgCgCgCQgCgEgCgBQgDAAgCAAQgCAAgBABQgDABgCADQgBABAAABQgCgBgCAAQABgCABgBQAAgCABgDQABgCABgDQAIgUAGgRQABAAACAAQAEABAEAAQAaAEAXADQAAABAAAAQABAIABAHQgBAAgBABQgIACgJACQgPADgRABQgFANgFAKQgBABAAABQgBADAAACQACgBADgCQAEgCAEAAQAAAAAAAAQACAAABAAQABAAABAAQABAAACABQABAAACABQACAAABACQABAAABABQABACAAABQABACAAABQAAACAAACQAAAEgBAFQAAAAgBABQgCAGgFAGQgFAFgHAEQgHAFgIACQAAAAgBAAQgHACgKgBQgKAAgJgDQgEgCgDgBQAAAAAAgBQgKgFgDgIQAAAAAAgB");
	this.shape_94.setTransform(520.8,354.8);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("rgba(73,89,73,0.379)").ss(0.8).p("Ag+AoQAAgFACgDQAOgEADACQAEAFgBABQABAFAAAGQACABABAAQAEACABAAQADABACABQAEAAAEAAQAAAAAAAAQAEAAAFgBQABgBACAAQAEgCACgCQAAgCABgBQADgDACgDQACgDABgCQACgEABgHQABgCAAgCQABgGgBgFQAAgGgDgCQgBgDgCgCQgEgEgDgBQgDAAgDAAQgCABgDABQgDABgDAEQAAABgBABQgCgBgDgBQABgBABgCQAAgDABgDQABgDAAgDQAIgWAHgVQACAAABAAQADABAFAAQAcADAaADQAAAAAAABQABAIABAIQgBABgCAAQgJACgLACQgQACgSABQgFAPgDAOQAAABgBABQgBAAAAADQAEgCABgBQAFgBAGAAQAAAAAAAAQACAAACAAQABAAACAAQABABACAAQACAAACAAQACAAADACQABABAAABQACACABACQAAACABABQABADAAACQAAAFgBAGQAAAAAAABQgCAIgFAGQgFAHgHAFQgJAFgIACQAAAAgBAAQgIADgKAAQgMgBgKgEQgDgBgEgCQAAAAAAAAQgLgGgDgJQAAgBAAAA");
	this.shape_95.setTransform(520.4,355.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("rgba(58,71,58,0.303)").ss(0.9).p("Ag+AsQAAgGADgDQAPgEADADQAEAGgBABQABAGgBAGQACABABABQAEABABABQAEABADAAQAEABAEAAQAAAAAAAAQAFAAAEgBQACgBACgBQACgBADgDQACgBABgCQADgDACgEQACgDABgCQACgFABgHQABgDAAgDQABgGgBgGQgBgGgDgDQgDgDgCgCQgFgEgEgBQgEAAgDAAQgDABgDABQgEABgDAFQgBABgBACQgDgBgDgCQABgBABgCQAAgEABgDQABgDAAgEQAIgZAGgYQACAAABAAQAFABADAAQAgACAcADQAAAAAAAAQABAJABAJQgCABgBAAQgLABgMACQgSACgTABQgDAQgFAQQAAABAAABQgBADgBACQAFgBAFgDQAEgDAHAAQAAAAAAAAQACAAACABQACAAACAAQACABACAAQACAAADACQADABADACQABAAABABQACACABADQABABABACQABADABADQAAAGgBAGQAAABAAABQgCAJgFAHQgEAIgIAGQgJAGgLADQAAAAgBAAQgHADgLAAQgNgBgKgEQgEgBgEgCQAAgBAAAAQgMgHgCgKQAAgBAAAA");
	this.shape_96.setTransform(520,355.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("rgba(44,53,44,0.227)").ss(0.9).p("Ag9AwQAAgGACgEQARgEADADQAEAHgBACQAAAGgBAHQACABACABQAEACABAAQADACAEAAQAEABAFAAQAAAAAAAAQAFAAAFgBQACgBAAgBQAFgCADgDQACgBABgCQADgEACgEQACgDABgDQADgFAAgIQABgDAAgDQAAgHgBgGQgCgHgDgDQgDgEgDgCQgFgEgGgBQgEAAgEABQgDAAgEACQgFABgEAFQgBACgBABQgDgBgEgBQABgCABgCQAAgEABgEQAAgEABgDQAHgdAFgbQACAAACAAQAGAAAFABQAgABAfACQAAABAAAAQABAKAAAKQgBAAgCAAQgMABgNABQgUABgTABQgEASgEASQgBABAAABQgBAEAAADQAFgCAGgEQAFgDAIAAQABAAAAAAQADAAACAAQACABADAAQABABADAAQADABADACQAEABADADQACABABACQACAAACADQABACABADQACADAAADQABAHAAAHQAAABgBABQgBAKgFAJQgFAIgIAHQgJAHgMAEQAAAAgBAAQgIADgMAAQgOAAgLgFQgEgCgEgCQAAAAgBgBQgMgHgCgMQAAAAAAgB");
	this.shape_97.setTransform(519.6,355.7);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("rgba(29,36,29,0.152)").ss(0.9).p("Ag9A0QAAgGADgEQARgFAEAEQAEAIgBABQAAAIgCAHQACABACACQAEACABAAQAEABAEABQAFABAFAAQAAAAAAAAQAGAAADgBQACgBACgBQAFgCAEgDQABgCACgCQADgEACgFQACgDABgDQADgFAAgKQABgDAAgDQAAgIgCgHQgCgHgEgEQgDgDgEgDQgGgFgHAAQgFAAgEABQgEAAgEACQgGACgEAGQgCABgBAAQgEAAgEgBQABgCABgDQAAgEABgEQAAgEABgEQAGggAFgeQACAAACAAQAGAAAGAAQAiACAiABQAAAAAAABQABAKAAALQgCAAgBAAQgOABgOAAQgWABgVABQgDATgEAUQAAABgBACQAAAEgBADQAHgDAGgDQAIgEAIAAQAAAAABAAQADAAADAAQACAAADABQACABADABQADAAAEACQAEACAEADQACACACACQADADACABQABACABADQACADABAEQABAHAAAJQAAABAAABQgBALgFAKQgFAJgJAIQgJAIgNAEQAAAAgBAAQgKAEgLAAQgPAAgMgFQgFgCgEgDQAAAAgBgBQgNgIgCgNQAAAAAAgB");
	this.shape_98.setTransform(519.2,355.9);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("rgba(15,18,15,0.076)").ss().p("Ag9A4QAAgHADgEQATgFADAEQAFAJgBACQgBAIgCAIQACACACABQAFACABABQAEABAEABQAFABAGAAQAAAAAAAAQAGAAADgBQADgBACgBQAGgCADgEQACgCACgCQADgEACgFQACgEABgDQADgGAAgKQABgEAAgDQAAgJgCgHQgDgIgFgEQgDgEgEgDQgIgFgIAAQgFAAgFABQgEABgFACQgHACgFAGQgCAAgBACQgEgCgFAAQABgCABgDQAAgEABgFQAAgFABgEQAFgiAEgiQADAAACAAQAGAAAGAAQAlABAlAAQAAABAAAAQABAMAAALQgCAAgCAAQgPAAgPABQgYAAgWAAQgDAWgEAVQAAACAAABQgBAEAAAEQAHgDAHgEQAKgFAIAAQABAAABAAQADAAADABQADAAAEABQACABADABQAEABAEACQAFACAEAEQADABACADQADADACADQACABABADQADAEABAEQABAIAAAKQAAABAAABQgBAMgFALQgFALgJAIQgKAJgNAFQAAAAgBAAQgLAEgMAAQgQAAgNgGQgFgCgEgCQAAgBgBAAQgOgJgCgOQAAgBAAgB");
	this.shape_99.setTransform(518.8,356.2);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(0,173,87,0.247)").s().p("AACgcQgKAAgLAFIgQAIIAIg6IBVAAIAAgZIhhAAIgMBiIAKAEQAHgJAKgDQAKgEALAAQAPAAALAMQALAMABATQAAAPgDAKQgEAKgGAHQgFAIgIACQgHAFgIAAIgMgCIgIgDIgGgCIgEgDIAEgWQAAgEgFgEQgEgFgJAAQgGAAgFAFQgDAFAAAIQAAAPARALQAQAMAZAAQAdAAAWgTQATgUABgdQAAgRgHgMQgGgJgJgHQgJgIgLgCQgLgFgKABIAAAA").cp();
	this.shape_100.setTransform(518.8,356.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_87}]}).to({state:[{t:this.shape_88}]},39).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).wait(21));

	// 3
	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#D0DDB6").ss(0.7).p("AgMAVQgSAJgRgCQgRgCgFgLQgDgIADgHQADgHAJgIQAOgLAUgBQAUgCAcAKQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFIAAAA").cp();
	this.shape_101.setTransform(329.2,258);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("rgba(189,201,165,0.91)").ss(0.6).p("AA9gLIgBAAQgBABgBAAQgDAAgCgBQgBAAgBgBQgDgBgBAAQgCgBgCAAQgDAAgCAAQAAAAgBAAQgCABgDABQgCACgEADQgBACgCACQAAAAgBACQgBAAAAABQgBAAgCABQgCACgBACQgCACgCACQgDACgDACQgDACgCABQgBABgBABQgDABgCACQgCABgCABQgDACgDACQgFACgFABQgDAAAAAAQgMAAgIgFQgDgCgCgDQgCgDgCgEQgBgCAAgDQAAgDABgDIAAAAQABgCABAAQAFgGACgBQAEgCABAAQABgBACAAQACgBABAAQACgBACgBQADgBADgBQAEgBADgBQACgCADgBQAEgCAEgBQAAgBACgBQAAgBACAAQABgBACAAQACAAABAAQACABACAAQACAAADAAQACAAADABQAFABAGAAQAFAAAFAAQAAgBgBgBQADABABAAQAEAAACACQABABACAAQAAABACAAQABABAAABQABAAABABQADADADACQABABABABIAAAA").cp();
	this.shape_102.setTransform(328.3,258.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("rgba(172,183,150,0.827)").ss(0.6).p("Ag4AOQABgCAAgCQADgFABgBQACgCABAAQACgCACAAQABAAABAAQAAAAABAAQABAAABAAQACAAABAAQACAAADAAQAAAAAAAAQACgBACgCQABAAAAAAQACAAACgBQABgBACgBQABAAAAAAQADgCACgCQACgCABgBQABgBABgBQABgBABAAQABgBABgBQAAAAABgBQAAgBABgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAAAQABgBACAAQAAAAABgBQACABABAAQABAAAAAAQADAAACAAQADAAADAAQAAAAAAAAQAFAAAFgCQAAAAABAAQADgCADAAQABgBABAAQgBgBAAAAQABAAAAAAQABAAAAAAQABAAABABQABAAAAABQAAAAABABQAAAAAAAAQABABABAAQAAABABABQABABABABQABAAABABQABABABABQACADABABQAAAAAAABQAAABAAABQAAAAAAAAQgBAAAAAAQgBAAgBAAQgBAAgBAAQgBgBgBgBQAAAAAAAAQgCgBgBgBQgBAAAAgBQgBAAgBgBQgBgBgCgBQgCAAgBAAQgBAAAAAAQgBAAAAAAQgBABgBAAQgBACgBABQAAABgBAAQAAACgBADQAAAAAAAAQgBABAAABQAAAAgBABQAAABAAABQAAABgBABQAAABgBABQAAAAgBABQAAAAAAAAQgBACgBABQgBACgBABQgBAAAAABQgDACgDACQAAAAAAAAQgDACgDABQAAAAAAAAQgBAAAAABQgBABgBABQgBABgBACQgBACAAACQAAAAAAAAQgCACgCACQAAABgBAAQgFAEgGABQgBABgCAAQAAAAgBAAQgKACgJgDQgBgBgCgBQgDgBgCgCQgBgBgBgBQgCgBAAgCQgCgCgBgCQAAgBAAAAQgBgDgBgD");
	this.shape_103.setTransform(328,258.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("rgba(155,164,135,0.744)").ss(0.7).p("AgzAVQAAgDABgCQAEgFABgBQADAAABAAQACgBABAAQABAAAAAAQABABABAAQABAAABAAQADAAABAAQADgBADAAQAAAAAAAAQACgBADgBQABAAAAAAQADgBABgCQADgBABgCQABAAAAAAQADgBACgDQACgCABgCQAAgBAAgBQAAgBAAgBQABgBAAgBQABAAAAgBQgBgBAAgBQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQACgCACAAQAAgBAAAAQADABACAAQAAAAABAAQADAAADgBQADAAADAAQAAAAAAgBQAGgBAEgDQAAAAABgBQADgCACgCQAAAAAAgBQAAgBgBAAQABAAgBAAQAAAAAAAAQABAAAAABQABAAAAABQAAAAAAABQAAABABAAQAAAAAAABQABABABABQABABABABQAAABABABQABABABACQACACAAACQAAAAAAAAQAAABAAABQAAAAgBAAQAAAAgBAAQgBABgBAAQgBgBgBAAQgCgBgBgBQAAAAAAgBQgBgBgBgBQgBgBAAAAQAAgBgBgBQgBgBgBgBQgCgBAAAAQAAAAAAgBQAAAAgBABQAAAAAAAAQAAABgBABQAAABAAABQABACAAACQAAAAAAAAQAAABAAABQAAABAAABQAAABAAABQAAABAAACQAAABAAABQgBACgBACQAAAAAAAAQgBAAgBACQgBACgBACQgBAAAAABQgDACgEACQAAAAAAABQgDACgEABQAAAAAAAAQAAABgBAAQAAABAAABQAAACAAACQgBACAAACQAAABgBAAQgBADgBACQgBABgBABQgEAFgFADQgBABgCAAQgBAAgBABQgLACgKgCQgCgBgCgBQgDgBgDgCQgBgBgCgBQgCgCgBgBQgCgDgBgCQAAgBgBgBQgBgCAAgD");
	this.shape_104.setTransform(327.7,258.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("rgba(137,146,120,0.662)").ss(0.7).p("AgvAbQABgDAAgCQAGgFABgBQAEAAAAABQACgBABACQAAAAABABQABAAABABQABAAABgBQADABACAAQADAAADAAQAAAAABAAQADgBADgCQABAAAAAAQADgBACgCQACgBABgDQAAAAAAAAQADgDACgFQABgCABgBQABgBAAgCQABgBAAgBQAAgBgBgCQAAAAAAgBQgBgBAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQACgCABgBQABAAAAgBQADABACAAQABAAAAAAQAEAAADgBQAEAAADgBQAAgBAAAAQAGgCADgFQABAAAAgBQADgEABgCQAAgBAAAAQgBgBgBgBQAAAAgBAAQAAAAAAAAQAAAAAAABQAAABgBABQAAAAAAABQAAAAAAAAQAAABABABQAAABABABQABACABABQAAABABABQACABAAACQACADAAACQgBAAAAABQAAABgBABQAAAAAAAAQgBAAgBAAQgBAAgBAAQgCgBgBAAQgBgCgBgBQAAgBAAAAQgBgBgBgCQgBgBAAgBQAAgBAAgBQgBgCAAgBQgBgBAAAAQAAAAAAgBQAAAAAAAAQABAAABAAQAAABABABQAAABAAAAQACACABADQAAAAAAAAQAAABABABQAAABAAABQABABAAABQAAACAAACQAAABAAABQAAADAAACQAAAAAAAAQgBADgBABQgCACgBABQgBABAAABQgDADgEACQAAAAgBAAQgDADgFABQAAABAAAAQAAAAAAABQAAABABABQABABAAADQABACAAAEQAAAAAAABQgBADgCADQAAACgBABQgEAGgHADQgCACgCAAQgBABgBAAQgKAEgMgCQgCgBgDgBQgDgBgDgCQgCgBgCgBQgCgCgBgCQgDgCgBgDQgBgBAAAAQgBgDgBgE");
	this.shape_105.setTransform(327.4,258.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("rgba(120,128,105,0.579)").ss(0.7).p("AgtAYQABgEAAgCQAHgFACgBQAEABAAABQACABAAABQABABAAABQABABABAAQACABABAAQADAAACABQAEAAADgBQABAAAAAAQADAAAEgCQABAAABAAQABgCACgCQADgCACgDQABAAAAgBQADgDACgFQAAgCABgDQABgBAAgCQAAgBAAgCQAAgCgCgBQAAgBgBAAQgBgBgBgBQAAAAAAAAQgBAAAAgBQgBAAgCAAQAAAAAAAAQABgDACgCQAAAAAAAAQADAAADAAQABAAAAAAQAEAAAEgBQAEAAAEgCQAAAAAAgBQAGgDADgHQAAAAAAgBQADgFAAgDQgBgBAAgBQgBgBgCAAQAAAAgCAAQAAAAgBAAQAAAAAAAAQgBABAAABQgBABAAABQAAAAAAAAQAAABAAABQAAACABABQABABABACQAAABABABQABACABACQABADAAACQgBABAAAAQgBABgBABQAAAAAAAAQgBAAgBAAQgBAAgCAAQgCgBAAAAQgCgCgBgCQAAgBAAAAQgBgCgBgBQAAgCAAgBQAAgCAAgBQAAgCABgBQgBgCABAAQAAAAAAgBQABAAAAAAQABgBACABQABAAABABQABAAABABQADACACACQgBAAABABQAAABABABQABABAAABQABABAAABQABADABACQAAABAAACQAAADgBADQAAAAAAAAQgBADgBADQgBACgBADQgBABgBAAQgCAEgFABQgBAAAAAAQgEACgFACQAAAAAAABQAAAAAAAAQABACACABQABABABADQACADABAEQAAABgBAAQAAAEgBAEQgBACAAABQgEAHgIAFQgCACgCABQgBAAgBABQgLAFgOgCQgDgBgCgBQgEAAgEgCQgCgBgCgCQgDgCgBgCQgDgCgCgDQAAgBgBgBQgBgDgBgE");
	this.shape_106.setTransform(327.3,259);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("rgba(103,110,90,0.496)").ss(0.8).p("AgvAcQABgEABgDQAIgFACAAQAEACABABQABACAAACQAAABABACQABAAABABQABAAABABQAFABACAAQAEAAAEAAQAAAAABAAQAEgBAEgBQAAgBAAAAQADgBACgDQAEgCACgEQAAAAABgBQADgDABgIQABgDABgCQAAgCAAgCQAAgBgBgCQgBgCgCgCQAAAAgBgBQgCgBgCgBQAAAAAAAAQgBAAgBAAQgBgBgCAAQgBAAAAAAQABgDABgCQAAgBABAAQADAAADAAQABAAAAAAQAFAAAEgBQAFgBADgCQABAAAAgBQAGgEACgIQABgBAAgBQACgGgBgEQgBgBgBgBQgBgBgCgBQgBAAgCAAQgBAAAAAAQgBAAgBABQgBABgBABQgBABgBABQABAAAAAAQgBABAAABQABACAAABQABACABACQAAABABABQABACABACQABAEgBACQgBABgBAAQAAABgBABQgBAAAAAAQgBAAgBAAQgBAAgCAAQgCgBgBgBQgCgCgBgDQAAAAAAAAQgBgCAAgCQAAgCAAgCQABgBAAgCQAAgCABgCQAAgBACgBQAAgBABAAQABAAAAgBQACAAACAAQACAAACABQABAAACABQAEABACADQAAAAAAAAQACABAAACQACABAAABQABABABACQABACABACQAAACABACQAAAEAAADQAAAAAAAAQgBAEgBADQgCADgBADQgBABgBABQgDADgFADQAAAAgBABQgEABgGABQAAABAAAAQAAABAAAAQACACACABQADABACADQACAEABAEQABABAAABQAAAEgBAFQgBACAAACQgEAIgIAGQgCACgDABQgBABgBABQgOAGgOgCQgDgBgDAAQgEgBgEgCQgDgBgCgCQgDgCgCgCQgDgCgCgEQgBgBgBgBQgBgDAAgE");
	this.shape_107.setTransform(327.6,259.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("rgba(86,91,75,0.414)").ss(0.8).p("AgxAgQABgEABgDQAKgFACAAQAEACABACQABADgBADQABABAAACQABABABABQACAAABABQAFABACABQAFAAAEAAQABAAAAAAQAFgBACgCQABAAABAAQAEgCADgDQADgDADgEQAAgBABAAQADgEABgJQAAgEABgEQAAgBgBgCQAAgBgBgCQgBgDgDgCQgBAAgBgBQgCgBgDgBQAAAAgBAAQAAAAgBAAQgDAAgCAAQgBAAAAAAQAAgEACgDQAAgBAAAAQAEAAADAAQABAAAAAAQAGAAAEgBQAFgBAEgDQAAAAAAgBQAHgFACgKQAAgBAAgBQACgIgCgEQgBgCgCgBQgBgBgCgBQgCAAgCAAQgBAAgBAAQgCAAgBABQgBABgCABQgBABgBABQAAABAAAAQAAABgBABQABACAAACQABACABACQAAABABABQABACABADQABAEgCACQgBABgBAAQgBABgBABQgBAAAAAAQgBAAgBAAQgCAAgCAAQgCgBgBgBQgCgDgBgDQAAAAAAgBQAAgCAAgCQAAgCAAgCQABgCAAgCQABgCACgCQAAgCACgBQABgBABAAQABgBABAAQADgBACAAQADAAADAAQACABABAAQAFACAEADQAAAAAAAAQACABABABQABACABABQACABABACQABADABACQABACAAACQAAAEABAEQAAAAAAAAQgBAEgBAEQgCAEgCADQAAABgBABQgDAEgGADQAAAAgBABQgFADgHABQAAAAAAAAQABAAABABQACABADABQAEACACADQADAEACAFQABABAAABQAAAFgBAGQAAACgBACQgDAKgIAGQgDADgDABQgBABgCABQgOAHgQgBQgDgBgDAAQgFgBgFgCQgDgBgCgCQgDgCgDgCQgEgDgCgDQAAgCgBgBQgCgDAAgF");
	this.shape_108.setTransform(328,259.3);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("rgba(69,73,60,0.331)").ss(0.9).p("AgzAlQABgEABgEQALgFADAAQAFADAAADQAAADAAAEQAAACAAACQACABABABQABABACAAQAFACADABQAFAAAFAAQAAAAABAAQAFgBADgCQABAAABAAQAEgCADgDQAEgDACgFQABgBAAgBQAEgFAAgJQABgFAAgFQAAgCgBgDQAAAAgBgBQgCgDgEgDQgBAAgCgBQgDgBgDgBQAAAAgBAAQgBAAgBAAQgDAAgBAAQgBAAgBAAQABgEABgEQAAgBAAgBQACABAEAAQABAAAAAAQAGAAAFgBQAGgCADgDQABgBAAAAQAGgHACgMQAAAAABgBQAAgJgCgGQgCgCgCgBQgBgBgCgBQgDAAgDAAQgBAAgBAAQgCAAgCABQgCABgCACQgBAAgBACQAAAAAAAAQgBACgBABQABACAAACQABACABACQAAABABACQABACAAADQABAEgCADQgBABgBAAQgBABgCABQgBAAAAAAQgBAAgBAAQgCAAgCAAQAAgBgCgCQgCgDgBgDQAAgBAAgBQAAgCAAgDQAAgCABgCQABgCABgCQABgDABgCQABgDACgBQABAAABgBQACgBABAAQADgBAEgBQADAAAEABQACAAACAAQAGACAEADQABAAAAAAQACABABACQACABABACQACABABACQACADABADQABACABACQAAAFABAEQAAAAAAAAQgBAFgBAEQgCAEgCADQgBABAAABQgEAFgGAEQAAAAgBAAQgFAEgIACQAAABAAAAQABAAABAAQADAAADABQAFACAEAEQADAEADAGQAAABABACQAAAFAAAHQgBACAAACQgDALgJAIQgCACgEACQgBABgCABQgPAJgSgBQgEgBgDgBQgGAAgEgCQgEgCgCgBQgEgCgDgDQgEgCgCgEQgBgCgBgBQgCgEAAgE");
	this.shape_109.setTransform(328.3,259.4);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("rgba(52,55,45,0.248)").ss(0.9).p("Ag1AqQABgEABgFQANgFACABQAGAEAAADQAAAEAAAFQAAACAAADQABABABABQACABACAAQAFACADABQAGAAAFABQABAAAAAAQAEgBAFgCQACAAABgBQAEgCADgDQAEgEADgFQABgBAAgBQADgFABgLQAAgFAAgGQAAgDgBgCQgBgCgBgCQgCgCgFgCQgCgBgCgBQgDgBgEAAQAAAAgBAAQgBAAgCAAQgCgBgEAAQAAAAgBAAQABgEAAgFQAAgBABgBQADABADAAQABAAAAAAQAHAAAFgBQAGgCAEgEQAAgBABAAQAGgIACgNQAAgBAAgBQAAgLgDgGQgCgCgDgBQgBgBgDgBQgDgBgEAAQgBAAgCAAQgCABgCAAQgCACgCABQgCABgBABQgBABAAAAQgBACAAABQAAACAAACQABADABACQAAABABACQABADAAADQABAEgDADQgBABgBAAQAAACgCAAQgBAAAAAAQgBAAgBAAQgDAAgCAAQgCgBgBgCQgDgDgBgEQAAgBAAgBQAAgCABgEQAAgCABgCQABgDABgCQACgDADgDQACgCADgCQABAAABgBQABgBABgBQAEgBAEgBQAEAAAFABQACAAACAAQAIABAFAEQAAAAABAAQACABABABQADACABACQACABACACQACADACAEQABACAAADQABAEAAAFQAAAAAAAAQgBAFgBAFQgBAFgCADQgBABgBACQgDAEgHAFQgBAAAAAAQgGAEgIACQAAABAAABQABAAABABQAEAAAEAAQAGACAEAEQAEAFAEAHQAAABAAABQACAGgBAIQAAACAAADQgDAMgJAIQgDADgEACQgCACgCABQgQAJgTAAQgEgBgEAAQgGgBgFgCQgDgCgEgBQgEgCgDgDQgEgCgDgFQgBgBgBgCQgCgEAAgF");
	this.shape_110.setTransform(328.6,259.4);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("rgba(34,37,30,0.165)").ss(0.9).p("Ag3AwQABgFABgFQAOgFADABQAGAFAAAEQAAAEgBAFQAAADAAADQABABACABQACACABAAQAGACADABQAGABAGAAQABAAAAAAQAEAAAGgCQACgBABAAQAFgCADgEQAFgEADgGQAAgBABgCQADgFABgMQgBgGAAgGQgBgDgBgDQgBgCgBgCQgDgEgGgBQgBgBgDAAQgDgBgFgBQAAAAgBAAQgCAAgBAAQgDAAgFAAQgBAAAAAAQAAgGAAgFQABgBAAAAQAEAAADAAQABAAAAAAQAHAAAFgCQAHgBAFgFQAAgBAAAAQAHgJABgPQAAgBAAgBQAAgMgFgHQgCgCgDgCQgCgBgCgBQgEgBgEAAQgCABgCAAQgCAAgDABQgCABgBACQgCABgCABQAAABAAAAQgCABgBACQABACAAADQABACAAADQABABAAACQABADABADQAAAFgDADQgCABgBAAQgCACgCAAQgBAAAAAAQgBAAgBAAQgDABgCgBQgDgBgBgCQgDgEgBgEQAAgBAAgBQABgDAAgDQABgDABgDQABgCABgCQADgEADgDQADgDAEgCQABAAABgBQADgBACgBQAEgCADAAQAFgBAFAAQADAAADABQAJABAGADQAAAAAAABQADABACABQACACACACQADACABACQADADACAEQABACABADQABAFAAAFQAAABAAAAQgBAFgBAGQgBAEgCAEQgBACgBABQgEAFgHAEQgBABAAAAQgHAFgJACQAAABAAABQACAAABAAQAFACAFAAQAGABAFAFQAFAEAEAIQABABAAACQACAHAAAIQgBACAAADQgCANgKAKQgDADgEADQgCABgCACQgRAKgWAAQgEAAgEgBQgGgBgGgCQgDgBgEgCQgEgCgEgDQgEgDgDgEQgCgCgBgCQgCgEAAgF");
	this.shape_111.setTransform(329,259.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("rgba(17,18,15,0.083)").ss().p("Ag7A1QACgFABgFQAPgFADABQAHAFAAAFQgBAFgBAGQAAADgBADQACACABABQACACACAAQAGADAEABQAHABAGAAQABAAAAAAQAEAAAHgDQACAAABgBQAFgCAEgEQAEgFAEgGQAAgBABgCQADgGAAgNQAAgHgBgGQAAgDgCgDQgBgDgCgCQgDgFgGgCQgDgBgCgBQgEAAgFAAQgBAAgBAAQgBAAgBAAQgFAAgGAAQAAAAgBAAQAAgGAAgFQAAgBAAgBQAFAAAFAAQABAAAAAAQAGAAAGgCQAHgCAEgFQABgBAAAAQAHgKABgRQAAgBAAgBQgBgNgFgIQgDgDgDgCQgCgBgDAAQgFgBgFAAQgBAAgCAAQgCABgDAAQgDACgDABQgCACgCABQAAABgBAAQgBABgCACQABADAAACQABADABADQAAABABACQAAAEABADQAAAFgEADQgBABgCABQgCABgDABQgBAAAAAAQgBAAgBAAQgDAAgDgBQgCgBgCgCQgDgEAAgFQAAgBAAgBQAAgEABgDQABgDABgDQABgDACgCQADgEAEgEQADgDAFgCQABAAACgBQACgBADgCQAFgBAGgBQADgBAGAAQAEAAADAAQAKABAGAEQABAAAAAAQADACACABQADACACACQADACACACQADAEACAEQACACAAAEQACAFAAAGQAAAAAAAAQgBAGgBAGQgBAFgCAEQgBACgBABQgEAGgIAEQgBABAAAAQgHAFgKACQAAABAAABQACABACAAQAFACAFABQAIAAAGAFQAGAFAEAIQABACAAABQADAIgBAJQAAADAAACQgCAPgKALQgDADgFADQgCACgCABQgSAMgXAAQgFAAgEgBQgHAAgGgDQgEgBgEgCQgFgCgDgDQgFgDgEgFQgBgBgBgCQgDgFAAgF");
	this.shape_112.setTransform(329.5,259.4);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("rgba(17,83,46,0.247)").s().p("AA2goIACgNIgDgMQgCgIgGgHQgFgGgMgFQgKgFgRAAQgMAAgLAEQgLAEgHAGQgIAGgEAHQgDAIgBAGQAAAHAEAFQADAFAHAAQAIAAAEgEQAFgDAAgGIgEgWQACgCABgBIAGgEIAHgEIALgBQANAAAIAIQAHAJAAAQQAAAUgIALQgIAKgQAAIgMAAIAAANIASAAQAIAAAIADQAHADAEAFQAEAFABAHIACAOQAAAOgDAHQgEAJgGAGQgEAFgIADQgIADgGAAIgNgCIgJgDIgGgDIgDgDIADgUQAAgFgEgEQgDgEgJAAQgHAAgEAFIgCALQAAAIADAHQAFAHAHAFQAIAFAKADQAKAEANAAQAdAAAUgRQAVgPgBgZQAAgNgEgJQgFgJgHgFQgGgEgJgCIgQgDIAAgCQAMgDAHgGQAJgFAEgGQAEgGACgHIAAAA").cp();
	this.shape_113.setTransform(330,259.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_101}]}).to({state:[{t:this.shape_102}]},43).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).wait(18));

	// greater than
	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#D9E9C1").ss(0.7).p("AgMAVQgSAJgRgCQgRgCgFgLQgDgIADgHQADgHAJgIQAOgLAUgBQAUgCAcAKQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFIAAAA").cp();
	this.shape_114.setTransform(412.2,267);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("rgba(197,212,175,0.91)").ss(0.6).p("AAAgXQAKADARAHQAMAGAHAEQAFADADABQgOgBgGABQgLADgIAGQgIAGgGADQgDACgBABQgSAFgPgDQgSgDgGgLQgEgHABgGQACgEADgCQAYgPAUAAQAHAAAHABIAAAA").cp();
	this.shape_115.setTransform(412,266.8);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("rgba(179,193,159,0.827)").ss(0.6).p("Ag5gIQACgCACgCQAagLAWABQAKACACAAQAIAEANAIQAKAGAEADQAEAEADADQgLgDgEABQgIACgHAFQgFAFgEACQgFACAAAAQgFABgCgBQgMACgMgDQgSgFgIgKQgFgGAAgI");
	this.shape_116.setTransform(411.9,266.7);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("rgba(161,173,143,0.744)").ss(0.7).p("AgzgNQABgBADgBQAbgIAVADQANADABAAQAFAFAJAIQAHAFACAFQADAEADAEQgIgEgDABQgFABgEADQgEAEgCABQgDABAAAAQgEAAgDgBQgLABgMgEQgTgFgKgLQgGgGgBgH");
	this.shape_117.setTransform(411.8,266.6);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("rgba(143,154,127,0.662)").ss(0.7).p("AgugYQABgBACAAQAcgFAXAGQANADAAABQACAFAGAJQAEAGgBAFQAEAFACAEQgGgEAAgBQgDAAgCACQgBACgBABQgCAAABAAQgDgBgDgCQgNgBgLgEQgUgGgLgJQgHgIgCgH");
	this.shape_118.setTransform(411.8,267.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("rgba(125,135,111,0.579)").ss(0.7).p("AgtgtQABAAABABQAegBAZAHQAMAEAAABQgBAGACAKQABAHgDAHQADADACAFQgDgFACAAQAAgBAAABQAAAAABAAQgBAAACgBQgCgCgCgCQgOgCgMgFQgUgHgNgLQgHgHgEgI");
	this.shape_119.setTransform(412.1,268.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("rgba(107,116,95,0.496)").ss(0.8).p("AgogrQABABACACQAfACAaAJQANAFgBABQgEAHgCAKQgCAGgFAHQACAFACAGQAAgGAEgCQACgDADAAQACAAADgCQAAAAACgBQgBgEgCgBQgOgCgOgGQgTgIgPgMQgIgHgFgH");
	this.shape_120.setTransform(412,267.9);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("rgba(90,96,80,0.414)").ss(0.8).p("AgpgpQAAADACADQAgAFAcAKQANAGgBABQgIAJgFAIQgFAIgIAIQACAGACAGQACgGAGgEQAFgDAFgCQAEgBAEgDQACgBADgBQAAgFgCgDQgPgDgOgGQgUgIgQgMQgJgHgGgH");
	this.shape_121.setTransform(412.7,267.1);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("rgba(72,77,64,0.331)").ss(0.9).p("AgsgtQABAEABAEQAiAIAdANQANAHgBABQgLAIgJAJQgIAJgIAIQABAHACAGQADgGAIgFQAHgEAHgDQAGgDAHgDQACgCAEgCQABgFgBgFQgQgCgPgHQgUgKgSgMQgKgHgHgH");
	this.shape_122.setTransform(413.3,266.8);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("rgba(54,58,48,0.248)").ss(0.9).p("AgugxQAAAEABAFQAjALAfAPQANAIgCABQgOAIgMALQgJAJgNAJQABAHABAHQAIgHAJgGQAJgFAKgFQAHgDAIgFQAEgCAFgCQACgHgBgEQgQgFgQgHQgVgLgUgMQgKgHgJgH");
	this.shape_123.setTransform(414.1,266.8);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("rgba(36,39,32,0.165)").ss(0.9).p("Agxg3QAAAGABAFQAkAPAhARQANAIgDACQgQAIgPAMQgOAJgPAKQABAHABAIQALgIAMgGQAKgHAMgGQAJgEAKgGQAFgCAFgDQADgIAAgDQgRgHgQgJQgWgLgVgMQgLgHgKgH");
	this.shape_124.setTransform(414.8,266.7);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("rgba(18,19,16,0.083)").ss().p("Ag0g8QAAAGABAHQAlASAiASQAOAKgDABQgUAKgSAMQgRAKgSAKQABAIAAAIQAOgIAOgIQANgHAOgIQALgFAMgHQAGgDAGgDQAEgJAAgEQgRgIgRgJQgXgMgXgNQgMgHgLgG");
	this.shape_125.setTransform(415.6,266.6);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("rgba(58,144,76,0.247)").s().p("Ag2hAIAAARIBbAvIhbAwIAAARIBug7IAAgLIhug7").cp();
	this.shape_126.setTransform(416.3,266.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_114}]}).to({state:[{t:this.shape_115}]},41).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).wait(20));

	// less than
	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#DCF0C1").ss(0.7).p("AgxgFQAKAAAGACQANADAMAHQABABADACQAFAEALAHQASAJARgCQARgCAFgLQABgDAAgCQABgGgCgEQgDgHgJgIQgOgLgUgBQgUgCgcAKQgZAIgJAGIAKAA").cp();
	this.shape_127.setTransform(481,326);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("rgba(200,218,175,0.91)").ss(0.6).p("AATgdQAJABABAAQAPADALALQAHAHABAHQACAHAAADQAAADgBADQgCAKgOAEQgIABgIgBQgFgBgEgBQgQgJgHgFQgBgCgCgBQgNgIgOgDQgGgCgKgBIgJgBQAKgHAZgIQAVgIASgCIAAAA").cp();
	this.shape_128.setTransform(480.7,325.7);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("rgba(175,191,153,0.796)").ss(0.7).p("Ag2gDQAMgIAagJQASgIAQgDQAOACgBABQALAEAGALQAFAIgBAGQAAACABABQABAFABACQAAADAAACQAAALgKAEQgFACgGgBQgDAAgCAAQgFgBgDgBQgKgGgHgEQgDgCgBgCQgOgIgPgGQgGgCgLAAIgBAAIgHgD");
	this.shape_129.setTransform(480.6,325.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("rgba(150,164,131,0.682)").ss(0.7).p("AgxgCQAOgJAagKQATgJATgFQAKAFgBABQAGAFABAMQACAHgCAGQAAACAAACQACAEABACQABADABACQACALgGAEQgDADgDABQgBAAgBAAQgEABgDAAQgLgGgIgFQgEgCgCgCQgOgJgQgGQgHgEgLgCIgBAAIgGgC");
	this.shape_130.setTransform(480.1,324.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("rgba(125,136,109,0.569)").ss(0.8).p("AgugDQARgKAbgLQAUgJAUgHQAIAIgDABQABAGgCAMQgBAIgEAFQgBACAAACQACADACADQACADABACQAFAKgCAGQAAADgBABQAAABAAABQgDACgCACQgMgHgJgFQgEgDgDgCQgPgJgRgHQgIgEgMgDIgBAAIgFgE");
	this.shape_131.setTransform(479.8,324.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("rgba(100,109,88,0.455)").ss(0.8).p("AgwgEQAUgLAbgLQAVgLAVgIQAFAKgDACQgEAIgHAMQgDAHgGAGQgBABgBACQADADACACQADADACADQAHAKACAGQACAEACACQACACABABQgCADgCADQgNgHgKgFQgEgDgEgCQgQgKgSgIQgJgEgMgEIgBAAIgEgG");
	this.shape_132.setTransform(480,324.4);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("rgba(75,82,66,0.341)").ss(0.9).p("AgygEQAWgMAcgMQAWgMAXgKQACANgEACQgJAJgLAMQgGAHgIAHQgBAAgCACQAEADADACQADADADADQAKAKAFAGQAFAFAFAEQADACACABQgBAFgCAEQgNgHgLgGQgFgDgEgCQgRgLgUgIQgKgFgMgEIgBgBIgDgH");
	this.shape_133.setTransform(480.2,324.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("rgba(50,55,44,0.227)").ss(0.9).p("AgzgEQAYgNAbgOQAYgMAZgLQgBAPgGADQgNAKgQAMQgIAHgIAHQgCAAgBABQAEADACADQADADAEACQANAKAJAHQAHAFAHAFQAEACAFADQgCAGAAAFQgOgHgNgHQgFgDgEgCQgTgLgUgKQgLgFgMgFIgBgBIgCgI");
	this.shape_134.setTransform(480.4,323.9);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("rgba(25,27,22,0.114)").ss().p("Ag1gFQAagOAbgOQAagNAagMQgEARgGADQgTALgTANQgJAHgMAHQgCAAgCABQAEACAFADQAFADAEADQANAJANAIQAKAGAJAFQAGADAGADQgBAIAAAGQgPgHgOgIQgFgDgFgCQgUgLgVgLQgMgGgMgFIgBgBIgBgL");
	this.shape_135.setTransform(480.6,323.6);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("rgba(113,191,86,0.247)").s().p("Ag3AGIBvA7IAAgRIhbgwIBbgvIAAgRIhvA6IAAAM").cp();
	this.shape_136.setTransform(480.8,323.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_127}]}).to({state:[{t:this.shape_128}]},51).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).wait(13));

	// +
	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#DBECAE").ss(0.7).p("AAZgTQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFQgSAJgRgCQgRgCgFgLQgDgIADgHQADgHAJgIQAOgLAUgBQAUgCAcAKIAAAA").cp();
	this.shape_137.setTransform(387.2,175);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("rgba(199,215,158,0.91)").ss(0.6).p("AAVgQQAXAGAKAFQABABABABQgDAAgCAAQgNgBgIADQgHABgHACQgFADgFAFQgHAHgGAGQgEACgDABQgBAAgBABQgPAFgPgEQgRgDgGgJQgCgDgBgDQAAgFABgFQAFgGAKgHQAUgMAMgDQANgBAFABQALAEAQAIIAAAA").cp();
	this.shape_138.setTransform(387.2,174.9);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("rgba(179,194,142,0.819)").ss(0.6).p("Ag/AKQAAgEADgFQARgMACAAQARgNAJgFQAAAAABAAQAFAAAEAAQAFAAABABQAKAFAMAIQACABADAAQASAFALADQADACACACQABABABAAQAAABAAAAQgDAAgDAAQgNgBgJABQgDAAgCABQgEACgEACQgFAEgFAFQgEAFgEAEQgDADgCACQAAAAAAAAQgDABgDABQAAAAgBAAQgLABgJgCQgEgBgFgBQgPgCgIgGQgBgBgBgCQgBgDgBgD");
	this.shape_139.setTransform(386.3,174.7);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("rgba(159,172,126,0.728)").ss(0.7).p("Ag+AJQABgEADgEQATgKACgBQAPgOAIgHQABAAAAAAQAFgBAFAAQADABACACQAIAHALAJQADAAACABQATAEAMADQADACACACQAAABABAAQAAAAAAAAQgDAAgDAAQgNAAgKABQgDABgCAAQgEADgEADQgEAFgEAFQgEAFgEAFQgDACgCACQAAABgBAAQgDAAgCgBQAAAAgBAAQgJgBgJgEQgEAAgFgBQgPgCgKgGQAAgBgBgCQgCgCAAgE");
	this.shape_140.setTransform(386.1,174.6);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("rgba(139,151,111,0.637)").ss(0.7).p("Ag+AHQADgDADgEQAVgJACAAQANgQAHgJQABAAAAAAQAFgBAFAAQACACACACQAIAIAKALQACAAADABQATADANADQACADACACQABAAABAAQAAAAAAAAQgEAAgDABQgOgBgLACQgDAAgCABQgEADgDAEQgEAFgDAGQgEAFgCAGQgEACgCABQgBABAAAAQgDgBgCgBQAAAAgBAAQgIgDgHgGQgFgBgFgBQgQgBgKgFQgBgBgBgCQgBgDgBgE");
	this.shape_141.setTransform(386,174.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("rgba(119,129,95,0.546)").ss(0.8).p("Ag9AFQADgDAEgCQAXgIACgBQALgQAGgNQAAAAABAAQAGAAAFAAQABADACACQAGAKAJAMQACAAADABQAUADAOACQACADACACQAAAAABABQAAAAAAAAQgEAAgDABQgOgBgMACQgDAAgDAAQgDAEgCAFQgEAFgDAGQgDAGgCAGQgFACgCACQAAAAgBAAQgCgBgCgCQAAAAgBgBQgHgFgGgIQgFAAgFgBQgQgBgMgFQgBgBAAgCQgCgDAAgE");
	this.shape_142.setTransform(385.8,174.7);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("rgba(100,108,79,0.455)").ss(0.8).p("Ag8ADQADgDAFAAQAZgIABAAQAKgSAFgPQAAAAABAAQAGAAAEAAQACADACAEQAFALAHANQADAAADABQATACAQACQACADABACQABABAAABQAAAAAAAAQgEAAgDAAQgPAAgNABQgDABgDAAQgCAFgCAEQgDAGgDAHQgCAHgCAGQgFACgCABQgBAAgBAAQgCgCgBgCQAAgBgBgBQgGgHgFgKQgFAAgFAAQgRgBgNgEQgBgCAAgBQgBgEAAgE");
	this.shape_143.setTransform(385.7,174.7);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("rgba(80,86,63,0.364)").ss(0.8).p("Ag8ABQAFgBAFgBQAbgGABgBQAIgTAEgRQAAAAABAAQAGAAAEAAQACAEABAEQAFANAFAOQADAAADAAQAUACASACQABADABACQAAABABABQAAABAAAAQgEAAgEAAQgQAAgNABQgDAAgDAAQgCAGgCAFQgCAHgCAHQgCAHgCAHQgFABgDABQgBAAAAAAQgCgCgBgDQAAgBgBgCQgEgJgEgLQgGAAgFgBQgSgBgOgDQAAgBgBgCQAAgEgBgE");
	this.shape_144.setTransform(385.6,174.7);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("rgba(60,65,47,0.273)").ss(0.9).p("Ag7AAQAFgBAHgBQAbgFACAAQAGgVADgTQAAAAABAAQAGAAAEAAQACAEABAFQADAOAEAQQADAAAEAAQAUACATABQABAEAAACQABABAAABQAAABAAAAQgEAAgEAAQgQAAgPABQgDAAgDAAQgBAGgCAGQgBAHgCAHQgBAIgCAIQgFABgDAAQgBAAgBAAQgBgDgBgDQAAgCAAgBQgEgMgDgNQgGAAgGAAQgRgBgQgCQAAgCAAgCQgBgEAAgD");
	this.shape_145.setTransform(385.4,174.7);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("rgba(40,43,32,0.182)").ss(0.9).p("Ag6gBQAGgBAHgBQAdgDACgBQAEgWACgWQAAAAABAAQAHAAAEAAQABAGABAFQACAQADARQADAAADAAQAVABAUABQAAAEABACQAAACAAABQAAAAAAABQgEAAgEAAQgQAAgQAAQgDAAgEAAQgBAHgBAHQgBAHgBAIQgBAIAAAIQgGABgEABQgBAAgBAAQAAgEgBgFQAAgBAAgCQgDgOgCgOQgGAAgGgBQgSAAgQgCQgBgBAAgCQAAgEAAgD");
	this.shape_146.setTransform(385.3,174.8);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("rgba(20,21,16,0.091)").ss().p("Ag6gDQAIgBAHAAQAfgCACAAQACgYABgYQABAAAAAAQAGAAAFAAQABAGAAAGQABASACASQADAAAEAAQAVAAAVABQAAAEAAADQABABAAACQAAAAAAABQgFAAgEAAQgRAAgRAAQgDAAgDAAQgBAHAAAHQgBAIAAAIQgBAJAAAJQgGABgEAAQgBAAgBAAQgBgFAAgFQAAgCAAgCQgBgQgBgQQgHAAgGAAQgSAAgSgBQAAgCAAgCQgBgEAAgD");
	this.shape_147.setTransform(385.1,174.8);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("rgba(114,191,88,0.247)").s().p("Ag5gGIAAAMIAzAAIAAA0IANAAIAAg0IAzAAIAAgMIgzAAIAAgzIgNAAIAAAzIgzAA").cp();
	this.shape_148.setTransform(385,174.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_137}]}).to({state:[{t:this.shape_138}]},45).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).wait(17));

	// equal sign
	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#BFDEAF").ss(0.7).p("AA5gPQgOgLgUgBQgUgCgcAKQgZAIgJAGIAKAAQAKAAAGACQANADAMAHQAFADAPALQASAJARgCQARgCAFgLQADgIgDgHQgDgHgJgIIAAAA").cp();
	this.shape_149.setTransform(563,270);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("rgba(174,202,159,0.91)").ss(0.6).p("ABGAIIAAAAQAAAEgCAEQgGAKgQACQgRACgRgIQgPgKgGgDQgLgIgOgBQgDgBgFgBQgDAAgEgBIgJAAQADgCAEgCIgHAAQAJgGAYgHQAcgJAUACQAUABAOAKQANARAAADQAAACAAABIAAABQgBACgBACQgGAKgQACQgRACgRgIQgPgKgGgDQgLgGgOgDQgDgBgGgBQgCAAgEAAIgCgBQAKgEAQgFQAcgJAUACQAUABAOAKQACADACACQAIALABAD");
	this.shape_150.setTransform(563,269.8);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("rgba(163,189,149,0.853)").ss(0.6).p("Ag7gFQAKgGAXgHQAbgIAVABQATACAOAJQANARAAACQAAAGAAABQgIAOgQACQgRACgRgIQgOgJgGgDQgMgHgNgDQgEAAgEAAQgDAAgEgBIgJAAQADgCAEgBIgHgBAg7gIQAKgGAXgGQAbgJAVACQATABAOAKQANARAAACQAAAFAAACQgBACgBACQgGAJgQADQgRABgRgIQgOgJgGgDQgMgHgNgBQgEgBgEAAQgDgBgEAAIgIAAQACgDAEgBIgHgB");
	this.shape_151.setTransform(563.2,269.7);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("rgba(152,177,139,0.796)").ss(0.7).p("Ag7gEQAKgFAXgGQAagIAVABQATABAOAJQANAQAAACQAAAGAAABQgJANgPACQgRABgRgHQgNgIgHgDQgLgGgOgEQgDAAgEgBQgDAAgEAAIgJAAQACgBAEgCIgGgBAg7gJQAKgGAXgGQAagIAVACQATABAOAJQANARAAABQAAAGAAABQgBACgBACQgHAJgPACQgRABgRgHQgNgJgHgCQgLgGgOgCQgDgBgEAAQgDgBgEAAIgIAAQABgCAEgCIgGgB");
	this.shape_152.setTransform(563.3,269.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("rgba(141,164,129,0.739)").ss(0.7).p("Ag7gDQAKgFAWgFQAbgIAUACQATABAOAIQANAPAAADQAAAFAAABQgJAMgPACQgQABgRgGQgOgIgHgDQgLgGgNgDQgDAAgFgBQgCAAgEgBIgJAAQACgBAEgBIgGgBAg7gLQAKgEAWgGQAbgHAUABQATABAOAIQANARAAABQAAAFAAABQgBACgBACQgHAIgPACQgQABgRgGQgOgIgHgDQgLgEgNgDQgDAAgFgBQgCAAgEgBIgIAAQABgCAEgCIgGgC");
	this.shape_153.setTransform(563.3,269.4);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("rgba(131,152,119,0.682)").ss(0.7).p("Ag7gBQALgFAVgFQAbgHATABQATABAOAIQANAOAAADQAAAFAAABQgJALgPACQgQABgRgGQgNgHgHgDQgLgFgNgDQgEgBgEAAQgDAAgDgBIgJAAQACgCADgBIgFgBAg7gMQALgEAVgGQAbgGATABQATABAOAHQANARAAACQAAADAAACQgBACgBABQgHAIgPABQgQACgRgGQgNgIgHgCQgLgEgNgCQgEgBgEgBQgDAAgDAAIgIAAQABgDADgCIgFgC");
	this.shape_154.setTransform(563.4,269.3);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().s("rgba(120,139,109,0.625)").ss(0.7).p("Ag7AAQALgEAVgFQAbgGATABQASABAOAHQANANAAADQAAAFAAABQgKAKgOACQgQABgQgFQgNgHgIgCQgLgFgNgDQgDgBgEAAQgDAAgDgBIgJAAQACgCADgCIgFgBAg7gNQALgEAVgFQAbgGATABQASABAOAHQANAPAAADQAAADAAABQgBACgBACQgIAGgOACQgQABgQgGQgNgHgIgCQgLgDgNgCQgDgBgEAAQgDgBgDAAIgIAAQABgDADgCIgFgC");
	this.shape_155.setTransform(563.5,269.2);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("rgba(109,126,99,0.569)").ss(0.8).p("Ag7AAQALgCAVgFQAagFATABQASABAOAGQANAMAAADQAAAFAAABQgKAJgOACQgQABgQgFQgMgGgIgCQgLgFgNgCQgDgBgEAAQgDAAgDgBIgJAAQACgCADgDIgFgCAg7gOQALgEAVgEQAagGATABQASABAOAGQANAOAAADQAAADAAABQgBACgBACQgIAGgOABQgQABgQgFQgMgGgIgCQgLgDgNgCQgDgBgEAAQgDAAgDgBIgIAAQABgCADgDIgFgC");
	this.shape_156.setTransform(563.5,269.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("rgba(98,114,89,0.512)").ss(0.8).p("Ag6ABQALgCAUgDQAagGATABQARABAPAGQANALAAADQAAAFAAABQgLAJgOABQgQABgQgFQgLgFgIgCQgMgEgMgCQgDgBgEAAQgDAAgDgBIgIAAQABgCADgDIgEgDAg6gQQALgDAUgEQAagFATABQARABAPAFQANAOAAADQAAAEAAAAQgBABgCACQgIAFgOABQgQABgQgEQgLgGgIAAQgMgEgMgCQgDAAgEgBQgDAAgDAAIgIAAQABgDADgDIgEgD");
	this.shape_157.setTransform(563.6,268.9);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("rgba(87,101,80,0.455)").ss(0.8).p("Ag6ACQAMgCATgCQAZgFATABQASABAOAFQANAKAAADQAAAFAAABQgLAIgOABQgPABgQgEQgLgFgJgCQgLgEgMgBQgDgBgEAAQgDAAgDgBIgIAAQABgCACgDIgDgDAg6gRQAMgDATgDQAZgFATABQASABAOAFQANAMAAADQAAAFAAABQgBAAgCABQgIAEgOACQgPAAgQgEQgLgDgJgBQgLgEgMgCQgDAAgEAAQgDgBgDAAIgIAAQABgDACgDIgDgD");
	this.shape_158.setTransform(563.6,268.8);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("rgba(76,88,70,0.398)").ss(0.8).p("Ag6AEQAMgDATgBQAZgEATABQARAAAOADQANALAAADQAAAFAAACQgLAGgOABQgPABgPgEQgMgEgIgCQgLgDgMgBQgEgBgDAAQgDAAgDAAIgIAAQABgDACgDIgDgEAg6gSQAMgDATgDQAZgEATABQARABAOAEQANALAAAEQAAAFAAABQgBABgCAAQgIADgOABQgPABgPgEQgMgCgIgBQgLgEgMgBQgEgBgDAAQgDAAgDAAIgIAAQABgEACgCIgDgE");
	this.shape_159.setTransform(563.7,268.7);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("rgba(65,76,60,0.341)").ss(0.9).p("Ag6AFQANgCASgDQAYgBATAAQARABAPACQANAKAAADQAAAFAAACQgNAFgNABQgPAAgPgDQgLgDgIgBQgMgDgMgCQgDAAgDAAQgDAAgDAAIgIAAQABgDACgDIgDgEAg6gTQANgDASgCQAYgEATABQARABAPADQANALAAADQAAAFAAABQgCABgCABQgJABgNABQgPABgPgCQgLgDgIgBQgMgDgMgBQgDAAgDgBQgDAAgDAAIgHAAQAAgEACgCIgDgE");
	this.shape_160.setTransform(563.7,268.5);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().s("rgba(54,63,50,0.284)").ss(0.9).p("Ag6AGQANgCASgCQAYgCATAAQAQAAAPAEQANAJAAAEQAAAEAAACQgNAEgMABQgPAAgPgCQgLgDgJgBQgLgDgMgBQgDAAgDAAQgDAAgDAAIgIAAQABgDACgEIgDgEAg6gVQANgBASgDQAYgCATAAQAQABAPADQANAJAAAEQAAAFAAAAQgCABgBABQgKADgMAAQgPAAgPgBQgLgDgJgBQgLgDgMgBQgDAAgDAAQgDAAgDgBIgHAAQAAgDACgDIgDgF");
	this.shape_161.setTransform(563.8,268.4);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("rgba(44,51,40,0.227)").ss(0.9).p("Ag5AIQANgCARgCQAXgCATABQARAAAOACQANAJAAAEQAAAEAAACQgNADgMABQgPAAgPgCQgKgCgJgBQgLgCgMgBQgDAAgDAAQgDAAgDAAIgHAAQAAgEABgDIgBgFAg5gWQANgBARgCQAXgCATAAQARAAAOADQANAIAAAEQAAAFAAABQgBAAgCABQgKACgMABQgPAAgPgCQgKgCgJgBQgLgCgMgBQgDAAgDAAQgDAAgDAAIgHAAQAAgEABgDIgBgF");
	this.shape_162.setTransform(563.8,268.3);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("rgba(33,38,30,0.171)").ss(0.9).p("Ag5AJQANgBARgBQAXgCATAAQAQABAPABQANAIAAAEQAAAFAAABQgOACgMABQgOAAgPgBQgKgCgJgBQgLgBgMgBQgDAAgDAAQgDAAgDAAIgHAAQAAgEABgDIgBgFAg5gXQANgBARgBQAXgCATAAQAQAAAPACQANAIAAAEQAAAEAAABQgCABgCAAQgKACgMAAQgOABgPgCQgKgCgJAAQgLgCgMAAQgDgBgDAAQgDAAgDAAIgHAAQAAgEABgDIgBgF");
	this.shape_163.setTransform(563.9,268.2);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("rgba(22,25,20,0.114)").ss().p("Ag5AKQAOAAAQgBQAWgBAUAAQAPAAAPABQANAHAAAEQAAAFAAABQgOABgMABQgOAAgOgBQgKgBgKgBQgLgBgLAAQgDAAgDAAQgDAAgCAAIgIAAQABgEAAgDIgBgGAg5gYQAOgBAQgBQAWgBAUAAQAPAAAPACQANAGAAAEQAAAFAAAAQgCABgCAAQgKABgMABQgOAAgOgBQgKgBgKgBQgLgBgLAAQgDAAgDAAQgDAAgCgBIgIAAQABgEAAgDIgBgF");
	this.shape_164.setTransform(563.9,268);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("rgba(11,13,10,0.057)").ss().p("Ag4AMQAOgBAPAAQAWgBATABQAQAAAPAAQANAGAAAEQAAAFAAABQgPABgLAAQgOAAgPgBQgJAAgKAAQgLgBgLAAQgDAAgDAAQgDAAgCAAIgHAAQAAgEAAgEIAAgFAg4gaQAOAAAPAAQAWgBATAAQAQAAAPABQANAFAAAFQAAAEAAABQgCAAgCAAQgLABgLAAQgOAAgPAAQgJgBgKAAQgLgBgLAAQgDAAgDAAQgDAAgCAAIgHAAQAAgEAAgEIAAgG");
	this.shape_165.setTransform(564,267.9);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("rgba(0,124,69,0.247)").s().p("AA5ANIhxAAIAAAPIBxAAIAAgPAA5gbIhxAAIAAAOIBxAAIAAgO").cp();
	this.shape_166.setTransform(564,267.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_149}]}).to({state:[{t:this.shape_150}]},40).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).wait(16));

	// %
	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().s("#D8E0AA").ss(0.7).p("AAZgTQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFQgSAJgRgCQgRgCgFgLQgDgIADgHQADgHAJgIQAOgLAUgBQAUgCAcAKIAAAA").cp();
	this.shape_167.setTransform(439.2,178);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("rgba(196,204,155,0.91)").ss(0.6).p("AALgYQABAAACABQAAAAABAAIACAAQACABACAAQgEgCgGgCQgQgGgOgCQgJgBgIABQgLABgWAMQgJAIgDAIIAAABQgCAGADAHIAAABQAAgDAAgDIAAAAQAAgEABgCQAAgBAAgBIAAgBQADgIAIgHQAbgNAFAAQAIgBAKABQANACAPAGQAAABABAAQABAAABABIABAAQAFACAFABAARgXQADABACAAIgBAAQAEABADABIAQAEQAAABABAAQgEAAgDABQADACABABQgBAAgBAAQABABAAAAQgBAAgBAAQAHADADADQABABAAAAQgBAAgBAAAAUgSQAEACAEABQACABADABQABAAACgBIgMgGQgFgBgGgCQgUgFgRABQAGAAAGABQANABARAHQABAAABAAIAAAAAAVgJQACAAAEgBQgDABgDAAQAAAAAAAAIAAAAAASgIQACAAABgBQACAAABgBQAEgBADgCQgFgCgHgCQgBAAgBgBQgQgGgMgBQgJgCgIABQgGABgaAMQgJAHgCAHIgBABQgCAHADAHQABABAAABQAFADAHABQAAAAABAAQAOACAPgHQABAAACgBQAJgEAMgKQAJgFAMgFIABAAAhGASQABABABABQACABADAAQACABACABQAPACATgIQAJgFANgJQADgCABgBQAFgBAEgDQAEgCAEgCIADgBQgCABgBAAAAKgEQgCACgDACQADgCAEgCQgBAAgBAAIAAAAAASgIQgDACgDACQADgCAEgBQAEgCAJgBIgFAAAACAJQgKAKgKAEQgRAIgNgCIgEAAQgDgBgCgBQgCAAgDAAQAEABAEABQABABACAAQAPACAQgHQABAAABgBQAKgEAQgOQAJgFAJgBQAHgDAPAAQgPgBgIADQgMADgLAHIAAAAAAmgOIAAAAQgBAAgBAAQACACACABQgBAAgBABQgCgCgDgBAAngKQgBAAgBAAQAHADAEAEAAngKQgBAAAAAAIAAAAQgBAAgBAAIABAAQgCAAgCAAIgBAAAAmgKQgDgCgDgBQAAAAgBAAQADACACABQgBAAgCAAAAcgPQACABACABIABAAAAcgUQgDgBgDgBQAKAEAGAEAhQAEQAEgHAJgIQANgKARgEQAFgBADgBQACAAABAAIABAAQAAAAABAAAglgZQACAAACgBQAEAAADgBAhEAUQABACACABIAEACQACACADAAQAAAAABAAQAQAAASgKQAKgGALgKIAFgBAhQAEQABACABACIAAABQACAEAEADQgCgDAAgEIAAgEQABgCAAgCIAAAAQADgHAJgIQAPgIAJgDAhQAKQADAFAGADQgBAAAAgCIAAAAAhIAQIAAAAIAAAAAhGASQgBgBgBgBQgCgDAAgEAhHASQABABACABAhQAKQABADABAFQAFAHALACQgGgDgDgGAg0AdQgDgBgBgBIgBAAQgCAAgCgC");
	this.shape_168.setTransform(440.2,178.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().s("rgba(172,179,136,0.796)").ss(0.7).p("AhXgHQADgJAIgHQAZgNAGgBQAHgBAJABQAGAAAHACQAIABAIAEQAOAEACACQACAAACABQAFACAGABQAAABABAAQgDABgDABQACACACABQgBABgBAAQAAAAgBAAQAGAEADADQAAAAABAAQgBAAgBAAQgNABgGAEQgJACgHAFQgQANgKAEQgBAAgBABQgCAAgBABQgOAFgOgDQgBAAgBgBQgEgBgEgBQAAAAgBAAQgKgDgDgGQgCgEAAgEQgBAAAAAAQgDgHACgGQAAgBAAAAAhVAPQADgBADAAQAGgCAIgDQADgBABAAQAAAAABAAQgKADgHACQgDABgDACQgBgBAAAAAhTAAQACgGAIgIQAOgJAGgBQAGgBAGgBQgMAIgKAGQgBAAAAABQgFAFgEAFQgBABgBABQgBACgBACQAAABAAACQAAAAgBAAQAAACABADQgDgEgCgEQgBgCAAgCAhGALQABgCAAgCQANgRADgBQAKgGAJgDQAHgBAEAAQAHAAAGAAQAKABAIAEQAFACAGADQAGACADACQACABACABQgEAAgCgBQgDgBgDgBQgBAAAAAAQgPgDgKAAQgKgBgIABQgEABgKAEQgHACgKAEQgHADgEAFQAAACgBABQAAABAAAAQgCAGACAFQAAAAABABQgCgBAAgBQgCgEAAgDQAAgCAAgBAhAAWQAAABABABQARACAKgEQAQgGAEgCQAHgEAHgDQACgCACgBQAEgCAEgCQAEAAADAAQABgBABAAQgBABgBAAQAAAAgBAAQgLAEgHAHQgBABgBABQgJAHgHAEQgCAAgBABQgCAAgBABQgHACgFAAQgIABgHgCQgBAAAAAAQgGgCgEgDAg/AYQACABADAAQAbgEAIgEQACAAACgBQAHgDAHgEQACgBACgBQABgBACgCQAEgBAEgCQgDADgBABQgDACgCACQgEAGgGAEQgFAEgFADQgDABgDABQgJAEgHABQgFAAgFgBQgBAAAAAAQgCgBgCgBQgCgBgCgBQgCgCgBgCAg5AeQACAAACAAQARACANgGQAMgGAIgFQALgIAHgDQAEgBAEgBQAHgCANACQgOABgFAEQgHADgHAEQgKAJgIAEQgFADgEACQgBAAgBAAQgFACgEABQgKACgKgDQgBAAgBgBQgEgBgDgCAg0AfQAAAAABAAQAOgCAQgKQAUgOABgBQAHgEAEAAQABAAACgBQABAAACgBQAEgBAIAAQABAAAAAAQACAAABAAQAHADADACQgNABgHADQgFADgFADQgGADgGAEQgBACgDACQgIAFgHACQgDABgCABQgNAEgJgDQgCAAgCgBQgCgBgBAAAgjgPQABgCADgBQAFgCACABQACABABABQgCADgCABQgBABgCAAQgDAAgBgBQgCAAgBgCAgYgQQAFgBAGgBQANAAAFACQAMAEAAAAQAFADAEACQACABACACQACAAABgBQgGgBgFgCQgDgBgCAAQgCAAgDgBQgEAAgFgBQgEgBgGgBQgKgCgHgBAAHABQACgBADgCQAFgDAAAAQADAAADABQAEABACABQgDACgDAAQgDABgDABQgBAAgCAAQgBABgBgBQgDAAgCAAAAIgNQABgBAAAAQAEgCACAAQACAAACACQACABABADQgBABgBABQgCAAgCAAQgCAAgBgCQgCgBgBgCAAJgNQAAgBABAAQAGgBAAAAQADAAACABQAEABADACQAEACACADQgBABgBABQgCAAgCAAQgDAAgDgBQgCgBgBgBQgCAAgBgBQgDgDgEgCAAPgBQACgCABgCQAIgDACABQADACACADQgBABgCABQgCAAAAAAQgCAAgDAAQgDAAgBAAQgCAAgCAAAAQgMQADgBADgBQAJABADACQADABADADQgCADgDABQgDABgDgBQgDgBgDgDQgEgCgDgDAAdgCQABgBABAAQAEgBACABQAGADABAAQAAABABABQAAAAAAAAQgBABgBAAQgBAAgBAAQgCAAgDAAQgCgBgCgBQgCgBgBgB");
	this.shape_169.setTransform(440.7,178);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("rgba(147,153,116,0.682)").ss(0.7).p("AhSgUQACgIAHgIQAXgNAFgBQAIgCAIABQAGABAGABQAJABAIADQAMAFADACQABAAACAAQAEADAFACQABAAAAAAQgCABgCACQACACABACQAAAAgBAAQAAABgBAAQAFADADADQAAABAAAAQgBAAAAAAQgMACgFAEQgHAEgIAFQgPALgKAEQgBAAgBAAQgCABAAAAQgOAFgNgEQgCAAAAAAQgEgBgDgCQgBAAAAAAQgKgDgDgGQgCgCAAgEQgBAAAAAAQgCgHACgHQAAgBAAAAAhQAQQAFgEAEgDQAMgJAMgGQAFgEAAAAQACAAABAAQgNAJgMAHQgHAEgFAGQgCAAgBAAAhNgMQACgJAHgHQAQgKAGABQAFgBAFABQgKAKgJAGQgBABAAAAQgFAGgEAEQgCACgBACQgBABgBABQgBACAAAAQAAABAAAAQgBABABAAQgDgCgCgFQgBgCAAgCAg4AHQAAgCABgCQAMgRACgBQALgHAIgCQAHgCAEAAQAHAAAEABQAKABAJAEQAFADAGACQAFADADADQABABACABQgDAAgCgBQgCAAgDAAQgBAAAAAAQgNgBgMABQgHABgIABQgEABgKADQgHACgKABQgHAEgDAEQgBABAAABQAAAAgBABQgCAEACADQAAABAAAAQgBgBgBgBQgBgDAAgEQAAgCAAgBAgxARQABAAAAABQAPAAAJgEQAPgHAEgCQAFgDAHgCQADAAACAAQAEgBAEAAQADgBADgBQABAAABAAQgCABAAAAQAAABgBAAQgJAEgJAIQgBAAgBABQgGAHgIADQgBABgBAAQgCABgBAAQgGABgGAAQgHAAgGgDQAAAAgBAAQgFgCgEgDAgwASQACABACAAQAZgIAHgDQACgBADAAQAHgDAFgCQABAAACgBQACgBADAAQAEAAADAAQgDACgBABQgCACgCACQgGAGgFAFQgDAEgEACQgDABgDABQgJAEgHgBQgFAAgEgCQgBAAAAAAQgCgBgCgCQgBgBgCgBQgBgCgCgCAgrAXQACAAACAAQAPgBALgFQALgHAGgEQANgGAHAAQADgBADAAQAHgBAMACQgMABgFAEQgHAEgGAEQgLAJgIADQgDADgEABQgBAAgBAAQgEABgEABQgJAAgJgDQgBAAgBgBQgDgCgCgCAgnAYQABAAAAAAQANgDAOgKQARgLACgBQAIgEAEgBQABAAABAAQACAAACAAQADgBAHABQABAAAAAAQABAAACAAQAFAEADACQgLACgHADQgEADgFADQgFAEgFADQgEACgDACQgGAEgGABQgDABgCAAQgLADgIgEQgCgBgBAAQgCgBgCgBAgYgPQACgDACgDQAIgDACACQACACACADQgCAFgCACQgCADgDgBQgEAAgCgCQgCgCgBgCAgPgQQAFgCAFgBQAKgDAIABQAMAGAAAAQAFADADADQACABACACQACAAAAAAQgEAAgGAAQgCAAgCAAQgCAAgDgBQgEABgEgBQgIgBgEgCQgIgDgHgDAAMAAQACgEADgDQAGgEAAAAQAEAAADACQAEADACACQgCAEgEABQgDACgDABQgDAAgBAAQgCAAgBgBQgDgBgCgCAANgOQAAAAAAAAQAGgGADAAQADAAACADQACACABAEQgBAEgCABQgBACgEAAQgDgBgBgCQgDgDgBgEAANgOQABAAAAAAQAGgFABAAQADgBADABQAEABAEADQADAEADAEQgBACgBABQgCABgDABQgCABgEgBQgDAAgCgCQgBgBgBgBQgEgDgEgFAATgDQABgEACgDQAKgDADACQADADACAEQgCADgBABQgCAAgBAAQgCADgEgBQgEAAgBgCQgDAAgBgCAATgMQADgDADgCQAMgBADADQADADACAEQgBAFgEACQgDABgEAAQgEgBgDgDQgEgEgDgEAAfgEQAAgBABgCQAFgDADABQAIAFABACQAAABABABQAAAAAAAAQgBABgBABQgBABgCABQgCABgDgBQgEAAgCgDQgCgBgBgC");
	this.shape_170.setTransform(440.2,178.7);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().s("rgba(123,128,97,0.569)").ss(0.8).p("AhMgWQACgJAHgHQAVgOAFgCQAGgBAJAAQAFAAAGABQAIABAHADQAMAFADACQABABACAAQAEACAFACQAAABAAAAQgBACgCABQACACABACQAAABgBAAQAAABgBAAQAFADACADQAAABAAAAQAAAAgBAAQgJADgFAFQgHAFgHAFQgNAKgMADQgBAAgBAAQgBABgBAAQgNAEgMgEQgBAAgBgBQgEgBgDgBQAAAAgBgBQgIgDgDgEQgCgDgBgEQAAAAAAAAQgCgHABgHQAAgBAAAAAhIAaQAGgGAHgGQAQgOAQgNQAHgHABAAQACAAADAAQgSAPgRANQgJAJgJAJQgCAAgCAAAhEgQQABgKAHgIQARgJAGACQAFABAEACQgIALgIAHQgBABAAAAQgFAGgGAEQgBABgBACQgCABgBABQgBABAAAAQgBAAAAAAQgBAAABABQgDgEgBgFQgBgCAAgCAgoANQAAgCABgCQALgSADgBQAJgHAJgDQAHgBACAAQAHAAAGABQAJABAJAFQAFADAFADQAEADADADQACABABABQgDAAgBAAQgCAAgCAAQgBAAAAAAQgLABgLADQgJABgIABQgFABgHADQgIACgJACQgGACgEADQgBABAAAAQAAABgBAAQgCADABACQAAAAAAAAQgBgBgBgBQgBgEAAgDQAAgCAAgCAgfAVQABAAAAABQANgDAIgFQAMgHAEgBQAHgDAHAAQADgBABAAQAEAAADAAQADAAACAAQABAAABABQgBABgBAAQAAAAAAABQgIAHgIAHQgBABgBABQgHAHgIADQgCAAgBABQgBAAAAAAQgGABgFgBQgGgCgFgDQgBAAAAAAQgFgDgDgDAgeAWQACAAABAAQAWgLAFgDQACAAADgBQAHgCAHAAQABAAACAAQACAAACgBQADABADAAQgCAEgBABQgCACgBACQgFAHgFAEQgFAFgEACQgDABgDABQgHADgHgCQgEgBgEgCQAAAAgBAAQgBgCgCgBQgBgCgBgBQgCgCgBgCAgaAaQACAAABAAQANgDAKgGQAIgHAIgEQANgFAGAAQADAAADABQAFAAAKAEQgKADgEAFQgFADgGAFQgKAJgIACQgFACgEABQgBAAgBAAQgCABgDgBQgJAAgHgFQgBAAAAgBQgDgBgCgDAgWAbQAAAAAAAAQALgFALgJQASgNACAAQAIgBADgBQABAAABAAQACAAABABQAEAAAGABQAAAAAAAAQACAAABAAQAEADADADQgJAEgGAEQgEADgEADQgFAEgFADQgEACgDABQgHAEgHAAQgCAAAAAAQgKABgHgEQgBgBgCgBQgBgBgBgBAgKgFQABgFADgEQAIgEADADQACADACAFQgCAGgCACQgDADgCAAQgFgBgBgCQgDgBgBgFAgCgGQACgDAEgCQALgGAIACQANAGAAAAQAFAEADADQABACACAAQABABAAAAQgEACgEAAQgCAAgCABQgCAAgDAAQgEABgFAAQgHgBgGgDQgIgCgDgFAAUAGQABgGAEgCQAHgFAAAAQAFAAADADQAEAEACACQgCAGgEADQgDAEgFAAQgCAAgCAAQgCAAgCgCQgDgCgBgEAAUgEQABgBAAAAQAGgKAEAAQAEAAACAEQADADABAGQgBAEgCACQgDADgEAAQgEAAgCgEQgDgDgBgEAAVgEQAAgBAAAAQAGgHABgBQADgCAEABQAFABAEAEQAEAEACAFQgBACgBABQgCADgDABQgDADgEgBQgDgBgDgBQgBgBgCgCQgDgEgDgEAAZADQABgEADgEQAMgEADADQADAEACAEQgBAEgCACQgCADgBAAQgCADgFAAQgFgBgCgCQgCgDgCgEAAagDQACgEAEgEQANgCADAEQADADACAGQgBAFgEADQgEADgEgBQgFgBgDgEQgEgEgCgEAAjACQABgCABAAQAFgHAEABQAJAGABACQABABAAACQAAABAAAAQAAACgBACQgBACgCACQgDACgEAAQgFgBgCgDQgDgDgBgF");
	this.shape_171.setTransform(439.4,178.5);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("rgba(98,102,78,0.455)").ss(0.8).p("AhIgRQACgJAFgHQATgOAFgCQAGgCAIAAQAFAAAGABQAIABAIADQAKAFADACQABAAABABQAEACAEADQAAAAABAAQgBACgCACQACACABACQAAABgBAAQAAACAAAAQAEADABADQAAAAABAAQgBAAAAAAQgIAFgEAFQgGAFgHADQgMAMgMACQgBABgBAAQgBAAgBAAQgNADgLgEQgBAAgBAAQgDgCgDgBQgBAAAAgBQgHgDgEgFQgBgEgBgCQAAAAAAAAQgCgGABgIQAAAAAAAAAhEAsQAJgIAIgJQAVgWAUgSQAJgJABgBQACAAADAAQgUAXgWATQgMANgLANQgDAAgEgBAg/gMQACgKAGgIQASgKAGAEQAEABAEAEQgHANgHAHQAAABgBABQgFAGgGADQgBAAgCABQgBAAgBABQgCAAAAAAQgBgBAAAAQgBAAAAgBQgDgCgBgFQAAgCgBgCAgbAbQABgCAAgCQALgUACgCQAJgFAHgCQAHgCADAAQAIAAAFABQAKACAIAFQAFABAEADQAEAEADADQABACABABQgCABgCABQgBAAgCABQAAAAgBABQgJAEgKADQgJACgIACQgEABgJACQgGACgJABQgGABgEACQgBAAAAAAQAAABgBAAQgDABABAAQAAAAAAAAQgBgBAAgBQgBgEgBgDQAAgCAAgCAgQAhQABAAAAABQAKgGAGgFQAMgHAEgBQAIgCAGABQADAAACABQADAAADABQACABACABQAAAAABAAQgBACAAAAQAAABgBAAQgGAIgHAHQgBABgBABQgHAIgIABQgBABgCAAQgBAAgBAAQgGAAgEgCQgEgCgFgEQAAAAAAAAQgEgDgDgEAgPAiQABAAACgBQARgNAHgDQACgBACAAQAIgCAGACQABAAACABQACAAABABQADABADABQgCAEgBACQgBACgCACQgEAHgEAEQgFAFgEACQgDABgDABQgJACgFgDQgDgCgEgCQAAAAAAgBQgCgBgBgCQgBgBgBgCQgBgCgBgBAgMAmQACgBABgBQAJgFAIgFQAJgIAIgDQAMgDAGABQACABADABQAFABAIAFQgIAEgEAFQgEAEgGAEQgIAJgJACQgFACgDAAQgBAAgBAAQgEAAgDgBQgFgBgGgGQgBAAAAgBQgDgCgBgCAgJAmQAAAAABAAQAIgGAIgKQATgMACgBQAIgBACABQACAAABAAQABAAABABQADABAFACQABAAAAAAQABABABABQAEADACAEQgIAEgFAFQgDADgEADQgEAEgFADQgEACgDABQgHADgGgBQgCAAgCAAQgIgBgFgGQgBAAgBgBQgBgBgBgBAAAALQAAgHADgEQANgEADAEQADACABAGQgBAJgDAFQgDAEgFAAQgHgBgBgDQgDgEAAgHAAFAKQADgEAEgDQALgGAIABQAMAFAAAAQAFAFADAEQABACABACQABABABABQgEADgEACQgCAAgBABQgCABgDABQgEABgFAAQgIgBgFgEQgIgFgEgHAAYAVQABgHAEgGQAIgFABAAQAFAAAEAEQAEAGACAFQgCAIgEAEQgDAFgGAAQgDAAgCAAQgCgBgCgCQgDgEgCgFAAZAMQAAgBAAgBQAHgMAFABQAFAAADACQADAFABAHQgCAJgCACQgDAFgFgBQgFAAgDgEQgDgFAAgHAAZAMQAAgBABgBQAFgKABAAQADgBAFABQAGAAAEADQAEAFACAIQgBADgBACQgBADgDADQgEAEgFgBQgEAAgCgCQgCgCgCgCQgEgFgCgHAAdATQABgHADgFQANgGAEAEQADAFACAIQgBAGgCACQgCAEAAAAQgDAEgGAAQgGgBgCgDQgDgEgBgGAAdAMQACgGAEgEQAPgCADADQAEAFACAGQgCAJgDAFQgFAEgFgBQgFgBgEgFQgEgFgCgIAAlASQAAgDABgCQAGgKAFABQALAIABAEQAAACABACQAAABAAABQgBACAAACQgBAEgDACQgDAEgFgBQgGAAgDgEQgCgEgBgG");
	this.shape_172.setTransform(438.9,177.5);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().s("rgba(74,77,58,0.341)").ss(0.9).p("AhFgVQABgJAFgHQARgPAEgCQAHgCAHAAQAFAAAFABQAIAAAHADQAKAFADADQABAAAAAAQAEADAEACQAAABAAAAQAAACgBADQACACABACQgBABAAAAQAAACAAAAQADADABADQAAAAAAAAQAAAAAAAAQgGAGgEAGQgFAFgHADQgLALgMACQgBABgBAAQgBAAAAAAQgNACgLgEQgBAAgBgBQgDgBgCgCQgBAAAAAAQgHgDgDgFQgBgCgBgEQAAAAAAAAQgCgGABgIQAAAAAAAAAhAA1QAKgLALgLQAagcAWgYQALgMAAgBQAFAAAFAAQgaAcgZAbQgPAQgPARQgEAAgEgBAg6gRQACgLAGgJQATgJAFAFQAEADADAEQgFAQgGAHQgBABAAABQgFAHgGACQgCAAgCAAQgBAAgCAAQgBAAgBAAQgBAAAAAAQgBgBgBgCQgCgEgBgFQAAgCgBgCAgOAfQAAgCAAgCQAKgUACgCQAHgFAJgDQAHgBADAAQAIAAAFABQAJACAIAEQAEADAEAEQAEAEACADQABACABACQgBABgCABQgBABgBABQAAAAgBABQgHAHgKAFQgIACgIACQgEACgJABQgIACgIgBQgFABgEAAQAAAAgBAAQAAAAgBAAQgDAAABgBQgBgBABAAQgBgBgBgBQgBgEAAgEQAAgCAAgBAgBAkQAAAAAAAAQAGgIAGgFQAMgIAEgBQAIgBAGADQADABABABQADABACACQACABACACQAAAAAAABQAAABAAABQgBAAAAABQgFAIgGAIQgBABAAAAQgHAIgIACQgCAAgBAAQgBAAgCAAQgFAAgFgDQgEgDgEgFQAAgBAAAAQgCgDgBgEAgBAlQABgBAAgBQAQgQAGgDQACAAACgBQAIgBAGADQACABABABQACABABABQADACACADQgCAEAAACQgCACgBACQgDAHgEAFQgEAFgFACQgDABgDABQgJABgGgEQgDgDgDgDQAAAAAAAAQgCgCgBgCQAAgBAAgCQAAgCgBgCAAAAnQABgBABAAQAIgHAHgGQAJgIAHgCQAMgCAFACQACABACACQAFADAGAFQgGAGgDAFQgEAFgFAEQgHAJgJABQgFABgDAAQgBAAgBAAQgDgBgDgBQgGgDgFgGQgBgBAAgBQgCgCgBgDAACAoQAAAAAAAAQAGgIAJgJQASgMACgBQAHABADAAQABABABAAQABABACABQACABAEADQAAABABAAQAAAAABABQADAEACADQgGAGgFAGQgCADgDADQgEAEgFADQgDABgEABQgHADgFgCQgDgBgBgBQgIgCgEgGQgBgBAAgBQgCgBAAgBAAJATQABgIADgGQAPgFAEAEQADAFABAIQAAALgEAFQgDAGgHAAQgHgCgCgEQgDgFgBgIAAOATQACgFADgEQAKgKAIABQANAHAAAAQAFAGACAEQABACABADQABACAAAAQgCAFgEADQgCABgBABQgCACgDAAQgEADgFgBQgIAAgFgGQgHgGgDgIAAcAbQABgJAEgGQAJgGABAAQAGgBAEAGQAEAHACAGQgCAKgEAGQgEAFgGAAQgDAAgDAAQgCgBgCgDQgEgFgBgHAAdAUQAAgBAAgBQAHgSAGABQAGAAADAFQAEAGABAJQgCALgCADQgDAGgHgBQgGAAgDgFQgDgGgBgJAAdAUQAAgBAAgBQAGgNAAAAQAEgEAFABQAHAAAEAGQAEAGACAJQgBAEAAACQgCAFgDADQgDAFgHAAQgEgBgDgCQgCgBgBgDQgFgGgBgJAAgAZQAAgIADgHQAQgGAEAFQAEAGABAKQgBAHgBADQgDAEAAAAQgDAGgHAAQgHgCgCgEQgEgFAAgHAAgAUQABgHAEgGQARgFAEAGQADAFACAIQgBALgEAGQgFAFgFgBQgHAAgEgGQgEgGgBgKAAlAZQABgEABgDQAGgMAGAAQAMAKACAEQAAACAAADQAAABAAABQAAADgBADQgBAFgCADQgEAFgGAAQgGgBgEgFQgCgFgCgH");
	this.shape_173.setTransform(438.5,177.4);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("rgba(49,51,39,0.227)").ss(0.9).p("AhIgZQACgJAEgHQAOgQAFgCQAFgCAIgBQAEAAAFAAQAHABAHACQALAGABACQABABAAAAQAEACADADQAAABAAAAQABADgBACQACADABACQgBABAAABQAAABAAABQACACABADQAAAAAAAAQAAAAAAAAQgEAHgDAHQgFAGgEAFQgLAIgNACQgBAAgBAAQgBAAgBABQgMABgKgFQgBAAgBgBQgCgBgDgBQAAgBgBAAQgFgDgDgEQgBgDgBgEQAAAAAAAAQgCgGAAgHQAAAAAAAAAhBA+QAMgOAMgNQAfgjAageQANgPABgBQAGAAAFAAQgfAjgdAgQgSAVgRAUQgFAAgFAAAg6gXQABgMAGgJQAUgJAFAGQAEAEACAGQgDARgFAIQgBABAAABQgFAHgIACQgBABgCAAQgCAAgBAAQgCgBgBgBQgBgBgBgBQgBgCAAgCQgDgFAAgFQgBgCAAgCAgHAjQAAgCAAgCQAIgVACgCQAHgHAKgBQAHgBADAAQAHAAAGABQAJABAHAGQAEADADAEQAEAFACAEQAAACABACQgBACgBABQgBABAAACQgBAAAAABQgFAJgKAGQgHAEgIACQgFABgIACQgIABgIgCQgGAAgEgBQAAgBAAAAQAAAAgBgBQgDgBAAgDQAAAAAAgBQgBgBgBgBQAAgEgBgEQAAgCAAgCAAGAmQAAAAAAAAQAGgKAFgGQALgIAEAAQAIgBAGAEQACABABACQADACACADQABACABACQAAABABABQgBABAAABQAAAAAAABQgEAKgFAHQgBABAAAAQgGAJgJAAQgBABgCAAQgBgBgBAAQgGgBgEgDQgEgEgCgGQgBAAAAgBQgCgDgBgFAAGAnQABgBAAgBQAOgUAGgCQACgBACAAQAJgBAFAFQACABABACQABACABABQACADACAEQgBAEAAACQgBADgBACQgDAHgEAFQgDAFgFACQgDABgDABQgJABgGgGQgCgDgDgEQAAAAAAAAQgBgCgBgCQAAgCgBgCQgBgBAAgCAAIApQAAgBABgBQAGgKAGgGQAIgIAHgBQALgBAFAEQACACACACQADAEAEAGQgEAHgCAGQgDAEgEAFQgHAJgIAAQgFABgDgBQgBAAgBAAQgDgBgDgDQgFgDgDgHQgBgBAAgBQgBgCgBgDAAJApQAAAAAAAAQAEgKAHgIQASgMACAAQAHABACACQACAAAAABQACABAAABQADADADADQAAAAAAABQABABAAABQACADABAEQgDAHgEAGQgCADgDADQgDAFgFACQgDACgEAAQgHACgFgDQgCgBgBgBQgGgEgEgHQAAgBgBgBQgBgBAAgCAAOAbQAAgKAEgHQASgHAEAGQADAHABAJQAAANgEAGQgEAHgHAAQgJgDgCgEQgEgGAAgKAARAbQACgGACgFQAJgNAJABQANAIAAAAQAEAHACAFQABACABADQAAACAAABQgCAHgDAEQgBABgCABQgBACgDACQgEACgGAAQgIAAgFgHQgGgGgCgKAAbAgQAAgKAEgHQALgHAAAAQAIAAAEAGQAEAIABAIQgBAMgEAGQgEAHgIAAQgDAAgCgBQgEgBgCgEQgDgGgBgIAAbAcQAAgBAAgCQAIgVAHABQAHAAAEAGQAEAHAAALQgBANgDAEQgEAGgHAAQgHAAgEgHQgDgHgBgKAAbAcQAAgBAAgCQAGgPABgBQADgFAHABQAHAAAEAHQAFAHABALQAAAEgBACQgBAHgEAEQgEAGgHAAQgFgBgDgCQgCgCgCgCQgEgIgBgKAAdAfQAAgKAEgHQASgHAEAGQAEAHABALQAAAIgCAEQgDAFAAAAQgDAHgIAAQgIgCgDgFQgDgGgBgJAAdAcQABgJAEgHQATgHAEAHQAEAGABAKQgBANgEAGQgFAHgGgBQgIAAgEgHQgEgHgBgLAAhAfQAAgFABgDQAHgQAHABQAOALABAFQAAADABADQAAABAAACQAAADgBADQgBAGgDAEQgEAHgHgBQgHAAgEgGQgDgGgBgI");
	this.shape_174.setTransform(438.7,177.4);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().s("rgba(25,26,19,0.114)").ss().p("AhKgfQABgJADgHQANgQAEgCQAFgDAHgBQAEAAAEAAQAIABAGACQALAGADACQAAAAAAAAQAEADABAEQAAAAAAAAQAAADABADQABADAAACQAAABAAABQABACgBABQACACAAACQAAAAAAAAQAAAAAAAAQgCAJgCAHQgCAGgGAFQgKAIgOACQgBAAgBAAQAAAAgBAAQgLABgKgGQgBAAgBAAQgCgBgCAAQgBgBAAAAQgFgEgCgFQgCgDgBgEQAAAAAAAAQgBgFAAgHQAAAAAAgBAhDBGQAOgRAOgQQAkgoAegmQAPgRABgCQAHAAAGAAQgjAqgiAnQgVAYgUAZQgGAAgFAAAg6geQAAgNAFgIQAWgKAFAIQADAFACAHQgBATgFAIQgBABAAABQgFAIgIABQgCABgBAAQgDgBgBgBQgDgBgBgCQgBAAAAgCQgCgCgBgEQgBgEgBgGQAAgCAAgCAAAAmQAAgCAAgCQAHgVACgDQAHgHAJgCQAIgBADAAQAHAAAFABQAJACAGAHQAEADADAFQADAFACAFQAAABAAACQAAADAAABQgBACAAACQAAABAAABQgEALgJAIQgHAFgIACQgFABgHABQgJABgIgDQgFgBgFgDQgBgBAAAAQAAgBgBAAQgDgDgBgEQgBgBAAgBQAAgBAAgBQAAgEAAgEQAAgCAAgCAAOAoQABgBAAAAQADgMAEgHQALgIAEAAQAIgBAFAGQACACABACQACADACAEQABACAAAEQAAABAAAAQAAACAAABQAAABAAAAQgCALgEAHQgBABgBAAQgFAJgJAAQgBAAgBAAQgCAAgBgBQgFgBgEgFQgDgEgCgHQAAAAAAgBQgCgEgBgEAAPAoQAAgBAAgBQALgYAGgBQACgBACAAQAJgBAFAHQABACACACQABACABADQABADABAFQAAAEgBADQAAACgBADQgCAHgDAFQgEAFgEACQgDABgDABQgJAAgFgHQgDgDgBgFQAAAAgBgBQAAgCgBgCQAAgCAAgCQgBgBAAgCAAPApQABgBAAgCQAEgLAEgGQAHgJAIAAQALABAEAFQABACACADQACAFADAHQgCAIgCAGQgCAFgDAEQgGAJgJAAQgEABgEgCQgBAAAAAAQgDgCgCgDQgFgFgCgHQAAgBAAgBQgBgDAAgDAAQApQAAAAAAAAQACgLAGgJQARgLACABQAGACADACQABABAAABQABABABABQACAEACAEQAAAAAAABQABABAAABQABADABAEQgCAJgDAGQgCADgCADQgDAFgEACQgEACgDAAQgHABgFgEQgCgBgBgCQgFgFgBgJQgBgBAAAAQgBgCAAgBAATAiQAAgMAEgIQAUgIAFAHQADAIABAKQAAAQgEAHQgFAIgIAAQgJgDgDgFQgEgIAAgLAAUAiQABgHACgGQAIgPAJABQAOAIAAABQAEAHABAGQABACAAADQAAADAAABQgBAIgDAFQgBACgBACQgCACgCACQgEADgGAAQgJAAgFgIQgFgHgBgMAAZAlQAAgMAFgJQALgHABAAQAIAAAFAHQAEAKABAJQgBAOgEAHQgFAIgIAAQgEAAgDgBQgDgCgDgEQgDgHgBgLAAZAiQAAgBAAgBQAJgZAIAAQAIAAAEAIQAEAIABAMQgCAQgDAEQgEAIgIgBQgIAAgEgHQgFgIAAgNAAZAiQAAgBAAgBQAFgTABgBQAFgFAGAAQAJAAAEAIQAFAIABANQgBAEAAADQgBAHgEAFQgEAIgIAAQgFAAgEgDQgCgCgCgDQgEgIgBgNAAaAkQAAgMAEgIQAVgIAEAIQAFAIAAAMQAAAKgCAEQgDAGAAAAQgEAIgIAAQgJgCgEgGQgDgHgBgLAAaAjQABgMAEgHQAVgJAEAIQAEAIABALQAAAPgFAHQgGAHgHAAQgIAAgEgIQgEgIgBgMAAcAkQAAgFABgFQAIgSAIABQAPAMABAGQABADAAADQAAACAAACQAAAEgBADQgBAIgDAFQgEAIgIgBQgJAAgEgIQgDgGgBgJ");
	this.shape_175.setTransform(438.8,177.4);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("rgba(102,139,70,0.247)").s().p("AhDhDQgKALAAASQAAATAKAKQAKAJARAAQAQAAAKgJQAKgLAAgSQAAgSgKgLQgKgLgQAAQgRAAgKALIAAAAAgbg9QAFAJAAAOQAAAOgFAJQgFAIgIABQgKAAgEgJQgFgJAAgOQAAgOAFgJQAEgJAKAAQAIAAAFAJIAAAAAAPALQgKAKAAASQAAATAKALQALAKAPgBQARAAAKgJQAKgLAAgTQAAgSgKgKQgKgLgRAAQgQAAgKALIAAAAAA3AQQAFAJAAAOQAAAPgFAIQgEAJgKAAQgJAAgEgJQgFgJAAgOQAAgNAFgKQAEgJAJABQAJAAAFAIIAAAAAg3BLIB+iWIgPAAIh9CWIAOAA").cp();
	this.shape_176.setTransform(439,177.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_167}]}).to({state:[{t:this.shape_168}]},42).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).wait(22));

	// 2
	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().s("#CDDFC3").ss(0.7).p("AAZgTQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFQgSAJgRgCQgRgCgFgLQgDgIADgHQADgHAJgIQAOgLAUgBQAUgCAcAKIAAAA").cp();
	this.shape_177.setTransform(367.2,347);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("rgba(186,203,177,0.91)").ss(0.6).p("AgLgfQACAAACABQABAAACABQAEACACACQACABABAAQACABACABQABAAABAAQACAAACAAQACAAADAAIABAAQABAAACAAQAEABAEAAQAFABAEACQAMAEAGAEQgEAAgFACQgDABgEABQgCACgDABQgFACgEABQgLADgKAGQgEACgDADQgEAGgEADQgGAEgGACQgEACgDABQgFAAgGAAQgSgDgIgJQgDgFgBgEQAAgEABgDQABgDACgBQAFgGAIgGQALgHADgBQACgCACgBQADgCAEgBQAEgDAEgBQADgBADAAIAAAA").cp();
	this.shape_178.setTransform(367,347.1);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().s("rgba(167,183,159,0.819)").ss(0.6).p("Ag+ANQAAgCABgDQAEgFACgDQAGgEAHgFQAHgGACgBQADgDACgCQACgCAAgBQABgCACgBQACgDACgBQADgCABAAQABAAABgBQAAAAAAAAQACAAACABQACAAABABQABAAAAABQABABAAAAQABAAAAABQABABACABQAAABABAAQAAAAAAAAQABAAABAAQAAAAAAAAQACAAACAAQAAAAABAAQAAAAABAAQACAAACgBQABAAABAAQACAAACAAQAAAAAAgBQACAAACAAQAFAAAEABQABAAAAAAQAGABAFABQAEACAEACQAHADAEAEQAAAAAAABQgDABgDACQgBAAgCAAQgBACgDAAQgBABgCABQgBABgCABQgCABgBAAQgGADgFAAQgEABgEACQgEACgDADQgDABgCADQgCABgCADQgEAFgCADQgCADgDACQgBABAAAAQgDADgDACQgBAAAAAAQgGAAgGgBQgVgCgMgJQgBgBgBgBQgCgEAAgD");
	this.shape_179.setTransform(366.7,347.3);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("rgba(149,162,142,0.728)").ss(0.7).p("Ag+ARQABgDACgDQAEgFADgDQAIgFAJgGQAHgHACgBQADgEABgDQACgCAAgCQABgCABgCQABgDABgBQABgCAAAAQAAAAAAAAQAAAAAAABQADABABABQACABABABQAAAAABABQAAABABABQAAAAAAABQABAAAAABQAAABACAAQAAAAAAgBQAAABABgBQAAgBAAAAQACAAAAgBQAAAAABAAQAAAAABAAQACgBADgBQABAAABgBQABAAADAAQAAAAAAgBQADAAACAAQAFgBAGABQAAAAABAAQAGABAGACQAFABAEADQAIAEADAGQAAAAAAAAQgCACgEADQgBAAgBABQgCACgCABQgCABgCABQgCABgCABQgCABgCABQgGABgFABQgFADgFACQgEADgEACQgBACgBACQAAABgBACQgCAFgBADQgBADgBABQgBABAAABQgBADgCADQgBAAgBAAQgGAAgIgBQgXgCgPgHQgBgBgCgCQgBgEgBgD");
	this.shape_180.setTransform(366.8,347.5);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f().s("rgba(130,142,124,0.637)").ss(0.7).p("Ag9AVQACgDABgDQAGgGAEgEQAJgFAKgHQAIgHACgDQACgEACgDQACgEgBgCQABgCAAgCQAAgEgBgBQAAgCgBABQgBAAAAABQAAAAAAABQACABACACQABABABACQAAAAAAABQABABAAABQAAABAAAAQAAABAAABQgBABABgBQAAAAAAAAQAAgBABgCQAAAAAAAAQABgBACgBQABAAAAgBQABAAABgBQACgBABgBQABAAABgBQABAAADgBQAAAAABAAQACgBADAAQAGgBAGAAQAAAAABAAQAHABAHACQAFACAFADQAJAFADAIQAAAAAAAAQgCADgEADQgBABgBABQgCACgDABQgCACgCABQgCACgCABQgCABgDAAQgHACgFACQgGADgFACQgFADgFADQABABABACQABACABABQAAAFABACQAAACABACQgBABAAAAQgCAFgCADQgBAAgBAAQgGAAgIAAQgZgCgSgHQgCgBgCgBQgCgEAAgE");
	this.shape_181.setTransform(366.9,347.6);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().s("rgba(112,122,106,0.546)").ss(0.8).p("Ag8AZQACgDACgEQAHgGAFgEQAKgIALgFQAJgJABgCQADgFACgEQABgEAAgDQgBgDAAgCQgCgFgCgBQgBgBgCABQgBABgBAAQgBABAAABQACACACADQABABABACQAAABAAABQAAABAAABQAAABgBABQAAABgBAAQgBABAAgCQAAAAgBAAQAAgBABgCQAAgBAAAAQABgBADgCQAAgBABAAQAAgBABAAQACgCADgCQABAAABgBQACAAABgBQAAAAABgBQACgBADAAQAHgBAHAAQAAAAABAAQAIABAHACQAHACAFADQAKAGACAKQAAAAAAAAQgCAEgDAEQgBABgBABQgCADgDABQgCACgDABQgCACgDABQgCAAgDABQgHADgHADQgGADgGADQgFADgDADQAAABADACQACABACACQACADADACQADACACACQAAABgBABQgCAFgCAEQgBAAAAAAQgJAAgHAAQgcgCgVgGQgDAAgCgBQgBgFAAgF");
	this.shape_182.setTransform(367,347.6);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f().s("rgba(93,102,89,0.455)").ss(0.8).p("Ag8AeQADgEADgDQAIgHAFgEQAMgJAMgGQAJgJACgEQADgFABgFQABgFAAgDQgBgDgBgDQgDgFgEgBQgDgBgDACQgBABgBABQgBAAgBABQACAEACADQABACABACQAAABAAABQAAACgBABQAAABgBAAQgBACgBAAQgDABAAgCQAAgBgBAAQAAgBABgEQAAAAAAAAQABgCACgDQAAAAABgBQABgBABgBQACgBADgCQABgBABgBQACAAADgBQAAgBABAAQACgBACgBQAIgCAHABQABAAAAAAQAKAAAHADQAHACAGADQAKAHADALQAAABAAAAQgCAFgDAEQgBABgBACQgCADgEACQgCACgDACQgCAAgDABQgDABgDACQgIADgHADQgHAEgHADQgDAEgGADQAEABACABQAEABAEACQADADAFABQAFACAEABQAAABgBABQgBAGgCAFQgBAAgBAAQgJAAgKAAQgcgBgZgFQgDgBgDAAQAAgGgBgF");
	this.shape_183.setTransform(367.1,347.6);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().s("rgba(74,81,71,0.364)").ss(0.8).p("Ag7AiQADgDADgEQAKgHAGgEQANgKANgGQAKgLABgEQABgGACgFQABgGgBgEQgBgEgCgCQgCgGgGgBQgEgBgEACQgCACgBABQgCABgBABQACAEACAEQABADABACQAAABAAABQgBACgBACQAAAAgBABQgBACgDAAQgDABgBgDQAAAAgBgBQgBgCABgEQAAAAAAAAQABgDACgDQABgBAAgBQABgBABgBQACgCAEgCQABgBABgBQACgBADgBQAAAAABgBQADgBAEgBQAGgCAIAAQABAAABAAQAKABAIACQAIADAGAEQALAHACANQAAAAAAABQgBAGgDAFQgBABgBABQgDAEgDADQgCACgDAAQgEACgDACQgDABgDABQgJAFgIADQgHAEgGADQgFAEgHAEQAGABAGABQADABAFABQAGACAGABQAHACAGABQAAABAAABQgCAHgBAGQgBAAgBAAQgKAAgLAAQgfgBgcgEQgDgBgDAAQgBgGAAgG");
	this.shape_184.setTransform(367.3,347.6);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f().s("rgba(56,61,53,0.273)").ss(0.9).p("Ag6AnQADgEAEgEQALgHAGgFQAPgJAOgKQAJgKACgEQACgGABgHQABgGgBgEQgCgFgCgDQgFgGgGgBQgFAAgFACQgDACgBABQgCACgBABQABAFACAFQABACABADQAAABgBACQAAACgCACQAAAAgBABQgCACgDAAQgFABgBgEQAAAAgBgBQgBgCAAgFQAAAAAAgBQABgDADgEQAAgBABAAQAAgBABgCQADgCADgDQABgBABgBQADgBADgBQAAgBABAAQAEgCAEgBQAGgCAJAAQABAAABAAQALAAAJADQAIACAHAFQAMAJABAOQAAAAAAABQAAAGgDAGQgBACgBABQgDAFgEACQgCABgDACQgEACgEACQgDACgDABQgJAFgJAEQgIADgGAFQgHAEgGAEQAHABAIAAQAEABAHABQAHABAIACQAJABAIAAQAAACAAABQgBAHgBAHQgCAAgBAAQgLAAgLAAQghgBgggCQgDgBgEAAQAAgGAAgH");
	this.shape_185.setTransform(367.4,347.6);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().s("rgba(37,41,35,0.182)").ss(0.9).p("Ag6AsQAEgEAEgEQAMgIAIgFQAQgKAOgLQALgKACgFQACgHABgHQABgHgCgFQgCgFgDgDQgHgHgGAAQgHgBgGADQgDACgDACQgCABgBACQACAGABAFQABADABADQAAABgBACQgBACgBACQgBABgCABQgCACgEAAQgFABgCgFQAAAAgBgBQgCgCABgGQAAAAAAgBQAAgEADgEQAAgBABgBQABgBABgCQACgDAEgDQABAAABgCQADgBADgCQAAAAABgBQAEgCAEgBQAKgDAIAAQAAAAABAAQAMAAAKAEQAJACAHAFQANAKABAQQAAAAAAABQgBAHgDAGQAAACgBACQgDAFgEACQgDACgDACQgEADgEACQgEABgEACQgJAFgJAEQgHAEgJAFQgHAFgHAEQAJAAAJABQAGAAAIABQAKABAJABQALAAAKABQAAABAAACQgBAIgBAIQgBAAgBAAQgMAAgMAAQgkgBgjgCQgEAAgDAAQgBgHAAgG");
	this.shape_186.setTransform(367.5,347.6);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f().s("rgba(19,20,18,0.091)").ss().p("Ag5AxQAEgEAFgFQANgIAIgFQASgLAPgLQAMgMACgFQABgIABgIQABgHgCgGQgCgFgEgEQgJgHgHAAQgIgBgIAEQgDACgDACQgCACgCABQACAHABAGQABAEABADQAAACgBABQgBADgCACQgBABgCABQgDACgEAAQgHAAgCgEQAAgBgBgBQgCgDAAgGQAAgBAAAAQAAgFADgFQABgBAAgBQABgBABgCQADgDADgDQABgBACgCQADgBADgCQAAgBABAAQAFgCAEgCQAKgDAJAAQAAAAABAAQANAAALADQAJADAIAFQANALABARQAAABAAAAQAAAJgDAHQAAACgBACQgDAFgFACQgCADgEADQgEACgFACQgEACgEACQgKAFgKAFQgHAEgJAFQgIAFgIAFQALAAALAAQAHAAAKABQALAAALABQANAAAMAAQAAACAAACQAAAJgBAIQgBAAgCAAQgMAAgNAAQgmAAgngBQgEAAgEAAQAAgHAAgH");
	this.shape_187.setTransform(367.6,347.6);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("rgba(0,91,52,0.247)").s().p("AgggwQAEgFAHgEQAJgDAIAAQALAAAJAIQAKAHgBARIgCARIgFAKIgKAIIg6AmIgKAJIAAASIB5AAIAAgXIhjAAIAQgLIAwgYQAKgFAGgHQAGgDADgJQADgHAAgKQAAgUgPgMQgRgMgYAAQgNAAgLAEQgJAEgIAFQgIAHgDAHQgFAHABAHQAAAIADAEQADAFAHAAQAIAAAEgEQAFgFAAgEIgEgW").cp();
	this.shape_188.setTransform(368.1,347.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_177}]}).to({state:[{t:this.shape_178}]},43).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).wait(19));

	// 1
	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f().s("#D4DBAF").ss(0.7).p("ABFAAQgDgHgJgIQgOgLgUgBQgUgCgcAKQgZAIgJAGIAKAAQAKAAAGACQANADAMAHQAFADAPALQASAJARgCQARgCAFgLQADgIgDgHIAAAA").cp();
	this.shape_189.setTransform(543,215);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().s("rgba(193,199,159,0.91)").ss(0.6).p("ABEAEQACAHgFAHQgHAKgSACQgBAAgBAAQgCAAgDAAQgFgBgFgCQgCAAgBgBQgCgBgDgCQgBgBgCgBQgOgMgFgGQgJgGgLgGQgBgBgCAAQgGgCgLAAIgIgBIgBAAQACgBACgBQAUgJAHgCQACgBADAAQACgBABAAQAYgEARAGQAKACAIAFQACACACABQADABACACQADABADACQADACADACQACADACADQABABAAADIAAAA").cp();
	this.shape_190.setTransform(542.9,215.4);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f().s("rgba(177,182,146,0.834)").ss(0.6).p("Ag+gSQACgBABAAQAYgKAEgCQABAAACgBQABAAABAAQABAAACAAQABAAACAAQAVAAAQAJQAHADAHAFQABABABABQABABABAAQABABACABQAAAAAAAAQADABACACQADABAEACQAAABABAAQACACACABQAAAAAAAAQACACABACQAAADAAACQAAAHgFAHQgIAHgPADQgCAAgCAAQAAAAgBAAQAAAAgBAAQgBAAgCgBQgEAAgEgCQgCgBgBgBQAAAAgBgBQgBgBgCgBQAAAAgBgBQgBgBgBAAQgMgOgFgHQgIgIgKgHQgBgBgCAAQgHgCgLAAIgDAAIgFgBIgBgB");
	this.shape_191.setTransform(543.7,215.5);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().s("rgba(161,166,133,0.758)").ss(0.7).p("Ag8gWQACgBACAAQAYgKAFgCQACgBABAAQABAAACAAQABAAABAAQACABABAAQATAEAOALQAHAFAGAHQABAAABABQABABABABQABABACABQAAAAABAAQACABADACQADAAAEABQABABAAAAQADACABACQAAAAAAAAQABADABACQgBADAAACQgBAGgHAGQgJAHgQACQgBAAgCAAQAAgBgBAAQgBAAAAAAQgBAAgBAAQgDgBgDgCQgBgBgBgBQAAAAgBgBQgBgBgBgBQgBgBAAgBQgBAAgBgBQgLgOgEgJQgHgJgJgJQgCgBgBgBQgIgBgLAAIgEAAIgEgCIgBgB");
	this.shape_192.setTransform(543.6,215.5);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f().s("rgba(145,149,119,0.682)").ss(0.7).p("Ag6gaQABAAADgBQAagKAEgDQADAAABAAQACAAABAAQABAAABABQACAAABABQARAIAMAOQAHAGAFAIQABABABABQABAAABAAQABABACACQABAAAAAAQADABADABQADABAEACQABAAAAABQADACABADQAAAAAAAAQAAACAAACQgBACgBACQgCAGgIAFQgKAHgRABQgBAAgCgBQAAAAgBAAQAAAAAAAAQgBgBgBAAQgBgBgCgBQAAgBgBgBQAAgBgBgBQAAAAgBgCQgBgBgBgBQAAgBgBAAQgKgQgDgLQgHgJgIgKQgBgCgCgBQgJgBgLAAIgEAAIgEgDIAAAA");
	this.shape_193.setTransform(543.6,215.6);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().s("rgba(129,133,106,0.607)").ss(0.7).p("Ag5geQACAAACgBQAcgKAFgDQACgBACAAQACAAABAAQABABABABQACABABABQAOAMAMARQAFAHAFAHQABABABABQABABAAABQACACACACQABAAAAAAQADABADABQAEABAEACQABAAABABQACACABADQAAAAAAAAQgBACgBACQgBACgCACQgEAFgIAEQgLAGgSACQgBgBgBgBQgBgBAAAAQgBAAAAAAQAAAAAAgBQAAAAgBgCQAAgBAAgBQAAgBgBAAQAAgBgBgCQgBgBAAgBQgBgBAAgBQgJgRgDgMQgGgLgHgLQgBgCgBgBQgKgBgMAAIgEAAIgEgEIAAAA");
	this.shape_194.setTransform(543.6,215.6);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f().s("rgba(113,116,93,0.531)").ss(0.8).p("Ag4giQACAAADgBQAegKAEgEQADAAACAAQACAAABAAQABABABABQABACABABQANAPAJAVQAFAIAFAIQABABAAACQABABABABQABACADACQAAAAABAAQADABADABQAFABAEACQABAAAAAAQACAEABADQAAAAAAAAQgBABgCACQgCACgCABQgFAFgJAEQgNAFgSABQgBgBgBgBQAAgBAAgBQAAAAAAAAQAAAAAAAAQAAgBABgCQAAgBAAgBQAAAAAAgBQAAgBgBgCQAAgBAAgCQAAgBAAgBQgJgRgDgOQgFgMgGgNQgBgCgBgBQgLgBgMAAIgEAAIgDgFIgBAA");
	this.shape_195.setTransform(543.7,215.6);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().s("rgba(97,100,80,0.455)").ss(0.8).p("Ag3gmQADAAADgBQAfgKAFgEQADAAACgBQACAAABAAQABACABABQABACABACQAKATAIAYQAFAHADALQABACABACQABABAAABQACACADACQAAAAAAAAQAEABAEABQAEABAFACQABAAAAAAQACAEABADQAAAAgBAAQgCACgCABQgCACgDABQgGAEgKADQgPAEgQACQgBgCgBgCQgBAAAAgBQAAAAAAAAQABAAAAgBQADgBACgBQAAgBAAgBQAAgBAAgBQAAgBAAgCQAAgBgBgCQAAgBAAgBQgIgTgDgPQgEgOgGgOQAAgBgBgCQgLgBgNAAIgFAAIgCgGIgBAA");
	this.shape_196.setTransform(543.7,215.6);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f().s("rgba(80,83,66,0.379)").ss(0.8).p("Ag2gqQADAAADgBQAhgKAFgFQADAAADAAQABAAACAAQABACAAACQAAACAAACQAKAXAHAbQAEAIADAMQABACAAACQABABAAACQACACAEACQAAAAAAAAQAEABAEABQAFABAFACQAAAAABAAQABAEABAEQAAAAAAAAQgDABgDABQgDABgDABQgIADgKADQgQAEgSABQgBgCAAgCQgBgBAAgBQAAAAAAAAQACAAABgBQADAAADgCQABgBABgBQAAgBAAgBQAAgBAAgCQAAgCAAgCQgBgBAAgBQgGgUgDgRQgDgOgFgPQgBgCAAgCQgMgBgNAAIgFAAIgCgHIgBAA");
	this.shape_197.setTransform(543.7,215.7);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().s("rgba(64,66,53,0.303)").ss(0.9).p("Ag1guQADAAAEAAQAigLAFgFQAEAAACAAQABAAABAAQABACAAACQABADAAADQAJAaAFAcQADAMACAMQABADABACQAAABABABQACADADACQAAAAABAAQAEABAEABQAFABAFACQABAAABAAQABAEABAEQgBAAAAAAQgDABgEABQgDABgEABQgJACgMADQgRADgSAAQgBgCgBgCQAAgBAAgBQAAAAAAAAQACgBACAAQAEgBAFgBQABgBABgCQAAgBABAAQAAgCAAgCQAAgCAAgCQAAgBgBgBQgFgVgCgTQgDgPgDgRQgBgCAAgCQgNgBgOAAIgFAAIgBgHIgBgB");
	this.shape_198.setTransform(543.8,215.7);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f().s("rgba(48,50,40,0.227)").ss(0.9).p("Ag0gyQAEAAADAAQAkgLAGgGQADAAABAAQACAAACAAQABADAAACQAAADABAEQAGAeAEAeQACAOABAOQABACABACQABACAAABQACADAEACQAAAAAAAAQAFABAEABQAFABAGACQABAAABAAQAAAEABAFQAAAAgBAAQgEAAgEABQgEABgEAAQgLACgMACQgRACgVABQAAgDgBgDQAAgBAAgBQAAAAAAAAQADAAACgBQAGgBAGgBQABgBABgBQABgBAAgBQABgCAAgCQAAgCAAgCQAAgCAAgBQgEgWgCgUQgCgRgDgSQAAgCAAgDQgOAAgOAAIgFAAIgBgIIgBgB");
	this.shape_199.setTransform(543.8,215.7);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("rgba(32,33,27,0.152)").ss(0.9).p("Agzg2QAEAAADAAQAmgLAGgGQABAAAEAAQACAAACAAQAAADABACQAAAEAAAEQAEAiACAhQACAPABAPQABACAAADQABACAAABQACADAEACQABAAAAAAQAFABAEABQAGABAGACQAAAAABAAQABAFAAAEQAAAAgBAAQgEAAgFABQgFAAgFABQgMABgMABQgTACgVAAQgBgDAAgDQAAgBAAgBQAAAAABAAQADgBACAAQAHgBAHgBQACgCABgBQABgBABgBQABgCAAgCQAAgCAAgDQAAgBAAgBQgDgXgBgWQgBgSgCgUQAAgCAAgDQgPAAgOAAIgGAAIgBgJIAAgB");
	this.shape_200.setTransform(543.9,215.8);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f().s("rgba(16,17,13,0.076)").ss().p("Agyg6QAEAAAEAAQAngLAEgHQAEAAADAAQADAAACAAQAAAEAAADQAAAEAAAEQACAmABAkQABAQAAAQQABADAAACQABACABACQABADAFACQAAAAABAAQAEABAFABQAGABAGACQABAAABAAQAAAFAAAEQAAAAAAAAQgGABgFAAQgGAAgFAAQgNABgOABQgTAAgXABQAAgEAAgDQAAgCAAgBQAAAAABAAQADAAADgBQAIgBAJgBQACgBACgCQAAgBABgBQACgCAAgCQAAgCAAgDQAAgCAAgBQgBgYgBgXQAAgUgBgUQAAgDgBgDQgOAAgPAAIgGAAIgBgKIAAgB");
	this.shape_201.setTransform(543.9,215.8);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("rgba(83,115,82,0.247)").s().p("Agxg+IAAANIAlAAIAABlQAAAIgCACIgHAFIgbADIAAALIBiAAIAAgLIgagEQgEgBgCgFIgDgJIACiDIgNAAQgEAHgMAFQgMAGgRAAIgIAA").cp();
	this.shape_202.setTransform(544,215.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_189}]}).to({state:[{t:this.shape_190}]},46).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).wait(14));

	// division symbol
	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f().s("#CCDFB4").ss(0.7).p("AAZgTQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFQgJAFgIABQgJACgJgBQgRgCgFgLQgDgIADgHQADgHAJgIQAMgJAQgDQADAAADAAQAUgCAcAKIAAAA").cp();
	this.shape_203.setTransform(351.2,212);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f().s("rgba(185,203,164,0.91)").ss(0.6).p("AgLgXQAPABAUAIQALADAHADQADgBADAAQADAAADABQgDgCgEgCQgIgDgLgDQgcgJgVACQgDAAgfALQgCABgCACQgDAEgCAFIAAACQgCACABAEIABgDQADgHAJgGQAQgKAJgBQALgCAFAAIAAAAAA2gIIAAAAQABAAAAAAQgFgEgOgGQgFgCgHgCQgRgFgLgCQgJgBgOABQgFABgUALQgEADgDADAgKARQgDACgDABQgFACgFABQgJACgIgBQgDgBgCgBQgMgDgDgIQgBgDgBgCIAAABQgBAFADAGIAAABQABABABACIABAAQAFADAJACQAJABAJgCQAIgBAJgEQAKgFALgJQALgHAOgCQAGgCAKAAQgDgCgGgCQgGAAgEACQgMAEgLAGQgLAJgIAEIAAAAAA2gIQAEACACACQgDAAgDAAQgBAAgCAAQADACABACQgPgCgIACQgJADgIAEQgPAMgJAFQgKAFgIABQgIACgIgBQgCgBgCAAQAAgBgBAAQAAAAAAAAQgIgCgEgFAg9AWQgCgBgCgCQgBgCgCgCQgDgIADgHIAAAAQADgGAGgF");
	this.shape_204.setTransform(351,212.2);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f().s("rgba(167,183,148,0.819)").ss(0.6).p("AhCgBQADgFAHgFQAagPAGgBQAiABARAFQAGACAFACQAMAEAGADQABABABABQgBAAAAAAQADADACACQgDAAgCABQgBAAgCAAQACABAAABQABAAAAAAQgOAAgIABQgKACgIAEQgRALgHAEQgKAFgIABQgIABgIAAQgCgBgCAAQAAAAgBAAQAAgBAAAAQgIgCgEgEIgBAAQgBgBgCgBQAAAAgBgBQgBgCgCgDQgCgHACgGAg9gEQACgFAGgFQASgNAHgCQARgEAJABQAPADALAEQAGACAFACQAGACAEACQAFADADACQABAEgCABQgBAAgCAAQADABABACQgNgBgIADQgIACgIADQgCACgDACQgLAIgGAEQgEACgFACQgEABgDABQgIABgHgBQgCAAgCgBQgBAAAAAAQgDgBgCgBQgEgCgDgDQAAAAAAAAQgDgCgBgBQgBgCgCgCQgDgIADgFQAAAAAAgBAg9ACQACgEAGgEQANgKAFgDQAYgGAJABQALABAPAGQAGACAFACQAOAGAEADQACADACABQgDAAgCAAQgCAAAAAAQACAAABACQgNgBgIADQgIADgGAEQgSAMgGAEQAAAAgBABQgJADgHACQgIABgHgBQgBgBgCAAQgBAAAAAAQgBgBAAAAQgBAAgCgBQgFgCgDgDQAAAAAAAAQgDgCgBgBQgBgCgCgCQgCgHABgH");
	this.shape_205.setTransform(350.7,212.4);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f().s("rgba(148,162,131,0.728)").ss(0.7).p("AhBgCQAEgFAGgEQAZgNAHgBQAjABAQAFQAHABAFACQALADAHADQAAABABACQAAAAgBAAQADACACADQgDAAgCABQgBAAgBABQABAAABAAQABAAAAAAQgPAAgIACQgKACgIAEQgQAKgIADQgKAEgIABQgIACgIgBQgCgBgCAAQAAAAgBAAQAAAAAAAAQgIgCgEgEIgBAAQgCgBgBgBQgBAAAAgBQgBgCgCgCQgCgIACgGAg4gIQADgFAFgEQARgMAFgDQARgDAIAAQAOADAKADQAFACAFACQAGACAEACQAEADACACQACAEgCABQgBAAgBAAQACACABABQgMgBgHAEQgHADgHACQgDACgCABQgLAIgFADQgEACgEACQgEABgDABQgIABgGgBQgCgBgBAAQgBAAAAAAQgDgBgCgBQgEgCgCgDQgBAAAAAAQgCgCgBgBQgCgCgBgCQgCgFABgHQAAAAAAAAAg4AGQADgFAFgDQAMgJAFgDQAWgGAIABQAKACAOAEQAGACAEACQANAGAEADQACABABACQgCAAgCAAQgBAAgBABQACABABABQgMAAgHADQgHADgGADQgQALgGAEQgBABAAAAQgIADgHABQgHABgGgBQgCAAgCgBQAAAAgBAAQAAAAAAAAQgCgBgBAAQgFgCgDgEQAAAAAAAAQgCgBgBgBQgCgCgBgCQgCgHABgG");
	this.shape_206.setTransform(350.4,212.5);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f().s("rgba(130,142,115,0.637)").ss(0.7).p("AhAgDQAEgEAGgDQAZgMAIgBQAiABAQAEQAHABAFACQALADAHACQABACAAABQAAAAAAAAQACADABACQgCABgBABQgBAAgBAAQABAAAAABQABAAgBABQgNgBgJACQgKACgIADQgQAJgJADQgJADgIACQgIABgIgBQgCAAgCgBQAAAAgBAAQAAAAgBAAQgHgCgFgDIAAAAQgCgBgCAAQAAgBgBgBQgBgCgBgCQgCgIACgGAgygLQACgFAFgEQAOgLAGgDQAPgEAHABQANACAJADQAFACAEACQAGACADACQAEACADACQABAFgBAAQgCAAgBAAQACACABABQgKAAgGAEQgHACgGAEQgCACgCAAQgLAHgEADQgEACgEABQgDABgDAAQgHABgGgBQgCAAgBgBQgBAAAAAAQgDgBgCgBQgDgCgCgCQgBAAAAAAQgCgCgBgBQgBgCgBgCQgDgEACgGQAAAAAAgBAgyAKQACgFAFgEQAKgHAFgCQAUgHAIABQAJACANAEQAFACAEACQAMAEADADQACACABACQgCAAgBAAQgCABAAAAQABABABACQgKAAgGADQgHACgFAEQgPAKgGADQAAABgBAAQgHADgGABQgHABgGgBQgBgBgCAAQAAAAgBAAQAAgBAAAAQgBAAgCgBQgEgCgDgDQAAAAAAAAQgCgBgBgCQgBgBgBgCQgDgGACgG");
	this.shape_207.setTransform(350.3,212.7);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f().s("rgba(111,122,98,0.546)").ss(0.8).p("AhAgEQAFgDAGgDQAYgKAJgBQAiABAQADQAGABAGACQALACAHACQABACAAABQAAAAAAABQACACABADQgCABgBAAQgBAAgBABQABABAAABQAAAAAAAAQgNgBgKACQgJACgIADQgRAHgJADQgJADgHABQgJABgHgBQgCAAgCgBQgBAAAAAAQgBAAAAAAQgIgBgFgDIAAAAQgCgBgCAAQAAgBgBgBQgBgCAAgCQgCgIABgGAgtgPQACgFAEgDQANgLAFgCQANgEAHAAQAMACAIADQAFACAEABQAFACADACQADACADADQABAEgBAAQgBABgBAAQACABABABQgJABgGADQgGADgFAEQgCABgCABQgJAFgEADQgEACgEABQgDABgDAAQgGABgFgBQgCAAgBgBQgBAAAAAAQgDgBgCgBQgDgCgCgCQAAAAAAAAQgCgCgBAAQgBAAgBgCQgCgGABgGQAAAAAAAAAgtAOQACgEAEgEQAJgHAEgCQATgGAHAAQAJACALAEQAFACAEABQAKAEADADQACACABACQgCAAgBABQgBAAgBABQACABABABQgKABgFADQgGACgFADQgNAKgFADQgBAAgBAAQgHADgFABQgGAAgFgBQgCAAgBgBQAAAAgBAAQAAAAAAAAQgBgBgCAAQgDgCgDgDQAAAAAAAAQgCgCgBgBQgBgBgBgCQgCgGABgF");
	this.shape_208.setTransform(350.1,212.9);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f().s("rgba(93,102,82,0.455)").ss(0.8).p("Ag/gFQAEgDAHgCQAXgJAJAAQAjABAPACQAHABAGABQAKADAIABQAAACABABQAAABgBAAQACADABADQgBAAgCABQAAAAgBABQABABAAABQAAAAgBABQgNgBgJACQgJABgJACQgQAGgKADQgIACgIABQgIABgIgBQgCAAgCAAQgBAAAAAAQgBgBAAAAQgHgBgFgCIgBAAQgCgBgCAAQAAgBgBgBQAAgCgBgCQgCgIACgGAgogTQACgEADgEQALgJAFgDQAMgEAGABQALABAHADQAFABADACQAEABADACQADACACADQACAEgBABQgBAAgBAAQACABABACQgIABgEADQgGADgFADQgBACgCABQgIAGgFAAQgDACgDABQgDABgCAAQgGABgFgBQgBgBgBAAQgBAAAAAAQgDgBgCgCQgCAAgCgCQAAAAAAAAQgCgBgBgBQgBgBgBgCQgCgFABgFQAAAAAAgBAgoASQACgEADgDQAIgIAEgDQARgEAGABQAIABALACQAEABADACQAJAFADADQACADABABQgCAAgBABQgBABAAAAQABABABACQgIABgFADQgFACgEADQgMAJgFACQgBAAgBABQgGACgFAAQgFABgFgCQgBAAgBgBQgBAAAAAAQAAAAAAAAQgCAAgBgBQgDgCgCgDQgBAAAAAAQgBgBgBgBQgBgBgBgCQgCgFABgF");
	this.shape_209.setTransform(350,213);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f().s("rgba(74,81,66,0.364)").ss(0.8).p("Ag/gFQAFgDAGgCQAXgHAKAAQAiABAQACQAGABAGAAQAKACAJACQAAABAAACQAAAAAAAAQABADABADQgBAAgBACQgBABAAABQAAABABABQgBAAAAAAQgNAAgKABQgJABgJACQgPAFgLACQgIACgIAAQgIABgIgBQgCAAgCAAQgBAAAAAAQgBAAAAAAQgHgBgFgCIgBAAQgCAAgCgBQgBgBAAAAQAAgDgBgCQgBgIABgGAgjgXQABgDADgEQAJgIAEgDQALgEAGAAQAKABAGACQAEACADACQAEABACABQADADACACQACAEgBABQgBAAAAABQABABAAABQgGABgDAEQgFACgEAEQgCABgBABQgIAGgFACQgBABgEABQgCAAgCAAQgFAAgFAAQgBAAgBgBQAAAAAAAAQgDgBgCgBQgCgCgCgCQAAAAAAAAQgBgBgBgBQgBgBgBgBQgCgFABgFQAAAAAAAAAgjAXQABgEADgEQAHgHAEgDQAPgFAFAAQAHABAKADQADACAEACQAHAEADAEQABACABABQgBABgBABQgBAAAAABQABABAAABQgGACgEADQgEACgEADQgLAHgFADQAAAAgBAAQgFACgFAAQgFAAgEgBQgBgBgBAAQAAAAAAAAQgBAAAAAAQgBgBgBgBQgDgBgCgDQAAAAAAAAQgCgBAAgBQgBgBgBgCQgCgFABgE");
	this.shape_210.setTransform(349.9,213.2);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f().s("rgba(56,61,49,0.273)").ss(0.9).p("Ag/gGQAFgCAHgCQAWgFALAAQAiAAAPACQAHABAGAAQAKACAIABQABABAAACQAAAAAAABQABADAAACQgBABAAACQgBABAAABQAAABAAABQAAAAgBABQgMgBgLABQgJABgIABQgQAEgLABQgIACgIAAQgIABgIgBQgCAAgCAAQAAAAgBAAQAAAAgBAAQgHgBgFgBIgBAAQgCAAgDgBQAAgBAAAAQAAgDgBgCQgBgIABgGAgegbQABgDACgDQAHgIAEgDQAKgDAFAAQAIAAAGACQADABADACQADABACACQADACACACQABAEAAABQgBAAAAABQABABAAABQgEACgDADQgEADgEADQgBABgBABQgHAFgFACQgBABgDABQgCAAgCAAQgEABgEgBQgBgBgBAAQAAAAAAAAQgDgBgCgCQgCgBgBgCQAAAAAAAAQgCgBAAgBQgBgBgBgBQgCgEABgEQAAAAAAgBAgeAbQABgEACgDQAGgHADgCQANgGAFAAQAHABAIADQADABADACQAHAEACAEQABACAAABQAAABgBABQgBABAAAAQABABAAACQgFACgDADQgEACgDACQgJAHgGACQAAAAAAAAQgFABgEAAQgEABgEgCQgBAAAAgBQgBAAAAAAQAAAAAAAAQgBAAgCgBQgCgCgCgCQAAAAAAAAQgBgBgBgCQgBAAAAgCQgCgEABgF");
	this.shape_211.setTransform(349.8,213.4);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f().s("rgba(37,41,33,0.182)").ss(0.9).p("Ag/gHQAGgCAGgBQAWgDALAAQAiAAAPABQAHABAGAAQAKABAJABQAAABAAACQAAABAAAAQABADAAACQAAACgBACQAAACgBABQABABAAABQgBAAgBAAQgMAAgKAAQgJABgJABQgQACgLABQgIABgIAAQgIABgIAAQgCgBgCAAQAAAAgBAAQAAAAgBAAQgHAAgGgBIAAAAQgCAAgDgBQAAAAAAgBQgBgDAAgCQgBgHABgGAgZgfQAAgCACgDQAFgHAEgDQAIgEAFAAQAHAAAFACQADABACACQADABABABQADACABACQACAEgBABQAAABAAAAQABABAAABQgDADgCADQgDADgDACQgBACgBAAQgGAFgFACQgCAAgBABQgCAAgCAAQgDABgEgBQgBgBgBAAQAAAAAAAAQgCgBgCgCQgCgBgBgCQAAAAAAAAQgBgBgBgBQAAgBgBgBQgCgDABgEQAAAAAAAAAgZAfQAAgEACgCQAEgHADgCQAMgGAEAAQAGABAHADQADABACACQAGAEABADQABACABACQgBAAAAABQgBABAAABQABABAAABQgDACgEAEQgCACgDACQgHAGgHABQAAAAAAAAQgEABgDAAQgDAAgEgBQAAgBgBAAQAAAAAAAAQAAgBAAAAQgCAAgBgBQgCgCgBgCQgBAAAAAAQAAgBgBgBQgBgBgBAAQgBgFAAgE");
	this.shape_212.setTransform(349.7,213.5);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f().s("rgba(18,20,16,0.091)").ss().p("Ag/gIQAGgBAHAAQAUgCANAAQAiAAAPAAQAGABAHAAQAJAAAJABQABACAAABQAAABAAAAQAAAEAAABQAAADAAACQgBACAAABQAAABAAABQgBAAgBAAQgLAAgLAAQgJABgJAAQgPABgNABQgHAAgIABQgIAAgIAAQgCAAgCgBQAAAAgBAAQAAAAgBAAQgHAAgGAAIAAAAQgDAAgDAAQAAgBAAgBQAAgDAAgCQAAgGAAgHAgVgiQABgDABgCQADgGADgDQAHgEAFgBQAFAAAEABQADACACABQACABABABQACACACACQABAFAAAAQAAABAAAAQABABAAABQgCADgBAEQgCACgDADQgBABAAAAQgFAFgFABQgCABgBAAQgBAAgCAAQgDAAgDgBQAAAAgBgBQAAAAAAAAQgDgBgCgCQgBgBgBgBQAAAAAAAAQgBgBAAgBQgBgBAAgBQgCgDAAgDQAAAAAAAAAgVAjQABgDABgDQADgGADgCQAJgGAEAAQAFABAGACQACACACACQAFADABADQABACAAACQAAAAAAABQgBACAAAAQABABAAABQgCADgDADQgCACgCACQgGAFgGABQgBAAAAAAQgCABgDAAQgDgBgDgBQAAgBgBAAQAAAAAAAAQAAAAAAAAQgBgBgCgBQgBgBgBgCQAAAAAAAAQgBgBgBgBQAAgBgBAAQgBgEAAgE");
	this.shape_213.setTransform(349.6,213.7);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("rgba(0,97,55,0.2)").s().p("ABAALIAAgVIh/AAIAAAVIB/AA").cp();
	this.shape_214.setTransform(349.5,214);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("rgba(0,97,55,0.2)").s().p("AgLgzQAFgFAGAAQAHAAAFAFQAFAGAAAHQAAAHgFAGQgFAFgHAAQgGAAgFgFQgFgGAAgHQAAgHAFgGIAAAAAAMAaQAFAGAAAHQAAAHgFAGQgFAFgHAAQgGAAgFgFQgFgGAAgHQAAgIAFgFQAFgFAGAAQAHAAAFAFIAAAA").cp();
	this.shape_215.setTransform(349.5,213.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_203}]}).to({state:[{t:this.shape_204}]},38).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).to({state:[{t:this.shape_210}]},1).to({state:[{t:this.shape_211}]},1).to({state:[{t:this.shape_212}]},1).to({state:[{t:this.shape_213}]},1).to({state:[{t:this.shape_215},{t:this.shape_214}]},1).wait(24));

	// minus sign
	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f().s("#D3E5B2").ss(0.7).p("AhFAAQADgHAJgIQAOgLAUgBQAUgCAcAKQAZAIAJAGQgRgCgJAEQgNADgMAHQgLAJgJAFQgSAJgRgCQgRgCgFgLQgDgIADgHIAAAA").cp();
	this.shape_216.setTransform(319.2,301);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f().s("rgba(192,208,162,0.91)").ss(0.6).p("AA2gEQgMgBgHADQgNACgMAHQgLAIgKAFQgRAIgRgCQgQgCgGgJQgDgJACgGQAEgHAKgHQAOgKATgBQAVgBAbAJQAeALADACQgDAAgDAAIAAAA").cp();
	this.shape_217.setTransform(319,300.9);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f().s("rgba(173,187,146,0.819)").ss(0.6).p("AhEAAQAEgHAKgGQAOgJATgBQAVgBAaAIQAXAIAHADQgPACgGACQgNABgMAHQgLAHgKAEQgRAIgRgCQgQgCgGgIQgDgJACgF");
	this.shape_218.setTransform(319,300.8);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f().s("rgba(154,166,130,0.728)").ss(0.7).p("AhEAAQAFgGAJgGQAPgIASgBQAVgBAaAHQAWAHAIADQgPADgGACQgNABgMAFQgKAHgLAEQgRAHgQgCQgQgCgHgHQgCgJABgE");
	this.shape_219.setTransform(318.9,300.6);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f().s("rgba(134,146,113,0.637)").ss(0.7).p("AhDgBQAFgFAJgFQAPgHASgBQAUgBAaAGQAVAGAJADQgOAEgGABQgNABgMAFQgLAGgKADQgRAGgQgBQgPgBgIgHQgCgIABgF");
	this.shape_220.setTransform(318.8,300.5);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f().s("rgba(115,125,97,0.546)").ss(0.8).p("AhCgCQAGgEAJgEQAOgGASgBQATgBAaAGQAUAFAKACQgMAFgHAAQgNACgMAEQgMAFgJADQgRAFgQgBQgPgBgIgGQgCgIABgF");
	this.shape_221.setTransform(318.7,300.3);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f().s("rgba(96,104,81,0.455)").ss(0.8).p("AhBgCQAGgEAJgDQAOgFASgBQATgBAZAFQAUAEALACQgMAFgHABQgNACgMADQgMAEgJADQgRAEgQgBQgOgBgJgFQgCgHABgF");
	this.shape_222.setTransform(318.5,300.2);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f().s("rgba(77,83,65,0.364)").ss(0.8).p("AhAgDQAHgDAIgCQAPgEARgBQATAAAZADQASAEAMABQgLAGgGABQgNABgNADQgMADgJACQgRAEgQgBQgNgBgKgEQgCgHABgF");
	this.shape_223.setTransform(318.4,300.1);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f().s("rgba(58,62,49,0.273)").ss(0.9).p("Ag/gDQAHgCAIgCQAPgDAQgBQAUAAAYACQASADAMABQgKAHgGABQgNABgNACQgMADgKABQgQACgPAAQgOgBgKgDQgBgGAAgF");
	this.shape_224.setTransform(318.3,299.9);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f().s("rgba(38,42,32,0.182)").ss(0.9).p("Ag+gEQAHgBAJgCQAOgCAQAAQAUAAAXACQARABANABQgIAIgHABQgNABgNABQgMACgKABQgQABgPAAQgNgBgLgBQgBgHAAgF");
	this.shape_225.setTransform(318.2,299.8);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f().s("rgba(19,21,16,0.091)").ss().p("Ag9gEQAIgBAIgBQAPgBAPAAQAUAAAXABQAPABAPAAQgIAKgHAAQgNAAgNABQgMABgKAAQgQABgPAAQgNAAgLgBQgBgHAAgE");
	this.shape_226.setTransform(318,299.7);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("rgba(109,190,86,0.247)").s().p("AA8gFIh3AAIAAALIB3AAIAAgL").cp();
	this.shape_227.setTransform(317.8,299.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_216}]}).to({state:[{t:this.shape_217}]},40).to({state:[{t:this.shape_218}]},1).to({state:[{t:this.shape_219}]},1).to({state:[{t:this.shape_220}]},1).to({state:[{t:this.shape_221}]},1).to({state:[{t:this.shape_222}]},1).to({state:[{t:this.shape_223}]},1).to({state:[{t:this.shape_224}]},1).to({state:[{t:this.shape_225}]},1).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).wait(22));

	// x
	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#007B46").s().p("AhJgWQAUgQAcgCQAbgCArAOQAkAMAMAJQgXgDgOAFQgSAFgSAKQgSANgMAHQgZANgXgDQgZgDgHgPQgFgLAEgLQAEgKAOgMIAAAA").cp();
	this.shape_228.setTransform(301,283.1);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#007B46").s().p("Ag3gaQALgJAPgEQAFgBAGgBQAHAAAHAAQAUAFAZALQAfAFAPAEQADACACACQgDAAgDAAQgSABgMAFQgKAEgKAEQgHAFgGAGQgLALgHAHQgEADgDADQgCABgBABQgYAHgYgGQgZgBgJgLQgCgDgBgDQgCgHABgIQAGgKAPgNQAHgGAIgEIAAAA").cp();
	this.shape_229.setTransform(301,283.2);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#007B46").s().p("AhaALQAGgLAPgNQAGgFAGgEQACgCABgBQAKgJANgFQAFgCAFgBQgBAAAAAAQAIgBAHAAQAAAAAAAAQAUAHAYALQABAAABABQAeADARACQAAAAABAAQACACACACQgCAAgCABQAAAAgBAAQgSACgMAGQgJAEgJADQgBABgCAAQgFAGgGAGQgJAMgGAIQAAAAAAAAQgEADgEADQgBABgBABQgYAFgXgIQgBAAgBAAQgZABgKgJQgCgCgCgDQAAgBAAAAQgCgHABgHIAAAA").cp();
	this.shape_230.setTransform(301,283.2);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#007B46").s().p("AhaAPQAHgOAQgMQAGgFAGgEQACgCABgBQAIgLALgFQAEgCAEgBQAAAAAAAAQAHgCAIgBQAAAAAAAAQAVAJAZAMQABAAABAAQAeACARAAQABAAAAAAQADACACACQgCABgBAAQgBAAAAAAQgTADgNAHQgJAFgJAEQgBAAgBABQgFAGgEAGQgIAMgEAJQAAAAgBAAQgEADgEADQgCACgCABQgWADgYgJQgBAAgBAAQgZACgLgHQgDgCgBgDQgBAAAAAAQgCgHAAgHIAAAA").cp();
	this.shape_231.setTransform(301,283.3);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#007B46").s().p("AhaASQAIgOARgNQAGgFAGgFQACgCABgBQAGgLAJgHQADgCAEgCQAAAAAAAAQAHgCAIgBQAAAAAAAAQAVAKAaANQABAAABABQAegBASgCQABABAAAAQADACADACQgCABgBABQgBAAAAAAQgTAEgNAIQgJAFgJAEQgBABgBAAQgEAHgEAGQgGANgDAJQAAAAAAAAQgEAEgFADQgCABgCACQgXAAgZgKQgBAAAAAAQgaAEgMgFQgCgCgCgCQAAAAAAgBQgDgHgBgHIAAAA").cp();
	this.shape_232.setTransform(301,283.4);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#007B46").s().p("AhaAVQAKgPARgNQAGgGAHgFQABgBABgCQAEgMAHgHQADgDADgCQAAAAAAAAQAHgDAIgCQAAABAAAAQAWALAaAOQABABABAAQAfgDATgDQAAAAABAAQADACADADQgCABgBABQAAAAgBAAQgSAFgOAJQgKAFgJAFQgBABgBAAQgCAHgDAHQgFANgBAKQAAAAgBAAQgEAEgEADQgDACgCACQgXgCgagMQgBAAAAAAQgaAGgNgDQgDgCgCgCQAAAAAAAAQgDgHgBgIIgBAA").cp();
	this.shape_233.setTransform(301.1,283.5);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#007B46").s().p("AhZAYQAKgQARgNQAHgGAHgFQABgCAAgCQADgNAFgIQACgDACgCQAAgBAAAAQAIgDAIgCQAAAAAAAAQAXANAaAQQABAAABAAQAfgEAUgGQABAAAAAAQAEADACACQAAACgBABQgBAAAAAAQgTAGgOAKQgKAGgKAFQAAAAgBABQgCAIgCAHQgCANgBALQAAAAAAAAQgEAEgFADQgCACgDACQgYgEgagNQgBAAgBAAQgZAHgOgBQgDgBgCgCQgBAAAAAAQgDgHgCgIIAAAA").cp();
	this.shape_234.setTransform(301.1,283.6);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#007B46").s().p("AhZAbQALgQASgOQAHgHAHgFQABgCAAgCQABgNADgKQACgDABgDQAAAAAAAAQAIgEAIgDQAAABAAAAQAXAOAcARQABAAABAAQAfgGAVgIQAAAAABAAQADADADADQAAABgBACQAAAAgBAAQgTAHgPALQgKAGgKAFQAAABgBABQAAAIgBAHQgBAOAAAMQABAAgBAAQgEAEgFADQgCACgDADQgYgGgbgPQgBAAgBAAQgaAJgPABQgCgBgDgBQAAAAAAAAQgEgIgDgIIAAAA").cp();
	this.shape_235.setTransform(301.1,283.8);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#007B46").s().p("AhZAeQANgRASgOQAHgHAHgGQABgCAAgCQgBgOABgLQABgDABgDQAAAAAAgBQAIgDAIgEQAAAAAAAAQAZAQAbASQABAAABAAQAfgIAWgKQABABAAAAQAEADADADQAAABAAACQgBAAAAAAQgUAIgPALQgKAHgKAGQgBABAAABQAAAIAAAIQABAOACAMQAAABAAAAQgFAEgEADQgDACgDADQgZgIgbgQQgBAAgBAAQgaAKgQADQgDAAgCgBQgBAAAAAAQgEgIgDgIIgBAA").cp();
	this.shape_236.setTransform(301.1,283.9);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#007B46").s().p("AhZAhQANgRATgQQAIgGAHgHQAAgCAAgCQgCgPgBgMQAAgDAAgEQAAAAAAAAQAIgEAJgEQAAAAAAAAQAbARAaAUQABgBABAAQAfgKAXgLQABAAAAAAQAEADADADQAAACABACQgBAAAAAAQgUAKgQALQgKAIgKAGQAAABgBABQACAJAAAIQACAPAEAMQAAAAAAABQgEAEgFADQgDADgDACQgagKgcgRQgBAAAAAAQgbAMgRAEQgDAAgCAAQgBAAAAAAQgFgHgDgJIgBAA").cp();
	this.shape_237.setTransform(301.1,284);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#007B46").s().p("AhZAkQAOgSAUgSQAIgFAHgHQAAgCgBgCQgEgQgCgMQgBgFAAgDQAAAAgBgBQAJgEAIgFQABAAAAABQAbASAbAVQABAAABgBQAfgMAYgNQABAAAAAAQAEAEADADQABACABACQgBAAAAAAQgUALgQAMQgLAIgKAHQAAABAAABQACAJACAIQADAQAFANQAAAAAAABQgEAEgFADQgDADgDADQgcgMgbgUQgBABgBAAQgaANgSAHQgDAAgDAAQgBABAAAAQgFgIgEgIIgBgB").cp();
	this.shape_238.setTransform(301.2,284.1);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#007B46").s().p("AhZAnQAPgSAUgTQAIgFAIgIQgBgCAAgCQgGgRgFgNQgBgFgBgEQAAAAAAAAQAIgFAJgFQAAAAAAAAQAcAUAbAWQABAAABAAQAhgPAYgPQABAAAAABQAEADAEAEQABACABACQgBAAAAABQgUALgRANQgLAJgLAHQABABAAABQADAJADAJQAFAQAGAOQAAAAAAAAQgEAFgFAEQgDACgDADQgdgOgcgVQgBABAAAAQgbAPgTAIQgDABgDABQgBAAAAAAQgGgIgEgIIgBgB").cp();
	this.shape_239.setTransform(301.2,284.2);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#007B46").s().p("AhZAqQAQgTAUgTQAJgGAIgHQgBgDgBgCQgIgRgGgPQgCgFgBgEQgBAAAAgBQAJgFAJgGQAAAAAAABQAdAVAbAXQABAAABAAQAhgQAZgSQABABAAAAQAEAEAEADQABADACACQgBAAAAABQgUAMgRAOQgLAJgMAIQABABAAABQAEAKAEAJQAGAQAIAPQABAAAAAAQgFAFgFAEQgDADgEADQgdgQgcgXQgBABgBAAQgbAQgUALQgDABgDABQgBAAAAABQgGgJgFgIIgBgB").cp();
	this.shape_240.setTransform(301.2,284.4);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#007B46").s().p("AhZAtQARgUAVgTQAJgGAIgIQgBgDgCgDQgJgRgIgQQgDgFgCgFQAAAAgBAAQAJgGAJgGQABAAAAAAQAdAXAcAZQABgBABAAQAhgSAagTQABAAAAAAQAFAEADAEQACADACACQgBABAAAAQgUANgSAPQgLAKgMAIQABABABABQAEAKAFAKQAIAQAJAQQABAAAAAAQgFAFgFAEQgDADgEADQgegSgcgYQgBABgBAAQgbASgVAMQgEACgDABQgBABAAAAQgHgIgFgJIgBgB").cp();
	this.shape_241.setTransform(301.3,284.5);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#007B46").s().p("AhZAwQASgUAVgUQAJgIAJgHQgCgDgBgDQgLgSgKgQQgEgGgDgFQAAAAAAgBQAJgGAJgHQAAABABAAQAdAYAdAaQABAAABgBQAhgUAbgVQABAAAAAAQAFAFAEAEQACACACADQgBABAAAAQgUAOgTAQQgLAKgMAIQABACABABQAGAKAFAKQAKARALAQQAAABAAAAQgFAFgFAEQgEADgDAEQgfgVgdgZQgBABgBAAQgbATgWAPQgEACgDABQgBABAAAAQgHgIgGgJIgBgB").cp();
	this.shape_242.setTransform(301.3,284.6);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#007B46").s().p("AhZAzQATgVAVgVQAKgIAJgHQgCgDgCgDQgNgTgMgRQgEgGgDgFQAAgBgBAAQAJgHAJgHQABAAAAAAQAfAaAdAbQABAAABgBQAhgWAcgXQABAAAAABQAFAEAEAEQADADACADQgBABAAAAQgUAQgTAQQgMALgMAIQABACABABQAHALAGAKQAMASAMAQQAAAAAAABQgFAFgFAEQgEAEgDADQgggWgdgbQgBABgBAAQgcAVgXAQQgDACgEADQgBAAAAABQgIgJgGgJIgBgB").cp();
	this.shape_243.setTransform(301.4,284.7);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#007B46").s().p("AhZA2QAUgVAWgWQAKgJAJgHQgCgDgCgDQgPgUgOgSQgFgGgEgGQAAAAAAgBQAJgHAJgIQAAABABAAQAfAbAeAdQABgBABgBQAhgYAegZQAAABAAAAQAFAFAFAEQACADADAEQAAAAgBAAQgVARgTARQgMALgMAJQABACABABQAIALAHALQANASAOARQAAAAAAABQgFAFgFAEQgEAEgDAEQgggZgfgcQgBABgBAAQgbAWgYATQgEACgEADQgBAAgBABQgHgJgHgJIgBgB").cp();
	this.shape_244.setTransform(301.4,284.8);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#007B46").s().p("AhZA5QAVgWAWgWQAKgJAKgIQgDgDgCgDQgRgUgPgUQgFgGgFgGQgBgBAAAAQAJgIAKgIQAAAAABABQAfAcAfAeQABgBABgBQAhgaAfgaQAAAAABAAQAEAFAFAEQADAEADAEQAAAAgBAAQgVASgTASQgMAMgNAJQABACACABQAIAMAJAKQAOATAPASQAAAAABABQgGAFgFAEQgEAEgEAEQgggbgfgdQgBABgBAAQgcAYgZAUQgEADgEADQgBABgBAAQgHgIgIgKIgBgB").cp();
	this.shape_245.setTransform(301.5,285);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#007B46").s().p("AhZA8QAWgWAXgXQAKgKAKgHQgDgEgDgDQgSgVgSgVQgFgGgGgHQAAAAgBgBQAKgIAJgJQABABAAAAQAhAeAfAfQABgBABAAQAhgcAggdQAAAAABABQAFAFAEAEQAEAEADAEQAAAAgBABQgVASgUATQgMAMgNAKQABACACABQAKAMAJALQAQATAQATQAAAAABAAQgGAGgFAFQgEAEgEAEQghgdgggfQgBABgBAAQgcAZgaAXQgEADgEADQgBABgBABQgIgJgIgKIgBgB").cp();
	this.shape_246.setTransform(301.5,285.1);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#007B46").s().p("AhZA/QAWgXAYgXQAKgKAKgIQgCgEgDgDQgUgWgUgVQgGgHgHgHQAAgBAAAAQAJgJAKgJQAAAAABABQAhAfAfAgQABAAABgBQAjgeAggfQAAAAABABQAFAFAFAFQADAEAEAEQAAAAgBABQgVATgVAUQgMANgNAKQACACABABQALAMAKAMQARATASATQAAABABAAQgFAGgGAFQgEAEgEAEQgigfggggQgBABgBAAQgcAbgbAYQgFAEgEAEQgBAAgBABQgIgJgJgKIgBgB").cp();
	this.shape_247.setTransform(301.5,285.2);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#007B46").s().p("AhZBCQAXgXAYgYQALgLAKgIQgDgEgDgDQgWgXgVgWQgHgHgHgIQgBAAAAgBQAKgJAKgKQAAABABAAQAhAhAgAiQABgBABgBQAjggAhghQAAABABAAQAFAGAFAEQAEAFAEAEQAAAAgBABQgVAUgVAVQgNANgNALQACACABABQAMANALALQATAUATAUQABABAAAAQgFAGgGAFQgEAEgEAFQgjghghgiQgBABgBAAQgcAcgcAbQgEAEgFAEQgBABgBABQgJgKgJgKIgBgB").cp();
	this.shape_248.setTransform(301.6,285.3);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#007B46").s().p("AAAAUIBGBGIAUgUIhGhGIBGhFIgUgUIhGBGIhFhGIgUAUIBGBFIhGBGIAUAUIBFhG").cp();
	this.shape_249.setTransform(301.6,285.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_228}]}).to({state:[{t:this.shape_229}]},38).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[{t:this.shape_236}]},1).to({state:[{t:this.shape_237}]},1).to({state:[{t:this.shape_238}]},1).to({state:[{t:this.shape_239}]},1).to({state:[{t:this.shape_240}]},1).to({state:[{t:this.shape_241}]},1).to({state:[{t:this.shape_242}]},1).to({state:[{t:this.shape_243}]},1).to({state:[{t:this.shape_244}]},1).to({state:[{t:this.shape_245}]},1).to({state:[{t:this.shape_246}]},1).to({state:[{t:this.shape_247}]},1).to({state:[{t:this.shape_248}]},1).to({state:[{t:this.shape_249}]},1).wait(14));

	// 0
	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#B5DAA4").s().p("AhbAAQAEgKAOgMQAUgQAcgCQAbgCArAOQAkAMAMAJQgXgDgOAFQgSAFgSAKQgSANgMAHQgZANgXgDQgZgDgHgPQgFgLAEgLIAAAA").cp();
	this.shape_250.setTransform(366,257.1);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#B5DAA4").s().p("AgeguQACAAABAAQAOgCANACQAQACARAFQAIACAHADQAFACAEACQAOAGAJAGQALAGAFAFQgDAAgEABQgRABgLAFQgBAAgBAAQgMAGgNAIQgEACgFADQgHAFgGAEQgMAIgIAEQgCABgCABQgPAFgOABQgKABgJgDQgEAAgDgBQgPgFgGgKQgCgDgCgDQgFgMAEgMQADgKALgLQACgBABgCQAJgJALgFQAMgGAOgCIAAAAAhIgXQgNAMgEALQgDAMAFALQAGAQAZAGQAVAFAYgLQABAAACgBQANgGAWgRQAPgKAPgFQAKgGARgBQADAAAEAAQgLgMgigNQgYgKgVgDQgOgCgdAGQgRAGgNAMIAAAA").cp();
	this.shape_251.setTransform(365.9,257.2);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#B5DAA4").s().p("AhfAAQADgKAMgMQAAAAAAAAQABgCABgCQAIgIAMgGQAAAAABgBQALgGAOgDQABAAAAAAQACAAABAAQANgCAOACQABAAAAAAQAQABAQAFQABAAABABQAIADAIADQAFACAEACQAAAAAAAAQAOAGAJAHQAKAHAFAGQgDAAgDABQAAAAAAAAQgQACgLAFQgBABgBAAQgCABgCACQgKAGgLAHQgBAAAAAAQgEADgEADQgHAFgHAEQgCABgBABQgKAGgIADQgCABgCABQAAAAAAAAQgPAFgOABQgBAAAAAAQgLAAgJgDQgEgBgDgBQAAAAAAAAQgPgFgGgLQAAAAAAgBQgCgCgCgDQgFgMADgNIAAAAAhYAAQAEgLANgNQAMgNARgGQAbgHAPACQAWACAWAKQAkAPAKAOQgXADgJAEQgPAIgPALQgWARgOAGQgbALgVgGQgYgHgGgQQgFgMADgM").cp();
	this.shape_252.setTransform(365.9,257.3);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#B5DAA4").s().p("AhgAAQADgLALgMQAAAAAAAAQABgCACgCQAIgJALgGQAAgBABgBQALgGAPgDQABAAAAgBQACAAABAAQAOgCAOACQABAAABAAQAQABAQAFQABABABAAQAJADAHAEQAFACAFACQAAAAAAAAQAOAHAIAIQAKAHAFAHQgDABgDABQAAAAAAAAQgPADgKAGQgBAAgBABQgCABgCACQgKAHgLAHQgBAAAAABQgEACgEADQgIAGgHAEQgCABgBABQgKAGgJADQgDABgBABQAAAAAAAAQgRAFgOAAQAAAAgBAAQgLAAgJgEQgEgBgDgBQAAAAAAAAQgPgGgHgLQAAgBAAAAQgCgDgBgDQgFgMADgOIAAAAAhXAAQAEgMAMgMQAMgOAQgHQAbgIAQABQAWADAWALQAjAQAKAQQgWAEgJAEQgOAJgPAMQgVARgPAGQgcALgVgIQgXgHgGgSQgFgLADgN").cp();
	this.shape_253.setTransform(365.9,257.4);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#B5DAA4").s().p("AhhAAQACgMALgMQAAAAAAgBQACgBABgCQAIgKALgHQABgBAAAAQAMgHAPgEQABAAAAAAQACAAABAAQAOgDAQABQAAAAABAAQAQACARAFQABABABAAQAJADAIAEQAFADAEACQAAAAAAABQAOAHAJAIQAKAIAEAHQgCACgDABQAAAAAAAAQgPAFgKAGQgBABgBABQgBABgCACQgKAIgMAIQAAAAgBAAQgEADgEADQgHAGgIAEQgCABgBABQgLAGgJADQgDABgCABQAAAAAAAAQgRAEgPAAQAAAAgBAAQgKgBgKgEQgEgBgDgBQAAAAAAAAQgPgHgHgMQAAAAAAgBQgCgDgBgCQgFgOADgOIAAAAAhWAAQADgMAMgNQAMgPAQgHQAagJARABQAXACAWANQAhAQAJASQgUAGgJAFQgNAKgPALQgVATgPAGQgdAJgUgJQgXgIgGgSQgEgMACgN").cp();
	this.shape_254.setTransform(365.9,257.4);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#B5DAA4").s().p("AhiAAQACgMAKgOQAAAAAAAAQACgCABgCQAIgKAMgIQAAAAABgBQALgHAQgEQAAgBABAAQACAAABAAQAPgDAQABQAAAAABAAQARACARAFQABABACAAQAJAEAIAEQAFADAEACQAAABAAAAQAOAIAIAJQAKAJAEAHQgCACgDACQAAAAAAAAQgNAEgKAJQgBABgBABQgCABgBACQgKAJgMAIQAAAAgBAAQgEADgEAEQgIAGgIAEQgCABgBABQgLAGgKADQgDABgCAAQAAAAAAAAQgSAFgPgBQgBAAAAAAQgLgBgKgFQgEgBgDgCQAAAAAAAAQgPgHgHgMQAAgBAAgBQgCgCgBgDQgFgOADgOIAAgBAhUAAQACgNAMgNQALgPAQgIQAZgKASABQAXACAWANQAgASAJATQgTAGgIAHQgNALgOAMQgVATgRAGQgdAIgUgKQgWgIgGgTQgEgNADgN").cp();
	this.shape_255.setTransform(365.9,257.5);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#B5DAA4").s().p("AhkAAQACgNALgOQAAAAAAAAQABgCABgCQAIgLAMgIQAAgBABAAQAMgJAQgEQAAAAABAAQACgBABAAQAPgDARABQAAAAABAAQASACARAFQACABABABQAJADAIAFQAFADAFACQAAABAAAAQAOAIAIAKQAJAKAFAIQgDACgCACQAAAAAAAAQgNAFgJAKQgBABgBABQgCACgCACQgJAKgMAJQgBAAAAAAQgEADgFADQgIAGgIAFQgBABgCABQgMAGgKACQgDABgDABQAAAAAAAAQgSAEgQgBQAAAAgBAAQgLgCgKgFQgEgBgEgCQAAAAAAAAQgOgIgHgNQAAgBAAAAQgCgDgBgDQgFgOACgPIAAgBAhTAAQACgNALgOQALgPAPgJQAZgMATABQAYACAVAPQAgASAIAWQgSAGgIAIQgMAMgOANQgVAUgRAFQgeAIgUgMQgVgJgGgUQgEgMADgO").cp();
	this.shape_256.setTransform(365.8,257.6);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#B5DAA4").s().p("AhlAAQACgOAKgOQAAAAAAAAQABgCACgDQAIgLALgJQABAAABgBQALgJARgFQAAAAABAAQACAAABgBQAPgDASABQAAAAACAAQASACASAFQABABABABQAJAEAJAFQAFACAEADQAAABABAAQANAJAJALQAJAKAEAJQgCACgDADQAAAAAAAAQgLAGgKALQAAABgBABQgCACgCACQgJALgMAJQgBAAAAAAQgFADgEAEQgIAGgJAEQgBABgCABQgMAGgLADQgDABgDABQAAAAAAAAQgTADgQgBQgBAAAAAAQgMgCgKgGQgEgBgEgDQAAAAAAAAQgOgIgHgOQAAAAAAgBQgCgDgBgDQgFgOACgQIAAgBAhSAAQACgOALgOQAJgQAQgJQAZgNATABQAYACAVAPQAfAUAIAXQgRAIgIAJQgLAMgOANQgUAVgTAFQgdAHgUgNQgVgKgFgUQgFgNADgO").cp();
	this.shape_257.setTransform(365.8,257.7);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#B5DAA4").s().p("AhmAAQABgOAKgPQAAgBAAAAQACgCABgCQAIgMAMgJQAAgBABgBQAMgJARgFQAAAAABgBQACAAABAAQAQgEASABQAAAAACAAQATABASAGQABABABABQAKAEAIAFQAGADAEADQAAABAAAAQAOAKAIALQAJALAEAKQgCADgCACQAAAAAAAAQgLAIgJALQgBABgBACQgBABgCACQgJAMgNAKQAAAAgBABQgEADgEADQgJAHgJAEQgBABgCABQgMAGgMADQgDABgDAAQAAAAAAAAQgUADgRgCQAAAAgBAAQgMgCgKgGQgEgCgEgCQAAAAAAAAQgPgJgGgPQAAAAgBgBQgBgDgCgDQgEgPACgQIAAgBAhRAAQACgOAKgOQAJgRAPgKQAZgOAUAAQAZACAVARQAdAUAHAZQgPAKgHAJQgLANgOAOQgUAVgTAFQgeAHgUgPQgUgLgFgVQgEgMACgP").cp();
	this.shape_258.setTransform(365.8,257.8);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#B5DAA4").s().p("AhnABQABgQAKgQQAAAAAAAAQABgCABgCQAIgNAMgKQABgBAAgBQANgKARgFQAAAAABAAQACgBACAAQAPgEATABQAAAAACAAQAUABASAHQABAAACABQAJAEAJAGQAFADAFADQAAABAAAAQAOAKAIAMQAJAMADALQgBADgCACQAAABAAAAQgLAIgIAMQgBACgBABQgCACgBACQgKANgMAKQAAABgBAAQgEADgFAEQgIAGgKAFQgBABgCABQgNAGgMACQgDABgEABQAAAAAAAAQgUADgSgDQAAAAgBAAQgMgDgKgGQgEgCgEgCQAAAAAAAAQgPgKgGgPQgBgBAAgBQgBgDgCgDQgFgPADgRIAAAAAhQABQACgQAJgOQAJgSAPgKQAYgQAVABQAZACAVARQAdAWAGAaQgOALgHAKQgKAPgNANQgUAWgUAFQgfAGgUgQQgTgMgFgVQgEgNACgO").cp();
	this.shape_259.setTransform(365.8,257.8);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#B5DAA4").s().p("AhpABQABgRAKgQQAAAAAAgBQABgCABgCQAIgNAMgLQABgBABAAQAMgLASgGQAAAAABAAQACgBACAAQAQgEATABQAAAAACAAQAVABASAHQACAAABABQAKAFAJAFQAFAEAEADQABABAAAAQANALAIANQAJAMADAMQgBADgCADQAAAAAAAAQgJAKgIANQgBABgBACQgCACgBACQgKAOgMALQgBAAAAAAQgEAEgFADQgJAHgJAFQgCABgCABQgNAGgOACQgDABgDAAQAAAAAAAAQgVADgSgDQgBAAAAAAQgNgDgKgHQgEgCgEgDQAAAAAAAAQgPgKgHgQQAAgBAAgBQgCgDgBgDQgFgQACgRIAAAAAhPABQACgQAJgPQAIgSAPgLQAXgRAWABQAaABAUATQAcAWAGAcQgNANgHAKQgJAQgNAOQgUAXgVAEQgfAFgUgRQgSgMgFgWQgEgOACgO").cp();
	this.shape_260.setTransform(365.8,257.9);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#B5DAA4").s().p("AhqAAQABgRAJgQQAAgBAAAAQACgCABgDQAHgOANgLQAAAAABgBQANgLASgGQAAgBABAAQACAAACgBQAQgEAUAAQAAAAACAAQAWACASAGQACABABABQAKAFAJAGQAFADAFAEQAAAAAAABQAOAMAIANQAIAOADALQgBAEgBADQAAAAAAABQgJALgIANQgBACgBABQgBADgBACQgKAPgNALQAAAAgBAAQgEAEgEAEQgJAHgKAEQgCABgCABQgNAGgQADQgCAAgDABQAAAAAAAAQgWACgTgDQAAAAgBAAQgNgEgKgHQgEgCgEgEQAAAAAAAAQgPgLgHgQQAAgBAAAAQgCgEgBgDQgFgQACgRIAAgCAhOAAQACgQAIgPQAIgTAOgLQAXgTAXABQAaACAVATQAaAXAGAeQgMAPgGALQgJAQgNAOQgTAYgWAEQggAEgTgSQgSgNgFgXQgDgOABgP").cp();
	this.shape_261.setTransform(365.8,258);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#B5DAA4").s().p("AhrAAQAAgRAKgSQAAAAAAAAQABgDABgCQAIgPAMgLQABgBAAgBQANgMATgGQAAAAABgBQACAAACgBQARgEAUAAQABAAACAAQAWABASAHQACABABABQALAFAJAHQAFADAFAEQAAAAAAABQAOAMAHAPQAJAOADAMQgBAEgCAEQAAAAAAAAQgHAMgIAPQgBABgBACQgBACgCADQgJAPgNAMQAAAAgBABQgEAEgFADQgJAHgKAFQgCABgCABQgOAGgQACQgCABgEAAQAAAAAAAAQgXACgSgEQgBAAAAAAQgNgEgLgHQgEgDgEgDQAAAAAAAAQgPgMgHgRQAAgBAAAAQgCgEgBgDQgFgQACgSIAAgCAhNAAQACgQAHgQQAIgUAOgLQAWgUAYAAQAbACAUAVQAaAYAFAfQgLAQgGAMQgIARgNAPQgTAYgWAEQghAEgTgUQgRgOgFgYQgDgNABgQ").cp();
	this.shape_262.setTransform(365.7,258.1);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#B5DAA4").s().p("AhtAAQABgSAJgSQAAgBAAAAQABgCABgDQAIgPAMgMQABgBABgBQANgMASgHQABAAAAAAQADgBACgBQARgFAVABQABAAACAAQAXABATAHQABABABABQALAFAJAHQAGAEAEAEQABAAAAABQANANAIAPQAIAPADANQgBAEgBAEQAAAAAAAAQgHAOgHAPQgBACgBABQgBADgCACQgJARgNAMQgBABAAAAQgEAEgFAEQgKAHgKAFQgCABgCABQgOAGgRACQgCAAgEABQAAAAAAAAQgYABgTgEQAAAAgBAAQgNgFgLgHQgFgDgDgEQAAAAAAAAQgPgMgHgSQAAAAgBgBQgBgEgBgDQgFgRABgSIAAgCAhMAAQACgRAHgQQAHgUANgNQAXgVAYABQAbABAUAWQAZAZAEAhQgJASgFAMQgJASgMAPQgSAZgYAEQggADgUgVQgQgPgEgYQgEgOABgQ").cp();
	this.shape_263.setTransform(365.7,258.2);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#B5DAA4").s().p("AhuAAQAAgTAJgTQAAAAAAAAQABgDACgCQAHgQANgNQAAgBABgBQANgMATgIQABAAAAAAQADgBACgBQASgFAVABQABAAACAAQAYABATAHQABABACABQALAGAJAHQAFADAFAFQAAAAABAAQANAOAIAQQAHAQADAOQgBAEgBAEQAAAAAAABQgFAOgIAQQAAACgBACQgCADgBACQgJASgNAMQgBABAAAAQgFAEgEAEQgKAIgLAEQgCABgCABQgOAGgSACQgDABgDAAQAAAAAAAAQgZACgTgFQgBAAAAAAQgOgFgLgIQgFgDgEgEQAAAAAAAAQgOgNgHgSQAAgBgBgBQgBgEgBgEQgFgQABgTIAAgCAhLAAQACgSAGgQQAHgVANgNQAWgWAZAAQAcACATAWQAYAaAEAkQgIASgFANQgIATgLAQQgTAZgYADQghADgTgWQgQgQgEgZQgEgOABgQ").cp();
	this.shape_264.setTransform(365.7,258.3);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#B5DAA4").s().p("AhvAAQAAgUAJgTQAAAAAAgBQABgCABgDQAHgQANgOQABgBABAAQANgOATgHQABgBAAAAQADgBACgBQASgFAWAAQABAAACAAQAZABATAIQACABABABQALAGAKAHQAFAEAFAFQAAAAAAAAQAOAPAHAQQAIARACAOQAAAFgBAEQAAABAAAAQgFAQgHAQQgBACgBACQgBADgBADQgJASgOAOQAAAAgBAAQgEAFgFADQgKAIgLAFQgCABgCABQgPAGgSACQgEAAgDABQAAAAAAAAQgZABgUgGQAAAAgBAAQgOgFgLgIQgFgEgEgEQAAAAAAAAQgOgNgHgTQgBgBAAgBQgBgEgBgEQgFgRABgTIAAgCAhJAAQABgSAGgRQAGgWANgNQAVgYAaABQAcABAUAYQAXAbADAlQgHAUgFANQgHAUgLAQQgSAbgaACQghACgTgXQgPgRgEgZQgDgPABgQ").cp();
	this.shape_265.setTransform(365.7,258.4);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#B5DAA4").s().p("AhwAAQAAgVAIgUQAAAAAAAAQABgDABgCQAIgRAMgPQABAAABgBQANgOAUgIQABgBAAAAQADgBACgBQATgFAWAAQABAAADAAQAYABAUAIQACABABABQAMAGAJAIQAGAEAEAEQABABAAAAQANAPAIASQAHARACAPQAAAFgBAFQAAAAAAAAQgEARgGASQgBACgBACQgBADgBADQgJATgOAOQAAAAgBAAQgEAFgFAEQgKAIgMAFQgCABgBABQgQAGgTABQgEABgDAAQAAAAAAAAQgaABgVgGQAAAAgBAAQgOgGgLgJQgFgDgEgEQAAAAAAAAQgOgOgHgUQgBgBAAgBQgBgEgBgEQgFgRABgUIAAgCAhIAAQAAgTAGgRQAGgWAMgOQAVgZAbAAQAdABATAZQAWAcADAnQgGAVgEAOQgHAVgLAQQgRAcgcACQghABgTgYQgNgSgFgaQgDgPABgQ").cp();
	this.shape_266.setTransform(365.7,258.5);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#B5DAA4").s().p("AhyAAQAAgWAIgUQAAAAAAgBQABgDABgCQAIgSANgOQABgBAAgBQAOgPAUgIQABAAAAgBQADgBACgBQATgGAXABQACAAACAAQAZAAAUAJQACABABABQAMAGAKAIQAFAEAFAFQABABAAAAQANAQAHASQAIASACAQQAAAFgBAFQAAAAAAAAQgDATgGASQgBACgBACQgBADgBADQgJAVgOAOQgBAAAAABQgEAEgFAEQgLAIgMAFQgCABgBABQgQAGgUACQgEAAgDAAQAAAAAAAAQgbABgVgGQgBAAAAAAQgPgHgLgJQgFgEgEgEQAAAAAAAAQgPgPgGgUQgBgBAAgBQgBgEgCgEQgEgSAAgUIAAgCAhHAAQAAgUAFgRQAGgXAMgPQAUgaAcAAQAeACASAaQAVAcACApQgEAXgEAOQgGAWgLARQgRAcgdACQghABgSgaQgNgTgFgbQgDgOABgR").cp();
	this.shape_267.setTransform(365.6,258.6);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#B5DAA4").s().p("AhzAAQAAgXAIgUQAAgBAAAAQABgDABgDQAHgSANgPQABgBABgBQAOgPAUgJQABAAAAgBQADgBACAAQAUgHAXAAQACAAACAAQAaABAUAJQACABACABQAMAGAJAJQAGAEAFAFQAAAAABABQANAQAHATQAHATACAQQAAAGAAAFQAAAAAAAAQgDAUgGATQAAACgBADQgBADgCADQgIAVgOAPQgBAAAAABQgFAEgFAEQgKAJgNAFQgBABgCABQgRAGgUABQgFABgDAAQAAAAAAAAQgbAAgWgHQAAAAgBAAQgPgGgLgKQgFgEgEgFQAAAAAAAAQgPgPgHgVQAAgBAAgBQgCgEgBgEQgEgSAAgVIAAgCAhGAAQAAgVAFgRQAFgYALgPQAUgbAdAAQAeABATAbQAUAeABAqQgDAZgEAOQgFAXgKARQgRAdgfACQghAAgSgcQgMgTgFgbQgCgPAAgR").cp();
	this.shape_268.setTransform(365.6,258.7);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#B5DAA4").s().p("Ah0AAQgBgYAIgVQAAAAAAgBQABgDABgCQAHgTANgQQABgBABgBQAOgQAVgJQABAAAAgBQADgBACAAQAUgHAYAAQACAAACAAQAbAAAUAKQACABACABQAMAGAKAJQAGAEAEAGQABAAAAABQANARAIATQAGAUACARQAAAGAAAFQAAAAAAAAQgBAWgGATQgBADgBACQgBADgBAEQgIAWgPAPQAAAAgBABQgEAFgFAEQgLAIgMAFQgCABgCABQgRAGgVACQgFAAgDAAQAAAAAAAAQgcAAgWgHQgBAAAAAAQgPgHgMgKQgFgFgEgEQAAAAAAAAQgPgQgHgWQAAgBgBgBQgBgEgBgEQgEgTAAgVIAAgCAhFAAQAAgVAEgSQAFgYALgQQATgdAeAAQAfABASAcQATAfABAsQgCAagDAPQgFAYgKASQgRAdgfACQgigBgSgdQgLgUgFgcQgCgPAAgR").cp();
	this.shape_269.setTransform(365.6,258.8);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#B5DAA4").s().p("AAAh+QgcAAgXAKQgWAKgPARQgPATgIAXQgHAWABAZQAAAcAGAXQAIAYAPARQAPASAWAKQAXAHAcABQAbAAAVgIQAVgIAQgRQAPgPAJgYQAJgaABgeQAAgXgIgYQgHgXgPgSQgPgRgVgLQgXgLgeABIAAAAAhEAAQAAg0ATgdQATgeAeAAQAfAAASAeQATAeAAAzQAAAzgSAfQgRAfghABQgfAAgTggQgRgfgBgzIAAAA").cp();
	this.shape_270.setTransform(365.6,258.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_250}]}).to({state:[{t:this.shape_251}]},33).to({state:[{t:this.shape_252}]},1).to({state:[{t:this.shape_253}]},1).to({state:[{t:this.shape_254}]},1).to({state:[{t:this.shape_255}]},1).to({state:[{t:this.shape_256}]},1).to({state:[{t:this.shape_257}]},1).to({state:[{t:this.shape_258}]},1).to({state:[{t:this.shape_259}]},1).to({state:[{t:this.shape_260}]},1).to({state:[{t:this.shape_261}]},1).to({state:[{t:this.shape_262}]},1).to({state:[{t:this.shape_263}]},1).to({state:[{t:this.shape_264}]},1).to({state:[{t:this.shape_265}]},1).to({state:[{t:this.shape_266}]},1).to({state:[{t:this.shape_267}]},1).to({state:[{t:this.shape_268}]},1).to({state:[{t:this.shape_269}]},1).to({state:[{t:this.shape_270}]},1).wait(20));

	// 8
	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#74C056").s().p("AAtgcQAkAMAMAJQgXgDgOAFQgSAFgSAKQgSANgMAHQgZANgXgDQgZgDgHgPQgFgLAEgLQAEgKAOgMQAUgQAcgCQAbgCArAOIAAAA").cp();
	this.shape_271.setTransform(338,336.1);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#74C056").s().p("AArgXQAPAEALAFQADABACABIABAAQAJgCAJgBQABAAAAAAQgHgIgSgIQgLgGgPgEQgCAAgCAAQgLgDgKgCQgNgDgJAAQgKgBgKAAQgSACgcARQgOAMgDAMIAAAAQgBACAAADQgDADgBAFQgEANAGAMQACAEADADQALALAUACQACAAADAAQAVABAUgJQAEgCAEgDQAHgGAJgIQADgCACgCQgPALgKAIQgYANgYgDQgagDgIgPQgGgMAEgNQAAgBAAAAQADgKAOgMQATgQAbgDQAbgBApAOIAAAAAAVAUQACgCACgCQAQgLAQgFQAMgFAUACQgFgEgKgFQgJACgJADQgDACgDABQgIAEgKAIQgCACgCACQgEAEgDAEIAAAA").cp();
	this.shape_272.setTransform(337.8,336.1);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#74C056").s().p("AhaAGQABgFADgDQABgDAAgCQAAAAAAgBQADgIAHgIQADgEAFgEQAPgJAMgFQAKgFAIgBQAIAAAIAAQABAAABAAQAIAAAMACQADAAAEAAQAGABAIACQACAAACAAQAOADALAFQAEABADABQANAHAGAGQgBAAAAAAQgJAAgIACQAAAAAAAAQgCgBgDgBQgCgBgDgBQgIgDgKgEQgOgEgNgDQgTgEgPACQgDABgDAAQgQAEgOAJQgFADgFAEQgLAKgFALQgBAAAAABQAAAAAAABQgDANAGAMQAEAGAGAEQAJAHAPACQAHACAGAAQAQgBAOgIQAGgDAGgEQAFgEAHgFQgCACgDACQgJAIgJAFQgDADgEADQgEABgDABQgRAGgRgBQgDAAgCAAQgKgCgHgDQgJgEgGgGQgDgDgCgEQgGgMADgNAAVALQADgEAEgEQAEgDABgBQAIgGAHgFQAHgDAEgBQADgBADAAQAGgBAGgBQAEACAEADQAEACACADQgFAAgEAAQgHABgHABQgFABgFACQgKADgLADQgGADgGAEQgCABgBABIgBAA").cp();
	this.shape_273.setTransform(337.3,336.4);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#74C056").s().p("AhZAGQABgFADgCQAAgDABgDQAAAAAAAAQACgJAHgIQAEgEAFgEQAPgJANgGQAIgEAHgCQAHgBAIAAQAAAAACAAQAHgBALABQADAAADAAQAHABAHABQACAAABAAQAOACAMAEQADABAEABQAMAFAHAGQgBAAAAAAQgHAAgHACQAAAAgBAAQgCgBgCgBQgCgBgCgBQgHgDgJgDQgNgFgLgBQgSgDgNADQgDABgDABQgPAEgOAKQgFADgFAEQgLAKgGAKQAAACAAACQgBAAAAAAQgBAMAGALQAEAGAGAFQAJAHAPADQAGACAGAAQAQABAMgGQAFgDAFgDQAFgEAGgFQgCACgDACQgKAIgJAFQgEADgDACQgEACgDABQgSAGgRgCQgDAAgCAAQgKgCgHgDQgKgEgGgGQgCgEgCgEQgGgMADgOAATAEQADgEADgDQAFgGABgBQAIgHAIgEQAIgDAEAAQADgBAEgBQAGAAAFAAQAFADADACQAEAEACACQgFABgEABQgIABgHACQgFABgFABQgLADgLAEQgHABgGACQgBABgCABIAAAA").cp();
	this.shape_274.setTransform(337.1,336.7);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#74C056").s().p("AhZAIQABgGADgDQAAgCABgDQAAAAAAAAQADgJAHgIQADgFAFgEQAPgJAOgGQAHgFAGgBQAGgCAHAAQABgBABAAQAIgBAJAAQADAAADAAQAGAAAHAAQABAAACAAQAOABALADQAEABADABQANAEAHAFQAAAAgBAAQgGAAgGACQAAAAAAAAQgCgBgCgBQgCgBgCgBQgFgDgIgDQgLgDgKgCQgQgBgNAEQgCABgDABQgOAGgOAKQgFADgFAFQgLAKgHAKQAAACAAACQAAAAAAAAQgBALAHALQAEAGAGAFQAJAHAOAEQAGACAGABQANACANgFQAEgCAFgDQAEgDAFgEQgDACgDACQgJAIgKAFQgEADgDACQgEABgEABQgSAGgRgCQgDAAgCgBQgKgBgIgEQgJgEgGgHQgDgDgCgEQgGgNADgNAAQgBQADgFAEgFQAFgGABgBQAIgHAJgFQAJgCAEgBQADAAAEAAQAGAAAGABQAEADADADQADADADADQgFACgEABQgIACgHADQgGAAgFABQgNACgKADQgHACgGABQgCABgBABIgBAA").cp();
	this.shape_275.setTransform(336.9,336.8);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#74C056").s().p("AhYAKQAAgGADgEQAAgBABgDQAAAAAAgBQADgJAHgIQAEgEAFgFQAPgJAOgGQAHgFAFgCQAFgCAGgBQAAAAABAAQAIgCAIgBQACgBADAAQAGgBAHAAQABAAACAAQANAAAMACQADABAEAAQANAEAHAFQAAgBgBAAQgFAAgFACQAAAAAAAAQgBgBgCgBQgCgBgBgBQgFgCgHgDQgJgDgIgBQgOAAgOAGQgCABgBABQgNAGgOALQgFAEgFAEQgMAKgGAKQgBACAAACQAAAAAAAAQABALAHALQAEAGAGAFQAJAIAOAEQAGADAGABQALAEAMgEQADgBAEgDQAEgCAEgEQgDACgDACQgKAIgKAEQgFADgEACQgCABgEABQgSAGgSgCQgDgBgDAAQgKgCgHgEQgJgEgGgHQgDgDgCgFQgGgMADgOAAOgIQADgFADgFQAGgHABAAQAJgIAJgEQAKgCAEgBQADAAAEAAQAGABAGABQAEADADAEQADAEACADQgEACgEACQgIADgIADQgGAAgFABQgOAAgLADQgHABgGABQgBAAgBAAIgBAA").cp();
	this.shape_276.setTransform(336.8,336.9);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#74C056").s().p("AhYANQABgGACgFQABgCAAgCQAAAAAAAAQADgJAHgJQAEgEAGgFQAPgJAOgGQAGgGAEgCQAEgCAFgBQABgBABAAQAGgDAIgBQACgBADgBQAFgBAGAAQACgBACAAQAMgBAMABQAEABADAAQANADAIAEQAAAAAAAAQgFAAgEABQAAAAAAAAQgBgBgBgBQgBgBgCgBQgDgCgGgDQgHgCgHAAQgMABgNAHQgCABgCACQgMAHgNALQgFAEgGAEQgLALgHAKQgBABABACQgBAAAAABQACAKAIALQAEAGAGAFQAKAIAMAFQAGADAEACQANAFAJgDQAEAAACgCQADgCADgEQgCADgEACQgKAHgKAFQgFACgFACQgBACgEAAQgTAGgSgDQgDAAgDgBQgKgCgIgEQgJgFgGgHQgCgDgCgEQgHgNADgOAALgNQADgFADgFQAGgIABgBQAKgIAKgEQALgCAEAAQAEAAADABQAHABAFACQAEADADAEQADAFACADQgEADgFACQgHAEgJADQgGAAgGAAQgOAAgLACQgIABgFgBQgCAAgBAAIgBAA").cp();
	this.shape_277.setTransform(336.6,336.9);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#74C056").s().p("AhYAQQABgGACgFQABgDAAgCQAAAAAAAAQADgJAIgIQAEgFAFgEQAPgKAPgGQAFgGADgCQADgDAFgCQAAAAABgBQAGgDAIgCQADgBAAgBQAFgCAGgBQACgBACAAQAMgBAMAAQADAAAEAAQANADAIADQAAgBAAAAQgEAAgCABQAAAAgBAAQAAgBgCgBQAAAAgBgBQgDgDgEgCQgGgCgFABQgKACgMAJQgCABgCACQgNAIgMALQgEAEgGAFQgLAKgIAKQAAACAAACQAAAAAAAAQADALAIALQAEAGAGAEQAKAJAKAGQAFADAGACQAMAGAIgBQADAAACgBQACgCACgCQgDACgDACQgKAHgLAFQgFACgFACQgDABgDABQgTAFgSgDQgDAAgDgBQgKgCgIgFQgJgFgGgHQgDgDgCgEQgGgNACgPAAJgSQADgFADgGQAGgIABgBQAKgJALgEQALgBAFAAQAEABADAAQAHACAFACQAEAEADAFQADAFACAEQgEADgFACQgHAFgJAEQgHgBgGAAQgPgBgLACQgIgBgGgBQgBAAgBgBIgBAA").cp();
	this.shape_278.setTransform(336.4,336.9);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#74C056").s().p("AhYAUQABgGACgFQABgDABgDQAAAAAAgBQADgIAHgIQAEgFAGgFQAPgKAPgGQAEgGACgDQADgDADgCQABAAABgBQAEgEAIgDQACgBADgBQACgDAGgBQACgBACAAQALgDAMgBQAEAAADABQANABAJACQAAAAAAAAQgDAAgBAAQAAAAAAAAQgBAAgBgBQAAgBgBgBQgBgCgEgCQgDgBgEACQgIADgLAJQgCACgCACQgMAJgMAMQgEAEgGAFQgLAKgJAKQAAACAAABQAAABAAAAQAEAKAIALQAFAGAGAFQAKAIAJAHQAGAEAFACQALAIAHAAQACABABgBQACgBABgCQgDACgEACQgKAHgMAFQgEACgFACQgEABgCABQgUAEgSgDQgDAAgDgBQgKgCgIgFQgKgFgGgIQgCgDgCgEQgHgNACgPAAHgWQACgHADgFQAHgJABgBQAKgKAMgDQAMgBAFABQAEAAAEABQAGACAGADQAEAFACAFQADAFABAEQgEAEgEADQgHAFgKAEQgHgBgGAAQgQgBgMAAQgIgBgFgCQgCgBgBAAIAAAA").cp();
	this.shape_279.setTransform(336.2,336.8);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#74C056").s().p("AhXAXQAAgGADgFQAAgDABgDQAAAAAAAAQADgJAIgJQAEgEAFgFQAQgKAQgHQACgFABgEQACgDADgDQAAAAABgBQAEgFAHgEQACgBACgCQAFgCADgCQACgBABgBQAMgDAMgCQADAAAEAAQANAAAJACQAAAAAAAAQgBgBgBABQAAAAAAAAQAAgBgBAAQAAgBgBgBQABgCgDgBQgCgCgDADQgFAEgKALQgCACgCACQgLAKgOANQgDAEgFAFQgMAKgJAKQAAACABABQAAAAAAABQAFAKAIAKQAFAHAGAFQAIAIALAIQAFAEAFADQAKAJAFACQACAAABAAQAAAAABgCQgDACgEADQgLAHgMAEQgEACgFACQgEABgDAAQgUAFgSgEQgDAAgDgBQgLgCgIgFQgJgGgGgHQgDgEgCgEQgHgOADgPAAEgbQACgHAEgFQAHgKABgBQAKgKANgDQANgBAFABQAEABAEABQAHADAFAEQAEAEACAGQADAFABAFQgEAEgEADQgIAHgKAEQgHgBgHgBQgQgCgMAAQgIgCgGgDQgBgBgBgBIgBAA").cp();
	this.shape_280.setTransform(336,336.8);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#74C056").s().p("AhXAbQABgGACgFQAAgEABgDQAAAAAAAAQADgJAIgJQAFgFAFgEQAPgKARgHQABgGAAgEQABgEADgDQAAAAAAgBQADgFAHgFQACgCACgCQAEgDAFgCQACgBAAgBQAKgFANgCQADAAADgBQANAAAKABQAAAAAAAAQAAgBAAABQAAAAAAAAQAAgBAAgBQAAgBAAAAQABgCgBgBQAAgBgCAEQgEAFgJAMQgBACgCACQgKALgOANQgFAFgFAFQgKAKgKAKQAAABABACQAAAAAAABQAGAJAJALQAEAGAFAGQAKAIALAJQAFAEAEADQAKALADADQABABAAABQAAAAgBgBQgDACgDACQgMAHgMAEQgEACgFACQgEABgFAAQgSAEgTgDQgDgBgDgBQgLgDgIgFQgKgGgGgHQgCgEgCgEQgHgOACgPAACggQACgGADgGQAHgLABgBQAMgKAOgDQANgBAFACQAEAAAEACQAHADAFAFQAEAFACAGQACAFACAFQgEAFgEAEQgIAHgKAFQgIgBgHgBQgSgDgLgBQgJgDgFgEQgCgBgBgCIAAAA").cp();
	this.shape_281.setTransform(335.8,336.7);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#74C056").s().p("AhXAfQABgGACgGQAAgDABgDQAAAAAAgBQAEgKAIgIQAEgFAGgEQAPgLARgHQAAgGAAgEQgBgEACgEQAAAAABgBQACgGAFgGQACgCACgCQAEgEAFgDQABgBACgBQAIgFANgDQADgBAEAAQANgBAKABQAAgBAAAAQABgBABAAQABAAAAAAQAAgBAAAAQAAgBAAAAQADgCAAgBQABAAAAAEQgCAHgIANQgBACgCADQgJALgOAOQgFAFgGAFQgJALgLAJQABABAAACQAAAAABABQAHAJAHALQAFAGAGAFQAKAKAKAIQAFAFAEAEQAJAMACAEQAAACAAABQgBABgCgBQgDACgEADQgLAGgNAEQgEACgGACQgEAAgEABQgTAEgTgEQgDgBgDgBQgLgDgJgFQgJgGgGgIQgDgEgCgEQgHgOACgPAAAgkQABgHAEgHQAHgKABgCQAMgLAPgCQAOAAAFABQAEABAEACQAHAEAGAFQADAFACAHQACAGABAFQgDAFgFAFQgHAIgLAFQgIgCgHgBQgTgEgLgCQgKgDgFgEQgBgCgBgCIAAAA").cp();
	this.shape_282.setTransform(335.6,336.6);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#74C056").s().p("AhWAiQAAgGACgFQABgEAAgDQAAAAAAAAQAEgLAIgIQAFgFAFgFQAQgKARgHQgBgHgBgEQgBgFABgEQAAAAAAgBQABgHAFgGQACgDACgCQADgEAFgEQABgBACgBQAJgGAMgEQADgBADgBQANgCALABQAAgBAAAAQACgBADAAQAAAAAAAAQAAgBABAAQAAgBABgBQADgBABgBQAEABABAFQAAAHgHAPQgBADgCACQgIAMgOAPQgFAFgGAFQgLALgKAJQABABABACQAAAAAAABQAGAJAKAKQAFAHAGAFQAKAKAKAJQAEAFAEAFQAIAMABAGQgBADgBABQgCACgCAAQgDACgEACQgMAHgNADQgEACgGACQgEAAgEABQgUADgTgEQgDAAgDgBQgLgEgJgFQgJgHgHgIQgCgDgCgFQgHgOACgQAgBgpQABgHACgHQAIgLABgBQAMgMAQgCQAOAAAGACQAEABAEACQAIAEAFAGQADAGACAHQACAGABAGQgDAFgFAFQgHAJgMAGQgIgCgIgCQgTgEgMgDQgJgEgFgFQAAgCAAgDIgBAA").cp();
	this.shape_283.setTransform(335.4,336.6);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#74C056").s().p("AhWAmQAAgGACgGQABgDAAgDQAAAAAAgBQAEgLAIgIQAFgFAGgFQAPgKASgIQgCgGgCgFQgCgFAAgEQAAgBAAgBQABgHAEgIQABgCACgDQADgFAFgEQABgBACgBQAJgHALgFQADgBAEgBQANgDALAAQAAAAAAgBQADgBAEAAQAAAAAAAAQABgBAAgBQABAAABgBQAFgBACAAQAFAAADAGQACAJgGAQQgBADgCADQgHANgOAPQgFAFgGAFQgMALgLAJQAAABABACQAAAAAAABQAKAJAJAKQAGAGAGAGQAKAKAJAKQAFAFADAFQAHAOgBAIQgBADgCACQgCACgDAAQgEACgEADQgMAGgNAEQgFABgFACQgEAAgFABQgUADgTgEQgDgBgEgBQgLgEgIgGQgKgGgGgIQgDgEgCgEQgHgPACgQAgDgtQABgIACgHQAIgMABgBQAMgMARgCQAPAAAGACQAEACAEACQAIAFAFAGQADAHACAHQACAHAAAFQgDAHgEAFQgHAKgMAGQgJgCgIgCQgUgFgMgEQgKgEgDgHQgBgCgBgDIAAAA").cp();
	this.shape_284.setTransform(335.3,336.5);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#74C056").s().p("AhWAqQABgGABgGQABgEABgDQAAAAAAAAQADgMAJgKQAFgDAGgFQAPgLASgHQgDgHgDgFQgDgFAAgFQAAgBAAgBQgBgIAEgIQABgDACgDQACgFAFgFQABgBABgBQAKgJALgGQADgBADgBQANgDAMgBQAAAAABgBQADgCAFAAQAAAAAAAAQABAAABgBQACgBABAAQAFgBAEAAQAHABAEAHQAEAKgFARQgBADgBADQgHAOgOAQQgFAFgGAFQgMALgNAJQABABACACQAAAAAAABQAKAIAKALQAGAGAGAGQALAKAIALQAEAFADAGQAHAPgDAJQgBAEgDACQgDADgEABQgEACgEACQgMAGgOAEQgFABgFACQgEAAgFABQgVADgTgFQgDgBgEgBQgLgEgJgGQgJgHgHgIQgCgEgCgEQgHgOABgRAgGgyQACgIADgHQAGgMACgCQAMgMASgCQAQAAAGADQAFABAEADQAIAFAEAIQAEAGABAIQACAHAAAGQgDAHgEAGQgIAKgMAHQgJgDgIgCQgVgGgMgEQgKgFgDgIQgCgDAAgDIgBAA").cp();
	this.shape_285.setTransform(335.1,336.4);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#74C056").s().p("AhWAuQABgHACgGQAAgDABgDQAAAAAAgBQAEgMAIgKQAFgEAGgEQAQgLATgIQgFgHgEgFQgDgGgBgFQgBgBAAgBQgBgIADgKQABgDABgDQADgGAEgFQABgBABgCQAJgJANgHQADgBACgBQANgEAMgCQAAAAABgBQAFgCAFAAQABAAAAAAQABgBABAAQACgBABAAQAHgBAFAAQAIACAGAHQAGAMgEASQgBADgBADQgGAPgPAQQgEAGgGAFQgMALgOAJQACACABABQAAAAAAABQAMAIAKALQAGAGAGAGQALAKAIAMQADAFADAHQAGAQgEAKQgCAFgEADQgEADgFABQgDADgFACQgMAGgOADQgFACgFABQgFAAgEABQgVACgUgEQgDgBgEgCQgLgDgJgHQgKgHgGgJQgDgDgCgFQgHgOABgRAgIg2QABgIADgIQAHgNABgBQAOgNASgCQARABAGACQAFACAEADQAIAGAFAIQADAHABAIQACAHAAAHQgDAHgEAHQgIALgNAHQgJgDgJgCQgVgHgMgFQgJgGgFgIQgBgEgBgDIAAAA").cp();
	this.shape_286.setTransform(334.9,336.3);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#74C056").s().p("AhVAyQAAgHACgGQAAgDABgEQAAAAAAAAQAEgNAJgKQAFgFAGgDQAPgLAUgIQgGgHgEgGQgFgGgCgGQAAgBAAgBQgDgJADgKQAAgDABgEQADgGAEgGQABgBABgCQAIgKAOgIQADgBADgCQAMgFAMgCQAAAAABAAQAGgDAGAAQABAAAAAAQACgBABAAQACgBACAAQAIgBAFABQAKACAIAIQAIANgEATQAAAEgBADQgFAQgPAQQgEAGgGAFQgMALgPAJQACACABABQAAAAABABQAMAIALAKQAHAHAGAGQAKAKAHANQAEAGACAGQAFASgGAMQgCAFgEADQgFAEgGACQgEACgEACQgNAGgOAEQgFABgFABQgFAAgFABQgVACgUgFQgEgBgDgBQgLgEgJgHQgKgHgGgJQgDgEgCgEQgHgPABgRAgKg7QABgIADgIQAHgOABgBQAOgOATgBQARABAHADQAFACAEADQAIAHAFAIQADAHABAJQABAIAAAHQgCAIgEAHQgIALgNAIQgLgDgIgDQgXgIgMgFQgJgHgEgJQgCgEAAgEIAAAA").cp();
	this.shape_287.setTransform(334.7,336.2);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#74C056").s().p("AhYA2QAAgHACgGQAAgEABgDQAAAAAAAAQAEgNAJgLQAFgFAGgFQAQgJAUgJQgHgHgGgGQgFgGgDgHQAAgBAAgBQgEgJACgMQABgDABgEQACgGADgGQABgCACgCQAIgLANgJQADgBAEgCQALgGANgCQAAgBABAAQAHgDAHAAQABAAAAAAQACgBABAAQADgBACAAQAJgBAHABQAMADAIAJQALANgDAWQAAADgBADQgFARgOARQgFAGgGAGQgMALgPAIQACACABABQABAAAAABQANAIALAKQAHAHAGAGQALALAGAMQAEAHACAHQAEATgHANQgDAGgFAEQgGAEgGADQgEACgFACQgNAGgOADQgFABgGABQgEABgFAAQgWACgUgFQgEgCgDgBQgMgEgJgHQgKgIgGgJQgDgEgCgEQgHgPABgRAgQg/QABgJADgHQAJgPACgCQAMgOATgBQATACAHADQAFACAEADQAIAHAFAKQADAHABAJQABAIAAAIQgDAIgEAHQgHANgOAIQgLgDgJgDQgXgJgMgHQgJgHgFgKQgBgEgBgEIAAAA").cp();
	this.shape_288.setTransform(334.8,336.1);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#74C056").s().p("AhcA6QAAgHACgGQAAgEABgEQAAAAAAAAQAEgNAJgLQAGgFAGgFQAPgKAVgIQgIgHgGgHQgGgHgEgGQAAgBgBgCQgEgKABgMQAAgEABgEQACgHADgGQABgCACgCQAHgMAOgKQADgCADgCQANgGAMgDQAAgBABAAQAIgDAJgBQAAAAAAAAQACAAACAAQADgBACAAQALgBAIACQANADAKAKQANAOgCAXQAAADgBAEQgEARgOASQgFAGgGAGQgMALgQAJQACABACABQAAAAAAABQAPAIALAKQAHAGAGAHQALALAGANQADAHACAIQADAUgIAPQgEAGgGAEQgGAFgHADQgFADgEACQgNAFgPADQgFABgGABQgFABgFAAQgWACgUgGQgEgBgDgCQgMgEgJgHQgKgIgHgJQgCgEgCgFQgIgPABgRAgWhEQAAgJADgHQAKgQACgBQAMgPAVgBQATACAHAEQAFACAEAEQAJAHAEAKQADAIABAJQABAJgBAHQgCAKgEAHQgHAOgPAIQgLgEgJgDQgYgJgKgIQgMgHgEgLQgCgFAAgFIAAAA").cp();
	this.shape_289.setTransform(335,336);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#74C056").s().p("AhgA9QABgHABgGQABgDAAgEQAAAAAAAAQAFgOAJgKQAFgGAHgFQAPgKAVgIQgJgIgHgHQgHgHgEgHQgBgBAAgBQgGgLABgNQAAgEABgEQABgIADgHQABgCABgCQAIgNANgKQADgDAEgCQANgHAOgEQAAAAABgBQAHgDAKgBQAAAAABAAQACAAACAAQADgBADAAQALAAAJABQAQAEALAKQAPAQgBAYQAAAEgBAEQgDASgOASQgFAHgGAFQgMALgRAJQACABACABQABABAAAAQAPAIAMAKQAHAGAGAHQALALAGAOQADAIABAIQADAVgLAQQgEAHgGAFQgHAGgJADQgEACgFACQgNAGgPADQgFABgGAAQgFABgFAAQgXACgUgGQgEgCgDgBQgMgFgKgHQgKgIgGgKQgDgEgCgEQgHgQAAgSAgdhIQABgJADgIQAKgQABgCQAOgPAVAAQAUABAHAEQAFADAEAEQAJAIAFALQACAIABAJQABAKgBAHQgCAKgEAIQgIAOgPAJQgLgEgJgDQgZgKgLgJQgLgIgFgMQgBgEgBgGIAAAA").cp();
	this.shape_290.setTransform(335.2,336);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#74C056").s().p("AhjBBQAAgHABgGQABgEABgEQAAAAAAAAQAEgNAJgLQAGgGAGgFQAQgKAVgJQgKgHgIgIQgIgHgFgIQAAgBgBgBQgGgMAAgOQAAgEAAgEQABgJADgHQABgCABgCQAHgOAOgLQADgDADgCQAOgIAOgFQAAAAABAAQAKgEAJgBQAAAAABAAQADAAACgBQADAAADAAQANAAAKACQARAEANALQAQARABAZQAAAEgBAEQgCATgOATQgFAHgGAFQgNAMgRAIQACABADABQAAABAAAAQARAIAMAKQAIAGAGAHQAKALAFAPQADAIABAIQACAXgMASQgFAHgHAFQgHAHgKAEQgEACgFACQgOAGgPACQgGABgFABQgFAAgFAAQgXABgVgGQgEgBgEgCQgMgFgJgIQgKgIgGgJQgDgFgCgEQgIgPABgTAgjhMQAAgKADgIQAKgRACgCQAQgPAUAAQAUACAIAEQAFADAFAEQAJAJAEALQADAIAAALQABAJgBAIQgCAKgEAJQgIAPgPAJQgMgEgJgEQgYgLgNgJQgMgJgEgMQgCgFAAgGIAAAA").cp();
	this.shape_291.setTransform(335.5,335.9);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#74C056").s().p("AhnBFQAAgHABgGQABgEABgEQAAAAAAAAQAEgOAKgLQAFgGAHgFQAPgMAWgHQgLgIgJgIQgJgHgFgIQgBgCgBgBQgHgMgBgPQAAgFABgEQAAgJADgIQABgCABgDQAGgOAOgMQADgDAEgDQANgIAPgFQAAgBABAAQALgEAKgBQABAAAAAAQADgBADAAQADAAAEAAQANAAAMACQATAFAOAMQASASABAaQABAEgBAFQgBATgPAUQgEAHgHAGQgMALgSAIQADABACABQAAABABAAQARAIAMAKQAIAGAGAHQALAMAFAPQACAIABAJQABAZgNASQgGAIgHAGQgJAHgKAEQgFADgFACQgOAFgPACQgGABgGABQgEAAgFAAQgYABgVgGQgEgCgEgCQgMgFgKgIQgKgIgGgKQgDgEgCgFQgHgPAAgTAgqhRQABgJADgJQAKgRACgCQAQgQAVAAQAVACAIAFQAFADAFAEQAJAJAEAMQADAJAAALQAAAKgBAIQgCALgEAJQgHAQgQAJQgMgEgKgEQgZgMgMgKQgNgJgEgOQgBgFgBgHIAAAA").cp();
	this.shape_292.setTransform(335.7,335.8);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#74C056").s().p("AhrBJQAAgHABgGQABgEABgEQAAAAAAAAQAEgPAKgLQAFgGAHgFQAQgMAWgHQgMgIgKgIQgJgJgHgIQgBgBAAgCQgJgNgBgPQAAgFAAgFQAAgJADgJQABgCABgDQAGgPANgNQADgDAEgDQANgKAPgFQABgBABAAQAMgEANgBQABAAAAAAQACgBADAAQADAAAEAAQAPAAAMADQAVAFAQANQAUATACAcQAAAEAAAEQAAAVgPAUQgEAHgHAGQgMALgTAJQADABACABQABAAAAABQASAHANAJQAIAHAGAHQALAMAEAQQADAIAAAKQAAAagPAUQgGAIgIAHQgJAHgLAFQgFADgGACQgNAFgRACQgFAAgGABQgFAAgDAAQgaABgVgHQgEgBgEgCQgMgFgKgJQgKgIgHgKQgCgFgCgEQgIgQAAgTAgwhVQAAgKADgJQALgSACgCQAQgQAVAAQAXADAIAFQAFADAFAFQAJAJAEANQADAJAAALQAAAKgBAJQgCALgEAKQgHARgRAKQgMgFgKgFQgagMgNgLQgMgKgFgPQgBgFAAgHIAAAA").cp();
	this.shape_293.setTransform(335.9,335.7);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#74C056").s().p("AAEijQgoAAggAYQgeAZAAAjQAAAYAOATQANASAcAQQghAMgSATQgRAUAAAcQAAAmAdAZQAeAZAwgBQAzAAAggaQAggbABglQAAgdgRgTQgRgUgkgNQAdgMAOgVQAPgVgBgVQAAgjgagYQgbgVgqgBIAAAAAA6hVQAAAYgHASQgIARgRALQgsgTgSgQQgSgPgBgYQAAgXAQgRQARgRAWAAQAaAAAQARQAQARAAAbIAAAAAgaAFIAnASQAUAJALAIQALAJAGALQAGAKAAAOQAAAbgSASQgSASgfAAQgeAAgSgUQgUgUAAggQAAgXAKgSQALgSAVgLIAAAA").cp();
	this.shape_294.setTransform(336.1,335.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_271}]}).to({state:[{t:this.shape_272}]},37).to({state:[{t:this.shape_273}]},1).to({state:[{t:this.shape_274}]},1).to({state:[{t:this.shape_275}]},1).to({state:[{t:this.shape_276}]},1).to({state:[{t:this.shape_277}]},1).to({state:[{t:this.shape_278}]},1).to({state:[{t:this.shape_279}]},1).to({state:[{t:this.shape_280}]},1).to({state:[{t:this.shape_281}]},1).to({state:[{t:this.shape_282}]},1).to({state:[{t:this.shape_283}]},1).to({state:[{t:this.shape_284}]},1).to({state:[{t:this.shape_285}]},1).to({state:[{t:this.shape_286}]},1).to({state:[{t:this.shape_287}]},1).to({state:[{t:this.shape_288}]},1).to({state:[{t:this.shape_289}]},1).to({state:[{t:this.shape_290}]},1).to({state:[{t:this.shape_291}]},1).to({state:[{t:this.shape_292}]},1).to({state:[{t:this.shape_293}]},1).to({state:[{t:this.shape_294}]},1).wait(13));

	// 9
	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#5C7C41").s().p("ABcAAQgEgLgOgLQgUgQgdgCQgbgCgrAOQgkAMgMAJIAOgBQAPAAAIADQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLIAAAA").cp();
	this.shape_295.setTransform(487,153.1);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#5C7C41").s().p("AAagxQAcACAUARQAOANAEAPQgBAEgCAEQABADAAACQAAAHgCAGQgBAFgDAFQgGAJgLAEQgEABgDABQgEAAgEABQgMAAgOgJQgFgDgEgEQgIgIgHgHQgJgEgGgCIAAAAQgHgDgIgDQgNgGgNgDQgCgBgDgBQgDgBgCgBQgEgBgFAAQgFgBgEgCQgEAAgEgBIgBAAQAIgKAXgKQAIgFALgDQAJgDAJgCQAKgCAKgBQAPgDAOABIAAAA").cp();
	this.shape_296.setTransform(486.5,153.3);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#5C7C41").s().p("AhagNQAHgMAWgKQABgBABgBQAJgFALgDQAHgCAHgCQACAAADgBQAMgCAIAAQAGAAAFAAQALAAAJACQAMABAKAFQAOAHAKAMQAAAAAAAAQALAMACANQABABAAACQgCAFgCAFQABADgBACQAAAEgBAEQAAADgCACQgCAFgDAFQgFAGgHAEQgDABgDABQgBAAAAAAQgDABgCAAQgBAAgBAAQgCABgCAAQgKAAgMgKQgCgBgBgBQgCgDgDgDQgHgJgFgIQgCgBgCgBQgGgDgGgBQAAAAgBAAQgBAAgBAAQgGgDgIgCQgCgBgCgBQgMgEgLgDQgDgBgCgCQgBAAAAAAQgDgBgCAAQgEgCgFgBQgFgBgEgCQgEgCgDgBQgBAAAAAAIAAAAAhYgNQAIgLAWgKQAVgKADgBQAGgCAGgBQAKgDAKgBQAGgBAIgBQAHAAAHAAQAWACAQAKQAFAEAFAFQAOAMADAQQgBAFgBADQABAMgCAGQgDAIgBACQgDAEgEAEQgEADgEACQgCABAAAAQgDABgDAAQgEABgEABQgIAAgJgDQgEgCgFgDQgFgDgEgEQgEgDgEgEQgEgEgDgCQgJgFgGgCQgIgDgHgDQgCgBgCgBQgLgFgKgDQgDgBgCgBQgDgBgCgBQgEgBgEgBQgFgBgFgCQgDgBgEAAQAAAAgBAA").cp();
	this.shape_297.setTransform(486.3,153.3);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#5C7C41").s().p("AhagPQAHgOAXgMQABAAABgBQAJgGANgDQAGgCAIgCQADgBADAAQAMgCAJABQAGAAAFABQALABAKADQALADAKAGQAMAJAJANQAAAAAAAAQAKAOABAMQAAACAAACQgCAGgCAFQAAADgBACQAAAEgCAEQgBADgCADQgCAFgEAEQgGAGgIAEQgCABgEAAQAAAAgBAAQgBAAgCABQgBAAgBgBQgBABgCAAQgHgBgKgLQgBgBgBgBQgDgDgCgDQgFgKgFgJQgCgCgBgBQgIgCgFAAQAAAAgBAAQgBAAgBgBQgHgBgIgCQgCgBgDgBQgNgEgMgGQgCAAgDgBQgBAAAAAAQgDgBgCgBQgEgCgFgBQgFgCgEgDQgEgCgDgCQAAAAgBAAIAAAAAhUgQQAHgLAVgLQAUgKADgBQAGgCAFgCQALgDAKgBQAGgBAIgBQAHAAAHABQAVABAQALQAFAEAFAFQANANAEAQQgBAFgBADQABALgCAHQgDAHgBACQgDAFgEAEQgDADgEACQgCABAAAAQgDABgDABQgDAAgEABQgIABgJgDQgFgBgFgDQgEgDgFgDQgEgEgEgDQgEgDgDgDQgJgEgHgDQgHgDgIgDQgCgBgBgBQgLgFgKgEQgCgBgCgBQgDgBgCgBQgEgBgEgBQgFgCgEgCQgDgBgEgBQAAAAAAAA").cp();
	this.shape_298.setTransform(486.1,153.4);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#5C7C41").s().p("AhZgRQAGgQAXgNQABgBABAAQAKgHAOgEQAHgCAIgCQADAAADAAQANgCAKACQAGAAAGACQALACAJAEQALAEAJAIQAMALAIAOQAAAAAAAAQAIAPAAANQAAACgBADQgCAGgDAFQgBACAAADQgBAEgCAEQgCADgCADQgDAFgEAEQgGAGgJADQgDABgDAAQAAgBgBAAQgBABgBAAQgBAAAAAAQgBAAgCAAQgEgCgIgMQgBgBgBgBQgCgDgCgDQgEgLgEgKQgBgCgBgCQgKgBgEAAQgBAAAAAAQgBAAgCAAQgHgBgIgCQgDgBgDgBQgNgEgNgGQgDgCgDAAQAAAAgBAAQgDgBgCgBQgEgCgEgCQgGgDgEgDQgDgCgDgDQgBAAAAAAIAAAAAhRgSQAGgMAUgLQAUgLADgBQAFgCAGgCQAKgEAKgBQAHgBAHgBQAIAAAHABQAVACAPALQAGAEAEAFQANANADAQQAAAGgCAEQABAKgBAHQgDAHgBACQgDAFgDAEQgDADgFACQgBABAAAAQgDABgDABQgDABgEABQgIABgJgCQgFgCgFgCQgEgDgFgDQgEgDgEgEQgEgCgEgDQgJgEgGgDQgHgDgIgDQgCgBgCgCQgKgEgJgFQgDgBgCgBQgCgBgDgBQgDgCgEgBQgEgBgEgDQgDgBgDgBQgBAAAAAA").cp();
	this.shape_299.setTransform(485.9,153.5);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#5C7C41").s().p("AhZgUQAGgSAYgOQABgBABgBQALgHAOgEQAHgCAJgCQADAAADAAQANgCAMADQAGABAGACQALADAJAFQAMAGAIAKQALAMAGAQQAAAAAAAAQAHAOgCAPQAAADgBACQgDAHgDAFQgBADgBACQgBAEgDAEQgBADgDADQgDAFgFAEQgHAGgJAEQgDAAgDgBQgBgBAAAAQgBAAAAABQgBgBAAAAQAAAAgBAAQgCgDgGgMQgBgBgBgBQgBgEgCgDQgCgLgDgMQgCgDgBgBQgJAAgIAAQAAAAAAAAQAAAAgBAAQgIgBgJgBQgDgBgCgBQgPgEgNgHQgEgCgDgBQAAAAgBAAQgCAAgDgCQgEgCgEgCQgGgEgEgEQgDgCgDgDQAAAAgBgBIAAAAAhOgVQAGgNATgLQATgMADgBQAFgCAGgCQAKgEAKgBQAGgCAIAAQAHgBAHABQAVACAPANQAGAEAEAFQAMANAEAQQgBAGgBAEQABAKgCAHQgCAHgBACQgCAFgEAEQgDADgEACQgBABAAABQgDABgDABQgDABgEABQgIABgJgCQgFgBgFgCQgEgCgFgDQgEgDgFgDQgEgDgDgDQgJgEgHgCQgHgEgHgDQgCgBgCgBQgKgEgJgGQgCgBgCgCQgDgBgCgBQgDgCgEgBQgEgCgEgCQgDgCgCgBQgBAAAAAA").cp();
	this.shape_300.setTransform(485.7,153.6);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#5C7C41").s().p("AhZgWQAGgUAYgQQABgBABAAQAMgJAPgEQAHgCAJgBQAEgBADAAQANgBANAEQAHABAGADQALAEAJAGQALAHAIALQAKAPAFAQQAAABAAAAQAGAPgDAQQgBADgBACQgDAHgFAFQAAADgCACQgCAFgCAEQgCADgDADQgEAFgGAEQgHAGgKADQgDgBgDgBQAAAAgBgBQAAABAAgBQAAAAAAAAQAAAAAAAAQABgEgFgNQAAgBgBgCQgBgDgBgEQgBgMgDgNQgBgCAAgDQgLABgIABQAAAAAAAAQgCAAgBAAQgGAAgKgCQgDAAgDgBQgQgDgNgIQgEgCgDgCQAAgBgBAAQgDAAgCgBQgFgDgEgCQgFgEgEgFQgDgDgDgDQAAgBgBAAIAAAAAhLgYQAFgNASgMQATgMACgCQAGgCAFgCQAKgEAKgCQAGgBAIgBQAIAAAHABQAUACAPANQAFAEAFAGQALANAEAQQgBAGgBAFQABAJgBAHQgCAHgCACQgCAFgDAEQgDADgDADQgBABgBAAQgDACgCABQgEABgDABQgIACgJgCQgFgBgFgBQgEgDgFgCQgFgDgEgDQgEgCgEgDQgJgEgHgDQgHgDgHgEQgCgBgBgBQgKgEgJgGQgCgCgCgBQgDgBgBgCQgEgBgDgCQgEgCgDgDQgDgBgDgCQAAAAAAAA").cp();
	this.shape_301.setTransform(485.6,153.7);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#5C7C41").s().p("AhZgZQAFgVAZgRQABgBABgBQAMgJAQgEQAIgDAJgBQAEAAAEAAQAOgBANAEQAHACAHADQALAFAJAIQALAIAHANQAJAQAEASQAAABAAAAQAEAQgFARQAAADgBACQgEAHgFAGQgBADgCACQgCAEgDAFQgDADgDACQgEAFgGAEQgJAGgLAEQgCgCgDgBQAAgBgBgBQABABAAgBQAAAAAAAAQABAAAAgBQAEgEgCgOQgBgCAAgBQgBgDAAgEQAAgNgCgPQgBgCgBgDQgKACgJABQAAAAAAAAQgCAAgBAAQgHABgKgCQgDAAgDgBQgRgDgPgJQgDgCgDgCQgBAAAAgBQgDgBgDAAQgEgDgFgDQgFgFgEgFQgDgEgCgEQgBAAAAAAIAAgBAhJgbQAFgOARgMQASgNADgBQAFgDAFgCQAKgFAKgBQAGgCAIAAQAIgBAHACQAUACAPAOQAEAEAFAGQALANADAQQAAAGgBAFQABAMgBAFQgCAGgBADQgCAFgDAEQgDADgDACQgBACgBAAQgCACgDABQgDABgEABQgIADgJgCQgFAAgFgCQgEgCgFgCQgEgDgFgCQgEgDgEgCQgJgEgHgDQgHgDgHgEQgCgBgBgCQgKgEgIgGQgCgCgCgBQgDgCgBgBQgDgCgEgCQgDgCgDgDQgDgCgCgCQgBAAAAAA").cp();
	this.shape_302.setTransform(485.5,153.9);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#5C7C41").s().p("AhZgbQAEgYAZgSQACgBABgBQANgKAQgEQAJgCAKgCQADAAAEAAQAPgBAOAGQAIACAGAEQAMAGAJAJQAKAKAHAOQAIASADATQAAAAgBABQAEARgHASQgBADgBACQgFAHgFAGQgBADgCACQgDAFgEAEQgCADgEADQgFAFgGAEQgJAGgMADQgCgCgDgCQAAgBgBAAQABAAACgBQAAAAAAAAQABAAABgBQAGgFAAgQQAAgBgBgBQAAgEAAgEQABgNgBgQQAAgDgBgDQgLACgJACQAAAAAAAAQgCAAgCABQgGAAgLgBQgDAAgEgBQgSgDgPgJQgEgCgDgDQAAAAgBAAQgDgCgCgBQgFgDgEgDQgGgFgDgGQgDgEgDgFQAAAAAAgBIAAAAAhHgdQAFgPAQgMQARgOADgCQAFgDAFgCQAKgFAKgBQAGgCAIgBQAHAAAHABQAUADAPAPQAFAEAEAFQALAOADAQQAAAGgBAFQABAMgBAFQgCAHgBACQgCAFgDAEQgCADgDADQgBACAAAAQgDACgDABQgDABgEACQgIACgJgBQgEAAgFgBQgFgCgEgCQgFgCgFgDQgEgCgEgCQgJgEgHgDQgHgEgHgEQgCgBgBgBQgKgEgIgIQgCgBgBgCQgDgBgBgCQgDgCgDgCQgEgCgDgDQgCgCgCgCQAAAAgBAA").cp();
	this.shape_303.setTransform(485.4,154);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#5C7C41").s().p("AhageQAEgZAagUQABgBACgBQANgKARgFQAJgCAKgBQAEgBAEAAQARAAAOAGQAIADAGAEQAMAHAJALQAKALAGAPQAIAUABATQAAAAAAABQABAVgHASQgCADgBACQgFAIgGAGQgCADgCACQgDAFgEAEQgDADgEADQgFAFgHAEQgKAFgMAEQgDgDgCgCQgBgBAAgBQACAAABgBQABAAAAAAQACgBABgBQAJgFACgRQAAgBgBgBQABgEAAgEQADgPAAgRQgBgDAAgEQgLAEgKACQAAAAgBAAQgBABgCAAQgIABgLgBQgDAAgEgBQgTgCgPgLQgEgCgEgDQAAAAgBAAQgDgCgCgCQgFgCgEgEQgGgGgDgGQgDgFgDgFQAAAAAAgBIAAgBAhFggQAFgPAOgNQARgPACgBQAFgDAGgDQAJgFAKgCQAHgCAHAAQAIAAAHABQATADAPAPQAFAFAEAFQAKAOADARQAAAFgBAGQABALgBAHQgBAFgBACQgCAFgCAFQgCADgEADQAAACgBAAQgCACgDABQgDABgEACQgIADgJgBQgEAAgFgBQgFgBgEgCQgFgCgFgCQgFgCgEgCQgJgEgHgDQgHgEgGgEQgCgBgCgCQgJgEgIgIQgBgBgCgCQgCgCgCgBQgCgCgDgDQgDgCgDgEQgCgCgCgCQgBAAAAAA").cp();
	this.shape_304.setTransform(485.3,154.1);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#5C7C41").s().p("AhbggQAEgcAagUQABgBACgCQAOgLASgEQAJgDALgBQAEAAACAAQATAAAQAHQAHADAHAFQAMAIAJALQAKANAFARQAHAWAAAUQAAAAAAABQAAAWgJATQgCADgBACQgGAIgGAGQgCADgDADQgDAEgFAFQgDADgEADQgGAEgIAEQgLAGgMADQgDgDgCgDQgBgBAAgBQACAAADgBQAAAAABAAQACgBACgBQAMgHADgRQAAgBAAgBQABgEABgFQAEgPAAgSQAAgEAAgEQgMAFgKACQAAAAgBAAQgBABgCAAQgKACgJgBQgEAAgEAAQgUgDgQgLQgEgCgEgEQgBAAAAAAQgDgCgDgDQgFgCgEgEQgFgGgEgHQgDgGgCgFQAAgBAAAAIAAgBAhDgjQAEgQAOgNQAPgPADgCQAFgDAFgDQAJgFALgCQAGgCAIAAQAHgBAHACQATADAPAQQAEAFAEAFQAKAOADARQAAAGAAAFQABAMgBAHQgCAFgBACQgBAFgCAEQgCAEgDACQgBADAAAAQgDACgCABQgEACgDABQgIADgJAAQgFAAgFAAQgEgCgFgBQgFgCgFgCQgFgCgEgCQgJgDgHgEQgGgDgHgEQgCgCgBgBQgJgFgIgIQgBgBgCgCQgCgCgBgCQgDgCgCgCQgDgDgDgEQgCgCgCgDQAAAAAAAA").cp();
	this.shape_305.setTransform(485.2,154.2);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#5C7C41").s().p("AhcgiQADgeAbgWQABgBACgBQAPgMASgFQAKgDALAAQAFgBACAAQAUABAQAHQAIAEAHAGQAMAJAJAMQAJAOAFATQAHAXgCAWQAAAAgBABQAAAXgLAUQgCADgCACQgGAIgHAHQgCADgDACQgEAFgFAEQgEAEgEACQgHAFgIAEQgLAGgNADQgDgEAAgDQgBgBAAgCQABAAADgBQABAAABAAQACgBADgBQAOgIAGgSQAAgBAAgBQABgEABgFQAGgQABgUQAAgEAAgEQgMAFgLAEQAAAAgBAAQgBAAgDABQgJACgKgBQgEAAgFAAQgUgCgRgMQgFgDgEgDQAAgBgBAAQgDgCgCgDQgFgCgEgFQgGgHgDgHQgDgGgCgGQAAgBAAAAIAAgBAhCgmQAEgQANgOQAPgQACgBQAFgEAFgDQAJgFALgCQAGgCAIgBQAHAAAHACQATADAOARQAFAEADAGQAKAOADARQAAAGAAAFQABAMgBAHQgCAHAAACQgCADgCAFQgBADgDADQgBADAAAAQgCACgDABQgDACgEABQgHAEgJAAQgFABgFgBQgFgBgEgBQgFgCgGgBQgFgCgEgCQgJgDgHgEQgGgDgHgFQgBgBgCgCQgJgFgHgIQgCgCgBgBQgCgCgBgCQgDgDgCgCQgDgDgCgEQgCgDgBgDQAAAAgBAA").cp();
	this.shape_306.setTransform(485.2,154.3);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#5C7C41").s().p("AheglQAEgfAbgXQABgCACgBQAPgNAUgFQAKgCALgBQAEAAAEAAQAVAAAQAJQAIAEAHAGQANAKAIAOQAKAPAEAVQAGAZgDAXQgBAAAAABQgCAYgMAUQgCAEgCADQgHAHgIAHQgCADgDADQgFAFgFAEQgEADgFADQgHAFgIAEQgNAFgMADQgCgEgCgEQgBgBAAgBQAEgBADgBQABAAABAAQABgBADgCQARgIAIgTQAAgBABgBQABgFACgEQAGgRADgVQAAgFAAgEQgMAGgMAEQAAAAgBAAQgCAAgCABQgKACgLAAQgEAAgEAAQgWgCgSgNQgEgCgEgEQgBAAAAgBQgDgCgDgDQgFgDgEgFQgGgHgDgJQgDgGgBgGQAAgBgBgBIAAgBAhAgoQADgRAMgOQAOgRACgCQAFgEAFgDQAJgFALgDQAFgCAJAAQAHAAAHABQATAFAOAQQAEAFAEAGQAJAOADARQAAAGAAAGQABAMgBAHQgBAGgBACQgBAEgCAFQgCADgCADQAAACgBABQgCACgDABQgDACgDACQgIAEgJABQgFAAgFAAQgEgBgFgBQgFgBgGgCQgFgBgEgCQgJgDgHgEQgHgEgGgEQgBgBgCgCQgJgFgGgJQgCgCgBgCQgCgCgBgCQgCgCgCgDQgDgDgCgEQgCgDgBgDQAAAAAAAA").cp();
	this.shape_307.setTransform(485.2,154.4);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#5C7C41").s().p("AhfgnQADgiAbgYQACgBACgCQAQgNAUgFQALgDALgBQADAAAFAAQAWABARAKQAIAEAIAHQANALAIAPQAJAQAEAWQAEAbgEAZQAAAAAAABQgEAagOAUQgCAEgCADQgHAIgIAHQgDADgDACQgFAFgGAFQgFADgEADQgIAFgJADQgNAGgNADQgCgFgCgEQgBgCAAgBQAEgBAEgBQABAAABAAQAEgBADgCQATgJAJgUQABgBAAgBQACgFACgFQAIgSADgWQAAgFAAgFQgMAIgMAEQAAAAgBAAQgCABgCAAQgLADgLAAQgEAAgFAAQgXgCgSgNQgFgDgEgEQAAAAgBgBQgDgCgDgDQgFgDgEgGQgFgIgEgJQgCgGgCgIQAAAAAAgBIAAgBAg/grQADgSAKgOQAOgRACgCQAFgEAFgDQAJgHAKgCQAGgCAIAAQAIgBAHACQASAFAOARQAEAFAEAGQAIAOADASQAAAFAAAGQABAMAAAHQgBAGgBADQgBAFgBADQgCADgCADQAAADgBABQgCACgDABQgDACgDACQgIAEgJACQgFAAgFAAQgEAAgFgBQgFgBgGgBQgFgBgEgCQgJgDgHgEQgHgEgGgFQgCgBgBgBQgJgGgGgJQgBgCgBgCQgCgCgBgCQgCgDgCgDQgCgEgCgEQgCgDgBgDQAAAAAAAA").cp();
	this.shape_308.setTransform(485.2,154.5);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#5C7C41").s().p("AhhgqQADgjAcgZQABgCACgCQARgOAVgFQALgDAMAAQADAAAFAAQAXABASAKQAIAFAIAHQANAMAIARQAJASADAXQAEAdgFAaQgBAAAAABQgFAbgPAVQgCAEgDADQgIAIgIAHQgEADgDADQgFAFgHAFQgFADgFADQgIAEgJAEQgMAFgQADQgCgFgCgFQAAgBgBgCQAFgBAFgBQABAAACAAQAEgCAEgBQAUgKAMgVQABgBAAgBQADgFACgFQAJgTAEgYQABgFAAgFQgNAIgNAFQAAAAAAAAQgCABgDABQgLADgLAAQgFABgFgBQgYgBgTgOQgEgDgFgFQAAAAgBAAQgDgDgDgDQgFgEgEgGQgGgIgDgKQgCgHgBgIQgBAAAAgBIAAgCAg+guQACgSAKgPQANgSACgCQAEgEAFgDQAJgHALgCQAGgDAIAAQAHAAAHACQATAFANASQAEAFADAGQAJAOACASQABAGAAAFQABANgBAHQgBAGAAACQgBAGgBAFQgBABgCADQgBADAAABQgCACgDACQgDACgDABQgIAFgJACQgFABgFAAQgEAAgFgBQgFgBgGgBQgFgBgDgBQgLgDgHgEQgGgEgGgFQgCgBgCgBQgIgHgFgJQgCgCgBgCQgCgCgBgDQgBgDgCgDQgCgEgCgEQgBgDgBgEQAAAAAAAA").cp();
	this.shape_309.setTransform(485.2,154.6);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#5C7C41").s().p("AhigsQACglAcgbQACgCACgBQARgPAWgGQALgCANgBQADAAAFAAQAYACASALQAJAFAIAIQANANAIASQAJATACAZQAEAegHAbQAAABgBABQgGAcgRAWQgCAEgDADQgIAIgKAIQgDADgDADQgHAFgGAEQgFAEgGADQgJAEgJAEQgNAFgQADQgCgFgCgGQgBgCAAgBQAFgBAGgBQABgBACAAQAFgCAEgCQAXgKAOgWQABgBAAgCQADgEADgGQALgTAEgZQABgFAAgGQgNAJgNAFQAAAAgBAAQgCABgDABQgLAEgMABQgFAAgFgBQgYgBgUgPQgFgDgFgEQAAgBgBAAQgDgDgDgDQgFgFgEgGQgGgJgDgKQgCgIgBgIQAAgBAAAAIAAgCAg9gwQACgTAIgPQANgTACgCQAEgFAFgDQAJgHAKgDQAIgCAGAAQAIAAAHACQASAFANASQAEAGADAGQAIAOADASQAAAGAAAGQABAMAAAHQgBAGAAADQgBAFgBAFQgBAEgCABQAAADAAAAQgCADgDACQgDACgDACQgIAFgJACQgFABgFAAQgEAAgFAAQgFAAgGgBQgGgBgDgBQgKgDgIgFQgGgDgGgFQgBgCgCAAQgIgHgFgKQgCgCgBgCQgBgDgBgCQgCgDgBgEQgCgEgBgEQgBgEgBgDQAAAAAAAA").cp();
	this.shape_310.setTransform(485.2,154.7);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#5C7C41").s().p("AhkguQABgoAdgcQACgBACgCQASgQAXgFQAMgDANAAQADgBAGABQAYABATAMQAJAHAIAIQAOAOAHATQAJAUACAbQACAggIAcQAAABgBABQgHAdgSAXQgDAEgDADQgJAJgKAHQgDAEgEACQgHAGgHAEQgFADgGADQgJAFgJAEQgPAFgRADQgCgGgCgHQAAgBgBgCQAHgBAGgBQABgBACAAQAFgCAFgCQAagLAQgXQABgBABgCQADgFADgFQAMgUAFgbQABgFABgGQgOAKgOAFQAAAAAAAAQgDABgCACQgMAEgNABQgFAAgFAAQgagBgUgQQgFgDgFgFQAAAAgBgBQgDgDgDgDQgFgGgFgGQgFgJgDgLQgCgIgBgJQAAgBAAgBIAAgBAg8gzQABgTAIgQQALgUACgCQAFgEAEgEQAJgHALgDQAHgCAHAAQAHAAAHACQASAFANATQADAGAEAGQAHAOADASQAAAGABAGQABAMgBAIQAAAGAAACQgBAGgBAFQgBADgBAEQAAABAAAAQgCADgDACQgDACgDACQgIAFgJADQgFABgFABQgEAAgFAAQgFAAgHAAQgFgBgDgBQgLgDgHgFQgHgEgFgFQgCgBgBAAQgIgIgFgKQgBgCgBgDQgCgCAAgCQgCgEgBgDQgCgFgBgEQgBgEAAgEQAAAAAAAA").cp();
	this.shape_311.setTransform(485.3,154.8);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#5C7C41").s().p("AhmgxQABgpAegdQABgCACgCQATgQAXgGQANgDANAAQAEAAAFAAQAaACATANQAKAHAIAIQAOAPAHAUQAJAWABAcQACAhgKAfQAAABgBABQgJAfgTAXQgDAEgEADQgJAJgKAIQgEADgEADQgHAFgIAFQgFADgGADQgIAFgLADQgQAFgSADQgCgGgBgHQgBgCAAgCQAGgBAHgBQACgBACAAQAGgCAFgCQAdgNARgXQABgBABgCQAEgFADgFQAOgVAGgcQABgGABgGQgOAKgOAGQgBAAAAAAQgDACgCABQgMAFgOABQgFAAgFAAQgbgBgVgQQgFgEgFgFQAAAAgBgBQgDgDgDgEQgGgGgEgGQgFgKgDgLQgCgJgBgJQAAgBAAgBIAAgCAg8g1QABgVAHgPQALgVACgCQAEgFAFgEQAIgHALgDQAHgDAHAAQAHAAAHADQASAFAMAUQAEAGADAGQAHAPADASQABAGAAAFQABANAAAHQgBAGAAACQAAAGgBAGQgBADgBADQAAAEAAAAQgCABgCACQgDACgEADQgHAFgJADQgFACgFABQgFAAgEAAQgGABgGgBQgEAAgFgCQgLgCgHgFQgHgEgFgFQgBgBgCAAQgHgJgFgLQgBgBgBgDQgBgCgBgDQgBgEgBgDQgCgFgBgFQAAgDAAgEQgBAAAAAA").cp();
	this.shape_312.setTransform(485.3,154.9);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#5C7C41").s().p("AhogzQABgrAegfQACgCACgCQATgRAYgGQANgDANAAQAFAAAFABQAbACAUAOQAKAHAIAJQAOAQAHAVQAJAYAAAdQABAigLAhQAAABgBABQgKAggVAYQgDAEgEADQgJAJgLAIQgFAEgEADQgHAFgIAFQgHADgFADQgJAEgMAEQgQAFgTADQgBgHgCgIQAAgCgBgCQAHgBAIgBQACgBABAAQAHgCAGgCQAfgOAUgYQABgBABgCQAEgFAEgGQAPgWAHgdQABgGABgHQgOAMgPAHQAAAAgBAAQgCABgDABQgMAFgOACQgGAAgFAAQgcgBgWgQQgFgEgFgGQAAAAgBAAQgDgEgDgEQgGgHgEgGQgGgKgCgMQgCgJgBgKQAAgBAAgBIAAgCAg7g4QABgVAFgQQAKgVACgDQAEgFAFgDQAJgIAKgDQAIgDAGAAQAIAAAHACQARAGAMAVQAEAFADAHQAGAPADASQABAGAAAGQABAMAAAIQAAAFAAADQAAAGgBAFQAAAEgBADQAAAEAAAAQgCADgDAAQgDADgDACQgHAGgJADQgFACgFABQgFABgEAAQgGABgHAAQgDgBgGgBQgKgCgIgFQgGgEgGgFQgBgBgCgBQgHgJgEgLQgBgCgBgCQgBgCgBgDQgBgEAAgEQgCgFAAgFQgBgEAAgEQAAAAAAAA").cp();
	this.shape_313.setTransform(485.4,155);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#5C7C41").s().p("AA7gKIAAAEQgMAMgPAGQgOAGgRAAQgbAAgPgTQgRgWAAgkQAAgoAQgWQARgXAZAAQAaAAARAdQARAeAAAzIAAARIgBAHAA6AOQgIAwgbAeQgYAggwAPIgUAEIAEATQAogFAfgRQAfgRAXgYQAYgaALgiQAMgiAAgkQAAg8gdgjQgdgjgxAAQgsAAgfAfQgfAfAAAuQAAArAbAaQAaAcAkAAQAWAAARgHQATgIARgPIAAAA").cp();
	this.shape_314.setTransform(485.4,155.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_295}]}).to({state:[{t:this.shape_296}]},40).to({state:[{t:this.shape_297}]},1).to({state:[{t:this.shape_298}]},1).to({state:[{t:this.shape_299}]},1).to({state:[{t:this.shape_300}]},1).to({state:[{t:this.shape_301}]},1).to({state:[{t:this.shape_302}]},1).to({state:[{t:this.shape_303}]},1).to({state:[{t:this.shape_304}]},1).to({state:[{t:this.shape_305}]},1).to({state:[{t:this.shape_306}]},1).to({state:[{t:this.shape_307}]},1).to({state:[{t:this.shape_308}]},1).to({state:[{t:this.shape_309}]},1).to({state:[{t:this.shape_310}]},1).to({state:[{t:this.shape_311}]},1).to({state:[{t:this.shape_312}]},1).to({state:[{t:this.shape_313}]},1).to({state:[{t:this.shape_314}]},1).wait(14));

	// 6
	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#70BF56").s().p("ABcAAQgEgLgOgLQgUgQgdgCQgbgCgrAOQgkAMgMAJIAOgBQAPAAAIADQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLIAAAA").cp();
	this.shape_315.setTransform(539,257.1);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#70BF56").s().p("ABZAfQgEAJgLAFQgGAEgJABQgPADgQgFQgJgCgJgEQgLgJgJgGQgDgCgCAAQgBAAAAAAQgKgFgJgEQgJgEgIgEQgCgBgCgBQgGgDgJgDQgEAAgEAAQgGgBgGgBIAAAAQAKgPAlgPQACgBADgBQAigOAbgCQAEABADACQABAAAAAAQACAAABAAQAOAEAMALQADAEADAEQADADADAEQACABABACQAFAEAEAEQAGAGACAIQADAMgFALIAAAA").cp();
	this.shape_316.setTransform(538.6,256.5);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#70BF56").s().p("AhbgBQAKgRAlgQQABgBABAAQACgBABgBQAdgNAZgDQADAAAEgBQACAAABABQACAAABABQACABABAAQAAAAABAAQABAAABAAQALAEAKAKQABABABACQACAEADAEQADAEACADQABACACACQAFAEADAFQABABABACQAFAEACAFQABACAAADQACAIgCAHQAAABAAABQgDAJgKAFQgBABgDACQgEACgGABQgIADgJAAQgGgBgGgBQgDAAgDgBQgGgBgGgCQgCgBgCgBQgIgFgFgEQgCgBgCAAQgDgCgDgBQAAAAgBAAQgCgBgCgBQgIgDgIgEQgBAAgCgBQgHgDgHgEQgBAAAAgBQgCgBgCgBQgGgDgIgDQAAAAgBAAQgEgCgDgBQgHgBgGAAQAAAAAAgBIAAAAAhZgBQAGgIAPgJQAbgNABgBQAPgGANgEQASgFASgBQAEABADACQAAAAABAAQABAAACAAQAOAEALAMQADAEADAEQADAEACADQACABACACQADADACACQABACACABQAGAGABAIQADAMgEALQgFAJgJAFQAAAAgBAAQgGAEgJABQgOADgQgEQgBAAAAAAQgJgCgJgEQgLgJgJgGQgDgBgCgCQgBAAAAAAQgBAAAAAAQgJgEgIgFQgJgEgIgEQgCgBgCgBQgFgEgJgCQgEgCgEgBQgGAAgGAAQAAAAAAgBIAAAA").cp();
	this.shape_317.setTransform(538.5,256.3);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#70BF56").s().p("AhaAAQAKgSAlgSQABgBABgBQABAAACgBQAdgPAbgEQAEABADAAQABAAACAAQABABABABQABAAABABQABAAAAAAQABAAABAAQAJAFAJAKQAAACABABQACAEADAFQACAEACADQABACACACQAEAFADAEQABACABACQAFADADAFQABACABACQACAHgBAHQAAABAAABQgCAJgIAGQgBABgCABQgEADgFACQgIADgJABQgFAAgGAAQgDAAgDAAQgGgBgFgBQgDgBgCgBQgIgEgGgDQgCgBgCgBQgEgBgCgBQgBAAgBAAQgCgBgCgBQgJgDgHgDQgCgBgCgBQgIgEgHgDQgBgBAAgBQgCgBgCAAQgGgEgIgEQAAAAgBAAQgEgDgDgBQgHgCgFgCQAAAAAAAAIAAAAAhWAAQAFgIAOgJQAbgNACgBQAPgGANgDQASgGASABQADABADABQABAAAAAAQACABABAAQAOAEALAMQADAEADAEQADAEACADQABACACACQADACACACQABACACABQAFAHACAHQADANgFAKQgEAJgJAGQgBAAAAAAQgHAEgJABQgNAEgQgFQgBAAAAAAQgJgCgJgEQgLgIgJgHQgDgBgCgBQgBAAAAAAQgBAAAAAAQgJgFgIgFQgIgEgIgEQgCgCgBgBQgGgEgIgDQgEgBgEgCQgGgBgFgBQAAAAAAAAIAAAA").cp();
	this.shape_318.setTransform(538.3,256.1);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#70BF56").s().p("AhaABQAKgUAlgTQABgBABgBQACgBABgBQAegQAdgEQAEABADABQABAAABAAQACABAAABQABAAABABQAAAAAAAAQABAAABAAQAHAFAHAMQABABAAABQACAFACAFQADAEABADQABACACACQAEAFADAFQAAACABACQAGADADAEQABABABACQADAHAAAHQAAAAABABQgBAJgHAGQgBACgCABQgDADgEADQgHAEgJACQgFABgGAAQgDAAgDAAQgGAAgFgBQgDAAgCAAQgJgEgIgDQgBAAgCgBQgDgBgDgBQgBAAAAAAQgDgBgCAAQgJgEgIgDQgCgBgCAAQgIgFgIgEQgBAAAAgBQgCgBgCgBQgGgFgIgEQAAAAgBAAQgEgDgDgCQgGgCgGgDQAAAAAAgBIAAAAAhUABQAFgHAOgJQAbgOABAAQAPgHANgDQASgFASABQAEABADACQAAAAABAAQABAAACAAQANAGALALQADAEACAFQADADACADQACACABACQADACACACQABAAACACQAFAIACAIQACAMgEALQgFAJgJAFQAAAAgBAAQgGAEgJACQgOAEgQgEQAAAAAAAAQgJgCgJgEQgLgIgJgHQgDgCgCgBQgBAAAAAAQgBAAAAAAQgIgFgIgFQgJgFgHgEQgCgCgBgBQgGgDgIgEQgDgBgEgCQgGgBgFgCQAAAAAAAAIAAgB").cp();
	this.shape_319.setTransform(538.2,255.9);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#70BF56").s().p("AhZADQAJgXAlgVQABAAABgBQACgBACgBQAegSAfgEQAEABADABQABABABAAQABAAAAABQABABAAABQABAAAAAAQAAAAABAAQAFAGAGAMQAAABABABQABAFACAFQACAEACAEQABACABACQADAFADAGQABACAAACQAGADAEACQABACABACQAEAGABAGQABABAAABQAAAIgFAHQgBABgCACQgCAEgEACQgGAFgIADQgFACgGABQgDAAgDABQgGAAgFAAQgDAAgCAAQgJgDgJgCQgDgBgBAAQgDgBgDgBQAAAAgBAAQgDgBgCAAQgKgDgIgEQgCgBgCAAQgJgFgIgEQAAgBgBgBQgCgBgBgBQgHgFgIgFQAAAAgBAAQgDgDgEgDQgGgCgFgEQAAAAAAgBIAAAAAhRADQAFgHAMgJQAbgOACgBQAPgGANgDQASgFASABQAEACADACQAAAAAAAAQACAAABAAQANAGALAMQADAEACAEQADAEACADQABABACACQACABACACQACACABABQAFAJABAHQACANgEAKQgEAJgJAGQgBAAAAAAQgGAEgJACQgOAEgQgEQAAAAgBAAQgIgCgJgEQgLgIgJgHQgDgCgCgBQgBAAAAAAQgBAAAAAAQgIgFgIgFQgIgFgHgFQgCgBgBgCQgGgDgHgEQgEgCgDgBQgFgCgFgCQAAAAAAAAIAAgB").cp();
	this.shape_320.setTransform(538,255.7);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#70BF56").s().p("AhYAFQAIgZAmgXQABAAABgBQACgBABgBQAggUAggEQAEABADACQABAAAAAAQABABAAABQAAABABAAQAAABAAAAQABAAAAAAQADAGAEANQABABAAACQABAEACAGQABAEACAEQABACABACQADAGACAGQABACAAACQAHADAEABQABACACABQAEAGACAFQABABABABQABAIgEAIQgBABgBACQgCAEgDADQgGAGgIAEQgEACgGABQgCABgEABQgFABgGABQgDAAgCAAQgKgCgJgBQgDgBgCAAQgCgBgEgBQAAAAgBAAQgDAAgCgBQgKgDgJgEQgCgBgCAAQgJgFgJgFQAAgBgBAAQgCgCgBgBQgHgFgIgGQAAAAgBgBQgDgDgEgCQgGgEgEgEQAAAAAAgBIAAAAAhPAGQAFgIAMgKQAbgOABAAQAPgHANgDQATgEARACQAEABADACQAAAAABAAQABABACAAQANAGAKAMQACAEADAFQACADACADQABABACABQACACACACQACACABACQAEAIACAIQACAMgFALQgEAJgJAGQAAAAAAAAQgHAEgIACQgOAEgQgDQAAAAgBAAQgIgCgJgEQgLgIgJgHQgDgCgCgCQgBAAAAAAQgBAAAAAAQgIgFgHgGQgIgEgHgFQgCgCgBgBQgFgEgIgEQgDgCgDgCQgFgBgFgCQAAAAAAgBIAAAA").cp();
	this.shape_321.setTransform(537.9,255.4);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#70BF56").s().p("AhYAHQAIgcAmgYQABgBABAAQACgCACgBQAggUAigFQAEACADACQABAAAAAAQAAABAAABQAAABAAAAQAAAAAAABQABAAAAAAQABAHADANQAAABAAACQABAFABAFQACAFABAEQABACABADQACAFACAGQABADAAACQAHACAFABQABABACABQAFAFADAGQABABABABQADAHgDAIQgBACgBACQgBAEgDAEQgEAGgIAFQgEADgGACQgCABgEACQgFABgGABQgDABgCAAQgKgBgKgBQgDAAgDgBQgEAAgBgBQgBAAgBAAQgDAAgDgBQgKgDgJgEQgCAAgCgBQgKgFgIgFQgBgBgBgBQgCgBgBgCQgIgGgHgGQAAAAgBgBQgDgDgEgDQgFgEgFgFQAAAAAAgBIAAAAAhNAIQAFgIAMgKQAagOACgBQAPgHANgCQASgFASADQAEACADACQAAAAAAAAQACAAABABQANAGAKAMQACAEACAFQADADACACQABABABACQADACABADQACABABACQAEAIABAIQACANgEALQgFAIgIAGQAAAAgBAAQgGAFgIACQgOAEgQgDQAAAAgBAAQgIgCgJgEQgLgHgJgIQgDgCgCgBQgBgBAAAAQgBAAAAAAQgIgFgHgGQgHgFgHgFQgCgCgBgBQgFgEgHgEQgDgCgDgCQgFgCgFgCQAAAAAAgBIAAAA").cp();
	this.shape_322.setTransform(537.7,255.2);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#70BF56").s().p("AhXAJQAHgeAmgaQABgBABgBQACgBACgBQAhgWAlgFQADACADACQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAAAQAAABAAAAQgBAHACAOQAAACAAABQAAAFABAGQABAFABAEQABACABADQACAGACAGQAAADABACQAHACAFABQABAAACABQAGAEAEAFQABABABABQAEAHgBAJQgBABAAACQgBAFgCAFQgEAHgHAGQgEADgFADQgDABgEACQgFADgGABQgDABgDAAQgKAAgKAAQgDgBgDAAQgEAAgDgBQAAAAAAAAQgDAAgEgBQgKgDgKgEQgCAAgCgBQgLgFgIgGQgBgBgBgBQgCgBgBgCQgIgGgHgHQAAAAgBgBQgDgDgEgEQgFgEgEgGQAAAAAAgBIAAAAAhKAKQAEgKALgIQAbgPABgBQAPgGAOgDQASgEARAEQAEABADADQAAAAABAAQABAAACAAQAMAHAJANQADAEACAEQACACACADQABACACACQACACACACQABACABACQAEAIABAIQACAMgFALQgEAJgIAGQgBAAAAAAQgGAEgJADQgNAEgQgDQgBAAAAAAQgJgBgIgEQgLgIgJgIQgDgCgCgBQgBAAAAgBQgBAAAAAAQgIgFgGgGQgIgFgGgFQgCgCgBgCQgFgEgGgEQgDgCgDgCQgFgDgEgCQAAAAAAgBIAAAA").cp();
	this.shape_323.setTransform(537.6,255);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#70BF56").s().p("AhXALQAHghAmgbQACgBABgBQACgBACgCQAhgXAngGQADADADADQAAAAAAABQAAAAgBABQgBABAAABQAAAAAAAAQAAABAAAAQgDAHAAAPQAAACAAABQAAAGABAGQAAAEABAFQABACAAADQACAGACAHQAAACABADQAHABAFABQACABACAAQAHADAFAFQABAAACABQAFAHgBAJQAAACAAACQAAAFgCAFQgDAIgHAHQgDAEgFADQgDACgEACQgFAEgGABQgDABgDABQgKABgLAAQgDAAgDAAQgFgBgEAAQAAAAgBAAQgBAAgEgBQgLgDgKgEQgCAAgDgBQgKgFgJgHQgBAAgBgBQgCgCgBgBQgIgHgHgIQAAgBgBAAQgDgEgEgEQgFgFgEgGQAAAAAAgBIAAAAAhIAMQAEgLALgIQAagPACAAQAPgHANgCQATgEARAEQAEACADACQAAAAAAAAQACABABAAQAMAHAJANQADAEACADQACADACADQABACABACQACACACACQABACABACQAEAIABAIQABANgFALQgEAIgIAGQAAAAAAAAQgHAFgIACQgNAFgQgCQgBAAAAAAQgJgCgIgEQgLgHgJgIQgDgCgCgCQgBAAAAAAQgBAAAAgBQgHgFgHgGQgHgGgGgFQgCgCgBgBQgFgFgGgEQgDgDgCgCQgFgCgEgDQAAAAAAAAIAAgB").cp();
	this.shape_324.setTransform(537.5,254.8);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#70BF56").s().p("AhWANQAGgjAngdQABgBABgBQACgCACgBQAjgZAogGQADADADAEQAAAAgBAAQAAABgBABQgBABAAABQgBAAAAAAQAAABAAAAQgFAIgBAPQAAACgBACQAAAFAAAGQABAFAAAFQABACAAADQACAHABAHQAAACABADQAIAAAFABQADABACABQAHABAGAEQACABABABQAHAHAAAJQABACgBACQABAGgBAFQgDAJgGAIQgDAEgFAEQgDADgDACQgGAEgGACQgDABgDABQgLADgLAAQgDAAgEAAQgEgBgEAAQgBAAgBAAQgCAAgDgBQgMgCgKgEQgCgBgDgBQgLgFgJgHQgBgBgBgBQgCgCgBgBQgIgIgHgIQAAgBgBAAQgDgEgEgEQgFgGgDgHQAAAAAAAAIAAgBAhGAOQAFgLAJgIQAbgPABgBQAPgHANgBQATgEARAFQAEABADADQAAAAABAAQABAAABABQAMAHAJANQACADACAEQACAEACADQABABABACQACADACACQABABABACQADAJABAHQABAOgEAKQgEAJgIAGQAAAAgBAAQgGAFgIACQgOAGgQgDQAAAAAAAAQgJgCgIgDQgLgHgJgJQgDgCgCgCQgBAAAAAAQgBAAAAAAQgHgGgHgGQgGgGgGgGQgCgBgBgCQgEgFgGgFQgDgCgCgCQgFgDgEgDQAAAAAAAAIAAgB").cp();
	this.shape_325.setTransform(537.3,254.5);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#70BF56").s().p("AhWAPQAGgmAngeQABgBABgBQADgCACgCQAigaArgGQADAEADADQAAABgBAAQgBABgBABQgBABgBABQAAAAAAAAQgBABAAAAQgHAIgDARQAAABAAACQgBAFAAAHQAAAFAAAFQABACAAADQABAHABAHQABADAAADQAIgBAGABQADAAACABQAIACAHADQACAAACABQAHAHACAJQABACAAADQABAGgBAGQgBAJgGAKQgEAFgEAEQgDADgDACQgGAFgGADQgDABgDABQgLAEgMAAQgEAAgDABQgFgBgEAAQgBAAgBAAQgDAAgCgBQgMgCgLgEQgDgBgCgBQgLgFgKgIQgBgBgBAAQgBgCgCgCQgIgIgHgJQgBgBAAAAQgDgEgEgFQgEgGgEgIQAAAAAAAAIAAgBAhDAQQAEgLAJgIQAagQACAAQAPgHALgCQAVgDARAFQAEACADACQAAAAAAAAQABABACABQAMAHAIANQACADACAEQACAEABADQABACACACQABACACACQABACAAACQAEAIABAIQABANgFALQgEAIgIAGQAAAAAAAAQgGAGgIACQgOAGgQgDQAAAAAAAAQgJgBgIgEQgMgHgIgJQgDgCgCgCQgBAAAAAAQgBAAAAAAQgHgGgGgHQgHgFgFgGQgCgCgBgCQgEgFgGgFQgCgCgCgCQgEgDgEgEQAAAAAAAAIAAgB").cp();
	this.shape_326.setTransform(537.2,254.3);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#70BF56").s().p("AhWARQAGgpAngfQABgBACgCQACgBACgCQAigcAugGQADAEADAEQgBAAgBABQgBABgCABQgBAAgBABQAAABAAAAQgBABgBAAQgJAJgDARQgBABAAACQgBAGgBAGQAAAGAAAFQAAACABADQABAHAAAIQAAADABADQAIgBAHAAQADAAACAAQAJACAIACQACABACAAQAJAHADAKQABACAAACQACAHAAAHQgBAKgGAKQgDAGgEAFQgDADgDADQgGAFgGADQgDACgDABQgMAFgMABQgEAAgEAAQgEAAgFAAQgBAAgBAAQgDAAgDgBQgMgCgLgEQgDgBgCgBQgMgGgKgHQgBgBgBgBQgCgCgCgCQgIgIgHgKQAAgBAAAAQgEgFgDgFQgEgHgEgIQAAAAAAAAIAAgBAhBASQAEgLAIgJQAagQACAAQAPgHAMgBQAUgEARAGQAEACADADQAAAAAAAAQACABABAAQAMAIAIAMQACAEABAFQACADACAEQAAABACACQABACACACQAAACABACQADAJABAHQABAOgFAKQgEAJgHAGQAAAAgBAAQgGAFgIADQgNAGgQgCQAAAAgBAAQgIgCgJgDQgLgHgJgJQgCgDgDgBQAAgBgBAAQAAAAAAAAQgHgGgGgHQgGgGgGgGQgBgCgBgCQgEgFgFgFQgDgCgCgDQgEgDgDgEQAAAAAAAAIAAgB").cp();
	this.shape_327.setTransform(537.1,254.1);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#70BF56").s().p("AhXATQAGgrAnghQABgCABgBQADgCACgCQAjgdAwgHQADAFADAEQgCABgBAAQgBABgCABQgCABgBABQAAAAAAABQgBAAgBABQgLAJgFASQgBABAAACQgCAGAAAHQgBAGAAAFQAAACAAADQABAIAAAIQAAADAAADQAJgCAHAAQADgBADABQAJABAJADQACABADAAQAKAFAEAKQABADABACQACAHABAIQgBAKgFALQgCAHgFAFQgCAEgEADQgFAGgHAEQgDACgDABQgMAFgNACQgEABgDAAQgFAAgFAAQgBAAgBAAQgEAAgDgBQgMgCgMgEQgCgBgDgBQgMgGgKgIQgBgBgBgBQgCgCgCgCQgIgJgHgLQAAAAgBAAQgDgFgDgGQgFgHgDgJQAAAAAAAAIAAgBAhAAUQADgLAIgJQAagQACgBQAPgHAMgBQAVgDAQAHQAEACADACQAAAAAAAAQACABABABQALAIAIAMQACAFACAEQABADACAEQAAABABADQACABABACQABACABACQADAJAAAIQABANgFALQgEAIgHAGQAAAAgBAAQgGAGgIADQgNAGgQgCQAAAAAAAAQgJgBgIgEQgLgHgJgJQgDgCgCgCQgBAAAAgBQAAAAgBAAQgGgGgGgHQgGgGgFgHQgBgCgCgBQgDgFgFgGQgCgDgCgCQgEgEgDgEQAAAAAAAAIAAgB").cp();
	this.shape_328.setTransform(537.1,253.9);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#70BF56").s().p("AhYAUQAFgtAogiQABgCABgBQACgCADgCQAkgfAxgHQADAFADAFQgBABgCAAQgCABgCABQgBABgCABQAAAAgBABQgBAAgBABQgNAKgGASQgBACgBABQgBAHgBAHQgBAFgBAGQAAADAAACQABAIAAAIQAAAEAAADQAJgDAIgBQADAAADAAQAKAAAKAEQACAAACABQAMAEAFALQACACAAADQAEAHABAIQAAAMgEAMQgDAHgEAGQgDAEgDAEQgGAGgGAFQgDACgEACQgMAFgNADQgEAAgEABQgFAAgGAAQAAAAgBAAQgEAAgEgBQgMgCgMgEQgDgBgDgBQgNgGgJgIQgCgBgBgBQgCgCgCgDQgIgJgHgMQAAAAAAAAQgEgGgDgGQgEgHgDgKQAAAAAAgBIAAgBAg/AWQADgLAHgLQAagPACAAQAPgHAMgCQAVgCAQAHQAEACADADQAAAAAAAAQACABABABQALAIAHANQACAEACAEQABAEACADQAAACABACQACACABACQAAACABACQADAIAAAIQAAANgEALQgEAJgHAGQAAAAgBAAQgFAGgIADQgOAGgQgCQAAAAAAAAQgJgBgIgDQgLgHgJgKQgCgCgDgCQAAAAgBgBQAAAAAAAAQgHgGgFgHQgGgGgFgHQgBgCgBgCQgEgFgEgGQgCgDgCgDQgDgDgDgEQAAAAAAgBIAAgB").cp();
	this.shape_329.setTransform(537.1,253.6);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#70BF56").s().p("AhZAWQAFgvAngkQACgCABgBQACgCADgDQAlggAzgHQADAFACAGQgBAAgCABQgCABgDABQgBABgCABQgBAAAAAAQgBABgBABQgPAKgIATQgBACgBACQgCAGgBAHQgBAGgBAGQAAADAAACQgBAJAAAIQAAAEAAADQAKgDAIgCQADgBADAAQALAAALADQADABACAAQANAFAHALQABACABADQAEAIACAIQABAMgEANQgDAIgEAHQgCAEgEAEQgFAHgHAFQgDADgEACQgMAGgOADQgEABgEAAQgGABgFAAQgBAAgBAAQgEAAgEgBQgMgCgNgEQgDgBgCgBQgOgGgKgJQgBgBgBgBQgCgCgCgCQgJgKgGgNQgBAAAAAAQgDgGgDgGQgEgJgDgKQAAAAAAgBIAAgBAg/AYQAEgMAGgLQAagPACAAQAPgHAMgBQAVgDAQAJQAEACADADQAAAAAAAAQABABACAAQALAJAGANQACAEACAFQABADABAEQABABABACQABACABACQABACAAACQADAJAAAIQAAANgEALQgEAIgHAHQAAAAgBAAQgFAFgIAEQgNAGgQgBQgBAAAAAAQgJgBgIgEQgLgGgJgKQgCgDgCgCQgBAAAAAAQgBAAAAgBQgGgGgFgHQgGgHgEgHQgCgCgBgCQgDgFgEgGQgCgDgCgDQgDgEgDgEQAAAAAAAAIAAgC").cp();
	this.shape_330.setTransform(537.1,253.4);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#70BF56").s().p("AhaAYQAEgyAogmQABgBACgCQACgCADgDQAmghA0gIQADAGADAGQgCABgCAAQgDABgDABQgBABgCABQgBABAAAAQgCABgBABQgRAKgKAUQAAACgBACQgDAGgBAHQgCAGgBAGQAAADAAADQgBAJAAAJQAAADgBAEQALgFAIgCQAEgBADAAQAMAAALACQADABADAAQAOAGAIAKQACACABADQAFAIABAJQACANgDAPQgCAIgFAHQgCAFgDAEQgGAIgHAFQgDADgDACQgNAIgOADQgFABgEABQgGAAgFABQgBAAgBAAQgFgBgEAAQgNgCgMgEQgDgBgDgBQgOgHgKgJQgCgBgBgBQgCgCgCgDQgJgKgGgNQAAAAgBgBQgDgGgDgGQgEgJgCgLQAAAAAAgBIAAgBAg+AZQADgLAGgMQAagPABAAQAQgHALgBQAWgCAQAJQAEACADADQAAAAAAAAQABABABABQALAHAHAPQABAEACAFQABADABAEQABABAAACQACACAAACQABACABACQACAJAAAIQAAANgFALQgEAIgGAHQAAAAgBAAQgFAGgIADQgNAHgQgBQAAAAgBAAQgIgBgJgEQgKgGgKgKQgCgDgCgCQgBAAAAgBQAAAAAAAAQgHgGgFgIQgFgHgEgHQgBgCgBgCQgEgGgDgGQgCgDgCgDQgCgEgDgFQAAAAAAAAIAAgC").cp();
	this.shape_331.setTransform(537.1,253.2);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#70BF56").s().p("AhbAZQADg1AognQACgBABgCQADgCACgDQAogjA2gIQACAHADAGQgCAAgCABQgDABgDABQgDABgCABQAAABgBAAQgCABgBABQgTALgLAUQgBACgBACQgCAHgCAHQgCAGgBAHQgBACAAADQAAAJAAAJQAAAEAAAEQAIgFAJgDQAEgBADAAQANgCAMADQADAAAEABQAOAFAKAKQACADABADQAGAJACAJQADAOgEAPQgBAJgEAIQgDAFgDAFQgGAIgGAGQgEADgDADQgNAIgPAEQgFABgEABQgGAAgGABQgBAAgBAAQgEAAgFgBQgNgCgNgEQgDgBgDgBQgOgHgLgJQgBgBgBgCQgDgCgCgCQgJgLgGgOQAAAAAAgBQgEgGgCgHQgEgKgCgLQAAAAAAgBIAAgBAg9AbQACgMAGgMQAagPABgBQAPgHAMAAQAWgCAQAJQADACADAEQAAAAABAAQABABABABQALAHAGAQQABAEACAEQABAEABADQAAACABACQABACABABQAAADABACQACAIAAAIQgBAOgEALQgEAIgGAGQgBAAAAAAQgGAHgHADQgNAHgQgBQAAAAgBAAQgIgBgIgDQgLgGgJgLQgDgCgCgDQAAAAgBAAQAAAAAAgBQgGgGgFgIQgFgHgEgHQgBgCgBgCQgDgGgDgHQgCgDgBgDQgDgFgCgEQAAAAAAAAIAAgC").cp();
	this.shape_332.setTransform(537.2,253.1);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#70BF56").s().p("AhdAaQADg3ApgpQABgBACgCQACgDADgCQAogkA4gJQACAHADAGQgCABgDABQgDABgDABQgDABgCABQgBABAAAAQgCABgCABQgVALgMAVQgBACgBACQgDAHgBAIQgCAGgBAHQgBADAAADQgBAJgBAJQgBAEAAAEQAJgGAJgDQAEgBAEgBQANgCANACQAEABADAAQAQAFALALQACADACADQAGAJADAKQADAPgDAQQgBAJgEAJQgCAFgEAFQgFAJgHAHQgEADgDADQgOAJgPAFQgFABgFABQgFAAgGABQgBAAgBAAQgFAAgFgBQgOgBgNgFQgDAAgDgCQgPgHgLgKQgBgBgBgBQgCgDgDgCQgJgMgGgOQAAAAAAgBQgEgGgCgIQgEgKgCgMQAAAAAAgBIAAgBAg9AcQADgMAFgMQAZgQACAAQAPgHAMgBQAVgBAQAKQAEACADADQAAAAAAAAQABABABABQALAIAGAQQABAEABAFQACADAAAEQABABAAACQABACABACQAAACABACQACAJgBAIQAAANgFALQgDAJgHAGQAAAAAAAAQgGAGgHAEQgNAHgQAAQAAAAgBAAQgIgBgHgDQgMgHgJgKQgDgDgCgCQAAgBgBAAQAAAAAAgBQgGgGgFgIQgEgHgEgIQgBgCgBgCQgDgGgDgHQgBgDgBgDQgDgFgCgFQAAAAAAAAIAAgC").cp();
	this.shape_333.setTransform(537.2,252.9);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#70BF56").s().p("AheAbQADg6AogqQACgCABgBQADgDADgDQApglA5gJQADAHACAHQgCABgDABQgEABgDABQgDABgDABQAAAAgBABQgCABgCABQgXAMgNAVQgCACAAADQgCAHgDAHQgCAHgCAHQAAADgBADQgCAJgBAKQAAAEgBAEQALgGAJgEQADgCAEgBQAOgCAOACQAEAAAEABQARAEAMAOQACABACADQAHAJADALQAFAPgDARQgBAKgEAJQgCAGgEAGQgFAJgHAIQgEADgDADQgOAKgQAFQgFACgFAAQgGABgGABQgBAAgBAAQgFAAgFAAQgOgCgOgEQgDgBgDgBQgPgIgLgKQgCgBgBgCQgCgCgCgDQgKgMgGgPQAAAAAAgBQgDgHgDgHQgDgLgCgNQAAAAAAgBIAAgBAg8AdQACgMAFgNQAZgPABgBQAQgHAMAAQAVgCAQALQAEADADADQAAAAAAAAQABABABABQAKAJAGAPQABAEABAFQABADABAEQAAACABACQABABAAACQABACAAADQABAIAAAIQgBAOgEALQgEAIgGAHQAAAAAAAAQgGAGgHAEQgNAIgQgBQAAAAgBAAQgIgBgGgDQgNgGgJgLQgDgDgCgCQAAgBgBAAQAAAAAAAAQgGgHgEgIQgEgHgEgIQgBgDgBgCQgCgGgDgHQgBgDgBgEQgCgFgCgFQAAAAAAAAIAAgC").cp();
	this.shape_334.setTransform(537.2,252.8);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#70BF56").s().p("AhfAcQACg8ApgsQABgCABgBQADgDADgDQAqgnA7gJQADAIACAHQgDABgDABQgDAAgEABQgDACgDABQgBAAAAABQgDABgCABQgZAMgNAXQgBACgBACQgEAHgDAIQgDAHgCAHQAAADgBADQgCAKgCAKQAAAEgBAEQAMgHAJgEQAEgCAEgBQAOgDAPABQAEABAEAAQATAEANAOQADADACACQAHAKAEALQAFAQgCASQgBALgEAJQgCAGgDAGQgGALgHAHQgEAEgEADQgOAMgQAFQgFABgFABQgGABgHABQgBAAgBAAQgFAAgFAAQgOgCgPgEQgDgBgDgBQgQgIgLgLQgCgBgBgBQgCgDgCgDQgKgMgGgQQAAAAAAgBQgDgHgDgIQgDgLgBgOQAAAAAAAAIAAgCAg8AeQACgMAEgNQAZgQACAAQAPgHAMAAQAWgCAPAMQAEACADAEQAAAAAAAAQABABACABQAKAJAEAQQACAEABAEQABAEAAAEQABABAAACQABACAAACQABACAAACQABAJAAAIQgBAOgFAKQgDAJgGAGQAAAAgBAAQgFAHgIAEQgMAIgQgBQgBAAAAAAQgJAAgFgDQgNgGgJgMQgDgCgCgDQAAAAgBgBQAAAAAAAAQgFgHgEgIQgFgIgDgIQgBgCgBgCQgCgHgCgHQgCgEAAgDQgCgFgCgGQAAAAAAAAIAAgC").cp();
	this.shape_335.setTransform(537.3,252.7);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#70BF56").s().p("AhhAdQACg/ApgtQABgCACgBQADgDADgDQAqgpA+gJQACAIACAIQgDABgDAAQgEABgEABQgEACgDABQAAAAgBABQgDABgCABQgbANgOAXQgCACgBACQgEAIgDAIQgDAHgCAHQgBADgBADQgDAKgBALQgBAEgBAFQAMgIALgFQAFgCACgCQAPgDAQABQAEAAAFABQATADAPAPQADADACAEQAIAIAFAMQAFAQgCAUQAAALgEAKQgCAGgDAHQgGALgHAIQgEAEgEADQgOANgRAGQgFABgFABQgHABgGABQgBAAgBAAQgGAAgFAAQgPgBgPgFQgDgBgDgBQgQgIgMgLQgBgBgCgCQgCgCgCgDQgKgNgGgRQAAAAAAAAQgDgIgDgJQgDgLgBgOQAAgBAAAAIAAgCAg7AfQABgNAEgMQAZgQABgBQAQgHAMAAQAWgBAPAMQAEADADADQAAAAAAAAQABABABAAQAKALAEAQQACAEABAFQAAADABAEQAAACAAACQABABAAACQABACAAADQABAJgBAHQgBAOgEALQgEAIgGAHQAAAAAAAAQgGAHgHAEQgNAIgQAAQAAAAAAAAQgJgBgFgDQgNgFgJgMQgDgDgCgDQAAAAgBAAQAAAAAAgBQgFgHgEgIQgEgIgDgIQgBgDgBgCQgCgHgCgHQgBgEAAgDQgCgGgBgFQAAAAAAAAIAAgD").cp();
	this.shape_336.setTransform(537.4,252.5);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#70BF56").s().p("AhiAeQABhBApgvQACgCABgCQADgDADgDQArgqBAgJQACAIACAIQgDABgDABQgFABgFABQgDABgDACQgBAAgBABQgDABgCABQgdANgQAYQgBACgCADQgEAHgEAJQgDAHgCAHQgBADgBADQgDALgCALQgBAEgBAFQANgJALgFQAFgDAEgBQAOgEARABQAFAAAEAAQAVAEAQAPQADADADADQAIAJAFANQAGARgBAUQAAAMgEALQgCAHgDAGQgGAMgHAJQgEAEgEAEQgOANgSAGQgFACgGABQgGABgHABQgBAAgBAAQgGAAgFAAQgQgBgOgFQgEgBgDgBQgRgIgMgMQgBgBgCgBQgCgDgCgDQgKgOgGgRQAAAAAAAAQgDgJgDgIQgDgNAAgOQAAgBAAAAIAAgCAg7AgQACgNACgNQAZgQACAAQAPgIANABQAVgBAQANQADACADADQAAAAAAAAQABAAABACQAKALAEARQABAEABAEQABAEAAAEQABABAAACQAAACAAABQABADAAACQABAJgBAIQgBAOgFALQgEAIgFAHQAAAAAAAAQgGAHgHAEQgNAIgQAAQAAAAAAAAQgHAAgIgDQgMgGgKgMQgCgDgCgCQAAgBgBAAQAAAAAAgBQgFgHgEgJQgDgHgDgJQgBgCAAgDQgDgGgBgIQgBgEgBgEQgBgFgBgGQAAAAAAAAIAAgD").cp();
	this.shape_337.setTransform(537.4,252.4);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#70BF56").s().p("AhkAfQABhEAqgwQABgCABgCQADgDAEgDQAsgrBBgKQACAIACAJQgDABgEABQgFABgFABQgDABgEACQgBAAgBABQgDABgCABQgfAOgRAYQgCADgCACQgEAIgEAIQgEAHgCAIQgBADgCAEQgDAKgCALQgBAFgBAFQANgKAMgGQAFgCAFgCQAOgFASABQAFAAAEABQAWADARAPQAEAEADADQAJAJAGANQAHASgBAWQAAAMgEALQgCAIgDAHQgGAMgHAKQgEAEgEAEQgPAOgSAHQgGACgFABQgHABgHABQgBAAgBAAQgGAAgFAAQgQgBgPgEQgEgBgEgCQgRgIgMgMQgBgBgCgCQgCgDgCgDQgLgOgFgSQAAAAAAAAQgDgJgDgJQgCgNgBgPQAAgBAAAAIAAgCAg7AhQACgNACgNQAZgQABgBQAQgHANAAQAVAAAPANQAEADADACQAAAAAAAAQABABABABQAJAMAEARQABAEABAFQABADAAAEQAAACAAACQAAABAAACQABACAAADQAAAJgBAHQgBAOgFALQgDAIgGAHQAAAAAAAAQgFAHgHAFQgNAJgQAAQAAAAAAAAQgHgBgIgDQgMgFgKgMQgCgDgCgDQAAAAgBgBQAAAAAAAAQgFgIgDgJQgEgHgCgJQgBgDAAgCQgCgHgCgIQAAgEgBgEQgBgGgBgGQAAAAAAAAIAAgD").cp();
	this.shape_338.setTransform(537.5,252.3);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#70BF56").s().p("AhlAgQAAhGAqgyQABgCACgCQADgDADgEQAtgsBDgKQACAJACAJQgEABgDABQgGABgFABQgEABgDACQgBAAgBABQgEABgCABQghAOgSAZQgCADgCACQgFAIgFAJQgDAHgDAIQgBADgCAEQgDALgDALQgBAFAAAFQANgKAMgHQAFgDAFgBQAPgGATABQAFAAAFAAQAXADASAQQAEADADAEQAKAKAGANQAIATgBAWQABANgDAMQgDAIgDAHQgGANgHAKQgEAFgEAEQgPAPgTAHQgGACgGACQgGABgIABQgBAAgBAAQgFAAgGAAQgRgBgPgEQgEgBgEgCQgRgIgNgNQgBgBgCgBQgCgDgCgEQgLgOgFgTQAAAAAAAAQgDgJgDgKQgCgNAAgQQAAgBAAAAIAAgCAg6AiQABgNABgNQAZgRACAAQAPgIAOABQAUAAAQAOQADACADACQAAAAAAAAQABACABABQAJAMAEASQABAEAAAEQABAEAAAEQAAABAAACQAAACABABQAAADAAACQAAAJgBAIQgCAOgEALQgEAIgFAHQAAAAAAAAQgGAHgHAFQgMAJgQAAQAAAAAAAAQgHAAgIgDQgMgFgKgNQgCgDgCgDQAAAAgBgBQAAAAAAAAQgFgIgDgJQgDgIgCgJQgBgCAAgDQgCgHgBgIQgBgEAAgEQgBgGAAgHQAAAAAAAAIAAgD").cp();
	this.shape_339.setTransform(537.5,252.1);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#70BF56").s().p("AAwiHIATgEIgEgUQhLAMguA0QgtA0AABMQAAAeAHAXQAHAYAOARQAOAPAUAJQATAHAWACQAVAAATgHQATgIAPgQQAOgNAIgUQAIgUAAgWQAAgogagbQgZgbgkAAQgSAAgSAGQgSAHgTAQQAIgtAZghQAYgfAvgPIAAAAAApAEQAQAVAAAjQAAAmgQAXQgPAWgaAAQgZAAgQgcQgRgdAAgzIACgaQALgNAPgFQAOgIAQACQAZAAAQATIAAAA").cp();
	this.shape_340.setTransform(537.6,252);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_315}]}).to({state:[{t:this.shape_316}]},31).to({state:[{t:this.shape_317}]},1).to({state:[{t:this.shape_318}]},1).to({state:[{t:this.shape_319}]},1).to({state:[{t:this.shape_320}]},1).to({state:[{t:this.shape_321}]},1).to({state:[{t:this.shape_322}]},1).to({state:[{t:this.shape_323}]},1).to({state:[{t:this.shape_324}]},1).to({state:[{t:this.shape_325}]},1).to({state:[{t:this.shape_326}]},1).to({state:[{t:this.shape_327}]},1).to({state:[{t:this.shape_328}]},1).to({state:[{t:this.shape_329}]},1).to({state:[{t:this.shape_330}]},1).to({state:[{t:this.shape_331}]},1).to({state:[{t:this.shape_332}]},1).to({state:[{t:this.shape_333}]},1).to({state:[{t:this.shape_334}]},1).to({state:[{t:this.shape_335}]},1).to({state:[{t:this.shape_336}]},1).to({state:[{t:this.shape_337}]},1).to({state:[{t:this.shape_338}]},1).to({state:[{t:this.shape_339}]},1).to({state:[{t:this.shape_340}]},1).wait(17));

	// 7
	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#84C554").s().p("Ag4gFQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLQgUgQgdgCQgbgCgrAOQgkAMgMAJIAOgBQAPAAAIADIAAAA").cp();
	this.shape_341.setTransform(572,186.1);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#84C554").s().p("AhOgCIgNgHQAVgIAqgLQAlgMAaADQATAPALAbQAMAKACALQAKgCADgDQgMAOgcADQgWACgYgLQgVgOgHgDQgRgJgRgDQgIgCgOAAIAAAA").cp();
	this.shape_342.setTransform(571.8,185.2);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#84C554").s().p("AhagKQAYgIAtgKQAkgLAZACQAOAXAGAgQAKAKACAKQANgJAGgKQgOAOgdADQgWACgXgLQgUgNgHgCQgRgIgQgDQgHgBgPAAIgLgK").cp();
	this.shape_343.setTransform(571.8,184.8);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#84C554").s().p("AhagSQAdgIAwgJQAigLAXADQAJAeACAmQAJAJAAAKQARgQAKgQQgRAMgeADQgWACgWgKQgTgMgHgBQgQgGgPgBQgIgCgOAAIgLgP").cp();
	this.shape_344.setTransform(571.8,185.1);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#84C554").s().p("AhagaQAhgIA0gJQAfgJAWAEQAFAjgDAtQAIAJgBAJQAUgWAOgYQgTAMggACQgVADgTgKQgVgLgHAAQgPgFgPAAQgIgCgNAAIgLgT").cp();
	this.shape_345.setTransform(571.8,185.4);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#84C554").s().p("AhZgiQAlgHA0gJQAggIAVAEQgBAqgHA0QAHAIgCAIQAXgdARgdQgVAKgiACQgUACgSgIQgUgJgHAAQgPgFgOABQgHgCgNAAIgKgX").cp();
	this.shape_346.setTransform(571.8,185.7);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#84C554").s().p("AhZgqQApgHA4gIQAegHATAEQgFAxgMA6QAFAHgCAIQAagkAVgjQgYAJgjABQgTADgSgGQgTgKgHABQgOgEgOABQgHgBgNAAIgJgb").cp();
	this.shape_347.setTransform(571.8,185.9);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#84C554").s().p("AhZgyQAugGA7gIQAbgGASAEQgKA4gQBAQAEAHgDAIQAdgsAZgqQgaAKglACQgTACgRgHQgSgJgHABQgOgCgMACQgIgBgMAAIgJgf").cp();
	this.shape_348.setTransform(571.8,186.2);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#84C554").s().p("AhYg6QAygGA9gHQAagFARAEQgQA/gUBGQADAGgEAIQAggzAcgxQgcAJgmACQgTACgQgGQgRgIgHACQgNgBgMADQgIgBgLAAIgIgj").cp();
	this.shape_349.setTransform(571.8,186.4);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#84C554").s().p("AhYhCQA2gFBBgHQAYgEAPAEQgUBGgZBMQABAGgEAHQAjg5Agg4QgfAIgoACQgRACgQgGQgQgHgHADQgMgBgMAFQgHgBgMAAIgHgn").cp();
	this.shape_350.setTransform(571.8,186.7);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#84C554").s().p("AhYhKQA7gFBDgGQAWgDAPAFQgaBNgdBRQAAAGgFAGQAnhAAjg/QghAIgqACQgPABgRgFQgQgGgGAEQgMAAgLAGQgHgBgLAAIgHgr").cp();
	this.shape_351.setTransform(571.8,187);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#85C555").s().p("AhXhSQA+gEBHgGQAUgCANAFQgeBUgiBYQgBAFgHAFQArhHAmhGQgjAIgrABQgPACgQgEQgPgGgGAFQgLABgKAHQgIgBgKAAIgGgv").cp();
	this.shape_352.setTransform(571.8,187.2);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#85C555").s().p("AhXhaQBDgEBKgEQASgCALAFQgjBbgmBeQgDAFgHAFQAuhOAqhNQgmAHgsABQgOACgQgEQgOgFgGAGQgLACgJAIQgHgBgKAAIgGgz").cp();
	this.shape_353.setTransform(571.8,187.4);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#85C555").s().p("AhXhhQBHgEBNgEQAQAAALAFQgoBhgrBlQgEAEgGAEQAvhVAuhTQgoAGgvABQgNABgPgCQgNgEgGAGQgKADgJAKQgHgBgKAAIgFg3").cp();
	this.shape_354.setTransform(571.8,187.7);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#85C555").s().p("AhZhpQBLgDBRgEQAOABAJAGQgtBoguBqQgFAEgIAEQAyhcAxhbQgqAGguABQgPABgOgCQgMgDgGAHQgKAFgIAKQgHgBgJAAIgFg7").cp();
	this.shape_355.setTransform(572,187.9);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#85C555").s().p("AhbhwQBQgDBTgDQAMACAIAFQgyBvgyBxQgGADgKADQA1hiA1hiQgsAFgwABQgOABgNgBQgMgDgGAIQgIAGgIALQgHAAgJAAIgEg/").cp();
	this.shape_356.setTransform(572.2,188.1);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#85C555").s().p("Ahdh4QBUgCBWgDQAKADAHAGQg3B0g2B4QgIADgKADQA4hqA5hoQgvAEgxABQgOABgMgBQgLgBgGAIQgIAHgHANQgHgBgJAAIgDhD").cp();
	this.shape_357.setTransform(572.5,188.3);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#85C555").s().p("Ahfh/QBYgCBagCQAIADAFAGQg8B7g7B/QgJACgLACQA8hwA8hvQgxADgzABQgNABgMAAQgJgBgGAKQgIAHgGAOQgHAAgIAAIgDhH").cp();
	this.shape_358.setTransform(572.7,188.5);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#85C555").s().p("AhhiHQBcgBBdgCQAGAFAEAGQhBCCg/CFQgKABgMACQA/h3A/h2QgzACg0ABQgNABgLABQgJAAgGAKQgHAJgFAOQgHAAgIAAIgChL").cp();
	this.shape_359.setTransform(572.9,188.8);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#85C555").s().p("AhjiOQBggBBggBQAEAFADAHQhFCIhECLQgMABgNABQBCh+BEh9Qg2ACg2ABQgMABgKABQgIABgGALQgGAKgGAQQgGAAgHAAIgChP").cp();
	this.shape_360.setTransform(573.2,189);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#85C555").s().p("AhliWQBlAABigBQACAHACAGQhKCQhJCRQgNAAgNABQBHiFBFiEQg4ABg4ABQgLABgJACQgIACgFALQgGALgFARQgGAAgHAAIgBhT").cp();
	this.shape_361.setTransform(573.4,189.2);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#85C555").s().p("AhnhHIANAAQAEgSAFgMQAGgMAGgDQAJgDALAAIBzgBIiTEXIAdAAICckuIAAgPIjPAAIAABX").cp();
	this.shape_362.setTransform(573.6,189.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_341}]}).to({state:[{t:this.shape_342}]},37).to({state:[{t:this.shape_343}]},1).to({state:[{t:this.shape_344}]},1).to({state:[{t:this.shape_345}]},1).to({state:[{t:this.shape_346}]},1).to({state:[{t:this.shape_347}]},1).to({state:[{t:this.shape_348}]},1).to({state:[{t:this.shape_349}]},1).to({state:[{t:this.shape_350}]},1).to({state:[{t:this.shape_351}]},1).to({state:[{t:this.shape_352}]},1).to({state:[{t:this.shape_353}]},1).to({state:[{t:this.shape_354}]},1).to({state:[{t:this.shape_355}]},1).to({state:[{t:this.shape_356}]},1).to({state:[{t:this.shape_357}]},1).to({state:[{t:this.shape_358}]},1).to({state:[{t:this.shape_359}]},1).to({state:[{t:this.shape_360}]},1).to({state:[{t:this.shape_361}]},1).to({state:[{t:this.shape_362}]},1).wait(15));

	// 4
	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#3C7951").s().p("AhdgHIAOgBQAPAAAIADQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLQgUgQgdgCQgbgCgrAOQgkAMgMAJIAAAA").cp();
	this.shape_363.setTransform(598,243.1);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#3C7951").s().p("AhSAAIgJAAIAMgBQAQAAAIABQASAFASAKQAJAEAXAPQAWAJAVgFQAXgEAHgkQAAgBAAgBQAFAEADAFQADANgEAKQgIAOgZADQgVAHgXgHQgWgOgJgFQgRgOgQgKQgNgCgVAAIAAAAAhegBQASgQAngTQAngNAbACQANAFAKAHQgNgEgRAAQgaABgpAPQgiANgNAJIgCAA").cp();
	this.shape_364.setTransform(598,242.9);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#3C7951").s().p("AhLAYQAVgUAogUQAIgCAGgDQADgBAFgBQAZgCATAEQAGAEAFAEQAHAEAGADQAAAAAAAAQgEgBgEAAQgIgCgJAAQgDABgDAAQgLACgNAEQgHACgIAAQgLABgQADQAAAAAAAAQgcAJgRAIQgDACgDACIgDgBIAAAA").cp();
	this.shape_365.setTransform(595.9,240.5);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#3C7951").s().p("AhNAbQAXgXAqgXQAHgDAGgDQAFgBAFgBQAYACARAIQAGAEAGAGQAHADAHADQAAAAAAAAQgEAAgEAAQgJgBgKAAQgCABgDABQgKACgMAGQgIABgJACQgLgCgPABQAAAAAAAAQgeAJgTAHQgEABgCABIgDgBIAAAA").cp();
	this.shape_366.setTransform(596.1,240.4);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#3C7951").s().p("AhOAeQAYgaArgZQAIgEAGgEQAGgBAGgBQAWAGAQALQAGAGAFAGQAIACAHACQAAAAAAAAQgDABgEABQgJgBgLAAQgCABgDACQgKAGgLAHQgJACgJABQgKgEgOgCQAAAAAAAAQggAIgWAHQgEAAgCABIgCgCIAAAA").cp();
	this.shape_367.setTransform(596.2,240.3);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#3C7951").s().p("AhQAhQAbgdAsgcQAIgFAGgEQAGgBAHgBQAUAJAQAPQAFAHAFAFQAJADAIADQAAAAAAAAQgDACgDACQgKgCgMAAQgCACgDADQgJAHgLAKQgJABgKABQgJgGgNgFQAAAAAAAAQgjAIgZAGQgDgBgCAAIgCgCIAAAA").cp();
	this.shape_368.setTransform(596.3,240.3);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#3C7951").s().p("AhSAiQAdggAtgfQAIgGAHgFQAHgBAHAAQATANAPASQAFAIAEAGQAKADAJADQAAAAAAAAQgDACgDADQgLgCgMAAQgCADgCADQgJAKgKALQgKABgLABQgKgJgLgHQAAAAAAgBQglAIgbAGQgDgCgCgBIgCgCIAAAA").cp();
	this.shape_369.setTransform(596.4,240.4);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#3C7951").s().p("AhUAhQAfghAvgjQAHgHAIgGQAIAAAHgBQASARAOAWQAEAJAEAHQALADAKACQAAAAAAABQgDADgDADQgLgBgNAAQgCADgCADQgIAMgKANQgKABgMABQgKgMgJgKQAAAAAAAAQgnAGgeAGQgDgCgCgCIgCgCIAAgB").cp();
	this.shape_370.setTransform(596.6,240.7);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#3C7951").s().p("AhWAhQAigkAvgnQAHgHAJgGQAIgBAIgBQARAVAMAaQAFAKAEAIQALACALADQAAAAAAAAQgDAEgDAEQgMgBgNAAQgCAEgCAEQgIANgIAOQgMABgLACQgKgPgJgMQAAgBAAAAQgpAGghAFQgCgCgCgDIgCgDIAAAA").cp();
	this.shape_371.setTransform(596.7,240.9);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#3C7951").s().p("AhYAgQAkgmAxgqQAHgIAKgHQAIgBAIAAQAQAZALAdQAEAKAEAKQAMACAMACQAAAAAAABQgDAEgCAFQgNgBgOAAQgCAEgCAFQgHAPgIAQQgMABgMABQgJgRgIgPQAAAAAAgBQgrAGgkAFQgDgDgBgEIgCgDIAAgB").cp();
	this.shape_372.setTransform(596.8,241.2);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#3C7951").s().p("AhaAgQAmgqAygsQAIgJAKgIQAIAAAJgBQAOAdALAhQAEAKADAMQANACANABQAAABAAAAQgCAFgDAGQgOgBgOAAQgCAFgCAFQgGARgIASQgMABgNABQgIgUgHgSQAAAAAAAAQguAFgnAEQgCgEgBgEIgCgDIAAgB").cp();
	this.shape_373.setTransform(596.9,241.5);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#3D7A52").s().p("AhcAfQApgsAzgwQAIgJAKgJQAJAAAJgBQANAhAKAkQADALADANQAOACAOACQAAAAAAABQgCAGgDAGQgOgBgQAAQgBAGgCAFQgFATgHAUQgOABgNABQgIgXgIgUQAAgBAAAAQgtAFgqAEQgCgFgBgFIgCgEIAAgB").cp();
	this.shape_374.setTransform(597,241.7);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#3D7A52").s().p("AheAfQArgwAzgyQAKgKAKgJQAKgBAJAAQAMAkAJAoQADAMACAOQAPACAPABQAAABAAAAQgCAHgCAHQgQgBgQAAQgBAGgBAHQgGAUgGAWQgOAAgOABQgHgZgHgXQAAAAAAgBQgwAEgsAEQgCgFgBgGIgCgEIAAgB").cp();
	this.shape_375.setTransform(597.2,242);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#3D7A52").s().p("AhfAeQAsgyA0g1QALgLAKgKQAKgBAKAAQALApAIArQACANADAPQAPABAPACQAAAAAAABQgBAHgCAIQgQgBgRAAQgBAHgBAHQgFAWgFAYQgPAAgPABQgGgbgHgbQAAAAAAgBQgxAEgwADQgBgGgBgGIgBgFIAAgB").cp();
	this.shape_376.setTransform(597.3,242.3);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#3D7A52").s().p("AhhAeQAvg2A0g4QALgLALgLQALAAAKgBQAJAtAHAvQADAOACAQQAQABAQABQAAABAAAAQgBAIgCAJQgQgBgSAAQgBAIgBAHQgEAYgFAZQgPABgQABQgFgegGgdQAAgBAAAAQg0ADgyADQgBgHgBgHIgBgFIAAgB").cp();
	this.shape_377.setTransform(597.4,242.5);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#3D7A52").s().p("AhjAdQAxg4A2g7QALgMAMgMQALAAAKAAQAIAwAGAzQACAOACASQARABARABQAAAAAAABQgBAJgBAJQgSgBgSAAQgBAIgBAIQgDAbgEAaQgRABgQAAQgFgggFggQAAAAAAgBQg2ADg0ACQgCgHAAgIIgBgFIAAgC").cp();
	this.shape_378.setTransform(597.5,242.8);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#3D7A52").s().p("AhlAdQAzg7A3g+QAMgNAMgMQALgBAMAAQAGA0AFA2QACAQABASQASABASABQAAABAAAAQgBAKgBAKQgSgBgTAAQgBAJgBAJQgDAcgDAcQgRAAgRABQgEgjgEgjQAAAAAAgBQg4ADg4ACQgBgJAAgIIgBgGIAAgB").cp();
	this.shape_379.setTransform(597.6,243.1);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#3D7A52").s().p("AhnAcQA2g+A4hBQAMgNAMgNQAMAAAMgBQAFA5AEA5QABARABATQATABATAAQAAABAAABQgBAKgBALQgTgBgTAAQgBAKgBAJQgCAegDAeQgRAAgSABQgDgmgDglQAAgBAAAAQg7ABg6ACQgBgJAAgKIgBgFIAAgC").cp();
	this.shape_380.setTransform(597.8,243.4);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#3D7A52").s().p("AhpAcQA4hBA5hEQANgOAMgOQANAAAMAAQAEA8ADA9QABASAAAUQAUAAAUABQAAABAAAAQgBALAAAMQgUgBgVAAQAAAKAAAKQgCAggCAgQgTAAgSAAQgCgogDgoQAAAAAAgBQg8ABg9ACQgBgKAAgLIgBgGIAAgB").cp();
	this.shape_381.setTransform(597.9,243.6);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#3D7A52").s().p("AhrAbQA6hEA7hGQAMgPANgPQANAAANAAQACBAACBBQABATABAVQAUAAAVAAQAAABAAABQgBAMAAAMQgVAAgVAAQAAAKAAAKQgBAigCAiQgTAAgTAAQgCgrgBgqQAAgBAAgBQg/ABhAABQAAgLAAgLIgBgGIAAgC").cp();
	this.shape_382.setTransform(598,243.9);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#3D7A52").s().p("AhtAbQA9hHA7hJQANgQANgPQAOgBANAAQABBEABBEQABAUAAAWQAVABAWAAQAAABAAAAQgBANAAANQgVAAgWAAQAAALAAALQgBAjAAAjQgUAAgUABQgBgugBgtQAAgBAAgBQhAABhDAAQAAgLAAgMIgBgGIAAgC").cp();
	this.shape_383.setTransform(598.1,244.2);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#3D7A52").s().p("AAoicIiXC2IAAAiICJAAIAABhIApAAIAAhhIAtAAIAAgdIgtAAIAAi7IgbAAAhZAfIBziLIAACLIhzAA").cp();
	this.shape_384.setTransform(598.3,244.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_363}]}).to({state:[{t:this.shape_364}]},35).to({state:[{t:this.shape_365}]},1).to({state:[{t:this.shape_366}]},1).to({state:[{t:this.shape_367}]},1).to({state:[{t:this.shape_368}]},1).to({state:[{t:this.shape_369}]},1).to({state:[{t:this.shape_370}]},1).to({state:[{t:this.shape_371}]},1).to({state:[{t:this.shape_372}]},1).to({state:[{t:this.shape_373}]},1).to({state:[{t:this.shape_374}]},1).to({state:[{t:this.shape_375}]},1).to({state:[{t:this.shape_376}]},1).to({state:[{t:this.shape_377}]},1).to({state:[{t:this.shape_378}]},1).to({state:[{t:this.shape_379}]},1).to({state:[{t:this.shape_380}]},1).to({state:[{t:this.shape_381}]},1).to({state:[{t:this.shape_382}]},1).to({state:[{t:this.shape_383}]},1).to({state:[{t:this.shape_384}]},1).wait(17));

	// 5
	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#00AD57").s().p("AAUAKQgSANgMAHQgZANgXgDQgZgDgHgPQgFgLAEgLQAEgKAOgMQAUgQAcgCQAbgCArAOQAkAMAMAJQgXgDgOAFQgSAFgSAKIAAAA").cp();
	this.shape_385.setTransform(418,157.1);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#00AD57").s().p("ABNgXQgMAAgJADQgOADgOAFQgGAGgHAGQgEADgEAEQgCACgBABQgCACgCABQAAADgDADQAAAAgBAAQgCACgCADQgDADgEADQgFADgFADQgJAFgKABQgCAAgCAAQgQABgLgGQgGgEgDgEQgEgEgBgFQgDgIACgIIAAgBQAAgDACgBQABgDADgBQADgDADgBQACgBABgBQACgBADgBQABAAAAgBQAEgBADgBQADgCAEAAQAEgCAEgCQAFgCAFgDQAEgCAFgCQAFgDAFgCQABgBABAAQAFgDAFgBQAFgBACABQADAAADACQADABAEACQABABABAAQAKgCAKgBQAJgBAIAAQAZAHAOAGQgDAAgCgBQgGACgEACIAAAA").cp();
	this.shape_386.setTransform(418,157.8);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#00AD57").s().p("AhZAHQAAgDABgCQAAgBABgBQABAAABAAQACgBABgBQABAAABgBQACAAABAAQABgBABAAQABgBACAAQAAABABAAQAAgBABAAQABAAACgBQABAAAAgBQACAAABAAQADgBADgBQADgBAEgBQAFgCADgCQABAAABgBQADgCADgCQACgBABgBQAEgCADgDQABgBABAAQAFgEAEgDQABgBABAAQAEgEADgBQACAAABAAQABgBABABQACAAABABQABABAAAAQADABADADQAAAAABAAQAAABABAAQABAAABAAQAIgDAIgEQAJgCAHgCQAFAAAEAAQAVAGAOAFQgCgBgCAAQgCABgDABQgBABgCABQgDABgDABQgJAAgIACQgNACgOAEQgCABgCACQgGAHgGAIQgCACgBABQgCACgCACQgBAAAAAAQgBABAAAAQgBACAAABQAAAAgBABQgBADgBACQAAAAAAAAQAAAAAAAAQgBADgBADQAAAAgBABQgCADgDACQgBACgCABQgCADgEACQgCACgEADQgFADgGACQgDAAgCABQgDAAgEABQgNAAgLgEQAAAAAAAAQgGgDgEgEQgEgEgDgFQAAgCgBgCQgDgGACgIQAAAAAAAAIAAgB").cp();
	this.shape_387.setTransform(417.9,158);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#00AD57").s().p("AhZANQABgEABgCQAAgBABgBQABgBACgBQACgBACgBQABAAABAAQACgBABABQABgBAAAAQACABABAAQAAABABAAQABAAABgBQABAAACAAQABAAAAgBQACAAABAAQAEAAADAAQAEgBAFgBQAFgCAEgCQAAgBABgBQAEgCADgDQABgBACgCQADgCADgEQABgBABgBQAEgEAEgEQAAgBABgBQADgEADgBQABgBAAAAQAAAAABABQABAAABABQAAABABAAQABACADADQAAAAAAAAQAAABABAAQABgBABAAQAHgEAJgFQAIgEAHgEQAEgBAEgBQAXAFARAFQgBgBgBAAQgCABgBABQgCABgBACQgDABgDACQgKAAgJACQgPACgQAEQgCABgCACQgGAJgGAJQgBADgCACQgBAAgBACQgBAAAAAAQAAABAAAAQAAABAAABQAAAAAAABQgBADAAACQAAAAAAAAQAAABAAAAQgBACAAADQgBABAAAAQgBAEgBADQgBACgBABQgCADgDADQgDADgDADQgFAEgGADQgDABgCABQgDABgFABQgOACgNgDQAAAAAAAAQgHgEgEgEQgFgEgDgFQgBgCgBgBQgEgHABgJQAAAAAAAAIAAgB").cp();
	this.shape_388.setTransform(417.9,158.1);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#00AD57").s().p("AhYATQAAgEACgDQABgBABgCQABgBACgBQACgBACAAQACAAABAAQACAAABABQAAgBABABQABABABABQABAAAAABQABAAABAAQACAAACgBQABAAABAAQABAAACAAQADAAAEgBQAFgBAFgCQAFgCAFgDQABAAAAAAQAEgDAEgEQABgBACgBQADgEADgEQABgBAAgBQAEgFADgFQAAgBABgBQACgFAAgBQAAgBAAAAQAAgBABABQAAAAABACQAAABAAAAQABACACAEQAAAAAAAAQAAABAAgBQABAAAAAAQAIgHAIgGQAIgGAHgGQAEgCADgBQAaAFATAEQAAgBgBAAQgBABAAABQgCACgBABQgDADgCACQgMAAgJACQgRACgSAEQgCABgBADQgGAKgGALQgCACgBADQgBABAAAAQgBAAABAAQAAAAAAAAQABABABABQAAAAAAABQAAACABADQAAAAAAABQAAAAAAAAQAAACAAAEQAAAAAAABQgBADgBAEQgBACgBACQgCADgBAEQgCADgDAEQgEAFgHAEQgCABgCACQgFABgEACQgQAEgPgDQAAAAAAAAQgHgDgFgEQgGgEgDgGQgCgBgBgCQgFgIABgJQAAAAAAgBIAAAA").cp();
	this.shape_389.setTransform(417.8,158.1);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#00AD57").s().p("AhYAYQABgFABgCQABgCACgBQABgCACAAQADgBACAAQACgBABABQACAAABABQABAAAAABQACACAAACQABAAAAABQABAAABAAQACAAADAAQAAAAABgBQACABACAAQAEgBAEAAQAGgBAFgCQAGgCAFgEQAAgBABgBQAFgDADgDQABgBACgCQADgEADgFQAAgBABgCQAEgGAAgGQAAgBAAgBQABgFAAgCQAAgBAAAAQgBAAAAABQAAAAAAACQAAAAAAABQAAACABAEQAAAAAAABQAAAAAAAAQABgBAAAAQAHgIAHgIQAIgIAHgIQAEgCADgDQAcAFAWAEQAAgBAAAAQAAABABABQgCACgBACQgCADgDADQgMAAgLACQgTACgTADQgCACgCADQgGAMgFAMQgCADgBADQAAABAAAAQAAAAABAAQAAAAABAAQABABACAAQABAAAAAAQABACABADQAAAAAAAAQAAABABAAQABACABAEQgBABAAAAQAAAEgBAEQAAADgBACQgBADgCAFQgCADgDAEQgCAHgHAEQgDACgCACQgEADgFACQgRAGgRgDQAAAAAAAAQgIgDgGgEQgGgEgEgFQgCgCgBgCQgGgIAAgKQAAAAAAgBIAAgB").cp();
	this.shape_390.setTransform(417.8,158.2);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#00AD57").s().p("AhYAdQAAgFACgDQABgCACgBQABgBACgBQAEgBADAAQABAAABAAQADACABABQAAAAABABQABACAAADQAAABABAAQABABABAAQACAAADAAQABAAABAAQACAAACAAQAEAAAFAAQAGgBAGgCQAGgDAFgEQABgBABgBQAFgEADgFQABgCACgCQADgDACgGQABgBAAgBQACgIABgGQAAgBAAgCQAAgGgCgCQAAAAgBAAQAAgBAAABQAAAAAAACQgBABgBABQAAACABAEQAAABAAABQgBAAAAgBQAAAAAAgBQAFgJAHgKQAIgKAGgJQAEgEADgDQAeAEAYAEQABgBABAAQABABABABQgBACgBACQgCAEgDAEQgNAAgMACQgVABgVADQgBADgCADQgGANgFAOQgBADAAADQAAABAAAAQAAAAAAAAQABAAACAAQACAAACABQABAAABAAQABACACACQABAAAAAAQAAAAAAABQACACACAFQAAAAAAABQABAEgBAFQAAACgBACQAAAEgCAFQgCAEgCAFQgEAHgGAGQgCADgCACQgFADgFADQgSAIgTgDQAAAAgBAAQgIgDgGgEQgHgEgFgFQgCgCgBgCQgHgJAAgKQAAgBAAAAIAAgC").cp();
	this.shape_391.setTransform(417.9,158.3);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#00AD57").s().p("AhZAjQAAgGACgDQACgCACgCQABgBADgBQAEgBADABQABAAABAAQAEACAAACQABAAAAABQABADAAAEQAAAAAAABQACABABAAQADAAADAAQABABABgBQACABACAAQAFAAAFAAQAHgBAGgDQAHgCAFgFQABgBABgBQAFgFADgGQACgCABgCQABgFACgFQABgBAAgCQADgIAAgHQAAgCAAgCQgBgGgDgCQgBgBgBAAQAAgBgBABQgBABgBACQgBABgBABQAAACgBAFQAAAAAAABQgBAAAAAAQAAgBgBgBQAHgLAFgLQAHgMAGgLQAEgFADgEQAgAEAbADQABAAACAAQACAAACABQgBADgBADQgCAEgCAFQgPAAgNABQgWACgXADQgCADgBADQgGAPgDAPQgCADgBAEQABAAACAAQAAAAABgBQAAAAABAAQADAAADAAQABABABAAQADACADADQAAAAAAAAQABAAAAAAQADACACAFQAAAAAAABQACAEAAAGQAAACAAADQgBAEgBAGQgBAEgDAGQgEAIgGAHQgDADgDADQgCADgGAEQgTAJgVgDQgBAAAAAAQgJgCgHgEQgHgEgGgFQgCgCgBgCQgJgJAAgMQAAAAAAgBIAAgB").cp();
	this.shape_392.setTransform(418,158.4);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#00AD57").s().p("AhaAoQABgGACgEQABgCACgBQACgCADAAQAEgBAEAAQABABACAAQADACABADQAAAAAAABQABAEAAAEQAAABAAABQACAAABABQADABADAAQABAAABAAQADAAACABQAFAAAGAAQAHgBAHgDQAHgDAGgGQABgBABgBQAFgEACgHQABgCABgDQADgGACgHQABAAAAgCQADgJgBgIQgBgCAAgCQgCgHgEgCQgBgBgCAAQAAAAgCABQgCAAgCACQgBABgBACQgBACgBAFQgBABAAABQAAAAgBgBQgBgBgBAAQAHgNAGgNQAFgOAHgNQADgFADgGQAiAEAeADQACAAACgBQADABADABQgBADgBADQgCAFgCAFQgPABgPABQgYABgZADQgBAEgCADQgDARgFAQQgCAEgBADQACAAACAAQABgBABAAQACgBAAAAQADAAAEAAQACABABAAQADACAEAEQAAAAABAAQAAAAABAAQADACADAEQAAABABAAQACAFABAGQAAADAAACQAAAFgBAGQgBAFgCAGQgEAKgGAHQgDAEgDADQgFAFgEAEQgUALgYgDQAAAAgBAAQgJgCgHgEQgJgEgGgFQgCgCgCgCQgJgKgBgMQAAAAAAgBIAAgC").cp();
	this.shape_393.setTransform(418.1,158.5);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#00AD57").s().p("AhbAtQABgGACgFQACgCACgBQACgCADAAQAFgBAEABQABAAACABQAEACAAADQABABAAACQAAAEAAAEQAAACAAAAQACABABABQADABAEAAQABAAABAAQACABADAAQAGABAFAAQAJgBAHgDQAIgEAGgGQAAgBABgBQAEgFADgHQACgDABgDQADgGACgJQAAgCABgBQACgJgCgIQgBgCAAgCQgDgJgFgCQgCgBgCAAQgBAAgDABQgCABgCACQgCABgBABQgCADgCAFQAAABgBABQAAAAgBAAQgBgBgBgBQAGgPAGgOQAHgQAEgPQADgGADgGQAkADAgADQADgBADAAQAEABAEABQgCADAAAEQgCAFgCAGQgQAAgQACQgaABgaACQgCAEAAAFQgEARgFASQgCAEgBAEQADgBACgBQABAAACgBQACgBACAAQADgBAEABQACAAABAAQAEADAFADQABAAAAABQABAAAAAAQAFADADADQABABAAABQADAEABAHQABADAAADQABAFgBAGQgBAGgCAHQgDAKgGAJQgDAEgDAEQgFAFgHAEQgTANgagCQAAAAgBAAQgKgCgIgEQgJgDgHgGQgCgCgCgCQgLgKAAgNQAAgBAAAAIgBgD").cp();
	this.shape_394.setTransform(418.2,158.5);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#00AD57").s().p("AhbAzQAAgIADgEQABgDADgBQACgCADAAQAGgBAEABQABABACABQAEACABAEQAAABAAACQAAAFAAAFQAAABAAABQABABACABQADABAEAAQABABABAAQADAAADABQAGAAAGAAQAJAAAIgEQAIgDAGgHQAAgBAAgBQAGgGADgIQACgDABgDQADgHACgJQAAgCAAgCQACgKgDgJQAAgCgBgCQgEgJgHgCQgCgBgCAAQgCgBgEABQgCABgDACQgCABgCACQgCADgCAGQgBABAAABQgBgBgBAAQgCgBgBgBQAFgQAHgQQAGgSAGgRQABgHADgHQAmADAjACQADAAAEAAQAEAAAFABQgBAEAAAEQgCAGgCAHQgRAAgRABQgbABgbACQgBAFgCAFQgFATgFATQgBAEgBAEQADgBADgBQACgBACgBQACgBADAAQADgBAFABQACAAACAAQAFACAFAEQABAAAAAAQABABABAAQAFADAEAFQABAAABAAQADAFACAHQABADABADQABAGgBAHQAAAGgCAIQgDALgGAKQgEAEgDAEQgFAGgHAFQgUAPgcgCQgBAAgBAAQgKgCgJgEQgJgDgIgGQgCgCgCgCQgMgLgBgOQAAAAAAgBIAAgC").cp();
	this.shape_395.setTransform(418.3,158.6);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#00AD57").s().p("AhcA4QAAgIADgFQACgCADgCQADgBADgBQAGAAAEABQACABABAAQAFAEAAAEQAAABAAACQAAAFAAAGQAAACAAABQABABACABQAEABADABQACAAABAAQADABADABQAGAAAHAAQAJAAAJgEQAIgEAFgHQABgBABgCQAGgGADgIQACgEABgDQADgIACgKQAAgCAAgCQACgKgEgKQgBgDgBgCQgFgKgIgCQgDgBgCAAQgDgBgEACQgDABgEACQgCABgCACQgDADgCAGQgBABgBABQgBAAgBgBQgCgBgCgBQAFgSAGgRQAHgUAFgSQADgJADgIQAmADAlACQAFAAAEAAQAFAAAGABQgBAEgBAFQgBAGgBAIQgTAAgRABQgeABgcACQgBAFgCAFQgFAUgFAVQgBAEgBAFQAEgCAEgBQACgBACgBQADgBADgBQADgBAHAAQACABACAAQAFACAHAEQAAAAABAAQABAAABABQAGADAFAGQAAAAABABQAEADADAIQABADABAEQACAGgBAHQAAAHgBAIQgDANgHAKQgDAFgDAFQgGAGgHAGQgVAQgegBQgBAAgBAAQgLgCgJgEQgKgDgIgGQgDgCgDgCQgNgLgBgPQAAgBAAAAIAAgD").cp();
	this.shape_396.setTransform(418.4,158.7);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#00AD57").s().p("AhdA9QABgIADgFQACgDADgCQADgBADgBQAHAAAEABQACABABABQAFAEABAEQAAACAAACQgBAGAAAHQgBABAAABQACACACABQAEABAEABQABAAACAAQADABADABQAHABAHAAQAKAAAJgFQAHgDAHgIQABgCABgBQAGgHADgJQACgDABgFQADgHABgLQABgCAAgDQABgNgFgJQgBgDgBgCQgGgKgJgDQgDgBgDAAQgEAAgFABQgDABgEACQgDACgCABQgEAEgDAGQgBABgBACQgBgBgBAAQgCgCgDgBQAFgTAGgUQAGgVAFgUQADgJADgKQAoADAoACQAFAAAFgBQAGABAHAAQgBAFgBAFQgBAIgBAHQgTABgTAAQggABgdACQgCAFgBAGQgFAWgFAVQgBAFgBAFQAFgCAEgCQACgBACgBQAEgBAEgBQAEgBAHAAQACAAACAAQAHACAHAEQABABAAAAQABAAABAAQAHAEAGAGQABABAAAAQAGAEADAIQABADABAEQACAHAAAIQABAHgCAJQgCANgHAMQgDAFgEAGQgFAHgIAGQgYASgegCQgBAAgBAAQgMgBgKgDQgKgEgJgGQgDgCgDgDQgOgLgBgPQAAgBAAgBIgBgD").cp();
	this.shape_397.setTransform(418.5,158.8);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#00AD57").s().p("AhdBCQAAgIADgGQACgDAEgCQADgBADgBQAHAAAFACQACABACABQAFAEAAAFQAAACAAACQgBAHgBAHQAAACAAABQACACACABQAEABAEABQACABABAAQAEABADABQAHABAIAAQAKAAAKgFQAHgEAHgIQACgCABgBQAGgIAEgJQABgEACgFQACgIABgLQABgDAAgCQAAgPgFgJQgBgDgCgDQgHgLgLgDQgDgBgDAAQgFAAgFABQgFABgEADQgDABgCACQgFAEgDAGQgCACAAABQgCAAgBgBQgDgBgDgCQAFgVAGgVQAFgXAGgWQACgKADgKQAqACArABQAFAAAGAAQAHAAAHABQAAAFgBAFQgBAJgBAIQgUAAgUABQghABggABQgBAGgCAGQgEAXgFAXQgBAFgBAFQAFgCAFgCQADgBACgCQAEgBAFgBQAEgCAIABQACAAADAAQAHACAIAEQABAAABABQABAAABAAQAIAEAGAGQABABABABQAGAFAEAHQABADACAFQACAHABAIQAAAIgBAJQgCAPgHAMQgDAGgEAGQgGAIgIAGQgZAUghgBQgBAAgBAAQgMgBgKgDQgMgEgJgGQgDgCgDgDQgQgMgBgQQAAAAAAgBIAAgE").cp();
	this.shape_398.setTransform(418.6,158.9);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#00AD57").s().p("AheBIQAAgKAEgGQACgDAEgBQADgCAEAAQAHgBAFACQACABACACQAFAEABAFQAAADgBACQgBAIgBAHQAAACAAACQACABACACQAEABAFABQABABACAAQAEABADACQAIAAAIABQALAAAIgGQAKgEAHgJQABgBACgCQAGgHAEgLQACgEABgFQACgJABgMQAAgDAAgCQABgQgHgKQgBgDgCgDQgIgMgMgCQgEgCgDAAQgGAAgGABQgFACgFACQgDACgCACQgFAEgFAHQgBABgBACQgCgBgBgBQgDgBgDgCQAEgWAFgXQAGgZAFgYQACgLADgLQAsACAtABQAGAAAHAAQAIAAAIAAQAAAGgBAGQgBAJAAAJQgWAAgVAAQgjABghABQgCAHgBAGQgEAZgFAYQgBAGgBAFQAGgDAGgDQACgBADgBQAFgCAEgBQAGgCAIAAQADABACAAQAIABAKAFQAAAAABAAQABABACAAQAIAEAHAGQABABABABQAHAGAEAHQACAEACAEQADAIABAIQAAAJgBAKQgCAQgGANQgDAGgEAHQgGAIgJAHQgaAWgjgBQgBAAgBAAQgNgBgLgDQgMgEgKgGQgDgCgDgDQgRgMgCgRQAAgBAAgBIAAgD").cp();
	this.shape_399.setTransform(418.7,159);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#00AD57").s().p("AhfBNQAAgKAEgGQADgEAEgBQADgCAEAAQAIAAAFACQACABACABQAGAFAAAGQAAACAAADQgCAIgBAJQAAACAAABQACACACACQAFABAEACQACAAACAAQADACAEABQAIABAIABQAMAAAIgGQALgEAIgKQABgCABgBQAHgIAEgLQACgFABgFQACgJABgNQAAgDAAgDQAAgRgHgLQgCgDgCgDQgJgMgNgDQgFgBgDAAQgHgBgGACQgGABgFADQgDABgEACQgFAFgFAHQgCABgBACQgCgBgBAAQgEgCgDgCQAEgYAFgYQAFgbAFgaQADgMACgMQAvACAvABQAHAAAGgBQAKABAJAAQgBAGAAAGQgBAKAAAJQgXABgWAAQglABgjAAQgBAHgBAHQgEAagFAaQgBAGgBAFQAHgDAGgDQADgCADgBQAFgCAFgCQAHgBAIAAQADAAADAAQAJACAKAEQABABABAAQABAAABABQAKADAHAHQACABABABQAHAGAFAHQADAFABAFQAEAHABAKQABAJgBALQgCAQgGAPQgDAHgFAGQgGAJgIAIQgcAXglAAQgBAAgCAAQgNgBgLgDQgNgEgLgGQgDgCgEgDQgRgNgCgSQAAAAAAgBIgBgE").cp();
	this.shape_400.setTransform(418.8,159.1);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#00AD57").s().p("AhgBSQAAgKAFgHQACgDAFgCQADgCAEAAQAJAAAFACQACACACABQAHAFAAAHQgBACAAADQgCAJgBAJQAAACgBACQADACACACQAFACAFABQACAAABABQAEABAEACQAIABAJAAQANABAIgGQALgFAJgKQABgCABgCQAHgIAEgMQACgEABgGQACgKABgOQAAgDAAgDQgBgRgIgNQgCgDgCgDQgKgNgOgDQgGgBgDAAQgIgBgHACQgGABgGADQgDACgEACQgGAFgGAHQgBACgCAAQgCAAgCAAQgDgCgEgBQAEgaAFgaQAFgdAEgcQADgNABgMQAyABAxAAQAIAAAHAAQALAAAKABQgBAGAAAGQgBALAAAKQgYAAgXABQgmAAglABQgCAHgBAHQgEAcgEAbQgBAGgBAGQAHgEAHgDQADgCAEgCQAFgCAGgCQAIgBAIAAQADAAADAAQAKABALAFQABAAABABQACAAABABQAKADAJAHQABABABABQAIAHAGAIQADAEACAFQADAIACAKQABAKgBALQgBASgGAPQgEAIgEAHQgHAJgIAJQgeAYgnABQgBAAgBAAQgOgBgMgDQgNgEgMgGQgEgCgDgDQgTgOgCgSQAAgBAAgBIgBgE").cp();
	this.shape_401.setTransform(418.9,159.2);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#00AD57").s().p("AhgBXQAAgLAEgGQADgEAEgCQAEgCAFAAQAJAAAFADQACABACACQAHAFAAAHQAAADgBADQgBAKgCAKQAAACgBACQADACACACQAFACAFABQACABACAAQAEACAEACQAJAAAJABQALAAALgGQAMgEAIgLQACgCABgCQAIgJADgMQACgFABgGQACgLABgOQAAgDgBgEQAAgSgJgPQgCgBgDgEQgLgNgQgEQgFgBgFAAQgIgBgIACQgGACgGADQgEABgEACQgHAFgGAIQgCAAgBACQgCgBgDgBQgDAAgFgBQAEgcAEgbQAFgfAEgeQADgOABgNQA0AAA0ABQAIAAAIAAQAMAAAKAAQAAAHAAAHQAAALgBALQgYAAgZAAQgoAAgnABQgBAHgBAIQgEAdgEAdQgBAGgBAGQAIgEAIgEQADgCAEgBQAFgDAGgCQAKgCAIAAQAEAAADABQAKABANAEQABABAAAAQACABACAAQALAEAJAHQABABABABQAJAHAHAKQADADACAFQAEAJACALQABAKAAAMQgBATgGAQQgEAIgEAHQgHAKgJAJQgfAbgpAAQgBAAgBAAQgPAAgMgDQgOgEgNgGQgEgDgDgCQgUgOgDgTQAAgBAAgBIAAgF").cp();
	this.shape_402.setTransform(419,159.3);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#00AD57").s().p("AhiBdQAAgMAEgHQADgEAFgCQAEgCAFAAQAJABAGACQACACACACQAHAGAAAHQAAADgBADQgCALgBAKQgBACAAACQADACACADQAFACAFABQACABACAAQAFACADACQAKABAKABQALAAAMgGQAMgFAJgMQABgBACgCQAHgKAEgNQACgFABgGQACgMAAgPQAAgDAAgDQgBgUgKgPQgCgEgDgCQgMgOgRgDQgGgCgFAAQgJAAgIACQgHABgHADQgFACgEACQgHAFgHAHQgCABgBACQgDgBgCgBQgEgBgFgBQAEgcAEgeQAEggAEggQACgOACgPQA1AAA3ABQAJAAAJAAQAMAAAMAAQAAAHAAAHQgBAMAAAMQgZAAgaAAQgqAAgpAAQgBAIgBAIQgDAfgEAeQgBAGgBAGQAIgEAJgEQADgCAEgCQAGgDAHgCQAKgCAJAAQAEAAADAAQAMABANAFQABABABAAQABABACAAQAMAEAKAIQABABACABQAJAHAHAKQADADADAGQAFAJACALQACALgBAMQAAAUgHARQgDAJgFAIQgHALgKAJQgfAcgrABQgCAAgBAAQgPAAgNgDQgPgEgNgGQgEgDgEgDQgVgOgDgUQAAgBAAgBIAAgE").cp();
	this.shape_403.setTransform(419.3,159.4);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#00AD57").s().p("ABeh2IAAgoIieAAIgSCfIAOAGQANgPAPgFQAQgIASABQAaAAARAUQASATAAAfQAAAZgFAPQgEAQgKALQgJAMgNAFQgMAHgMAAIgUgCIgYgJIgFgFIAGgiQAAgHgHgHQgGgGgPgBQgLAAgGAIQgFAIAAAMQAAAZAaARQAbASAoABQAvAAAigfQAfggABguQAAgbgJgTQgKgQgPgLQgPgMgRgEQgSgHgQABQgSAAgQAHIgaAOIALheICMAA").cp();
	this.shape_404.setTransform(419.7,159.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_385}]}).to({state:[{t:this.shape_386}]},42).to({state:[{t:this.shape_387}]},1).to({state:[{t:this.shape_388}]},1).to({state:[{t:this.shape_389}]},1).to({state:[{t:this.shape_390}]},1).to({state:[{t:this.shape_391}]},1).to({state:[{t:this.shape_392}]},1).to({state:[{t:this.shape_393}]},1).to({state:[{t:this.shape_394}]},1).to({state:[{t:this.shape_395}]},1).to({state:[{t:this.shape_396}]},1).to({state:[{t:this.shape_397}]},1).to({state:[{t:this.shape_398}]},1).to({state:[{t:this.shape_399}]},1).to({state:[{t:this.shape_400}]},1).to({state:[{t:this.shape_401}]},1).to({state:[{t:this.shape_402}]},1).to({state:[{t:this.shape_403}]},1).to({state:[{t:this.shape_404}]},1).wait(12));

	// 3
	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#10532D").s().p("AhdgHIAOgBQAPAAAIADQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLQgUgQgdgCQgbgCgrAOQgkAMgMAJIAAAA").cp();
	this.shape_405.setTransform(549,336.1);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#10532D").s().p("AgXgKQAFgCAEgDQAEgCAEgDQADgCADgBQAAgCACgBQADgBACgBQACgCACAAQADAAACAAQADgCADgBQADAAAEAAQABAAACAAQAHAAAFAAQAIgBAHgBQAFAAAEABQAEACACAEQAAAAgBAAQABABABACQABACABACQAEAGACAFQACADABADQAAACgBACQAAAAgBAAQAAAAAAAAQAAABABACQAAACAAABQAAADAAADIAAAAQAAACgBACQgBADgCACQgDADgEACQgDABgDABQgBABgCABQgCABgDABQgCABgDAAQgCABgDAAQgDABgDAAQgEABgFgBQgFgBgGgCQgCAAgBgBIAAABQgCgCgBgCQgCgBgCgBQgCgBgCgBQgEgCgDABQgCgBgBAAQgHgBgJgCQgMgDgOgCQgBgBgCAAQgGgBgHgBQgGgBgGgBQAAAAgBAAQgEAAgEgBQgEgBgCgBIAAAAQABgDADgCQADgBADAAQAEgCADAAQADgBACAAQAEAAAFAAQABAAABAAQACAAACAAQACAAADgBQAEgBAEgBQACAAACgBQABAAAAAAQADgBAEgCIAAAA").cp();
	this.shape_406.setTransform(548.1,335.6);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#10532D").s().p("AhSAOQABgCABgBQABgBACgCQABAAABgBQACgBACgBQABAAACAAQACAAACgBQAAAAABAAQACAAACABQABAAABAAQABAAABAAQABAAADAAQABAAAAABQABAAABAAQABAAAAAAQACAAACgBQABAAACAAQABAAACgBQACAAADgBQACAAABgBQACAAABAAQABgBABAAQABAAAAgBQACAAACAAQACgBACgBQACgBACgCQACgBACgCQABAAABgBQACgCABgCQABAAABgBQAAgCABgBQABAAAAgBQACgBAAgBQABAAAAgBQACgBABgBQABAAAAAAQACgBABgBQABgBABAAQACAAABAAQABAAABAAQAEgBADgBQACgBACAAQABAAACAAQACAAABgBQAEAAAEgBQACgBACAAQADgBACgBQAEgBADAAQABAAAAAAQACgBACABQACAAABABQAAAAAAAAQACABABACQABACABABQAAABgBAAQABABABACQABACABACQAAAAAAABQABACABACQABADABACQAAABAAABQABABABACQAAABAAABQABABgBACQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAABQABABAAABQAAABABABQAAACAAABQAAAAAAAAQAAABAAACQAAABAAAAQgBACgBADQAAABgBABQgCABgCABQgCABgCABQAAAAAAAAQgCABgBACQAAAAgCABQgBABgBAAQgCABgBABQgBAAAAAAQgCABgCABQgBAAAAAAQgCABgCABQgBAAgBABQgBAAgBAAQgEABgEgBQgBAAAAAAQgFAAgGgCQgBABAAAAQAAgBgBAAIAAAAQgCgCgBgBQAAAAgBAAQgBgBgBgBQgBgBAAAAQgBAAgBAAQgDgBgCAAQgBAAAAAAQgCAAgCAAQgCAAgDAAQgDAAgGAAQgGgBgGAAQgIgBgIgBQgBAAgDgBQgEAAgFgBQgCAAgDgBQgDAAgEgBQgDAAgDgBQAAAAgBAAQgBAAgBAAQgDgBgEgBQgBAAAAAAQgDgBgCgCQAAAAAAAAIAAAA").cp();
	this.shape_407.setTransform(547.7,335.2);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#10532D").s().p("AhQAWQABgDACgBQABgCABgBQABAAACgBQACgBADgBQABAAABAAQACAAACAAQABAAAAAAQACABACABQABAAABAAQABAAABABQACAAACAAQABAAABAAQABAAABABQABAAAAAAQACAAACgBQACAAABAAQACAAACgBQACAAADgBQACAAACgBQACAAABgBQABAAACgBQAAAAAAgBQACgBACgBQACgBACgCQACgCADgCQACAAABgBQABgBAAgBQABgCABgCQABgBAAgBQACgBAAgCQABAAAAgBQABgBAAgBQABAAAAgBQABgBAAAAQABgBAAAAQACgCACgBQAAAAABAAQADAAABAAQABAAABAAQAFgCADgBQACgBACAAQACgBABAAQACAAACgBQAEgBADgCQADgBABgBQADgBACgBQADgCACAAQAAAAAAAAQACgBACABQABABAAAAQAAABAAAAQACABABACQABACABACQgBAAAAABQABABABACQABACABACQAAAAgBABQACACABADQAAACAAADQAAABAAAAQABACAAABQABABAAAAQAAABgBABQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABABABABQAAABAAABQABABAAABQAAAAAAAAQABABAAABQAAABAAAAQAAACAAADQgBAAgBABQgBACgCABQAAABgBABQgBAAAAAAQgBACAAABQgBABgBABQgBAAgBABQgBACgCABQAAAAgBAAQgBABgDACQAAAAAAAAQgCABgCABQgBABgBAAQgBABgBAAQgEABgFAAQAAAAgBAAQgFAAgHgBQAAAAAAAAQgBAAgBAAIABAAQgCgCAAgBQgBAAAAAAQgBAAAAgBQgBgBAAAAQgBAAgBAAQgCAAgCAAQgBAAAAABQgCgBgBABQgCAAgDABQgFABgFAAQgFABgHAAQgIAAgJgBQgBAAgDgBQgFAAgFgBQgDAAgDAAQgDgBgEgBQgEgBgDAAQAAgBgBAAQgBAAgBAAQgEgBgEgBQAAAAgBAAQgDgCgCgCQAAAAAAAAIAAAA").cp();
	this.shape_408.setTransform(547.4,334.8);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#10532D").s().p("AhOAaQAAgCACgCQACgCABgBQACgBABAAQADgBADgBQABAAABAAQADABABAAQABAAAAAAQACABACACQAAAAABABQABAAACAAQACABACAAQABAAABAAQABABACAAQAAAAABAAQACAAACAAQACAAABAAQACgBACAAQADgBADgBQACAAACgBQACAAACgBQABgBABgBQABAAAAgBQACgBACgBQACgCACgCQACgCABgDQABgCACgBQAAgBABAAQACgCABgDQAAAAABgBQABgCAAgBQABgBAAgBQAAgBAAgBQAAAAAAAAQAAgBAAgBQABAAAAgBQACgCABgCQABAAABAAQADAAACAAQABAAAAAAQAGgCAEgBQACgBACgBQACAAABgBQACAAACgBQAEgCADgCQACgCACgBQACgCACgBQACgCABgBQAAAAAAAAQABAAABAAQABABABABQgBAAAAAAQACACAAACQABACABACQAAABAAAAQAAACABACQABACABACQAAABAAAAQABADABACQAAADgBACQAAABAAABQAAABABABQAAAAAAABQAAABgBAAQAAABAAAAQAAgBgBAAQAAAAAAAAQABABAAAAQABAAAAAAQAAACABAAQABABAAAAQABAAAAAAQABAAAAAAQABABAAABQABAAAAABQAAACAAACQAAAAAAABQgBACgBABQAAABgBABQAAAAAAABQAAABgBACQAAAAgBABQgBABgBABQAAACgCACQAAAAgBAAQgBACgCABQgBAAAAABQgCABgBACQgCABgBAAQgBABgBABQgEABgFAAQgBAAAAABQgGAAgHgBQgBAAAAABQAAgBAAAAIAAAAQgBgBAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAAAgBABQgCgBgCACQAAAAAAAAQgCAAgBABQgCABgCABQgFACgHABQgGABgFABQgIAAgKAAQgCAAgDgBQgFAAgGAAQgDgBgDAAQgEgBgEgBQgEgBgDAAQgBgBgBAAQgBAAgBAAQgEgBgEgCQgBAAAAAAQgEgDgBgCQAAAAAAAAIAAgB").cp();
	this.shape_409.setTransform(547.2,334.7);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#10532D").s().p("AhNAeQABgDACgDQABgBACgBQABgBACgBQADgBADAAQABAAACAAQADABABABQAAAAABAAQACACABACQABAAAAABQACAAABAAQACABADAAQABABABAAQABAAACAAQAAAAABAAQACABADgBQABAAACAAQACAAADgBQADAAADgBQACgBACgBQADAAABgBQACgBABgBQAAAAABgBQACgCACgBQABgCABgDQACgCACgDQACgCABgCQABgBAAgBQACgCAAgCQABgBAAgBQABgCAAgCQAAAAAAgBQAAgBgBgBQAAAAgBgBQAAgBAAAAQABgBAAAAQACgDABgCQABAAABAAQADAAACAAQABAAABAAQAGgCAEgCQACgBADAAQABgBACgBQACgBABgBQAEgCAEgDQACgCABgCQACgCABgCQACgDgBAAQABAAAAAAQAAgBABABQAAABAAABQAAAAAAAAQABACAAACQABADABACQAAABAAAAQABACABACQABACAAADQAAAAAAABQABADAAACQAAADgBACQAAABAAABQgBABABAAQAAABgBAAQAAABAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAQABAAAAAAQABABAAgBQABABABABQAAAAABAAQABABABABQAAAAAAAAQABAAABABQABAAAAABQABABABACQAAAAAAAAQAAABgBABQABACAAABQAAAAAAAAQAAACAAACQAAABgBABQgBABAAABQgBACgBACQAAAAgBAAQgBACgCACQAAABgBAAQgBACgCACQgBABgCABQgBABgBAAQgEADgGAAQAAAAgBAAQgGABgIAAQAAAAAAAAQAAAAgBAAIABAAQgBgBAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAABQgCAAgBABQAAABgBAAQgBAAgBACQgCABgCABQgFADgHACQgGACgHABQgHABgLAAQgCAAgDAAQgFAAgHAAQgDgBgDAAQgFgBgEgBQgEgBgEgBQgBAAAAgBQgCAAgBAAQgEgBgFgDQAAAAgBAAQgDgDgCgDQAAAAAAAAIAAAA").cp();
	this.shape_410.setTransform(547,334.8);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#10532D").s().p("AhNAhQAAgEADgCQABgCACgBQACgBABAAQAEgBADgBQABAAABABQAEABABABQABAAAAABQABACACACQAAABABAAQABABACAAQACABADABQABAAABAAQACAAABABQABAAAAAAQADAAADAAQABAAACAAQADAAACgBQADgBAEgBQACAAADgBQACgBACgBQABgBACgCQAAAAAAgBQACgBABgCQACgCACgDQACgDACgDQACgDABgCQAAgBABgCQABgCAAgCQABgBAAgCQAAgBAAgCQAAgBgBAAQgBgCgBAAQAAgBgBAAQAAgBgBgBQAAAAABgBQABgDACgCQABgBABAAQADAAACAAQABAAABAAQAHgBAFgCQACgCACAAQACgBACgBQACgBABgCQAEgCADgEQACgDABgCQACgDABgCQABgDgCAAQAAAAAAAAQAAgBABABQAAABAAABQgBAAAAAAQABACAAADQABACABADQgBAAAAABQABACABACQABADABACQAAABgBABQABADAAACQAAAEgCABQAAABgBABQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAQABAAABgBQAAABAAgBQABABACAAQAAAAABAAQABABABAAQABAAAAAAQABAAACABQABAAAAAAQABACACACQAAAAAAABQABABgBABQACACAAABQAAABAAAAQABABAAAAQABACgBABQAAABgBACQAAACgBACQAAAAgBAAQgBADgCACQAAABAAAAQgCACgCADQgBABgBABQgCABgBABQgEADgGAAQgBABAAAAQgHABgIAAQAAAAAAAAQAAAAAAAAIAAAAQAAgBAAgBQAAAAAAABQAAgBABAAQAAAAABABQAAAAgBABQAAAAgCACQAAAAAAABQgBAAgBACQgCABgCACQgEAEgHADQgGACgIACQgIACgLABQgCAAgDgBQgHABgHgBQgDAAgDgBQgFAAgFgCQgFgBgDgBQgBAAgBAAQgCgBgBAAQgFgCgEgCQAAgBgBAAQgEgDgBgDQAAgBAAAAIAAAA").cp();
	this.shape_411.setTransform(547,334.9);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#10532D").s().p("AhOAkQABgEACgDQACgCACgBQABgBACAAQAEgBADAAQACAAABAAQAEABABACQAAABABAAQABADABADQABAAAAABQACABABAAQADABADABQABAAABAAQACABABAAQABAAAAAAQADABADgBQACAAACAAQADAAACgBQAEAAADgBQADgBADgBQACgBACgBQACgCAAgBQAAAAAAgBQACgCACgCQADgDACgDQACgDACgEQABgCABgDQABgCAAgBQABgEAAgBQAAgBAAgCQAAgCgBgBQAAgBgBgBQgBgBgCgBQAAAAgBgBQgBAAgBgBQAAgBAAAAQACgEABgDQABAAACAAQADAAACAAQACAAABAAQAHgBAFgDQACgBADgBQACgBACgCQABgBACgCQAEgDADgFQACgDABgCQABgDAAgDQABgDgDgBQAAAAAAAAQgBAAAAABQAAABgBABQAAAAAAAAQAAACAAADQABADABADQAAAAgBABQABACABACQABADABADQAAAAAAABQAAADAAADQgBAEgCABQgBABAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAAAAAAAQABgBABAAQAAAAAAgBQABAAACAAQABAAABAAQABAAACABQAAgBABAAQABAAACABQABAAAAAAQACABACACQABABABAAQABACAAABQACABABACQAAAAAAAAQABACABACQAAACAAABQAAACAAABQAAABgBACQgBAAAAABQgBADgBACQgBABAAAAQgCADgCADQgBABgBACQgCABgBABQgEADgGABQgBAAgBAAQgGACgJAAQgBAAAAABQAAAAAAAAIABAAQAAgBABgBQAAAAAAAAQABAAAAAAQABAAABABQAAAAAAABQAAABgBADQAAAAgBAAQAAABgCACQgBACgCACQgEAFgHAEQgGADgJADQgJACgLABQgCAAgDAAQgHAAgHAAQgEgBgEAAQgFgBgFgBQgFgBgEgCQgBAAgBAAQgBgBgCAAQgFgCgEgDQgBgBgBAAQgEgDgBgEQAAAAAAgBIAAAA").cp();
	this.shape_412.setTransform(546.9,334.9);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#10532D").s().p("AhPAnQABgEACgDQACgCACgCQACgBACAAQAEgBAEAAQABAAACABQADABACADQAAAAAAABQABADABADQABABAAABQACABABAAQADABADABQACAAABABQACAAABABQABAAAAAAQADAAAEAAQACAAACAAQADAAACgBQAEgBAEgBQADAAADgCQACgBABgBQABgCACgCQAAAAAAgBQADgCACgCQACgDACgEQACgDACgEQACgDAAgDQABgCAAgBQABgFgBgBQABgBgBgCQAAgCgBgCQgBgBgBAAQgBgCgDAAQAAgBgCAAQgBgBgCAAQABgBAAgBQABgEABgDQACAAABAAQAEAAACAAQACAAABAAQAIgCAFgDQADgBACgBQACgBACgCQACgCACgBQADgEADgGQACgDABgDQABgEAAgDQgBgEgEAAQABAAgBAAQgBgBAAABQgBACgBABQAAAAAAAAQgBACAAADQABADABAEQAAAAgBABQABACABACQABADABADQAAABAAABQAAADAAADQgBAEgEABQAAABgBAAQgBABgBgBQAAAAgBAAQABgBgBAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAABgBQABAAAAgBQACAAACgBQAAAAABAAQACAAACAAQABAAAAAAQABgBADABQABAAABAAQACABADABQABABABABQABABABABQADABABACQAAABABAAQABACABACQABACAAABQAAACAAACQAAACgBADQAAAAAAABQgBABgBADQgBABAAAAQgBADgDADQgBACgBACQgCABgBACQgFADgGABQgBABgBAAQgHACgJAAQAAABAAAAQAAAAAAAAIABAAQABgBABAAQAAAAAAAAQABAAABAAQABAAABACQAAAAAAABQAAABAAADQAAAAAAABQgBABgBADQgBACgCADQgEAFgHAEQgGAFgJADQgLADgKABQgDAAgDAAQgIABgIgBQgDAAgEAAQgGgBgFgCQgGgBgEgBQgBgBgBAAQgCgBgBgBQgFgCgFgDQgBAAAAgBQgEgEgCgEQAAAAAAAAIAAgB").cp();
	this.shape_413.setTransform(547,335);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#10532D").s().p("AhQAqQABgFACgDQACgCADgCQACgBACAAQAEgBAEABQACAAABAAQAEACABADQAAAAAAABQABAEABADQABABAAABQACABABABQADABADABQACABABAAQACAAACABQABAAAAAAQADABAEgBQACAAACAAQADAAADgBQAEAAAEgCQADAAADgCQABgBACgCQACgBACgCQAAgBABgBQACgCACgDQADgCABgFQACgDACgFQACgDAAgDQABgCAAgCQABgFgBgCQAAgBgBgBQAAgCgCgCQgBgBgBgBQgCgBgDgBQgBAAgCgBQgBAAgDgBQABgBAAAAQABgFABgEQACAAACAAQADAAADAAQABAAACAAQAIgBAGgDQADgCACgBQACgCACgBQACgCACgCQAEgFACgGQACgEABgDQAAgEAAgEQgBgEgFgBQAAAAAAAAQgCAAgBABQgBABgBABQgBABAAAAQgBACgBADQABAEACADQgBABAAABQABACABACQABADABADQAAABgBABQABAEgBADQgBAEgEABQgBABgBAAQgCAAAAAAQgBgBAAgBQAAAAgBgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQABgBABgBQAAgBABAAQABgBADgBQABAAABAAQACAAACgBQAAAAABAAQACgBACAAQACABABAAQADAAADACQABAAABABQACABABABQAEACACACQAAAAABAAQACACABADQABACAAABQABACAAACQAAADAAADQgBAAAAABQAAAEgCADQAAABAAAAQgCACgCADQgBACgCACQgBACgCABQgEAEgHACQgBAAgBAAQgHADgKAAQAAABAAAAQAAAAABAAIAAABQACgBABgBQAAABAAAAQABAAACAAQABAAACACQAAABABABQAAABAAAEQAAAAAAAAQgBACgBADQgBADgBADQgEAGgHAFQgGAFgKAEQgLAEgMABQgCABgEAAQgHAAgJAAQgEAAgEgBQgGgBgGgBQgGgCgEgBQgBgBgBAAQgCgBgBgBQgGgCgFgEQgBAAAAgBQgFgEgBgFQAAAAAAAAIAAgB").cp();
	this.shape_414.setTransform(547,335.1);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#10532D").s().p("AhRAtQABgFACgDQACgDADgBQACgBACgBQAFgBAEABQACAAABABQAEACABADQABABAAABQAAAEABAEQAAABABABQABABACABQADABAEABQABABACAAQACABACAAQAAAAABAAQADABAEAAQACAAADAAQADAAADgBQAEgBAEgBQAEgBABgCQADgBACgCQACgCACgCQAAAAABgBQACgDACgDQADgDACgEQACgEABgFQACgDAAgEQAAgCAAgCQABgFgBgEQAAAAgBgBQgBgDgCgCQgBgBgBAAQgDgCgDAAQgCgBgBAAQgDgBgCAAQAAgBAAgBQABgFABgEQACAAACAAQAEAAADAAQABAAACAAQAJgBAGgEQADgCACgBQADgCABgCQACgCACgCQAEgFACgHQACgFAAgDQABgFgBgEQgCgFgGAAQAAAAAAAAQgDgBgBACQgCABgBABQAAAAgBABQgBACgBADQABAEABAEQAAABAAABQABACABACQABAEAAADQAAABAAABQAAADgBAEQgCAEgEABQgBABgBAAQgCAAgBgBQAAgBgBgBQAAgBAAgBQAAAAgBgBQAAgBAAgBQAAAAABAAQAAgCABgBQABgBABAAQABgBADgBQABgBABAAQACgBADAAQAAgBABAAQACgBADAAQACAAABAAQADABAEABQABABACAAQACABACABQAEACADACQAAABABAAQADACABADQABACABACQAAACAAACQABADAAADQAAAAAAABQgBAEgBAEQAAABgBAAQgBAEgCACQgBACgCACQgCACgBACQgFAEgHACQgBABgBAAQgHADgLABQAAAAAAABQAAAAABAAIABAAQABgBACAAQABAAAAAAQABABACAAQABABACABQABABABABQAAACABAEQAAAAAAABQgBACAAADQgBADgCAEQgDAHgHAGQgHAGgKAEQgMAFgMACQgDAAgDAAQgIABgJgBQgFAAgEAAQgHgBgGgCQgGgCgEgBQgCgBAAAAQgCgBgCgBQgGgDgFgEQgBAAAAgBQgFgFgBgFQAAAAAAAAIAAgB").cp();
	this.shape_415.setTransform(547,335.2);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#10532D").s().p("AhSAwQABgFACgEQACgDADgBQACgBADgBQAFAAAEAAQACABABAAQAFADABADQAAABAAABQABAEAAAFQAAABABACQABABACABQADABAEACQACAAABAAQACABACABQABAAAAAAQAEAAAEAAQACAAADAAQADAAADgBQAFAAAEgCQADgBACgCQADgBADgCQACgCACgCQAAgBABgBQACgDADgDQACgDACgFQACgEABgGQACgDAAgEQAAgCAAgCQABgGgCgFQAAAAgBgBQgBgCgDgCQgBgBgCgBQgDgBgEgBQgBAAgCgBQgDAAgDgBQAAgBAAAAQACgGAAgFQACAAACAAQAEAAADAAQACAAABAAQAKgBAHgEQADgCACgCQADgBACgCQACgDABgCQAEgGADgHQABgFAAgEQAAgGgBgEQgDgFgHgBQAAAAAAAAQgEAAgBABQgCACgCABQAAAAAAAAQgCADgCAEQACAEABAEQAAAAAAACQAAACABACQABAEABADQAAABAAABQAAAEgBADQgDAFgFABQgBAAgBABQgCAAgBgCQgBgBgBgBQAAgBAAgBQAAgBAAgBQAAgBAAgBQAAAAAAgBQABgBABgCQABgBAAgBQACgBADgBQABgBABgBQADAAACgBQABAAABgBQACgBAEAAQABAAACAAQAEAAAEABQACABACAAQADABACABQAFACADADQABAAAAAAQADADACACQABACABADQABACAAACQABADAAAEQAAAAAAABQAAAFgBAEQgBAAAAABQgBAFgCAEQgCACgBABQgCACgCACQgFAEgHADQgBAAgBAAQgIAEgLABQAAAAAAABQAAAAABAAIABABQACgBADAAQAAAAAAAAQACAAACABQACABACACQABABABABQABACABAFQAAAAgBABQABACgBADQgBAEgBAEQgDAIgHAHQgHAGgLAFQgMAGgOACQgCAAgEAAQgIABgKAAQgEAAgFgBQgHgBgGgCQgHgBgFgCQgBgBgBAAQgCgBgBgBQgHgDgFgFQgBAAAAgBQgFgFgBgGQAAAAAAAAIAAgB").cp();
	this.shape_416.setTransform(547.1,335.3);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#10532D").s().p("AhTAzQAAgGADgEQACgCADgCQADgBADgBQAFAAAEABQACAAABABQAFACABAEQAAABAAABQABAFAAAGQAAABAAABQACACACABQADABAEACQACAAACABQACAAACABQAAAAABAAQADABAFAAQADAAACAAQAEAAADgBQAFgBAEgCQACAAAEgDQADgBACgCQACgCADgDQAAAAABgCQACgDADgDQACgEACgFQACgEABgGQACgEAAgEQAAgDAAgCQAAgGgCgFQAAgBgBAAQgCgDgDgCQgBgBgCgBQgEgBgEgBQgCAAgCAAQgEgBgDAAQAAgBAAgBQACgGAAgFQACAAADAAQADAAAEAAQACAAABAAQAKgBAHgFQAEgCACgCQADgBACgDQACgCACgDQADgGADgJQABgFAAgFQAAgFgCgEQgDgHgJAAQAAAAAAAAQgEgBgCACQgCABgCACQgBAAAAAAQgCAEgCADQABAEABAEQAAABAAABQABADABADQABADABAEQAAABgBABQABAEgCADQgDAFgFABQgCAAgBAAQgDAAgBgBQgBgCgBgBQAAgBAAgCQAAgBAAgBQAAgBAAgBQAAgBAAAAQABgCABgCQABgBABgBQACgBADgCQABgBABgBQADgBADgBQABAAAAAAQADgBAEgBQACAAACAAQAEAAAFABQACAAACABQAEAAACABQAGACAEADQABAAAAABQAEACACADQACACAAADQABACABACQABAEAAAEQAAABAAAAQABAFgCAEQAAABAAABQgBAFgDAEQgBADgCADQgBACgCABQgGAEgHADQgBAAgBABQgIADgMACQAAABAAAAQABAAABABIABAAQACAAADgBQAAABABAAQACAAACABQACABADACQABABABACQABACABAFQAAABAAAAQABADgBAEQAAAEgCAEQgDAJgHAHQgHAIgLAGQgNAGgPACQgCAAgDABQgJABgKAAQgFgBgFAAQgHgBgHgCQgHgCgFgCQgBgBgBAAQgCgBgCgBQgHgDgFgGQgBAAAAgBQgFgGgBgGQAAAAAAAAIAAgB").cp();
	this.shape_417.setTransform(547.1,335.4);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#11532E").s().p("AhVA3QABgHADgEQACgDADgCQADgBADAAQAGgBAEABQACABABABQAFACABAFQAAABAAABQAAAFAAAGQABACAAABQACABACACQADABAEACQACAAACABQACABACAAQABAAAAAAQAEABAFAAQADAAACAAQAEAAAEgBQAEAAAEgCQAEgBADgCQADgCADgCQACgDACgCQABgBABgBQACgDADgEQACgEACgGQACgEABgGQABgFAAgEQABgDgBgCQABgHgDgFQgBgBgBgBQgBgCgEgCQgCgBgCgBQgEgCgFAAQgCAAgCgBQgEAAgCgBQAAgBAAgBQAAgGAAgFQACgBADAAQAEAAADAAQACAAACAAQALgBAHgEQADgCADgDQADgCACgCQACgDACgDQADgHACgJQACgGgBgFQAAgGgCgEQgEgHgKgBQAAAAAAAAQgFAAgCABQgDACgCACQgBAAAAAAQgCAEgDADQACAFABAEQAAABAAABQABADAAADQABADABAEQAAABAAACQAAAEgCADQgDAFgGABQgCAAgCAAQgCAAgCgCQgBgBgBgCQAAgCAAgCQAAgBAAgBQAAgBAAgBQAAgBAAgBQABgBACgDQAAgBABgBQACgCADgCQACgBABgBQADgBAEgBQABgBAAAAQADgBAFgBQACAAABgBQAFAAAGABQACAAADABQAEABADABQAGABAFADQAAABABAAQAEADADADQACACABADQABACABADQABAEAAAEQAAABAAAAQABAGgBAEQgBABAAABQgBAFgCAFQgCADgBADQgCADgCACQgFADgIADQgBABgBAAQgJAEgMACQgBABAAABQACAAABAAIABAAQADAAADAAQAAAAABABQACAAACABQADABADADQABABACACQACACABAGQAAAAAAABQABADgBAEQAAAEgBAFQgDAKgHAIQgHAJgMAGQgNAHgQACQgEABgCAAQgJABgLAAQgFAAgFgBQgIgBgHgCQgHgCgFgCQgCgBgBAAQgCgBgCgBQgHgEgFgFQgBgBgBgBQgFgGgBgHQAAAAAAAAIAAAA").cp();
	this.shape_418.setTransform(547.2,335.5);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#11532E").s().p("AhWA6QABgHADgFQACgDAEgCQACgBADAAQAGgBAFABQACABABABQAFADABAFQAAABAAABQAAAGAAAGQAAACABACQABABADABQADACAEACQACAAACABQADABACABQAAAAABAAQAEABAFAAQADAAADAAQAEAAADgBQAFgBADgCQAFgBAEgCQADgCADgDQACgCACgDQABgBABgBQACgDADgEQADgEABgHQACgFABgGQABgEAAgGQAAgCAAgCQAAgIgDgFQgBgBgBgCQgCgBgEgDQgCgBgCgBQgFgBgFgBQgDAAgCAAQgFgBgCAAQAAgBAAgBQABgHABgGQAAAAADAAQAEAAAEAAQACAAACAAQALgBAIgFQADgCADgDQADgCACgDQACgDACgDQADgHACgKQABgGAAgGQgBgHgCgEQgFgIgLAAQAAAAAAAAQgGgBgCACQgDACgDABQAAABgBAAQgCAEgDADQABAFABAFQAAABAAABQABADABADQABADABAEQAAACgBABQAAAEgCAEQgDAFgHABQgCAAgCAAQgDgBgBgCQgBgBAAgDQAAgBAAgDQAAgBAAgBQAAgBAAgBQAAgBAAgBQAAgCABgDQABgBABgBQACgDADgCQACgBACgBQADgCAEgBQAAAAABgBQADgBAFgBQACgBACAAQAGAAAGAAQACABADAAQAFABADABQAHABAFAEQABAAABABQAFACADAEQACACABADQABADABACQACAEABAFQAAABAAAAQAAAGgBAFQAAABAAABQgBAGgDAFQgBADgCADQgCADgCACQgFAGgJACQAAAAgBAAQgJAFgOACQAAABAAABQACAAABAAIABABQAEAAADAAQABAAAAAAQADABACABQAEABADADQABABACACQACADACAGQAAABAAAAQABAEAAAEQgBAFgBAFQgCALgHAJQgIAJgMAHQgOAHgRADQgDABgEAAQgIACgLAAQgGgBgFAAQgIgBgIgDQgHgCgGgCQgBgBgBAAQgCgCgCgBQgIgDgFgGQgBgBgBgBQgFgGgBgIQAAAAAAAAIAAAA").cp();
	this.shape_419.setTransform(547.2,335.6);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#11532E").s().p("AhXA9QABgIADgEQACgEAEgCQACgBAEAAQAGgBAFACQACAAABACQAGADAAAFQAAABAAACQAAAGAAAHQAAACAAABQACACACABQAEACAEACQACABACAAQADABACABQABAAAAAAQAEABAGAAQADAAADAAQAEAAAEgBQAFgBADgCQAFgBAEgCQADgCADgDQADgCACgDQABgBAAgCQADgDADgFQADgEABgGQACgGABgGQABgFAAgGQAAgCgBgDQAAgHgDgGQgBgCgBgBQgDgCgEgCQgCgCgDAAQgFgCgGAAQgCgBgDAAQgEAAgEgBQAAgBAAgBQABgHABgGQACgBABAAQAEAAAEAAQACAAACAAQAMgBAIgFQAEgCADgDQADgCACgDQACgDACgEQADgIACgKQABgHAAgGQgBgHgDgFQgGgJgMAAQAAAAgBAAQgFgBgEACQgDACgDACQAAAAgBABQgDAEgDADQACAFABAFQAAACAAABQABADAAADQABAEABAEQAAABAAACQAAAEgDAEQgEAEgHACQgCAAAAgBQgDAAgCgCQgCgCgBgDQAAgCAAgDQAAgBAAgBQAAgBAAgCQAAgBABgBQABgCABgDQABgBABgCQADgCABgDQACgBACgBQADgCAEgCQABAAABAAQADgCAGgCQACAAACAAQAGgBAGABQADAAAEAAQAFABAEABQAIACAFADQABABABAAQAFADADAEQADACABADQACADABADQACAEABAFQAAABAAAAQABAHgBAFQgBABAAABQAAAGgDAFQgCAEgBADQgCADgDADQgFAGgJAEQgBABgBAAQgJADgOACQAAABAAABQACAAABABIABAAQAEAAAEAAQABABAAAAQADABADABQAEABADADQACACABACQADADADAGQAAABAAABQABAEAAAFQAAAFgBAGQgDALgHAJQgHALgNAHQgPAIgRAEQgEAAgEABQgJABgLAAQgGAAgFgBQgJgBgHgCQgIgDgGgCQgCgBgBgBQgCgBgCgBQgIgEgFgGQgBgBgBgBQgFgHgBgIQAAAAAAAAIAAAA").cp();
	this.shape_420.setTransform(547.3,335.7);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#11532E").s().p("AhYBAQAAgIAEgFQACgEAEgCQADgBADAAQAHAAAFABQACABABABQAGAEABAFQgBABAAACQAAAHAAAHQAAACAAACQACACACABQAEACAEACQACABADAAQACABADABQAAAAABAAQAEACAGAAQADAAADAAQAEgBAEAAQAEgBAFgCQAFgBAEgDQAEgCADgDQACgDADgDQABgBAAgBQADgEADgFQADgEABgHQACgGABgHQABgFAAgGQAAgCgBgDQAAgIgEgGQgBgCgCgCQgCgBgFgDQgCgBgDgBQgGgCgGAAQgDAAgEAAQgDgBgFAAQAAgBAAgCQABgHABgHQACAAACAAQADAAAFAAQACAAACAAQAMgBAJgFQAEgDADgDQACgCADgEQACgDACgEQAEgIABgLQABgIgBgGQgBgIgDgFQgHgJgMgBQgBAAgBAAQgGAAgEACQgDACgDACQgBAAgBAAQgDAFgDAEQABAFABAFQAAABABACQAAADABADQABAEABAEQAAACgBABQAAAFgDADQgEAFgGABQgCAAgCAAQgEAAgCgDQgCgCAAgDQgBgCAAgDQAAgCAAgBQAAgCAAgBQABgBAAgBQABgCACgEQABgBABgCQACgDAEgDQACgBACgCQABgCAFgCQABAAAAAAQAFgCAFgCQACAAADgBQAGAAAHAAQAEAAADAAQAGABAEABQAJACAGADQABABABABQAFADAEADQADADABADQACADACADQACAFABAFQAAABAAAAQABAHgBAGQAAABAAABQgBAGgCAGQgCAEgCAEQgCADgCADQgGAGgJAEQgBABgBAAQgKAFgOABQAAABAAABQACABACAAIABAAQAEABAEAAQABAAABABQADAAADACQAEABAEAEQACABABADQAEADACAHQAAABAAABQACAEAAAFQAAAFgBAHQgCAMgHAKQgIALgNAIQgPAJgSAEQgEABgFAAQgJACgMAAQgFgBgGAAQgJgBgIgDQgIgCgHgDQgBgBgBgBQgDgBgCgBQgIgEgGgHQAAgBgBgBQgGgHAAgIQAAgBAAAAIAAAA").cp();
	this.shape_421.setTransform(547.4,335.8);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#11532E").s().p("AhaBDQABgIADgGQADgDAEgCQADgCADAAQAIAAAEABQADABABACQAGADABAGQAAACgBABQAAAIgBAIQAAACAAACQACABADACQAEACAEACQACABADABQADABACABQABAAAAAAQAFABAGAAQADAAADAAQAFAAAEgBQADgBAGgCQAFgBAFgDQADgCADgDQADgDADgDQABgBAAgCQADgEADgFQADgFABgHQACgGABgHQABgGgBgGQAAgDAAgCQgBgJgEgGQgBgCgCgCQgDgCgFgCQgDgCgDgBQgGgBgHgBQgDAAgEAAQgDAAgGgBQAAgBAAgBQABgIAAgHQADgBADAAQADAAAEAAQACAAADAAQANAAAIgGQAFgDADgDQACgDADgDQACgEACgEQAEgJABgMQABgIgBgGQgCgJgEgFQgGgKgOAAQgBAAgBAAQgHgBgEADQgDACgEACQgBAAgBAAQgDAFgDAEQAAAFACAGQAAABAAACQABADAAADQABAEABAFQAAABAAACQgBAEgDAEQgCAFgJABQgCAAgDAAQgEgBgCgDQgBgCgBgDQgBgDAAgDQAAgCAAgBQAAgCAAgBQABgBAAgBQABgDACgEQABgBABgCQADgDAEgDQACgCACgCQAEgCADgCQAAgBABAAQAFgCAFgCQADgBADAAQAHgBAHAAQAEAAAEABQAGAAAFABQAJACAHAEQABAAABABQAGADAEAEQADADACADQACADABADQADAFABAGQAAABAAAAQABAIAAAGQgBABAAABQAAAHgDAGQgCAEgCAEQgCADgCADQgGAHgJAFQgBAAgBABQgKAGgPACQAAAAAAABQACAAACABIABAAQAFAAAEABQABAAABAAQADABAEACQAEACAEADQACACACACQAEAEADAHQAAABAAABQACAEAAAGQAAAGAAAHQgCANgIALQgHAMgOAIQgQAKgTAEQgEABgEAAQgKACgMAAQgGAAgGgBQgJgBgJgDQgIgCgHgDQgBgBgCgBQgCgBgCgBQgJgFgGgHQgBgBAAgBQgGgIgBgIQAAgBAAAAIAAAA").cp();
	this.shape_422.setTransform(547.4,335.9);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#11532E").s().p("AhbBGQAAgJAEgFQADgEAEgCQADgCAEAAQAHAAAFACQADABABABQAGAEABAGQAAACgBACQAAAIgBAIQAAACAAACQACACADACQAEACAEACQACABADABQADABADABQAAAAABAAQAEABAHABQADAAADAAQAFgBAEAAQAEgBAGgDQAFgBAFgDQAEgCADgEQADgDACgDQABgBABgCQADgEADgFQADgFABgIQACgGABgIQAAgFAAgHQAAgDgBgDQgBgJgEgGQgCgCgBgCQgEgDgFgCQgDgBgDgBQgHgCgHAAQgEAAgEAAQgEgBgGAAQAAgBAAgCQABgIAAgIQADAAADAAQADAAAFAAQACAAACAAQAOgBAJgGQAEgDADgDQADgDACgEQADgDACgFQADgJACgNQAAgIgBgHQgBgJgFgGQgHgKgQgBQAAAAgBAAQgIAAgEACQgEACgEACQgBABgBAAQgBAFgFAEQACAGABAFQAAACAAABQABAEABADQAAAEAAAFQAAACAAABQAAAFgDAEQgFAFgJABQgDAAgCAAQgEgBgCgDQgCgDgCgEQAAgCAAgEQAAgBAAgCQAAgCAAgBQABgCAAgBQABgDACgEQABgBACgCQACgEAEgDQADgCACgCQAEgDAFgCQABAAABgBQADgCAGgCQADgBACAAQAIgBAIAAQAEAAAEAAQAGAAAGABQAKACAHAEQACABABABQAGADAFAEQADADACADQACAEACADQADAFABAGQAAABAAAAQACAIgBAGQAAACAAABQgBAHgDAHQgBAEgCAEQgCAEgDADQgGAHgJAFQgBABgBAAQgLAHgPADQgBABAAABQADAAACAAIABAAQAFAAAFAAQABABABAAQAEABADACQAFACAFAEQACABACADQAEAEADAIQABABAAABQABAEABAGQABAHgBAHQgCAOgHAMQgIAMgPAKQgPAKgUAEQgEABgFABQgKACgNAAQgGgBgGAAQgKgBgJgDQgJgDgGgDQgCgBgBgBQgDgBgCgBQgJgFgGgIQgBgBgBgBQgGgIAAgJQAAgBAAAAIAAAA").cp();
	this.shape_423.setTransform(547.5,336);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#11532E").s().p("AhdBJQABgJAEgGQADgEAEgCQADgCAEAAQAIAAAFACQACABACACQAGAEABAHQAAABgBACQgBAJgBAIQAAADAAACQACACADACQAEACAFADQACAAADABQADABADABQAAAAABAAQAFACAHAAQADAAADAAQAFAAAEgBQAFgBAGgCQAGgCAEgDQAEgCADgEQADgDADgDQABgCABgBQADgFADgFQADgFABgIQACgHAAgIQABgGgBgHQAAgDgBgDQAAgJgGgHQgBgCgCgCQgDgEgGgBQgEgCgDgBQgHgBgIgBQgEAAgDAAQgGAAgGAAQAAgCAAgBQAAgJABgIQADAAADAAQAFAAADAAQACAAADAAQAOgBAJgGQAFgEADgDQADgDACgEQADgEACgFQADgKABgNQABgJgBgHQgCgKgFgGQgIgLgRAAQAAAAgBAAQgIgBgFADQgFACgCACQgBABgBAAQgEAFgEAEQABAGABAGQABACAAABQABAEAAADQABAFABAEQAAACAAACQgBAFgEAEQgFAFgKABQgDAAgCgBQgFgBgCgDQgCgDgCgEQAAgDAAgEQAAgBAAgCQAAgCAAgBQABgCAAgBQABgDACgFQABgCACgCQADgDAEgEQACgCADgCQAEgDAGgDQABAAAAAAQAFgDAFgCQADgBADgBQAIgBAJAAQAEAAAEAAQAHAAAGABQALACAIAFQABAAACABQAHADAEAFQAEADACADQACAEACADQAEAGABAGQAAABAAAAQACAJgBAGQAAACAAABQAAAIgDAGQgCAFgCAEQgCAEgDAEQgGAHgKAGQgBAAgBABQgLAHgQADQAAABAAABQADABACAAIABABQAGAAAFABQABAAABAAQAEAAAEACQAFACAFAEQACACADADQAEAFAEAHQAAABABABQABAFABAHQABAGgBAIQgBAPgIAMQgIAOgPAKQgQALgUAFQgFABgFAAQgLACgNAAQgGAAgGAAQgLgCgJgDQgJgDgHgDQgCgBgBgBQgDgBgCgCQgJgFgGgIQgBgBgBgBQgGgJgBgJQAAgBAAAAIAAAA").cp();
	this.shape_424.setTransform(547.6,336.1);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#11532E").s().p("AheBNQABgJAEgGQADgFAEgCQADgCAEAAQAJAAAFADQACABACABQAHAFAAAHQAAACgBACQgBAJgBAJQAAACAAADQACACADACQAEACAFADQADABACAAQADACADABQABAAAAAAQAFABAIABQADAAADAAQAFgBADAAQAGgBAHgDQAGgBAEgEQAFgCADgEQADgDADgEQABgBABgCQADgFADgFQADgGABgIQACgHAAgJQABgGgBgHQAAgDgBgDQgBgKgGgHQgBgCgCgCQgEgFgHgBQgDgBgEgBQgHgCgJAAQgEAAgCAAQgHgBgHAAQAAgBAAgCQAAgJABgJQADAAADAAQAFAAADAAQADAAACAAQAPgBAKgGQAFgDADgEQADgDACgEQADgFACgFQADgKABgOQABgKgCgHQgCgKgFgHQgJgLgSgBQAAAAgBAAQgJAAgGACQgCADgFACQgBAAAAABQgFAFgFAEQABAHACAGQAAACAAABQABAEABADQABAFABAFQAAACgBABQgBAFgEAFQgFAFgLABQgDAAgDgBQgFgBgCgEQgCgDgCgEQAAgDAAgEQAAgCAAgCQAAgCABgCQAAgBAAgCQACgDACgEQABgDABgCQAEgEAEgEQACgCADgCQAEgDAGgDQABgBABAAQAFgDAHgCQAEgBABgBQAIgBAJgBQAFAAAFAAQAHABAHABQALACAJAEQABABACABQAHADAFAFQAEADACADQADAEACAEQAEAGABAGQAAABAAABQACAIAAAHQAAACAAABQAAAIgEAHQgBAFgDAFQgCAEgCADQgHAIgKAGQgBABgBAAQgLAIgRADQAAABAAACQADAAACABIACAAQAGABAFABQABAAABAAQAFABAEABQAGACAFAEQACADADACQAFAGAEAIQAAABAAABQACAFABAHQABAHAAAIQgCAQgHANQgIAPgQAKQgRAMgVAFQgEABgGABQgMACgMAAQgHAAgHgBQgKgBgKgDQgJgDgHgEQgCgBgBgBQgDgBgDgCQgJgFgHgJQAAgBgBgBQgGgJgBgKQAAAAAAgBIAAAA").cp();
	this.shape_425.setTransform(547.6,336);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#11532E").s().p("AhgBSQAAgKAEgHQAEgEAEgCQADgCAFAAQAIAAAGADQACABACABQAHAFAAAIQAAACgBACQgBAJgBAKQAAACgBADQADACADACQAEADAFACQADABADABQADABADACQAAAAABAAQAFABAIABQADAAAEAAQAFAAADgBQAGgBAHgDQAGgCAFgDQAEgDAEgEQADgDADgEQABgBABgCQADgFADgGQADgFABgJQACgIAAgJQABgGgBgHQAAgEgBgDQgCgKgGgIQgBgCgCgCQgFgEgHgEQgDAAgEAAQgIgCgJAAQgFAAgCAAQgIgBgHAAQAAgBAAgCQAAgJAAgKQAEAAADAAQAGAAAEAAQABAAADAAQAQAAAKgHQAFgEADgEQADgDACgEQADgFACgFQAEgLAAgPQABgKgCgIQgDgKgFgIQgKgLgSAAQgBAAgBAAQgKgBgEADQgEACgGACQAAABgBAAQgFAFgFAFQABAHABAGQABACAAACQABADAAADQABAGABAFQAAACAAABQgBAGgFAEQgGAGgLAAQgDAAgDAAQgFgCgDgEQgCgDgBgFQgBgDAAgEQAAgCAAgDQAAgCABgBQAAgCABgBQABgEACgFQABgCACgDQADgEAFgEQACgCADgDQAFgDAGgDQABgBABAAQAGgEAHgCQADgBAEgBQAHgBAJgBQAFAAAFAAQAIAAAHABQAMACAKAFQABABACABQAHADAGAFQAEADACAEQADAEADAEQAEAGABAHQAAAAABABQACAJgBAIQAAABAAACQAAAIgDAIQgCAFgCAFQgCAEgDADQgGAJgLAGQgBABgBAAQgMAIgRAEQAAABAAABQADABACABIACAAQAGABAGABQACAAABABQAEABAFAAQAGADAFAEQADADADADQAFAFAEAJQABABAAABQACAGABAHQABAHAAAJQgBARgIAOQgIAPgQALQgRAMgWAGQgFABgFABQgNACgNAAQgHAAgHgBQgKgBgLgDQgJgDgIgEQgBgBgCgBQgDgCgCgBQgKgGgHgJQgBgBAAgCQgHgJAAgKQAAgBAAAAIAAAA").cp();
	this.shape_426.setTransform(547.8,336);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#11532E").s().p("AhjBWQABgKAEgHQADgEAEgCQAEgCAFAAQAIAAAGADQADABACACQAGAFABAIQgBACAAACQgBAKgCAKQAAADgBACQADACADADQAEADAFACQADABADABQAEABADACQAAAAABAAQAFABAIABQADAAAEAAQAGAAADgBQAGgBAHgDQAHgCAFgDQAEgDAEgEQADgEADgEQABgBABgCQAEgFADgGQACgGACgKQABgHAAgJQABgHgBgIQAAgDgBgEQgCgLgGgHQgCgCgCgDQgFgEgHgDQgEgCgEgBQgIAAgKAAQgDAAgFAAQgIAAgIgBQAAgBAAgCQABgKAAgJQADgBAEAAQAFAAAGAAQACAAABAAQAQAAALgHQAFgEADgEQADgEADgEQADgFABgGQAEgLABgPQAAgLgCgJQgDgKgGgIQgKgMgUAAQgBAAgBAAQgIgBgGADQgFADgGACQgBAAgBABQgFAFgGAFQACAHABAHQABABAAACQABAEAAADQABAFABAGQAAACAAACQgBAFgFAFQgGAGgMAAQgEAAgDgBQgFgCgDgEQgDgEgBgEQgBgEAAgFQAAgCABgCQAAgCAAgCQABgBAAgCQABgEADgFQABgDACgCQADgFAFgEQADgDACgCQAGgEAGgDQABgBABAAQAGgEAIgCQADgCAEAAQAJgCAJgBQAFAAAFAAQAJAAAHABQANACAKAFQACABABABQAIADAGAFQAEAEADAEQADAEADAEQAEAGABAHQABABAAABQADAKgBAHQAAACAAACQAAAIgDAIQgCAGgCAEQgCAFgDAEQgHAJgLAGQgBABgBAAQgMAIgSAFQAAABAAABQADABADABIACAAQAHABAGABQABABABAAQAFACAFAAQAHADAFAEQADADADADQAGAGAFAJQAAABAAABQADAGABAIQABAIAAAJQgBASgIAOQgIAQgRAMQgSANgWAFQgFACgFABQgOACgNAAQgHAAgHgBQgLgBgLgDQgKgEgIgEQgBAAgCgBQgDgCgDgCQgJgGgHgJQgBgCgBgBQgHgKAAgLQAAAAAAgBIAAAA").cp();
	this.shape_427.setTransform(548,335.9);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#11532E").s().p("AhmBbQABgLAEgHQADgEAFgDQAEgBAEAAQAKAAAFADQADABACACQAHAFAAAIQAAADgBACQgBAKgCALQAAADgBACQADADADACQAFADAFADQADABADABQADABAEACQAAAAABAAQAFABAJABQADAAAEAAQAFAAAEgBQAHgBAHgDQAGgCAFgDQAFgEAEgEQADgEADgEQABgBABgCQAEgFADgHQADgGABgKQACgIAAgJQAAgHgBgIQAAgEgBgEQgCgLgHgIQgCgCgCgCQgFgFgIgDQgEgCgEgBQgJgCgKAAQgDAAgFAAQgJAAgIAAQAAAAAAgCQAAgKAAgKQAEAAADAAQAGAAAGAAQACAAADAAQAPgBALgHQAFgEADgFQAEgDACgFQADgFACgGQAEgMAAgQQAAgLgCgJQgDgLgHgIQgLgNgUAAQgBAAgCAAQgIgBgHADQgFADgGACQgBABgBAAQgGAGgGAFQACAHABAHQABACAAACQABADAAAEQABAFABAGQAAACAAACQgCAFgFAFQgGAGgNAAQgDAAgDgBQgGgBgDgFQgDgEgBgFQgBgEAAgFQAAgCAAgDQAAgCABgBQAAgCABgCQABgEACgFQACgDACgDQADgFAFgFQADgCADgDQAFgEAHgDQABgBABAAQAHgEAIgDQADgBAEgBQAKgCAJgBQAFAAAGAAQAJAAAIABQAOACAKAFQACABACABQAIAEAHAFQAEADADAFQADAEADAEQAEAGACAIQAAABABABQACAKAAAIQAAABAAACQAAAJgDAIQgCAGgCAFQgDAFgCAEQgHAJgMAHQAAABgCAAQgMAJgTAEQAAACAAABQAEABADABIACAAQAHABAGABQACABABAAQAFACAFABQAHACAGAFQADADADADQAGAHAGAJQAAABABACQACAGABAIQACAIAAAJQgBATgIAPQgIARgRAMQgTAOgXAGQgFACgGABQgOACgNAAQgIAAgHAAQgLgCgLgDQgLgEgIgEQgBgBgCgBQgDgCgDgBQgKgHgHgJQgBgCgBgCQgHgJAAgMQAAAAAAgBIAAAA").cp();
	this.shape_428.setTransform(548.2,335.8);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#11532E").s().p("AhpBgQABgLAEgIQAEgEAEgDQAEgCAFAAQAKABAGADQADABACACQAHAGAAAIQgBADAAACQgCALgCALQAAADgBADQADACADADQAFADAFADQADABAEABQADABAEACQAAAAABAAQAFABAJABQADAAAEAAQAGAAAEgBQAHgBAHgDQAHgCAFgEQAFgDAEgEQADgEAEgFQABgBABgCQAEgGADgGQACgHACgKQABgIAAgKQABgHgCgJQAAgDgBgEQgCgMgHgIQgCgCgDgDQgFgFgIgDQgFgCgEgBQgJgCgKAAQgFAAgFAAQgJAAgJAAQAAgCAAAAQAAgLAAgKQAEAAAEAAQAGAAAGAAQACAAADAAQAQgBALgHQAFgEAEgFQADgEADgFQADgFABgGQAEgNAAgQQAAgMgCgKQgDgLgHgJQgMgNgWAAQgBAAAAAAQgLgBgHADQgFADgHADQgBAAgBABQgGAFgGAGQACAHABAHQABACAAACQABAEAAADQABAGABAGQAAACAAACQgCAGgFAFQgHAGgNAAQgEAAgDgBQgGgCgEgFQgDgEgBgFQgBgFAAgFQAAgCABgDQAAgCAAgCQABgCAAgCQACgEACgGQACgDACgCQADgGAGgFQADgDACgCQAGgFAHgDQABgBABAAQAHgFAJgCQADgCAEgBQALgCALgBQAEAAAGAAQAKAAAIABQAOACALAFQACABACABQAJAEAHAFQAEAEADAEQAEAFADAEQAFAHABAHQABABAAABQADALAAAIQAAACAAACQAAAJgDAJQgCAGgCAFQgDAFgDAEQgHAKgLAHQgBABgCAAQgMAJgTAFQAAACAAABQADABADABIACAAQAIABAHACQABAAACABQAFACAGABQAHACAGAFQADADAEAEQAGAGAGAKQAAABABACQADAGABAJQACAIAAAKQgBAUgIAQQgIARgSANQgTAPgYAGQgFACgGABQgOACgOAAQgIAAgHAAQgMgCgMgDQgKgEgJgEQgBgBgCgBQgDgCgDgCQgKgHgIgKQgBgBgBgCQgHgKAAgMQAAgBAAAAIAAAA").cp();
	this.shape_429.setTransform(548.4,335.8);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#11532E").s().p("AADikQgXAAgTAGQgSAHgNAKQgNAMgGALQgGANgBALQAAAMAGAIQAFAIAMABQAOAAAHgHQAIgGAAgJIgHgmIAPgNIAMgFQAIgDAMAAQAXAAANAOQANAPAAAcQAAAigOASQgOASgdgBIgUAAIAAAYIAeAAQAQAAANAFQANAGAGAIQAHAIACAMQAEANgBALQAAAYgFAMQgHAPgJAKQgJAKgNAEQgMAGgMgBQgOAAgJgCIgPgFIgKgHQgDgCgDgDIAGgiQAAgJgHgGQgHgGgOgBQgLAAgHAKQgEAHgBAMQAAANAHALQAIANAMAIQAMAIASAGQASAGAVAAQAyAAAjgcQAkgagBgrQAAgWgHgPQgJgPgLgJQgLgIgPgEIgbgGIAAgDQATgFANgJQAOgIAIgLQAGgKAEgMQAEgLgBgLQAAgJgEgNQgEgMgKgMQgKgMgTgIQgSgJgbABIAAAA").cp();
	this.shape_430.setTransform(548.7,335.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_405}]}).to({state:[{t:this.shape_406}]},34).to({state:[{t:this.shape_407}]},1).to({state:[{t:this.shape_408}]},1).to({state:[{t:this.shape_409}]},1).to({state:[{t:this.shape_410}]},1).to({state:[{t:this.shape_411}]},1).to({state:[{t:this.shape_412}]},1).to({state:[{t:this.shape_413}]},1).to({state:[{t:this.shape_414}]},1).to({state:[{t:this.shape_415}]},1).to({state:[{t:this.shape_416}]},1).to({state:[{t:this.shape_417}]},1).to({state:[{t:this.shape_418}]},1).to({state:[{t:this.shape_419}]},1).to({state:[{t:this.shape_420}]},1).to({state:[{t:this.shape_421}]},1).to({state:[{t:this.shape_422}]},1).to({state:[{t:this.shape_423}]},1).to({state:[{t:this.shape_424}]},1).to({state:[{t:this.shape_425}]},1).to({state:[{t:this.shape_426}]},1).to({state:[{t:this.shape_427}]},1).to({state:[{t:this.shape_428}]},1).to({state:[{t:this.shape_429}]},1).to({state:[{t:this.shape_430}]},1).wait(14));

	// greater than
	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#39904C").s().p("AAZgoQgbgCgrAOQgkAMgMAJIAOgBQAPAAAIADQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLQgUgQgdgCIAAAA").cp();
	this.shape_431.setTransform(596,305.1);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#39904C").s().p("AA/AnQgPAAgRgLQgCgBgCgCQgDgCgDgCQgUgNgHgGQgUgJgUgIQgJgDgQgBIgPgBQAEgCAIgCQAPgEAYgEQAdgGAWAAQAJAAAIACQAVAEAOARQADAEACAEQAGAHACAHQABAAABAAQAFAKgCAIQgDANgUABIAAAA").cp();
	this.shape_432.setTransform(595,305.1);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#39904C").s().p("AhTgZQAEgCAIgBQABAAABgBQAPgDAXgDQAZgDATAAQAEAAAEABQAIAAAGACQATAFALARQADAEACAEQACADABACQADAEABAFQABABABAAQAAABABABQAFAIgBAHQgDALgRABQgNgBgPgLQgCgBgCgCQgCgDgDgCQgEgDgDgDQgEgDgEgCQgIgFgEgDQgUgLgVgIQgKgEgRgBIgPgBIAAAA").cp();
	this.shape_433.setTransform(594.6,305.1);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#39904C").s().p("AhQgfQAEAAAHgBQABAAABAAQAQgCAYgCQAagDAUACQAEAAADABQAHAAAFADQAQAFAJARQADAFABAEQABACABABQADAGABAGQABAAABAAQAAABAAACQAGAHAAAGQgBAKgPAAQgLgCgNgLQgCgBgCgCQgCgDgCgCQgDgDgDgDQgEgEgDgCQgJgGgFgBQgUgNgWgIQgLgFgRgCIgQgCIAAAA").cp();
	this.shape_434.setTransform(594.1,305.1);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#39904C").s().p("AhNgkQAEAAAHAAQAAAAABAAQASgBAYgBQAZgBAXACQADABADABQAFABAEACQAOAHAHARQACAEAAAEQABABABADQADAGABAGQABAAAAABQABABAAABQAGAGABAGQAAAJgNgBQgJgCgLgMQgBgBgCgCQgBgCgCgDQgCgDgDgDQgDgEgEgDQgIgEgGgDQgWgNgWgKQgMgFgRgCIgRgCIAAgB").cp();
	this.shape_435.setTransform(593.7,305);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#39904C").s().p("AhKgoQADABAHAAQABABABAAQASgBAYAAQAaAAAZAEQACABACABQAFABADADQALAHAEASQABAEABADQABACAAADQACAGACAGQABABAAAAQAAACABABQAHAFABAFQACAIgMgCQgGgCgJgNQgBgBgBgCQgCgCgBgCQgCgEgBgDQgEgFgDgDQgJgEgHgEQgWgNgYgKQgMgFgSgEIgRgDIAAAA").cp();
	this.shape_436.setTransform(593.3,304.9);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#39904C").s().p("AhIgqQAEABAGABQABAAABAAQATABAZABQAbABAaAFQABABACABQADACACADQAIAIACARQABADAAAFQABACAAADQACAGABAHQABAAAAABQABABAAABQAIAFACAEQADAHgJgCQgFgEgHgMQAAgBgCgCQAAgDgCgCQgBgEgBgDQgDgFgDgEQgJgEgHgDQgZgOgXgLQgNgGgTgEIgRgDIgBAA").cp();
	this.shape_437.setTransform(593,304.6);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#39904C").s().p("AhFgtQADACAGABQABABAAAAQAVACAZACQAcACAbAGQABABABABQACADABADQAGAJgBAQQABAEgBAFQAAACAAADQACAGACAIQAAAAABABQAAABAAABQAIAEADADQAFAGgHgDQgDgEgFgNQAAgBgBgCQAAgCgBgDQgBgDAAgEQgDgFgDgFQgJgDgIgFQgagOgYgMQgNgGgTgEIgTgEIAAAA").cp();
	this.shape_438.setTransform(592.6,304.4);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#39904C").s().p("AhDgwQADACAFADQABAAABAAQAVADAbADQAcAEAdAGQAAACAAABQABADAAAEQADAKgDAQQAAAEgBAFQAAACAAADQACAHABAHQAAABABABQAAABAAABQAJADAEADQAGAEgFgDQgBgFgDgNQAAgBAAgCQgBgDAAgCQAAgEABgEQgEgGgCgFQgKgDgIgFQgbgPgZgMQgOgGgUgFIgTgFIAAAA").cp();
	this.shape_439.setTransform(592.3,304.1);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#39904C").s().p("AhCgzQADADAFADQABABAAAAQAXAEAbADQAeAFAdAIQAAACgBABQAAAEgBAEQAAAKgFARQgBAEgBAEQgBADAAACQACAIABAHQAAABABABQAAABAAABQAJADAFACQAIADgEgEQABgGAAgNQAAgBAAgCQAAgDAAgCQABgEABgEQgDgGgCgGQgKgDgIgFQgdgPgagNQgPgHgUgGIgUgFIAAAA").cp();
	this.shape_440.setTransform(592,303.9);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#39904C").s().p("AhEg2QACADAFAEQABABABAAQAXAFAcAFQAeAGAfAJQgBABgBACQgBAEgDAFQgCAJgIASQgBAFgCAEQAAADgBACQACAIABAIQAAAAAAABQABACAAABQAKACAFABQAJACgBgFQADgGACgOQAAgBAAgCQABgDAAgCQABgEACgEQgDgHgCgGQgKgEgJgEQgdgQgbgOQgQgHgUgGIgVgGIAAAA").cp();
	this.shape_441.setTransform(592.1,303.7);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#39904C").s().p("AhGg6QACAFAFAEQAAABABAAQAYAGAcAGQAgAHAgAKQgCACgBACQgDAEgDAFQgFAKgKATQgCAEgCAFQgBACgBADQABAIABAIQABABAAABQABABAAABQAKABAGABQALABAAgGQAFgHAEgOQABgBAAgCQABgDABgCQACgFACgEQgCgHgCgGQgLgEgJgFQgegQgdgOQgQgIgVgHIgVgGIAAgB").cp();
	this.shape_442.setTransform(592.2,303.5);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#39904C").s().p("AhIg9QACAFAEAFQABABAAAAQAZAHAdAHQAhAIAhALQgCACgDADQgDAEgFAGQgIAKgMATQgCAEgDAFQgBACgBADQABAIABAJQABABAAABQAAABABABQAKAAAHAAQAMAAADgGQAHgIAGgOQABgCAAgCQACgCAAgDQADgEADgEQgCgIgCgGQgLgEgJgGQgggRgdgOQgRgJgVgHIgWgHIAAAA").cp();
	this.shape_443.setTransform(592.3,303.3);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#3A904C").s().p("AhLhBQADAFAEAGQAAABABAAQAaAIAdAIQAiAJAiANQgDACgDADQgFAFgFAFQgLALgOAUQgDAEgDAFQgBACgCADQABAIABAJQAAABABABQAAABAAABQAMAAAHgBQAOgBAEgHQAKgJAIgOQABgBABgCQABgDABgDQAEgEAEgFQgDgHgBgIQgLgEgKgFQghgRgegQQgSgJgVgHIgXgIIgBAA").cp();
	this.shape_444.setTransform(592.4,303.2);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#3A904C").s().p("AhNhGQACAHAEAGQAAABABAAQAbAJAeAJQAjALAjANQgEADgDACQgGAGgHAEQgNAOgRATQgDAFgDAEQgBADgBACQABAJAAAJQAAABAAABQAAACAAABQAMgBAJgCQAOgDAHgHQALgJAKgPQACgCABgCQABgCACgDQAEgEAFgFQgCgIgCgIQgLgEgKgFQgigSgggRQgSgJgWgIIgXgIIgBgB").cp();
	this.shape_445.setTransform(592.5,303.1);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#3A904C").s().p("AhPhKQACAHADAHQABABAAABQAcAJAfAKQAkAMAkAOQgEADgEADQgIAGgIAEQgPAPgTAUQgCAEgEAFQgCACgCADQABAJABAJQAAABAAACQAAABABABQAKgCAKgCQAPgEAJgIQAOgKAMgPQABgCACgCQACgCACgDQAFgFAFgEQgCgJgCgHQgLgFgKgGQgjgSghgRQgTgKgWgJIgYgJIgBAA").cp();
	this.shape_446.setTransform(592.6,303);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#3A904C").s().p("AhRhOQACAHADAIQAAABAAABQAdAKAgALQAlANAlAQQgFADgEADQgJAFgJAGQgSAPgUAUQgEAFgEAEQgDADgCACQABAKAAAJQABABAAACQAAABAAABQANgCAJgDQARgFALgJQAPgLAPgPQABgCACgCQACgCADgDQAFgFAGgFQgCgJgBgGQgMgHgKgFQgkgUgigRQgUgKgXgJIgYgKIgBAA").cp();
	this.shape_447.setTransform(592.7,302.8);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#3A904C").s().p("AhThTQABAJADAIQAAABABABQAdALAhAMQAlAPAnAQQgGADgFAEQgJAEgLAHQgUARgWAUQgFAEgFAFQgCACgDADQABAJAAAKQABACAAABQAAABAAACQAOgEALgEQAQgFANgKQASgMAQgPQACgCACgCQADgCADgDQAGgFAGgFQgBgJgCgHQgMgHgLgGQglgUgigSQgVgKgXgKIgZgKIgBgB").cp();
	this.shape_448.setTransform(592.8,302.7);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#3A904C").s().p("AhVhXQABAJACAJQABABAAABQAfANAhAMQAmAQAoARQgGAEgGADQgLAGgLAHQgYARgYAUQgFAFgFAEQgDADgDACQABAKAAAKQAAACAAABQABACAAABQAOgEAMgFQASgHAPgKQATgMATgQQACgCACgCQADgDADgCQAHgFAHgFQgBgKgBgIQgMgGgMgGQgmgVgkgSQgVgLgYgKIgagLIAAgB").cp();
	this.shape_449.setTransform(592.9,302.6);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#3A904C").s().p("AhXhbQABAJACAKQAAABAAABQAgAOAhANQAoARAoATQgGADgGAEQgMAGgNAIQgYARgcAVQgGAEgGAFQgDACgDADQAAAKABAKQAAACAAACQAAABAAABQAPgFANgFQATgIARgLQAWgNAUgQQADgCACgCQAEgDADgCQAIgGAHgFQgBgKgBgIQgMgHgMgGQgngVglgTQgWgLgYgLIgbgMIAAAA").cp();
	this.shape_450.setTransform(593,302.5);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#3A904C").s().p("AhahgQABALACAKQAAABAAABQAhAPAiAOQApATApATQgHAEgHACQgNAIgNAIQgbASgfAVQgGAFgGAEQgEADgDACQAAALABAKQAAACAAACQAAABAAACQAPgGAOgGQAXgJARgMQAXgOAXgQQADgCADgCQADgDAEgCQAIgGAJgFQgBgLgBgIQgNgHgMgHQgogVgmgUQgXgLgZgMIgbgMIgBgB").cp();
	this.shape_451.setTransform(593.1,302.4);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#3A904C").s().p("AhchkQABALABALQAAABABABQAhAQAjAQQAqATAqAUQgHAFgIACQgOAIgPAJQgdATghAVQgHAEgHAFQgDACgEADQAAALAAALQABABAAACQAAABAAACQAQgHAOgGQAYgLATgMQAagPAZgQQADgCADgCQAEgDAEgDQAJgFAJgFQgBgLgBgJQgNgHgMgHQgpgWgogUQgXgNgZgLIgcgNIgBgB").cp();
	this.shape_452.setTransform(593.2,302.3);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#3A904C").s().p("AhehoQABALABAMQAAABAAACQAjAQAjARQArAVArAVQgIADgIAEQgQAIgPAJQggAUgkAVQgHAFgHAEQgEADgEACQAAAMAAALQAAABAAACQABACAAABQAQgHAPgHQAagMAVgNQAbgPAbgRQAEgCADgCQAEgDAFgDQAJgFAKgGQgBgLAAgJQgNgIgNgGQgrgXgogVQgYgNgZgMIgdgNIgBgB").cp();
	this.shape_453.setTransform(593.2,302.2);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#3A904C").s().p("AhghsQAAAMABAMQAAABAAACQAkARAkASQAsAWAsAWQgIADgJAEQgRAKgRAJQgiAUgmAWQgIAEgHAFQgFACgEADQAAALAAAMQAAACAAACQAAABAAABQARgIARgIQAagMAXgOQAegQAdgRQADgCAEgCQAFgDAFgDQAKgGAKgFQAAgMgBgKQgNgHgNgHQgsgWgpgXQgZgNgagNIgdgNIgBgB").cp();
	this.shape_454.setTransform(593.3,302.1);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#3A904C").s().p("AhihxQAAANAAANQAAABAAACQAlASAlATQAsAXAuAYQgJACgKAFQgRAKgSAJQgmAWgoAVQgIAFgIAEQgFADgEACQAAAMAAAMQAAACAAACQAAABAAACQARgJASgJQAcgOAbgOQAdgRAggRQADgCAEgCQAFgDAFgDQALgGALgGQAAgMAAgKQgOgHgOgHQgsgYgqgWQgagOgagNIgegPIgBgB").cp();
	this.shape_455.setTransform(593.4,302);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#3A904C").s().p("AhkhXICnBXIinBXIAAAfIDJhqIAAgXIjJhqIAAAe").cp();
	this.shape_456.setTransform(593.5,301.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_431}]}).to({state:[{t:this.shape_432}]},35).to({state:[{t:this.shape_433}]},1).to({state:[{t:this.shape_434}]},1).to({state:[{t:this.shape_435}]},1).to({state:[{t:this.shape_436}]},1).to({state:[{t:this.shape_437}]},1).to({state:[{t:this.shape_438}]},1).to({state:[{t:this.shape_439}]},1).to({state:[{t:this.shape_440}]},1).to({state:[{t:this.shape_441}]},1).to({state:[{t:this.shape_442}]},1).to({state:[{t:this.shape_443}]},1).to({state:[{t:this.shape_444}]},1).to({state:[{t:this.shape_445}]},1).to({state:[{t:this.shape_446}]},1).to({state:[{t:this.shape_447}]},1).to({state:[{t:this.shape_448}]},1).to({state:[{t:this.shape_449}]},1).to({state:[{t:this.shape_450}]},1).to({state:[{t:this.shape_451}]},1).to({state:[{t:this.shape_452}]},1).to({state:[{t:this.shape_453}]},1).to({state:[{t:this.shape_454}]},1).to({state:[{t:this.shape_455}]},1).to({state:[{t:this.shape_456}]},1).wait(13));

	// less than
	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#71BF56").s().p("AhJgWQAUgQAcgCQAbgCArAOQAkAMAMAJQgXgDgOAFQgSAFgSAKQgSANgMAHQgZANgXgDQgZgDgHgPQgFgLAEgLQAEgKAOgMIAAAA").cp();
	this.shape_457.setTransform(338,166.1);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#71BF56").s().p("ABUgFQgRgBgIAGQgOAFgNAMQgFAFgEAFQgHAGgFAEQgDABgDABQgZAKgagFQgagFgJgQQgDgFgBgFQgBgHACgGQAGgKAQgMQAWgRAegEQALgCAPABQAHACAGADQALAEAMAGQAcANAHALQgBAAgCAAIAAAA").cp();
	this.shape_458.setTransform(337.5,166.3);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#71BF56").s().p("AhSAMQAAgHACgFQAIgLAQgNQAYgRAggFQAAAAAAAAQAFgBAHABQAFAAAGABQAGACAFADQAJAFAKAHQAOAIAHAIQAGAEADAEQgBAAgBABQgOAAgHAEQgLAHgKANQgEAEgDAEQgBABAAABQgEAFgFADQgBACgCABQgDABgDAAQgbAIgbgGQgZgGgMgOQAAgBgBgBQgCgFgBgFIAAgB").cp();
	this.shape_459.setTransform(337.4,166.5);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#71BF56").s().p("AhPALQABgGADgFQAJgMARgNQAagSAggGQAAAAABAAQAFAAAHABQAEABAEABQAFADAEADQAHAFAIAIQALAIAFAIQAHAFADAEQgBABgBAAQgMABgEAEQgJAIgIANQgCAEgCAFQgBABgBABQgEAFgEAEQgBABgCABQgEABgDAAQgcAGgcgIQgagGgOgPQAAgBgBgBQgCgFgBgGIAAgB").cp();
	this.shape_460.setTransform(337.2,166.6);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#71BF56").s().p("AhMALQACgHADgEQALgNASgNQAcgSAhgIQAAgBABAAQAFACAGACQADABAEACQADACADAEQAEAGAGAHQAJAKADAIQAHAFAEAEQgBAAgBAAQgJABgDAHQgFAIgGANQgCAFgBAEQgBABAAACQgEAFgEAFQgCAAgCABQgDAAgEABQgdADgegIQgbgHgPgQQAAgBgBgBQgCgFgBgGIAAgB").cp();
	this.shape_461.setTransform(337,166.7);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#71BF56").s().p("AhJAKQADgGAEgFQAMgNATgNQAegTAigKQABAAAAAAQAFACAGADQACACACACQACADACADQACAHAEAIQAHAKAAAJQAHAFAFACQgBAAAAABQgHACgBAIQgDAJgDANQgBAFgBAEQAAACgBABQgDAGgEAFQgCAAgCABQgEAAgEAAQggABgdgJQgcgIgRgQQAAgBgBgBQgCgGgBgGIAAgB").cp();
	this.shape_462.setTransform(336.8,166.8);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#71BF56").s().p("AhGAJQAEgHAEgEQAOgOAUgNQAegUAlgLQABAAABAAQAEADAFAEQABACABACQABADABAEQABAHABAJQAEAKgCAJQAHAGAGACQgBAAAAABQgFADACAIQgBAKgBANQAAAFABAFQgBABAAABQgEAHgDAFQgCABgCAAQgFAAgEgBQgiAAgegLQgdgJgSgPQAAgCgBgBQgCgGgBgHIAAAA").cp();
	this.shape_463.setTransform(336.6,167);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#71BF56").s().p("AhGAHQAEgGAFgFQAPgOAWgNQAfgVAngMQABAAAAAAQAFAEAEAEQAAADAAADQAAADAAAEQgCAIgBAJQACAKgFAKQAIAFAGADQAAABAAAAQgDAEAEAJQACAKACANQAAAFACAFQgBACAAABQgDAHgDAGQgDAAgCAAQgFAAgEgBQgjgCgggMQgegKgTgQQgBgCAAgBQgCgGgBgHIAAgB").cp();
	this.shape_464.setTransform(336.8,167.2);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#71BF56").s().p("AhIAGQAEgGAGgFQARgOAWgOQAhgWApgNQAAAAABgBQAEAFAEAGQgBADgCADQgBAEgBAEQgEAIgDAJQgBALgHALQAJAFAGADQAAABAAAAQAAAFAGAJQAEALAFANQABAFACAFQAAACgBACQgCAHgDAHQgDAAgCAAQgFgBgFgBQgkgFghgNQgfgLgVgQQgBgBAAgCQgCgHAAgHIAAAA").cp();
	this.shape_465.setTransform(337.1,167.4);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#71BF56").s().p("AhLAEQAFgFAHgGQASgOAXgPQAjgVAqgQQABAAAAAAQAEAGAEAGQgDAEgCADQgCAEgCAFQgGAIgGAKQgEAMgIALQAIAEAHAEQAAAAAAABQADAGAIAJQAHALAHAOQACAGADAEQgBACAAACQgCAIgDAHQgDAAgDgBQgFgBgFgBQglgGgjgPQgfgLgXgRQAAgCgBgBQgBgHgBgIIAAAA").cp();
	this.shape_466.setTransform(337.5,167.6);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#71BF56").s().p("AhOACQAGgEAHgHQAUgOAYgPQAlgWAsgRQAAAAABAAQADAGAEAIQgEADgEAEQgDAFgDAEQgIAJgIALQgGAMgLALQAJAEAHAFQAAAAABABQAFAHAJAJQAKAMAJAOQAEAGADAFQAAACAAABQgDAJgCAHQgDAAgDgBQgFgBgGgCQgmgIgkgPQgggNgZgRQAAgCgBgBQgBgIgBgHIAAgB").cp();
	this.shape_467.setTransform(337.9,167.9);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#71BF56").s().p("AhQAAQAHgEAHgHQAVgOAagPQAngXAsgSQABAAABgBQACAIAEAIQgGAEgFAFQgEAEgEAFQgKAKgJAKQgKANgNAMQAJADAIAGQABAAAAABQAIAHALALQAMAMAMAOQAFAGAEAFQAAACgBACQgCAIgCAJQgDgBgDgBQgGgBgFgCQgogKgmgRQgggOgbgRQAAgCAAgBQgCgIAAgIIAAgB").cp();
	this.shape_468.setTransform(338.3,168.1);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#71BF56").s().p("AhTAAQAIgGAIgGQAWgPAbgPQApgYAtgUQABAAABAAQADAIACAJQgGAFgGAFQgFAFgFAFQgNAKgLALQgMANgQAMQAKAEAIAGQABAAABABQAKAIANALQAPANAOAOQAFAGAGAFQgBACAAACQgCAJgBAJQgEgBgDgBQgGgCgGgCQgpgMgngSQgigOgcgSQAAgCAAgBQgBgJgBgHIAAAA").cp();
	this.shape_469.setTransform(338.7,168.3);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#71BF56").s().p("AhVgBQAIgHAJgGQAYgPAbgQQArgYAvgVQABAAABgBQACAKACAKQgHAFgIAFQgGAFgGAFQgPALgNALQgPAOgQANQAIAEAJAFQABABABABQANAJAPALQARANARAPQAGAGAGAFQAAACAAACQgCAKgBAJQgEgBgDgBQgHgCgGgDQgqgOgogTQgjgPgegSQAAgCAAgBQgBgJAAgHIAAAA").cp();
	this.shape_470.setTransform(339.1,168.5);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#71BF56").s().p("AhYgDQAJgGAJgHQAagPAcgQQAtgZAwgWQABgBABAAQACALACAKQgJAGgIAFQgIAFgHAGQgQALgQAMQgSAOgSANQALAEAHAGQABABABABQAPAKASALQAUAOATAPQAHAGAHAFQAAADgBACQgBAKgBAKQgEgCgDgBQgHgDgHgCQgrgQgqgUQgjgQgfgTQgBgCAAgCQgBgIAAgHIAAgB").cp();
	this.shape_471.setTransform(339.5,168.8);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#71BF56").s().p("AhagEQAJgHAKgGQAbgQAdgQQAvgaAygXQABgBABAAQABALACAMQgKAFgKAGQgIAGgIAGQgTALgSANQgSAOgWAOQAKAEAKAGQABABACABQAPAKAUAMQAWAPAWAPQAIAGAHAGQAAACAAACQgBALgBAKQgEgBgEgCQgGgDgHgDQgtgSgrgVQgkgRghgTQAAgCgBgCQAAgJAAgHIAAAA").cp();
	this.shape_472.setTransform(339.9,169);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#71BF56").s().p("AhdgGQAKgHALgGQAcgQAfgQQAwgbAzgZQABAAABgBQABANABAMQgLAGgLAHQgJAFgJAGQgVANgUAMQgVAPgYAPQALAEAKAGQACABABAAQASAMAWANQAYAPAZAPQAIAGAJAGQAAACAAADQgBALgBALQgEgCgEgCQgHgDgHgDQgugUgtgXQglgSgigTQAAgCAAgCQgBgJAAgIIAAAA").cp();
	this.shape_473.setTransform(340.3,169.2);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#71BF56").s().p("AhggIQALgGAMgHQAegQAfgRQAygbA1gaQABgBABAAQAAANABANQgMAHgMAHQgKAGgLAGQgXANgWANQgYAPgaAPQALAEALAHQACAAABABQAVANAYANQAbAPAbAQQAJAGAKAGQgBADAAACQAAAMgBALQgEgCgEgCQgHgEgIgDQgvgWgugYQgmgSgkgUQAAgCAAgCQAAgKgBgIIAAAA").cp();
	this.shape_474.setTransform(340.6,169.4);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#71BF56").s().p("AhigKQAMgGALgHQAggQAggRQA0gcA2gbQABgBABAAQABAOAAAOQgNAHgOAHQgLAGgMAHQgYANgYAOQgbAPgdAPQAMAFALAGQACABACABQAZAOAXANQAeAQAeAQQAKAGAKAGQAAADAAACQAAAMAAAMQgFgCgEgCQgIgEgHgEQgxgYgvgYQgngUgmgUQAAgCAAgCQAAgJAAgJIAAgB").cp();
	this.shape_475.setTransform(341,169.7);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#71BF56").s().p("AhCAAICohXIAAgeIjLBqIAAAXIDLBqIAAgfIiohX").cp();
	this.shape_476.setTransform(341.4,169.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_457}]}).to({state:[{t:this.shape_458}]},38).to({state:[{t:this.shape_459}]},1).to({state:[{t:this.shape_460}]},1).to({state:[{t:this.shape_461}]},1).to({state:[{t:this.shape_462}]},1).to({state:[{t:this.shape_463}]},1).to({state:[{t:this.shape_464}]},1).to({state:[{t:this.shape_465}]},1).to({state:[{t:this.shape_466}]},1).to({state:[{t:this.shape_467}]},1).to({state:[{t:this.shape_468}]},1).to({state:[{t:this.shape_469}]},1).to({state:[{t:this.shape_470}]},1).to({state:[{t:this.shape_471}]},1).to({state:[{t:this.shape_472}]},1).to({state:[{t:this.shape_473}]},1).to({state:[{t:this.shape_474}]},1).to({state:[{t:this.shape_475}]},1).to({state:[{t:this.shape_476}]},1).wait(16));

	// +
	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#71BF58").s().p("AgUAKQACABABABQAJAFATANQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLQgUgQgdgCQgTgBgXAGQgNADgPAEQgkAMgMAJIAOgBQAPAAAIADQASAFASAKIAAAA").cp();
	this.shape_477.setTransform(472,219.1);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#71BF58").s().p("AgpgZQANgHAMgGQAGgCAGgDQAGgBAHAAQAIABAIACQANAEAMAHQANAFALAGQALAHAGAHQACAFABACQABACAAACQAAAJgGAIQgHAMgSAEQgEABgEACQgSAGgTgEQgFgCgEgCQgCgBgDgBQgOgNgHgHQgBgBgCgCQgFgFgGgEQgNgFgNgCQgKgDgQAAIgMgBIAAAAQAPgIAigKQACgBACgBIAAAA").cp();
	this.shape_478.setTransform(471.3,218.7);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#71BF58").s().p("AhfgFQAQgIAjgJQACgBACgBQANgJALgGQAGgDAFgDQACAAABAAQAFgBAGgBQABAAAAAAQAHACAHADQANAFALAIQACACADABQALADAJAFQAMAHAHAGQACAFABADQABACAAACQAAAAAAAAQgBAJgGAHQgIALgTAEQAAAAgBAAQgDACgEACQgRAIgSgDQgCAAgCgBQgDAAgDgBQgCgCgCgBQgCgBgCgBQgKgMgHgIQgBgBgBgCQgGgFgFgFQgBgBgBAAQgMgEgOgCQgJgCgQAAQgBAAgBAAIgLgDIAAAA").cp();
	this.shape_479.setTransform(471,218.6);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#71BF58").s().p("AhggFQASgHAkgJQACgCABgBQANgJALgIQAFgEAFgDQABAAABgBQAFAAAIgBQAAAAAAAAQAHADAHADQAMAHAKAJQADABACACQALADALAFQAMAGAIAGQACAFABAEQABABAAADQAAAAAAAAQgCAIgHAHQgJAKgTAEQgBABAAAAQgDACgEACQgRAJgRAAQgCAAgBgBQgDgBgDAAQgCgCgDgBQgCgBgBAAQgLgNgFgKQgCgBgBgCQgFgGgFgFQgBgBgBAAQgNgEgOgDQgLgBgQAAQgBAAAAAAIgLgEIAAAA").cp();
	this.shape_480.setTransform(470.8,218.5);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#71BF58").s().p("AhhgFQAUgHAkgJQACgBACgCQALgKALgJQAFgEAFgEQABgBABAAQAFgBAIAAQAAAAAAAAQAHADAGAEQAMAIAKALQACABACACQAMADAMAEQANAGAIAGQADAFAAAEQABACAAACQAAAAAAAAQgCAIgIAHQgLAJgTAEQgBABAAAAQgDACgEADQgQAKgQACQgCAAgBAAQgDgBgDgBQgDgBgCgBQgCgBgCgBQgKgNgFgLQgCgBgBgCQgFgGgEgGQgBgBgBgBQgOgDgOgEQgMAAgQAAQgBAAgBAAIgKgFIAAAA").cp();
	this.shape_481.setTransform(470.5,218.4);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#71BF58").s().p("AhigFQAWgHAlgIQACgCABgCQALgLAKgLQAFgEAEgEQABgBABAAQAGgBAIgBQAAAAABAAQAGAFAGAEQALAKAJALQACACACABQANADAMAFQAOAFAKAGQACAFAAAEQABACAAACQAAAAAAAAQgDAIgJAHQgMAIgUAEQAAAAgBABQgDACgDADQgPAMgPAEQgCABgBAAQgDgBgEgBQgCgBgDgBQgCgBgBgBQgKgPgFgLQgBgCgCgCQgEgGgFgHQAAgBgBAAQgPgEgPgDQgMgBgRAAQgBAAgBAAIgJgFIAAAA").cp();
	this.shape_482.setTransform(470.2,218.3);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#71BF58").s().p("AhjgGQAXgGAmgIQACgCABgCQALgNAJgLQAEgFAFgFQABAAABgBQAGgBAIAAQABAAAAAAQAFAFAGAFQAKALAJAMQACACACACQAOADANAEQAOAFALAFQACAGABAEQAAACAAADQAAAAAAAAQgEAHgKAGQgMAIgVAEQgBAAAAABQgDADgDADQgOANgOAGQgCABgBAAQgEgBgDgBQgDgBgDAAQgCgBAAgBQgKgQgFgNQgBgBgBgCQgFgHgEgHQgBgBAAgBQgPgDgQgDQgNgCgSAAQAAAAgBAAIgJgGIAAAA").cp();
	this.shape_483.setTransform(469.9,218.3);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#71BF58").s().p("AhkgGQAZgGAngHQABgDACgCQAJgOAJgMQAEgGAEgFQABgBABAAQAHgBAIAAQABAAAAAAQAFAFAGAGQAJAMAJAOQABACACACQAPACAOAEQAPAFALAFQACAGABAEQAAADAAACQAAAAAAAAQgFAHgKAFQgOAIgWAEQAAAAAAAAQgDAEgDADQgNAPgOAIQgBABgBAAQgEAAgDgBQgDgBgDgBQgCAAgBgBQgJgRgFgOQgBgCgBgCQgEgIgEgHQgBgBAAgBQgQgDgQgCQgOgCgSAAQgBgBgBAAIgIgGIAAAA").cp();
	this.shape_484.setTransform(469.6,218.2);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#71BF58").s().p("AhlgHQAbgFAngHQACgCABgDQAJgPAIgOQAEgFAEgGQABgBAAgBQAHgBAJAAQABAAAAAAQAFAHAFAGQAJANAIAPQABACACACQAQADAOADQAQAFAMAEQACAHABAFQAAACAAACQAAAAAAAAQgGAHgLAFQgPAHgWADQgBABAAAAQgCAEgDAEQgMAQgNAKQgBABgCABQgDgBgEAAQgCgBgEgBQgBgBgCAAQgJgSgEgPQgBgCgBgDQgEgIgDgHQgBgBgBgBQgQgDgRgDQgOgBgTAAQgBgBAAAAIgIgHIAAgB").cp();
	this.shape_485.setTransform(469.3,218.1);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#71BF58").s().p("AhmgHQAdgFAogGQABgDACgDQAIgQAHgPQAEgGADgHQABAAABgBQAHgBAKAAQAAAAAAAAQAFAHAFAHQAIAOAHAQQACADABACQARACAPADQAQAFAOAEQABAHABAFQAAACAAADQAAAAAAAAQgHAFgLAFQgRAHgXADQAAABAAAAQgCAEgDAEQgLASgMAMQgBABgCABQgDAAgEgBQgDgBgDAAQgBgBgCgBQgJgSgEgRQgBgCgBgCQgDgJgDgIQgBgBgBgBQgRgDgRgCQgPgCgUAAQAAAAgBgBIgHgIIAAAA").cp();
	this.shape_486.setTransform(469,218.1);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#71BF58").s().p("AhngIQAegEAqgGQABgDABgDQAIgRAGgQQAEgHADgHQABgBAAgBQAIgBAKAAQAAAAABAAQAEAIAEAIQAIAPAGASQACACABADQARACARADQARAEAOADQABAIABAFQAAACAAADQAAAAAAAAQgIAFgMAFQgRAGgYADQAAAAgBABQgCAEgCAFQgKATgLAOQgBABgCACQgDgBgEAAQgDgBgEgBQgBAAgCgBQgIgUgEgRQAAgCgBgDQgDgJgEgIQAAgBgBgCQgRgCgSgCQgQgCgUAAQgBAAAAgBIgHgJIAAgB").cp();
	this.shape_487.setTransform(468.7,218);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#71BF58").s().p("AhogIQAggEAqgFQABgEABgDQAHgSAHgSQADgHADgHQAAgBABgBQAIgBAKAAQABAAAAAAQAEAIAEAJQAHARAGASQABADABACQASACARADQASAEAPADQABAIABAFQAAACAAADQAAAAAAAAQgJAFgNAEQgSAGgYACQgBABAAABQgCAEgCAFQgKAVgKAQQgBACgBABQgEAAgDgBQgEgBgDAAQgBgBgDAAQgHgVgDgTQgBgCgBgDQgDgJgDgJQAAgBgBgBQgSgDgSgCQgSgBgUAAQgBgBAAAAIgGgLIAAAA").cp();
	this.shape_488.setTransform(468.5,217.9);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#72BF58").s().p("AhpgIQAigEArgFQABgEABgDQAGgUAGgSQADgIACgHQABgCAAgBQAJAAAKgBQABAAAAAAQAEAKADAJQAHASAFATQABADABADQATABASADQASADAQAEQABAHABAGQAAADAAACQAAAAAAAAQgKAFgNAEQgUAFgZACQAAABAAABQgCAFgCAEQgJAXgJASQgBACgBACQgEgBgEAAQgDgBgDAAQgCgBgDAAQgGgWgDgUQgBgDgBgCQgCgKgDgJQAAgCgBgBQgTgCgTgCQgSgBgVAAQAAgBgBgBIgFgLIAAAA").cp();
	this.shape_489.setTransform(468.2,217.9);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#72BF58").s().p("AhqgJQAjgDAsgFQABgDABgEQAGgVAFgTQACgIADgJQAAgBABgCQAJAAAKAAQABAAAAAAQADAKAEAKQAFATAFAUQABADABADQAUACATACQATADAQADQACAIAAAGQAAADAAADQAAAAAAAAQgLAEgOADQgVAFgZACQAAABgBABQgBAFgCAFQgIAYgIAUQgBACgBACQgEAAgEgBQgEAAgCgBQgDAAgDgBQgFgWgDgVQgBgDAAgDQgDgKgCgJQgBgCAAgCQgTgBgUgCQgTgBgVAAQgBgBAAgBIgFgMIAAgB").cp();
	this.shape_490.setTransform(467.9,217.8);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#72BF58").s().p("AhrgJQAlgDAtgEQAAgEABgEQAFgWAFgVQACgIACgJQABgCAAgBQAJAAAMgBQAAAAAAAAQADALADALQAFAUAFAWQABADABADQAUABATADQAUACASADQABAIAAAGQAAADAAADQAAAAAAAAQgMAEgOADQgWAEgbACQAAAAAAABQgBAGgCAFQgHAagHAWQgBACgBADQgEgBgEAAQgEgBgCAAQgDAAgDgBQgGgYgCgWQgBgDAAgDQgCgKgCgKQgBgCAAgBQgUgCgUgBQgUgBgWAAQAAgBgBgBIgEgOIAAAA").cp();
	this.shape_491.setTransform(467.6,217.7);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#72BF58").s().p("AhsgKQAngCAtgEQABgEABgFQAEgWAEgWQACgJACgJQAAgCABgCQAJAAAMAAQAAAAABAAQACALADAMQAEAVAEAXQABADABAEQAVABAUACQAUACATACQABAJAAAGQAAADAAADQAAAAAAAAQgNADgPADQgXAEgbABQAAABAAABQgCAGgBAGQgGAbgGAYQgBACgBADQgEAAgFgBQgEAAgCAAQgDgBgDAAQgFgZgCgXQAAgDgBgDQgCgLgCgKQAAgCAAgCQgVgBgVgCQgUgBgXAAQAAgBAAgBIgEgOIAAgB").cp();
	this.shape_492.setTransform(467.3,217.7);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#72BF58").s().p("AhtgKQApgCAugDQAAgFABgFQAEgXADgXQACgKACgKQAAgBAAgCQAKAAAMgBQAAAAABAAQACANACAMQAEAXADAXQABAEABADQAVABAWACQAVACATACQABAJAAAHQAAACAAAEQAAAAAAAAQgOACgQADQgYADgcABQAAABAAABQgBAGgBAGQgFAdgGAaQAAADgBADQgEgBgFAAQgEAAgDgBQgDAAgDAAQgEgagCgYQAAgEgBgDQgBgLgCgLQAAgCAAgCQgWgBgVgBQgVgBgXAAQgBgBAAgBIgDgPIAAgB").cp();
	this.shape_493.setTransform(467,217.6);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#72BF58").s().p("AhugLQAqgCAvgCQABgFAAgFQADgYADgZQACgKABgKQAAgCABgCQAKAAAMAAQABAAAAAAQACANACANQADAYADAZQAAADABAEQAWABAWABQAWACAUABQABAKAAAHQAAADAAADQAAAAAAAAQgOACgRACQgaADgcABQAAABAAABQgBAGgBAHQgEAegFAbQAAAEgBADQgFAAgEAAQgFgBgCAAQgDAAgEgBQgDgagCgaQAAgDAAgEQgCgLgBgLQAAgCAAgCQgWgBgWgBQgWgBgYAAQAAgBgBgBIgCgRIAAgB").cp();
	this.shape_494.setTransform(466.7,217.5);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#72BF58").s().p("AhvgLQAsgCAwgBQAAgGABgFQACgaACgZQACgLABgKQAAgCAAgCQALAAAMAAQABAAAAAAQACANABAOQADAZACAaQAAAEABAEQAXAAAXABQAWACAWABQAAAJAAAIQAAADAAADQAAAAAAAAQgPACgSABQgaADgdAAQAAACgBABQAAAHgBAGQgDAggEAdQAAAEgBADQgFAAgFAAQgEAAgDAAQgDgBgEAAQgCgbgCgbQAAgEAAgDQgBgMgBgMQAAgCgBgCQgWgBgXgBQgWAAgZAAQAAgBAAgCIgCgRIAAgB").cp();
	this.shape_495.setTransform(466.4,217.5);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#72BF58").s().p("AhwgLQAugCAwgBQABgFAAgGQACgbACgaQAAgLABgLQAAgDABgCQALAAAMAAQABAAAAAAQABAOACAOQABAbACAbQAAAEABAEQAYABAYABQAXABAWABQAAAJAAAIQAAADAAADQAAAAAAAAQgQACgSABQgcABgeABQAAABAAACQAAAHgBAHQgDAhgCAfQgBAEAAAEQgFAAgFAAQgEgBgDAAQgEAAgEAAQgBgdgBgcQgBgDAAgEQgBgMAAgMQgBgDAAgCQgXAAgXgBQgYAAgYAAQgBgCAAgBIgBgTIAAAA").cp();
	this.shape_496.setTransform(466.2,217.4);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#72BF58").s().p("AhxgMQAwgBAxgBQAAgFAAgGQACgcABgcQAAgLABgMQAAgCAAgCQAMAAANAAQAAAAABAAQAAAPABAOQABAcABAdQABAEAAAEQAZAAAYABQAYAAAXABQAAAKAAAIQAAADAAAEQAAAAAAAAQgRABgTAAQgdABgeABQAAABAAACQgBAHAAAHQgCAjgCAhQAAAEAAAEQgFAAgFAAQgEAAgEAAQgEAAgDAAQgCgeAAgdQAAgEgBgDQAAgNgBgNQAAgCAAgCQgYgBgXAAQgZAAgZAAQAAgCAAgBIgBgUIAAgB").cp();
	this.shape_497.setTransform(465.9,217.4);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#72BF58").s().p("AhygMQAxgBAyAAQABgGAAgGQAAgdABgdQAAgMAAgMQAAgCABgDQAMAAANAAQAAAAABAAQAAAQABAPQAAAeABAdQAAAEAAAFQAaAAAZAAQAYAAAYABQAAAKAAAIQAAAEAAADQAAAAAAAAQgSAAgTABQgfAAgfABQAAABAAABQAAAIAAAIQgBAkgBAjQAAAFAAAEQgFAAgGAAQgDAAgEAAQgEAAgEgBQgBgeAAgeQAAgEAAgEQgBgNAAgNQAAgDAAgCQgYAAgZAAQgZgBgaAAQAAgBAAgBIAAgVIAAgB").cp();
	this.shape_498.setTransform(465.6,217.3);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#72BF58").s().p("AB0gNIhmAAIAAhmIgbAAIAABmIhmAAIAAAaIBmAAIAABnIAbAAIAAhnIBmAAIAAga").cp();
	this.shape_499.setTransform(465.3,217.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_477}]}).to({state:[{t:this.shape_478}]},33).to({state:[{t:this.shape_479}]},1).to({state:[{t:this.shape_480}]},1).to({state:[{t:this.shape_481}]},1).to({state:[{t:this.shape_482}]},1).to({state:[{t:this.shape_483}]},1).to({state:[{t:this.shape_484}]},1).to({state:[{t:this.shape_485}]},1).to({state:[{t:this.shape_486}]},1).to({state:[{t:this.shape_487}]},1).to({state:[{t:this.shape_488}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_490}]},1).to({state:[{t:this.shape_491}]},1).to({state:[{t:this.shape_492}]},1).to({state:[{t:this.shape_493}]},1).to({state:[{t:this.shape_494}]},1).to({state:[{t:this.shape_495}]},1).to({state:[{t:this.shape_496}]},1).to({state:[{t:this.shape_497}]},1).to({state:[{t:this.shape_498}]},1).to({state:[{t:this.shape_499}]},1).wait(18));

	// equal sign
	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#007C45").s().p("AAtgcQAkAMAMAJQgXgDgOAFQgSAFgSAKQgSANgMAHQgZANgXgDQgZgDgHgPQgFgLAEgLQAEgKAOgMQAGgEAFgDQAQgJAVgCQAVgBAZAGQAMADAMAEIAAAA").cp();
	this.shape_500.setTransform(396,206.1);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#007C45").s().p("AAWAOQgTAMgMAGQgaAMgYgCQgXgEgJgMQgEgJABgJQgBgHACgFQAFgLAPgKQAFgEAGgDQARgIAVgBQAVgCAaAGQALADANAEQAYAGAPAGQAGAEAEAEQgGAAgEAAQAFAIgFAAQgQgBgLADQgSAEgTAKIAAAA").cp();
	this.shape_501.setTransform(395.8,206.3);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#007C45").s().p("AhfAFQgBgFADgHQAFgKAPgKQAFgDAGgDQARgIAVgBQAWgBAaAGQALACANAEQATAEANAFQADABAEACQAGAEADAEQgCAAgBAAQgEAAgDABQAFAHgFAAQgQgBgLADQgSADgTAKQgTAMgNAGQgaALgYgCQgTgDgJgIQgDgCgCgDQgDgJABgJAhfAJQgBgGADgFQAFgKAPgKQAcgPAVgBQAWgBAaAGQALACANAEQATAFANAEQANAHADAEQgHAAgDABQAFAGgFAAQgQAAgLABQgSAFgTAKQgTAMgNAGQgaALgYgCQgTgDgJgIQgDgCgCgDQgDgJABgJ").cp();
	this.shape_502.setTransform(395.7,206.4);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#007C45").s().p("AhgACQAAgEACgHQAHgJAPgKQAFgDAGgDQARgIAVAAQAWgCAaAGQAMACANADQASAFAOAEQADACADACQAGAEADAEQgBAAgCAAQgDAAgDABQAEAHgFAAQgQgBgLADQgTADgTAJQgTALgOAGQgaAKgYgCQgTgCgKgIQgCgCgCgDQgDgJABgJAhgAKQAAgGACgFQAHgJAPgKQAcgNAVgBQAWgCAaAGQAMACANAEQASAEAOAEQAMAIADAEQgGAAgDABQAEAFgFAAQgQgBgLADQgTAFgTAJQgTALgOAGQgaALgYgDQgTgCgKgIQgCgCgCgDQgDgJABgJ").cp();
	this.shape_503.setTransform(395.7,206.5);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#007C45").s().p("AhhAAQAAgFADgGQAHgJAPgJQAGgDAGgDQARgHAVgBQAWgBAaAFQAMACANADQATAFAOADQADACADACQAFAFADAEQgBAAgCABQgDAAgDAAQADAGgEAAQgQAAgMADQgTADgTAIQgTALgOAFQgaAKgZgCQgSgCgLgIQgCgCgCgDQgDgJABgIAhhALQAAgGADgFQAHgIAPgJQAdgNAVgBQAWgBAaAFQAMACANAEQATAEAOAEQALAIADAEQgGABgDAAQADAFgEAAQgQgBgMADQgTAEgTAJQgTALgOAFQgaAKgZgCQgSgCgLgHQgCgDgCgDQgDgJABgJ").cp();
	this.shape_504.setTransform(395.6,206.6);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#007C45").s().p("AhigCQABgGADgGQAHgIAQgJQAFgDAGgCQASgHAVgBQAVgBAcAFQAMACANADQASAEAPAEQACACADACQAFAFADAEQgBAAgCABQgDAAgDAAQADAGgFAAQgQgBgMADQgTAFgTAGQgUAKgNAFQgbAJgZgCQgSgCgLgGQgCgDgCgDQgDgJABgHAhiAMQABgFADgHQAHgGAQgJQAdgMAVAAQAVgCAcAFQAMACANADQASAEAPAEQAKAJADACQgGABgDAAQADAHgFAAQgQgBgMADQgTAEgTAIQgUAKgNAFQgbAKgZgCQgSgCgLgHQgCgDgCgDQgDgJABgJ").cp();
	this.shape_505.setTransform(395.5,206.7);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#007C45").s().p("AhjgFQABgGAEgFQAIgIAQgIQAFgDAGgCQARgHAWgBQAVgBAcAFQAMACANADQATAEAOADQADACADADQAEAEADAFQgBAAgCABQgDAAgDAAQACAGgEAAQgQgBgMADQgUAEgTAGQgUAJgOAFQgbAJgZgCQgSgCgMgGQgCgDgBgDQgDgJABgHAhjANQABgFAEgGQAIgGAQgIQAcgLAWgBQAVgBAcAEQAMACANADQATAEAOAEQAKAIADADQgGABgDABQACAFgEAAQgQAAgMACQgUAFgTAHQgUAKgOAEQgbAJgZgCQgSgBgMgHQgCgDgBgDQgDgJABgJ").cp();
	this.shape_506.setTransform(395.4,206.7);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#007C45").s().p("AhkgIQACgFADgGQAJgHAQgIQAFgCAGgCQASgHAVAAQAWgBAcAEQAMACANADQATADAPADQADADACACQAEAFADAFQgBAAgCABQgDAAgDABQACAFgEAAQgRgBgMADQgUAEgTAFQgUAJgOAEQgbAJgagCQgSgCgMgGQgCgDgBgDQgDgIABgIAhkAOQACgFADgFQAJgGAQgHQAdgLAVgBQAWgBAcAFQAMABANADQATAEAPADQAJAIADAEQgGACgDAAQACAFgEAAQgRAAgMACQgUAEgTAHQgUAJgOAEQgbAJgagCQgSgCgMgGQgCgCgBgDQgDgKABgJ").cp();
	this.shape_507.setTransform(395.3,206.8);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#007C45").s().p("AhlgMQACgEAEgFQAKgHAQgHQAFgDAGgCQASgFAVgBQAWgBAdAEQAMACANACQATAEAPADQACACADADQAEAFACAFQgBABgBAAQgEAAgDABQACAFgFAAQgQgBgNACQgTAEgUAFQgUAIgPAEQgbAIgagCQgSgBgMgGQgCgDgBgDQgDgHABgKAhlAPQACgFAEgFQAKgFAQgHQAdgKAVAAQAWgBAdAEQAMABANADQATADAPADQAJAJACAEQgGACgDAAQACAFgFAAQgQAAgNACQgTAEgUAGQgUAJgPAEQgbAIgagCQgSgCgMgFQgCgDgBgDQgDgKABgJ").cp();
	this.shape_508.setTransform(395.2,206.9);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#007C45").s().p("AhmgPQADgEAEgFQAKgGAQgHQAFgCAGgCQATgFAVgBQAXgBAcAEQAMACANACQATADAQADQACADACADQAEAFACAFQgBABgBABQgEAAgDAAQABAFgEAAQgQgBgNACQgUADgUAHQgUAFgPAEQgcAIgagCQgSgCgNgFQgBgDgCgDQgCgIABgJAhmAQQADgEAEgFQAKgGAQgFQAegJAVgBQAXgBAcAEQAMABANADQATADAQADQAIAIACAFQgGACgDAAQABAFgEAAQgQgBgNADQgUADgUAGQgUAIgPAEQgcAHgagBQgSgCgNgFQgBgDgCgDQgCgKABgJ").cp();
	this.shape_509.setTransform(395.2,207);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#007C45").s().p("AhngSQADgEAFgEQAKgGARgGQAFgCAGgCQATgFAVAAQAXgBAcADQANACANACQATADAPACQACADACADQAEAGACAFQgBABgBABQgEAAgDAAQABAEgFAAQgQAAgNACQgUADgUAGQgUAFgQADQgbAHgbgBQgSgCgNgFQgCgDgBgCQgCgJABgJAhnARQADgEAFgEQAKgGARgEQAegJAVgBQAXAAAcADQANABANADQATADAPABQAIAKACAFQgGACgDABQABAEgFAAQgQgBgNACQgUAEgUAFQgUAHgQAEQgbAHgbgCQgSgBgNgFQgCgDgBgDQgCgKABgJ").cp();
	this.shape_510.setTransform(395.1,207.1);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#007C45").s().p("AhogVQADgEAGgEQALgFAQgGQAGgCAGgBQATgFAVAAQAXgBAdADQAMACANACQATACAQADQACADACADQADAFACAGQgBABgBABQgDAAgEAAQABAEgFAAQgQAAgOABQgUADgUAGQgUAEgQADQgcAHgbgCQgSgBgNgEQgCgDgBgCQgCgKABgJAhoASQADgEAGgEQALgFAQgFQAfgHAVAAQAXgBAdADQAMACANACQATABAQACQAHALACAFQgFADgEAAQABAEgFAAQgQgBgOACQgUADgUAFQgUAHgQADQgcAGgbgBQgSgBgNgFQgCgDgBgDQgCgKABgJ").cp();
	this.shape_511.setTransform(395,207.2);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#007C45").s().p("AhpgYQAEgEAFgDQAMgFARgFQAFgCAGgBQATgEAWgBQAXAAAdACQAMACAOABQATADAQACQACADABAEQADAFACAGQgBABgBABQgDAAgEAAQAAAEgEAAQgRAAgNABQgVADgUAFQgUAGgRAAQgcAGgbgBQgSgBgOgEQgBgCgBgDQgCgKABgJAhpATQAEgEAFgDQAMgFARgFQAegFAWgBQAXAAAdACQAMACAOAAQATACAQACQAGAMACAFQgFADgEAAQAAAEgEAAQgRgBgNACQgVADgUAEQgUAGgRADQgcAGgbgBQgSgBgOgFQgBgDgBgDQgCgKABgJ").cp();
	this.shape_512.setTransform(394.9,207.3);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#007C45").s().p("AhqgbQAEgDAGgEQANgEAQgFQAGgBAGgBQATgEAVAAQAZgBAcACQANACANABQATACARACQABAEACADQACAGACAGQgBABgBABQgDAAgEABQAAADgFAAQgQgBgOACQgVACgUAFQgUAFgRACQgcAEgcgBQgSgCgOgBQgBgEgBgDQgBgKAAgJAhqAUQAEgDAGgDQANgFAQgEQAfgFAVAAQAZgBAcABQANABANABQATADARABQAFANACAFQgFADgEAAQAAAEgFAAQgQgBgOACQgVACgUAEQgUAGgRACQgcAFgcgBQgSgBgOgDQgBgDgBgEQgBgKAAgJ").cp();
	this.shape_513.setTransform(394.8,207.3);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#007C45").s().p("AhrgfQAFgCAGgDQANgEARgEQAFgBAGgCQAUgDAVAAQAZgBAcADQANABAOABQATACARACQABADABAEQADAGABAGQgBABAAACQgEAAgEAAQgBADgEAAQgQgBgPACQgUACgVAEQgVAEgQADQgdADgcAAQgSgBgOgDQgBgDgBgEQgBgKAAgKAhrAVQAFgDAGgDQANgEARgEQAfgGAVAAQAZAAAcACQANABAOABQATACARACQAFANABAFQgFAEgEAAQgBADgEAAQgQgBgPACQgUACgVADQgVAFgQACQgdAFgcgBQgSgBgOgDQgBgDgBgEQgBgKAAgJ").cp();
	this.shape_514.setTransform(394.8,207.4);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#007C45").s().p("AhsgiQAFgCAHgDQANgDARgEQAGgBAGgBQAUgDAVAAQAZAAAdACQANAAANACQATABARACQACAEABAEQACAGABAFQgBACAAACQgEAAgEAAQgBACgEAAQgRAAgOABQgVACgVADQgVAFgRACQgdAEgcgBQgSgBgPgDQgBgDAAgEQgBgKAAgKAhsAWQAFgDAHgCQANgEARgDQAggFAVgBQAZAAAdACQANABANABQATACARABQAFAOABAFQgFAEgEAAQgBACgEAAQgRAAgOABQgVACgVADQgVAFgRACQgdAEgcgBQgSgBgPgDQgBgDAAgEQgBgKAAgJ").cp();
	this.shape_515.setTransform(394.7,207.5);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#007C45").s().p("AhtglQAGgCAGgCQAPgDARgDQAGgBAGgBQAUgCAVgBQAZAAAdACQANAAANACQAUABARABQABAEABAEQACAGABAGQAAACgBACQgEAAgDAAQgCACgFAAQgQAAgPABQgVACgVACQgVAEgRACQgdADgdgBQgSAAgPgDQgBgDAAgEQgBgKAAgKAhtAXQAGgCAGgDQAPgDARgDQAggEAVAAQAZgBAdACQANABANABQAUABARACQAEAOABAGQgFADgDAAQgCACgFAAQgQAAgPABQgVACgVADQgVADgRACQgdADgdAAQgSgBgPgDQgBgDAAgDQgBgKAAgK").cp();
	this.shape_516.setTransform(394.6,207.6);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#007C45").s().p("AhugoQAGgCAHgBQAPgDARgCQAGgBAGgBQAUgCAWAAQAZgBAdACQANAAAOABQATACASABQABAEABAEQABAGABAGQAAACgBACQgEAAgDAAQgDACgEAAQgRAAgPABQgVABgVACQgVADgSACQgdADgdgBQgSgBgPgCQgBgDAAgEQgBgKAAgKAhuAYQAGgCAHgCQAPgCARgDQAggDAWgBQAZAAAdABQANABAOABQATABASABQADAOABAHQgFADgDAAQgDACgEAAQgRAAgPABQgVABgVADQgVADgSABQgdADgdgBQgSAAgPgCQgBgEAAgDQgBgKAAgK").cp();
	this.shape_517.setTransform(394.5,207.7);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#007C45").s().p("AhvgrQAHgBAHgCQAPgCASgCQAGgBAGAAQAUgCAWAAQAaAAAdABQANAAANABQAUABASABQAAAEABAFQABAGABAGQAAACgBACQgEAAgDABQgDABgFAAQgQAAgPAAQgWABgVACQgVADgSABQgeACgdAAQgSgBgQgBQAAgEgBgEQAAgKAAgKAhvAYQAHgBAHgBQAPgCASgCQAggDAWAAQAagBAdACQANAAANABQAUABASABQACAOABAHQgFAEgDAAQgDABgFAAQgQAAgPABQgWABgVACQgVACgSABQgeACgdAAQgSgBgQgBQAAgDgBgEQAAgKAAgL").cp();
	this.shape_518.setTransform(394.4,207.8);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#007C45").s().p("AhwguQAHgBAIgBQAQgCARgBQAGgBAGAAQAVgCAVAAQAbAAAdABQANAAAOABQATABATAAQAAAFABAEQAAAHABAGQAAACgBADQgDAAgEAAQgDABgFAAQgQAAgQAAQgWABgVABQgVACgTABQgdACgegBQgSAAgQgBQAAgEgBgEQAAgKAAgKAhwAZQAHgBAIgBQAQgBARgCQAhgCAVAAQAbAAAdABQANAAAOABQATAAATABQABAPABAHQgEAEgEAAQgDABgFAAQgQAAgQAAQgWABgVACQgVABgTABQgdACgeAAQgSgBgQgBQAAgDgBgEQAAgKAAgL").cp();
	this.shape_519.setTransform(394.3,207.9);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#007C45").s().p("AhxgxQAIgBAHgBQARgBASgBQAGAAAGAAQAVgBAVAAQAbAAAdAAQAOAAANABQAUAAASABQABAEAAAFQABAHAAAGQAAADAAACQgEAAgEAAQgEABgEAAQgRAAgQAAQgVAAgWABQgVACgTAAQgeABgeAAQgSAAgQgBQgBgEAAgEQAAgKAAgKAhxAaQAIAAAHgBQARgBASgBQAhgBAVgBQAbAAAdABQAOAAANABQAUAAASAAQACAQAAAHQgEAEgEAAQgEABgEAAQgRAAgQAAQgVABgWABQgVABgTAAQgeACgegBQgSAAgQgBQgBgDAAgEQAAgKAAgL").cp();
	this.shape_520.setTransform(394.3,208);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#007C45").s().p("Ahyg1QAIAAAIAAQASgBARAAQAGAAAGgBQAWAAAVAAQAbAAAeAAQANAAAOAAQATABATAAQAAAFABAFQAAAGAAAHQAAADAAACQgEAAgEAAQgEAAgFAAQgQAAgQABQgWAAgWAAQgVABgUAAQgeABgeAAQgSgBgRAAQAAgEAAgEQAAgKAAgLAhyAbQAIAAAIAAQASgBARAAQAigBAVAAQAbAAAeAAQANAAAOAAQATABATAAQABAQAAAHQgEAEgEAAQgEABgFAAQgQAAgQAAQgWAAgWABQgVAAgUABQgeAAgeAAQgSAAgRAAQAAgEAAgEQAAgKAAgL").cp();
	this.shape_521.setTransform(394.2,208);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#007C45").s().p("AB0g4IjnAAIAAAdIDnAAIAAgdAB0AcIjnAAIAAAdIDnAAIAAgd").cp();
	this.shape_522.setTransform(394.1,208.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_500}]}).to({state:[{t:this.shape_501}]},39).to({state:[{t:this.shape_502}]},1).to({state:[{t:this.shape_503}]},1).to({state:[{t:this.shape_504}]},1).to({state:[{t:this.shape_505}]},1).to({state:[{t:this.shape_506}]},1).to({state:[{t:this.shape_507}]},1).to({state:[{t:this.shape_508}]},1).to({state:[{t:this.shape_509}]},1).to({state:[{t:this.shape_510}]},1).to({state:[{t:this.shape_511}]},1).to({state:[{t:this.shape_512}]},1).to({state:[{t:this.shape_513}]},1).to({state:[{t:this.shape_514}]},1).to({state:[{t:this.shape_515}]},1).to({state:[{t:this.shape_516}]},1).to({state:[{t:this.shape_517}]},1).to({state:[{t:this.shape_518}]},1).to({state:[{t:this.shape_519}]},1).to({state:[{t:this.shape_520}]},1).to({state:[{t:this.shape_521}]},1).to({state:[{t:this.shape_522}]},1).wait(12));

	// %
	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#668B46").s().p("AhPgIQAPAAAIADQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLQgUgQgdgCQgbgCgrAOQgkAMgMAJIAOgB").cp();
	this.shape_523.setTransform(493,287.1);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#668B46").s().p("AhjgNQALgMAigMQACgBABgBQAegKAWgCQAJAAAHAAQATACAPAJQADABADACQAKACAJAEQAJAFAGAFQAHAKABACQAAAGgCAEQABAEABADQADANgEAKQgHAQgXAEQgZAEgYgLQgDgCgEgCQgRgLgIgEQgIgFgJgFQgFgDgFgCQgJgDgKgBQgIgBgOABIgQABIgBAAQAAAAABAAQAFgEAHgDQAHgEAKgFQgHgDgMgBQgGAAgGAAIAAAAABCgaQgEgCgEgBIgkgFQgBAAgCgBQgCAAgCAAQgBAAgBAAQgQACgUAGQgCABgBAAQgKAEgMAFQgJADgIAEQACAAABABQgCABgBAAIAAABQAIADAJAEQAJADAKAGQAFADAKAFQACABADABQAEADAEACQABABACACQAUAJATgBQAEgBAEAAQAFgBAEgCQAPgFAFgMQADgIgCgMQgCgHgFgHQADADAEADQAAABABAAQgCgDgDgEQgEgDgFgDQAAAAAAAAIAAAA").cp();
	this.shape_524.setTransform(492.6,287.3);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#668B46").s().p("AhigLQAKgNAigNQABgBACAAQAFgDAFgBQAXgIASgCQAIAAAHAAQAEABADAAQAQADAMAGQADACACABQAKADAJAEQAFADADACQAEACADADQAHAKABACQAAAGgBAFQABADABADQACANgDAKQgBACgBACQgIANgTAEQgSAEgTgFQgFgBgFgCQgDgCgEgBQgQgKgJgEQgHgEgIgFQgBAAgBgBQgFgCgEgCQgKgCgKgCQgIgCgOABQgGABgGAAQgCAAgCAAQAAAAAAAAQAAAAAAAAQAFgFAGgEQAHgDAJgEQgHgEgLgCQgFAAgGgBIgBAA").cp();
	this.shape_525.setTransform(491.9,286.8);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#668B46").s().p("AhhgJQAKgOAggNQABgBACgBQAFgCAFgCQAWgJAUgBQAHgBAHAAQADABAEAAQAPACAMAHQADACADABQAKACAJAFQAEADADACQAEACADADQAHAJABADQABAGgCAFQABADABADQADANgDAKQgBACgBACQgHANgSAFQgSAFgSgEQgFgBgFgCQgEgBgDgBQgQgJgJgDQgIgEgHgEQgBgBgBAAQgFgCgFgCQgKgCgJgCQgIgCgNABQgGAAgHAAQgBgBgCAAQAAAAgBAAQAAAAABAAQADgEAHgFQAFgFAJgDQgHgEgLgCQgEgBgGgBIgBAA").cp();
	this.shape_526.setTransform(491.1,286.3);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#668B46").s().p("AhfgHQAJgPAegOQACgBABgBQAFgCAFgCQAWgJAUgCQAGgBAIAAQADABADAAQAQACAMAHQADABADACQAJACAJAFQAEACAEADQAEACACADQAHAJABADQABAGgBAGQABACABADQACANgCAKQgBACgBACQgHANgRAGQgRAGgSgDQgEgBgFgBQgEgBgDgBQgSgHgIgEQgHgDgHgEQgBAAgBgBQgFgCgFgBQgKgDgJgBQgIgCgNAAQgGgBgGAAQgCAAgCgBQAAAAAAAAQAAAAAAAAQADgEAGgEQAFgGAHgFQgGgDgKgCQgEgBgFgCIgBAA").cp();
	this.shape_527.setTransform(490.3,285.8);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#668B46").s().p("AhegFQAJgQAcgOQACgCABgBQAFgCAFgDQAVgJAUgCQAHgBAHAAQAEAAADABQAPACAMAGQADABADACQAKACAJAFQAEADADACQAEADADADQAGAJACADQAAAGAAAHQABABABADQACAMgDALQAAACgBACQgGANgQAGQgQAHgSgBQgFAAgFgBQgDgBgDgBQgSgGgIgDQgHgDgIgEQgBAAgBAAQgFgCgEgCQgKgCgJgCQgJgCgMAAQgGgBgGgBQgCAAgCAAQAAAAAAAAQAAAAAAAAQADgFAFgEQAEgGAHgGQgGgEgJgBQgFgCgEgCIgBAA").cp();
	this.shape_528.setTransform(489.6,285.3);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#668B46").s().p("AhcgEQAHgQAcgPQABgCACgBQAEgDAFgCQAVgKAUgDQAGgBAIABQADAAADAAQAQACAMAGQADACADABQAKADAIAFQAEACAEADQADADADACQAGAJACADQABAHgBAGQABACABACQADANgDAKQAAACgBACQgGAOgPAGQgPAJgRgBQgFABgFgBQgDAAgDgBQgRgFgJgDQgHgCgIgEQgBAAgBAAQgFgCgEgCQgKgCgKgCQgIgCgMgBQgGAAgFgBQgCgBgCAAQAAAAAAAAQAAAAAAAAQACgFAEgFQADgFAHgGQgGgFgJgDQgEgBgEgDIAAAA").cp();
	this.shape_529.setTransform(488.8,284.8);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#668B46").s().p("AhbgCQAHgSAagPQABgCACgBQAEgDAFgDQAUgLAUgCQAHgBAIAAQADAAADAAQAPACANAGQADABACACQAKADAJAFQAEADADACQADADADADQAGAIACAEQABAGAAAHQABADABABQACAMgCAKQgBACAAACQgFAOgOAIQgPAJgQABQgFAAgFAAQgDAAgEgBQgQgEgJgCQgHgCgIgDQgBAAgBAAQgFgCgEgBQgKgCgKgDQgIgCgMgBQgFgBgGgCQgCAAgCgBQAAAAAAAAQAAAAAAAAQACgEADgFQADgGAFgGQgFgGgIgEQgEgBgDgCIgBAA").cp();
	this.shape_530.setTransform(488,284.4);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#668B46").s().p("AhagBQAHgTAYgQQACgBABgCQAEgDAFgDQATgLAVgDQAHgBAHAAQADAAADABQAQABAMAGQADABADACQAKADAIAFQAEADADACQAEADACADQAGAIACAEQACAGAAAHQABADAAACQADALgCALQgBACgBABQgEAOgNAIQgNALgRACQgEABgFAAQgDAAgEAAQgQgDgKgCQgHgCgHgCQgBAAgBgBQgFgBgFgCQgKgBgJgDQgIgCgLgCQgGgBgGgCQgBAAgCgBQAAAAgBAAQAAAAABAAQABgFACgFQACgGAFgGQgGgGgGgFQgEgDgDgBIgBAA").cp();
	this.shape_531.setTransform(487.3,284);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#668B46").s().p("AhYAAQAFgUAXgQQACgCABgBQAEgEAFgDQATgLAUgEQAJgBAGAAQADAAADAAQAPACANAFQADACACABQAKADAIAGQAEACAEADQADADADADQAFAIACAEQACAGAAAHQABADABADQACAKgBALQgBABgBACQgEAOgMAJQgMALgQAEQgFABgEABQgEAAgDAAQgQgCgLgBQgGgCgHgCQgBAAgBAAQgFgBgFgCQgKgCgJgCQgJgDgKgCQgGgBgFgCQgCgBgCgBQAAAAAAAAQAAAAAAAAQAAgEACgFQACgHADgHQgFgGgGgFQgDgDgDgCIAAAA").cp();
	this.shape_532.setTransform(486.5,283.6);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#668B46").s().p("AhXAAQAFgUAWgRQABgCACgBQAEgEAEgDQASgMAVgEQAIgBAHAAQADAAACAAQAQABAMAGQADABADACQAKADAIAFQAEADADADQADADADADQAGAHACAFQABAGABAHQABADABADQACAJgCALQAAACgBACQgDAPgLAJQgMAMgPAFQgFACgFAAQgDABgDAAQgPAAgNgBQgFgBgIgCQgBgBgBAAQgFgBgEgBQgKgCgJgCQgJgDgKgDQgGgBgFgDQgCgBgBAAQAAAAgBAAQAAAAABAAQgBgFACgFQAAgHADgHQgFgGgFgGQgDgEgDgDIAAAA").cp();
	this.shape_533.setTransform(485.7,283.2);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#668B46").s().p("AhWAAQAFgVAUgRQABgCACgBQAEgEAEgDQASgNAUgEQAJgBAGgBQADABADAAQAPABANAFQADABADACQAJADAIAGQAEADADADQADACADADQAGAIACAFQACAGAAAHQABADABADQACAJgBALQAAACgBACQgDAOgKAKQgKAOgQAGQgEACgFABQgDAAgDABQgPABgNgBQgFgBgIgBQgBgBgBAAQgFgBgEgBQgKgBgJgDQgJgDgKgDQgFgCgGgDQgBgBgCAAQAAAAAAAAQAAAAAAAAQgBgFABgGQAAgGACgIQgFgGgFgHQgCgEgCgEIgBAA").cp();
	this.shape_534.setTransform(485,282.9);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#668B46").s().p("AhUAAQAEgVASgSQACgCABgCQAEgEAEgDQARgOAVgEQAIgBAHAAQADAAACAAQAQABAMAFQADABADACQAKADAIAGQAEADADADQADADACACQAGAIACAFQACAGABAHQABADABADQACAJgBALQAAACgBACQgCAPgJAKQgKAPgPAHQgEACgFACQgDABgDAAQgPACgOAAQgEAAgIgCQgBAAgBAAQgFgBgEgBQgKgBgKgDQgIgDgKgEQgFgCgFgDQgCgBgCgBQAAAAAAAAQAAAAAAAAQgBgFAAgFQgBgHABgIQgEgHgEgHQgCgEgCgFIAAAA").cp();
	this.shape_535.setTransform(484.2,282.5);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#668B46").s().p("AhTAAQADgWARgSQACgDABgBQAEgEAEgEQARgOAUgEQAJgCAGAAQADAAADAAQAPABANAFQADABADABQAJAEAIAGQAEADADADQADADADADQAFAHACAFQACAGACAHQABADAAADQACALAAAJQAAACgBACQgCAPgIALQgJAPgOAJQgFADgEACQgDABgDABQgPADgOAAQgGAAgGgBQgBAAgBAAQgFgBgFgBQgKgBgJgDQgJgDgJgEQgFgDgFgDQgCgBgBgBQAAAAAAAAQAAAAAAAAQgCgFgBgGQgCgHABgIQgEgHgDgIQgCgFgCgFIAAAA").cp();
	this.shape_536.setTransform(483.5,282.2);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#668B46").s().p("AhSAAQADgXAQgTQABgCACgCQADgEAEgEQAQgPAVgEQAIgCAIAAQACAAACAAQAQAAAMAFQADABADACQAKAEAIAGQADADADADQADADADADQAFAGACAGQADAGABAHQABADABADQACALAAAJQgBACAAACQgBAPgHAMQgJAQgOAKQgEADgEACQgEACgDABQgNAEgPABQgHAAgFgBQgBAAgBAAQgFAAgFgBQgKgBgJgDQgJgEgJgEQgFgDgFgEQgBgBgCgBQAAAAAAAAQAAAAAAAAQgDgFgBgFQgCgIAAgIQgEgIgDgIQgBgFgBgGIgBAA").cp();
	this.shape_537.setTransform(482.7,281.9);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#668B46").s().p("AhQAAQABgYAPgTQABgDACgBQADgFAEgEQAPgPAVgFQAJgCAJAAQAAAAADAAQAPAAANAFQADABADACQAJADAIAHQAEADADADQACADADADQAFAGADAGQACAGACAHQABADAAADQACALAAAJQAAACAAABQgBAQgGANQgHARgOALQgEADgFADQgDACgDABQgNAGgQABQgGAAgGAAQgBAAgBAAQgFgBgEAAQgKgBgJgEQgJgDgIgFQgGgDgEgEQgCgBgBgCQAAAAAAAAQAAAAAAAAQgEgEgCgGQgDgIgBgJQgDgIgCgIQgBgGgBgGIAAAA").cp();
	this.shape_538.setTransform(481.9,281.6);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#668B46").s().p("AhPAAQABgZANgUQACgCABgCQADgFAEgEQAPgQAVgFQAIgCAJAAQACAAABAAQAQAAAMAFQADABADABQAKAEAHAGQAEADADAEQADADACADQAFAGADAGQACAGACAHQABADABADQACAKAAAKQAAACAAABQgBARgFAMQgGATgNAMQgEAEgFADQgDACgDABQgNAHgQACQgGABgGgBQgBAAgBAAQgFAAgEgBQgKgBgJgDQgJgDgIgGQgFgDgFgEQgCgCgBgBQAAAAAAAAQAAAAAAAAQgEgFgDgGQgEgIgBgJQgDgIgCgJQgBgGAAgHIAAAA").cp();
	this.shape_539.setTransform(481.2,281.3);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#668B46").s().p("Ah3iGQAJgVAVABQATAAAKAUQAKATAAAfQAAAfgKASQgKATgUABQgTAAgKgUQgLgTABgeQAAgfAKgTIAAAAAiphUQAAAoAWAXQAWAVAjAAQAkAAAWgVQAWgXAAgoQAAgngWgYQgVgYgkAAQgkAAgWAYQgVAYgBAnIAAAAAh4ClIESlJIghAAIkRFJIAgAAABaABQgkAAgVAYQgWAXAAAmQAAApAWAXQAXAWAiAAQAjAAAWgWQAXgXAAgpQAAgmgXgXQgVgZgkABIAAAAABaASQATAAALATQAKATAAAeQAAAhgKASQgKATgUgBQgTAAgLgSQgJgUAAgfQAAgdAJgUQAKgUAUABIAAAA").cp();
	this.shape_540.setTransform(489.5,289.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_523}]}).to({state:[{t:this.shape_524}]},43).to({state:[{t:this.shape_525}]},1).to({state:[{t:this.shape_526}]},1).to({state:[{t:this.shape_527}]},1).to({state:[{t:this.shape_528}]},1).to({state:[{t:this.shape_529}]},1).to({state:[{t:this.shape_530}]},1).to({state:[{t:this.shape_531}]},1).to({state:[{t:this.shape_532}]},1).to({state:[{t:this.shape_533}]},1).to({state:[{t:this.shape_534}]},1).to({state:[{t:this.shape_535}]},1).to({state:[{t:this.shape_536}]},1).to({state:[{t:this.shape_537}]},1).to({state:[{t:this.shape_538}]},1).to({state:[{t:this.shape_539}]},1).to({state:[{t:this.shape_540}]},1).wait(13));

	// 2
	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#10532D").s().p("AA4gFQgSAFgSAKQgQAMgLAHQgBABgCAAQgZANgXgDQgSgCgJgJQgDgDgCgEQgFgLAEgLQAEgKAOgMQAUgQAcgCQAbgCArAOQAkAMAMAJQgXgDgOAFIAAAA").cp();
	this.shape_541.setTransform(309,223.1);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#0F542E").s().p("AgEguQADABABACQADABADABQACACADABQACABADABQACACACABQACABACAAQADAAADAAQACgBACAAIABAAQAEAAAFABQAGAAAFABQAIACAHACQAPAEAHAGIAAAAQgHABgIADQgFACgEACQgEACgEABQgBABgBABQgGACgGACQgOAFgOAIQgCABgCACQgGADgEAEQgEAGgEAEQgBABAAAAQgIAGgHACQgFADgGADQgHAAgHgBQgVgDgNgIQgDgDgDgDQgFgGgBgGQAAgFABgFIAAgBQACgEACgDQAGgGAIgHQADgCADgCQACgCACgBQAEgDAFgDQAFgDAFgCQADgCADgCQAEgCAFgDQAGgEAEgBQAEgCAEAAQACAAAEABIAAAA").cp();
	this.shape_542.setTransform(309.1,223.7);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#0E542E").s().p("AhbAVQAAgEABgDQABgCAAgCIAAgBQACgEADgEQABgBACAAQAEgFAFgEQACgBACgCQABgBABgBQACgBACgCQACgBABgBQABAAAAgBQADgCACgBQACgDADgBQACgCADgBQACgCACgBQADgDACgCQABAAAAgBQADgCAEgCQABgBABgBQAEgDACAAQAAAAAAAAQADgBADAAQABAAABAAQACABACABQABAAABABQACAAACACQAAAAAAAAQACACABABQABAAAAAAQACACABABQABAAAAAAQACABABABQAAAAAAAAQACABACAAQAAAAAAAAQACABACAAQACgBABABQACgBABAAQACgBADgBQAAAAAAAAQABAAAAAAQAEAAAFABQABgBABAAQAGAAAFABQABABABAAQAHABAHACQAGACAFADQAIADAEAEQAAAAAAAAQgDABgDABQgEACgEACQgBABAAAAQgEACgEACQgBAAAAAAQgEACgEACQgBAAgBABQAAAAgBAAQgGADgGABQgIADgIAFQgGACgFAEQgBABgCAAQgBABgBACQgFADgEAEQgEAFgBAEQAAABAAAAQgEADgDADQgDACgDABQgDACgDACQgCABgDABQgIAAgIgBQgXgCgOgIQgEgDgDgDQgBgBgBgBQgDgFgBgFIAAAA").cp();
	this.shape_543.setTransform(309.3,223.9);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#0E552F").s().p("AhcAXQABgEABgDQABgCABgCIAAgBQADgEADgEQABgCACgBQAEgDAGgFQACgCADgCQABgBABAAQACgCACgCQACgBACgBQAAAAABgBQACgCADgCQACgCACgCQADgCACgBQACgDACgBQACgDADgDQAAAAAAgBQADgCACgDQACgBAAAAQADgDABAAQAAAAABAAQACgBADABQAAAAABAAQACABACABQABAAABABQACABACACQABAAAAABQABABABACQAAAAABAAQABACABABQAAAAABAAQAAABACAAQAAAAAAAAQACABABAAQAAAAAAAAQACAAACgBQACAAABAAQACAAABgBQACgBADgBQABAAAAAAQAAAAABAAQAEgBAFAAQABAAABAAQAGAAAGABQABAAABAAQAIACAHACQAHACAGADQAIAEAFAEQAAABgBAAQgCAAgDACQgEACgFADQAAABgBAAQgEADgEACQAAAAgBAAQgEACgEACQgBABgBAAQgBABAAAAQgHADgGABQgJAEgJAEQgGAEgFADQgBABgBABQgBABgBABQgEADgCADQgDAGgCAEQAAABAAAAQAAADgDACQgCACgDACQgDACgDACQgDACgDABQgIAAgJgBQgYgDgQgHQgFgDgDgDQgCgBAAgBQgEgFgBgGIAAAA").cp();
	this.shape_544.setTransform(309.4,224.2);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#0D552F").s().p("AhcAaQABgEACgEQABgCABgCIABgCQACgDADgEQACgCADgCQAEgDAGgEQADgDADgCQABgBABgBQACgBADgCQABgCACgBQABAAABgBQACgCADgCQACgDACgCQACgCACgCQACgCACgCQACgEACgCQAAgBAAgBQACgDACgCQABgBAAgBQACgCABAAQAAAAAAAAQACgBACABQAAABABAAQACABACABQABABABABQACABADACQAAABAAAAQADACAAABQAAAAAAABQAAACAAABQABAAAAAAQAAABABAAQAAAAAAAAQACAAABgBQAAAAAAAAQACAAACgBQACAAABgBQACAAACgBQABgBADgBQABAAAAgBQABAAAAAAQAFAAAFgBQABAAACAAQAGgBAGABQACAAABABQAJABAHACQAIADAFADQAJAEAFAGQAAAAgBAAQgCABgDACQgDADgFADQAAABgBAAQgEADgEADQgBAAAAAAQgFADgEACQgBAAgBABQgBAAgBABQgHACgHACQgJAEgKAFQgGAEgGADQAAABgBABQAAABAAABQgDADgCADQgBAGAAADQAAABAAAAQgCADgBACQgBADgCACQgDADgDACQgDABgDABQgJAAgKgBQgZgCgTgHQgEgCgEgDQgCgBgBgBQgDgGgBgGIAAAA").cp();
	this.shape_545.setTransform(309.5,224.5);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#0C552F").s().p("AhcAcQACgEABgEQACgCABgCIABgBQADgFADgEQADgCACgCQAFgDAGgEQADgDAEgCQABgBABgBQACgCADgCQACgBACgCQAAAAABgBQADgCACgDQACgDACgCQADgCACgCQABgDACgCQACgEABgDQAAgBAAgBQACgDABgCQAAgBAAgBQABgCABAAQgBAAABAAQABAAACABQAAAAAAABQACABADACQABAAAAABQACACADACQAAABAAAAQADACAAACQAAAAABAAQAAADAAABQAAAAAAAAQAAABABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQACgBACgBQACgBABAAQACgBACAAQACgCADgCQAAAAAAAAQABAAABAAQAFgBAFgBQACAAABAAQAHgBAHABQABAAABAAQAKACAIACQAIACAGAEQAJAFAFAGQAAAAgBAAQgCACgCACQgDADgFAEQgBABAAABQgEADgEADQgBAAgBAAQgEADgFACQgBABgCABQAAAAgBABQgHABgIAEQgKAEgKAFQgHAEgGAEQAAABgBABQABAAAAACQgCADAAACQAAAFABAEQAAABABAAQgBACgBADQgCACgDADQgBADgCADQgDABgEABQgJAAgLgBQgbgCgUgHQgFgCgEgDQgCgBgBgBQgDgGgBgGIAAgB").cp();
	this.shape_546.setTransform(309.6,224.7);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#0C562F").s().p("AhcAfQACgEACgEQACgDABgCIABgBQADgFAEgEQADgCACgCQAFgEAHgEQAEgDAEgCQABgBACgBQACgCACgCQACgCACgBQABgBABgBQACgCADgDQACgDACgDQACgCACgDQACgDABgCQACgFABgDQAAgBAAAAQABgEAAgCQAAgBgBgBQABgCgBAAQAAAAAAAAQABAAABACQAAAAABABQACABACACQABABABABQACACACACQAAABABABQABACABACQAAAAAAAAQAAADgBABQAAAAABAAQgBABAAgBQAAAAAAAAQABgBACgBQAAgBAAAAQABAAABgCQABgBABAAQACgBACgBQACgCADgCQABAAAAAAQAAAAABAAQAFgCAGgBQACAAABAAQAIgBAHAAQABABACAAQAKABAJADQAIACAHAEQAJAFAFAHQAAABAAAAQgCACgCADQgEADgEAEQgBABAAABQgEAEgFADQAAAAgBAAQgFADgFADQgBABgCABQgBAAgBABQgHABgJAEQgKAFgLAFQgIAFgGAEQAAAAABABQAAABABABQAAADABADQABAEACADQAAABACAAQgBADABACQgDADgCADQgCADgDAEQgCABgDABQgKAAgLgBQgdgCgWgGQgFgDgFgCQgCgBgCgBQgCgHgBgHIAAAA").cp();
	this.shape_547.setTransform(309.8,224.9);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#0B5630").s().p("AhcAiQACgFADgEQABgCACgDIABgBQAEgFAEgEQADgCACgCQAGgGAIgCQAEgDAEgDQABgCACAAQACgCADgCQACgCACgCQABgBAAgBQADgDACgCQACgEACgDQACgCACgDQACgDABgDQACgFAAgDQAAgBAAgBQAAgEgBgCQAAgBgBgBQAAgCgBABQAAAAAAAAQAAAAAAACQABAAAAABQACACACACQABABABABQACACACADQAAABABAAQABADAAACQABAAAAAAQAAADgCABQAAAAAAAAQgBABAAgBQAAAAgBAAQABgBACgDQAAAAAAAAQABgBACgBQACgCABgBQABgBABgBQACgCAEgCQAAAAAAAAQABAAABgBQAFgBAGgBQACgBACAAQAHgBAIAAQACAAABABQALABAKACQAJADAGAEQAKAGAFAIQAAAAAAAAQgCACgCAEQgDAEgEAFQgBAAAAABQgEAEgFAEQgBAAgBABQgFADgFADQgCABgBABQgBAAgBAAQgIADgJADQgLAGgMAGQgIAEgGAEQAAABABABQABAAACACQAAACACADQADAEADADQABABABAAQABACABACQgCAEgCADQgCAEgDAEQgDABgEAAQgKAAgLAAQgfgCgYgGQgFgCgFgDQgCgBgCAAQgCgHgBgIIAAAA").cp();
	this.shape_548.setTransform(309.9,225.2);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#0A5630").s().p("AhcAlQACgFADgFQACgCACgDIABgBQAEgEAFgFQADgCADgDQAGgFAIgDQAEgDAFgEQABgBACAAQACgDADgCQACgCACgCQABgBABgBQADgDACgDQACgDACgDQACgDACgDQABgEABgDQACgFgBgEQAAgBAAgBQAAgEgCgCQAAgBgCgBQgBgCgCABQAAAAAAAAQAAABAAACQAAABAAAAQACACACADQABAAABABQACADACADQAAABABAAQABADAAADQAAAAAAABQAAACgDABQAAAAABAAQgCABgBgBQAAgBAAAAQAAgBACgDQAAAAAAAAQABgCACgBQACgCABgBQACgBACgBQACgDACgCQAAAAABAAQAAgBABAAQAGgCAHgBQABgBACAAQAIgCAIABQACAAACAAQAMABAJADQAKADAHAFQALAGAEAIQAAABAAAAQgBACgCAEQgDAFgFAFQAAABgBABQgEAEgFAEQAAAAgBABQgGAEgFADQgCABgBAAQgBAAgCAAQgIAEgJAEQgMAFgNAHQgIAEgFAFQABABAAAAQABABACABQACADADACQADAEAFADQABABACAAQACACACACQgCAEgCAEQgCAEgDADQgEACgEAAQgKAAgMAAQgggCgagGQgGgCgFgCQgCgBgCgBQgDgHAAgIIAAAA").cp();
	this.shape_549.setTransform(310,225.4);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#0A5630").s().p("AhdAnQADgFAEgEQACgDACgCIABgCQAFgEAFgFQADgCADgDQAGgGAJgDQAFgDAFgEQABgBACgBQACgCADgCQACgCADgCQABgBABgBQACgEADgDQACgDACgEQABgDACgEQABgDACgDQABgHgBgEQgBgBAAgBQgBgEgCgCQgBgBgBgBQgDgCgCACQAAAAAAAAQgCABAAACQAAABABAAQABADADACQAAABABABQACADACAEQAAAAABABQABADAAADQAAAAAAABQgBADgDABQAAAAAAAAQgDABAAgDQgBAAAAAAQAAgBACgEQAAAAAAAAQABgCACgCQABgCADgBQABgCACgBQADgDADgCQABAAAAAAQAAgBAAAAQAGgDAHgBQACgBABAAQAJgCAJABQACAAACAAQAMABAKADQAKADAIAFQALAGAFAKQAAAAgBAAQgBADgCAEQgCAGgFAFQAAABgBABQgEAFgFAEQgBABgBAAQgFAEgGADQgCABgCAAQgBAAgBABQgJAEgKAEQgMAGgNAHQgKAFgFAFQACAAACABQABABACABQADACADACQAFAEAGADQACAAACAAQACADADABQgCAFgCAEQgCAEgBAEQgFABgEABQgMAAgMgBQghgBgcgFQgGgCgGgDQgDAAgCgBQgCgIgBgIIAAgB").cp();
	this.shape_550.setTransform(310.1,225.6);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#095730").s().p("AhdAqQAEgFADgFQADgCACgDIABgBQAFgFAGgFQADgDADgCQAHgGAJgFQAFgCAGgEQABgBACgBQACgCADgCQADgDACgCQABgBABgBQADgEACgDQACgEACgEQACgDABgEQACgEABgDQAAgHgBgEQAAgBgBgBQgBgFgDgCQgCgBgBgBQgDgCgEACQAAAAAAAAQgCABAAADQAAABAAAAQACADACADQABABAAABQACAEACADQAAABABAAQABAEgBADQAAABAAAAQgBADgEABQAAAAAAAAQgDABgBgDQAAAAAAAAQAAgCABgEQAAAAAAgBQABgCACgCQABgCADgCQABgBACgCQADgDAEgCQAAAAABgBQAAAAABAAQAEgDAIgCQACgBACAAQAJgCAJAAQACABACAAQANABALADQAKADAIAFQAMAHAFAKQAAABgBAAQAAADgCAFQgDAFgEAGQgBABAAABQgEAGgFAEQgBABgBABQgGAEgGADQgCAAgCABQgBAAgBABQgKAEgKAFQgNAGgOAHQgIAFgHAFQACABADABQACAAABABQAEACAFACQAGAEAHADQACAAADAAQADACAEACQgCAFgCAEQgCAFgBAEQgFABgFABQgNAAgMgBQgjgBgegFQgGgCgGgCQgDgBgCAAQgCgIgBgJIAAgB").cp();
	this.shape_551.setTransform(310.3,225.9);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#085731").s().p("AhdAuQAEgGAEgFQACgCADgDIABgCQAGgFAGgFQADgCADgDQAHgGAKgFQAGgCAFgEQACgBACgBQADgDADgCQACgDADgCQABgBABgBQACgEADgEQACgEACgEQABgDACgFQABgEABgDQAAgIgBgEQgBgBgBgBQgCgFgEgDQgBgBgCAAQgEgCgEACQAAAAAAAAQgDACgBADQAAAAAAABQACADACADQABABABABQACAEABAEQABABAAABQABADgBAEQAAAAAAAAQgCAEgEABQAAAAAAAAQgEABgBgDQgBgBAAAAQAAgCABgFQAAAAAAAAQABgDACgCQABgCADgCQABgCACgCQADgDAEgDQABAAAAAAQABAAAAgBQAHgDAGgCQACgBACAAQAJgCAKAAQACAAADAAQANABAMADQALADAIAGQAMAHAFALQAAABAAAAQgBAEgCAFQgCAGgEAGQgBABAAABQgEAGgGAFQgBABgBAAQgGAFgGACQgCABgCABQgCABgBAAQgKAFgKAFQgPAHgOAHQgIAGgIAFQADAAADABQADAAADABQAEACAGACQAHAEAIACQADAAACAAQAFACAEACQgBAFgCAFQgCAFgBAFQgFABgFAAQgOAAgMAAQglgCgggEQgHgCgGgCQgDAAgCgBQgCgJgBgJIAAAA").cp();
	this.shape_552.setTransform(310.4,226);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#085731").s().p("AhdAxQAEgFAEgGQADgCADgDIABgCQAGgFAHgFQADgDAEgCQAHgHAKgFQAGgEAGgCQACgCACgBQADgCADgDQADgCACgDQABgBABgCQADgDACgEQACgEACgFQACgEABgEQAAgEAAgEQAAgIAAgFQgBgBAAgBQgDgGgFgCQgCgBgCgBQgFgBgEACQgBAAAAAAQgDACgBAEQgBAAAAABQACADACADQABACABABQACAEABAEQABABAAABQABAEgCAEQAAAAAAAAQgCAEgFABQAAAAAAAAQgEABgCgEQAAAAAAAAQgBgDABgFQAAgBAAAAQABgCACgDQABgDADgCQABgCADgCQACgDAEgDQABAAAAAAQABgBABAAQAHgEAGgCQACgBACgBQAKgCALAAQACAAACABQAPAAALAEQAMADAJAGQAMAIAFAMQAAAAAAAAQgBAEgBAGQgCAGgFAHQAAABgBACQgEAGgFAFQgBABgBAAQgGAFgHACQgCACgDABQgBAAgBABQgLAFgLAFQgPAHgPAIQgIAGgIAFQADABADAAQAEABAEABQAEABAHACQAJADAKACQACABADAAQAFACAGABQgCAGgBAFQgCAFgBAGQgGAAgFABQgOAAgOgBQglgBgigEQgHgCgHgCQgDAAgDgBQgCgJAAgJIAAgB").cp();
	this.shape_553.setTransform(310.5,226.2);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#075831").s().p("AhdA1QAEgGAFgGQADgCADgDIABgCQAHgFAHgFQADgDAEgDQAIgGAKgGQAHgEAGgDQACgBACgBQADgDADgCQADgDADgDQABgBABgCQADgEACgEQACgEAAgFQABgEABgFQABgEABgEQAAgJgDgFQAAgBgBgBQgCgGgFgDQgCgBgDAAQgFgBgGACQAAAAAAAAQgEACgCAFQAAAAAAABQACADABAEQABABABABQACAFABAEQABABAAABQABAEgCAFQAAAAAAAAQgDAEgFABQAAAAAAAAQgFABgCgEQgBgBAAAAQgBgDABgGQAAAAAAAAQABgDACgDQABgDADgCQABgCADgDQACgDAFgDQAAgBABAAQABAAAAgBQAHgEAJgCQABgBACgBQAKgCALAAQACAAADAAQAPABAMADQAMAEAJAGQANAIAFANQAAAAAAABQAAAEgCAGQgCAHgEAHQAAABgBACQgEAGgGAGQgBABgBAAQgGAFgHADQgCABgDABQgBABgCABQgLAFgLAFQgQAIgOAIQgLAGgIAGQAEAAAEABQAEAAAEABQAGABAIACQAKADALACQADAAADAAQAGACAGABQgBAGgBAGQgCAGgBAFQgGABgFAAQgPAAgQAAQgmgBgkgEQgHgCgHgBQgDgBgDAAQgCgKAAgJIAAgB").cp();
	this.shape_554.setTransform(310.6,226.3);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#075831").s().p("AhdA4QAEgGAFgFQAEgDADgDIACgCQAGgFAHgGQAEgDAEgCQAIgHAMgGQAGgEAHgEQACAAACgCQADgCAEgDQACgDADgDQABgBACgCQACgEABgEQACgFABgFQACgEABgFQABgFAAgEQAAgJgDgGQgBgBgBgBQgDgGgFgDQgDgBgDAAQgGgCgGADQgBAAAAAAQgEADgCAEQgBABAAAAQACAEACAEQAAACABABQACAFACAEQAAABAAABQABAFgCAEQgBABAAAAQgCAEgHABQAAAAAAAAQgFABgDgFQAAAAAAAAQgCgEABgGQAAgBAAAAQABgDACgEQABgCADgDQABgCADgDQADgDAEgEQABAAAAAAQABgBABAAQAHgFAJgDQADAAACgBQAJgDALAAQADAAACABQAQAAANAEQANADAJAHQANAJAFANQAAAAAAABQAAAFgBAGQgCAHgEAIQAAABgBACQgEAHgGAFQgBACgBAAQgHAEgHAEQgDACgCABQgCABgBAAQgMAGgLAFQgRAIgOAIQgMAHgIAGQAEAAAEABQAFAAAFABQAGABAJACQAMADAMABQADABAEAAQAHABAHABQgBAHgCAGQgBAGgBAGQgGAAgGABQgQAAgQgBQgngBgmgDQgIgBgHgCQgDAAgDgBQgCgKAAgKIAAgB").cp();
	this.shape_555.setTransform(310.8,226.5);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#065832").s().p("AheA8QAGgGAFgGQAEgDADgDIACgCQAHgFAHgGQAEgDAEgDQAJgHAMgGQAHgEAHgGQACAAACAAQADgDAEgDQADgDADgDQAAgBAAgCQADgEACgFQACgEACgGQABgEABgGQABgFAAgEQAAgKgEgGQgBgBgBgBQgEgHgGgCQgDgBgDgBQgHgBgHADQAAAAAAAAQgFADgDAFQAAABgBAAQACAEACAFQABABAAABQACAGACAEQAAABAAABQABAFgDAFQAAAAAAABQgDAEgHABQgBAAAAAAQgGAAgCgEQgBgBAAAAQgCgEABgHQAAAAAAAAQAAgEADgEQABgDADgDQACgCACgCQADgEAFgEQAAAAABgBQAAAAABgBQAIgFAJgDQADgBACAAQAKgDAMAAQACAAADAAQARAAANAEQANAEAKAHQANAJAGAOQAAABgBAAQABAFgBAHQgCAIgEAIQgBABAAACQgEAHgGAGQgBABgCABQgGAEgIAFQgDABgDACQgBAAgCABQgMAGgMAGQgRAIgPAIQgMAHgJAGQAFABAFAAQAFABAFAAQAIACAKABQANACANACQADAAAEAAQAIACAIABQgBAGgBAHQgBAGgBAGQgGABgGAAQgRAAgRAAQgpgBgngDQgIgBgIgCQgEAAgDAAQgBgLgBgKIAAgB").cp();
	this.shape_556.setTransform(310.9,226.7);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#055932").s().p("AheA/QAGgGAGgGQADgDAEgDIACgCQAHgGAIgFQAEgEAEgDQAKgGAMgGQAIgFAHgGQACgBACgBQAEgBADgDQACgEACgDQACgBABgCQADgEACgFQACgFABgGQABgFABgFQABgGAAgEQAAgKgFgGQgBgCgBgBQgFgHgGgDQgDgBgEAAQgIgBgHADQAAAAgBAAQgFAEgEAFQAAAAAAABQABAEACAFQABABABACQACAGABAEQAAACAAABQABAFgDAFQAAAAgBAAQgDAFgIABQAAAAAAAAQgHAAgDgFQAAAAgBAAQgCgFABgHQAAgBAAAAQAAgEADgEQABgDADgDQACgDACgCQADgFAFgDQAAgBABAAQABgBABAAQAIgFAKgEQACgBADgBQAJgDANAAQADAAACAAQASABAOAEQANAEAKAHQAPAKAFAOQAAABAAABQAAAFgBAHQgBAIgEAJQgBABAAACQgEAIgHAGQgBABgBABQgHAEgIAFQgDACgDABQgBABgCABQgNAGgMAGQgSAIgQAJQgNAIgIAGQAFAAAFABQAGAAAGAAQAIACALABQAOACAPABQAEABAEAAQAJABAJABQgBAHgBAHQgBAGgBAHQgGABgGAAQgSAAgRAAQgrgBgpgDQgJgBgIgBQgEgBgDAAQgBgLgBgLIAAgB").cp();
	this.shape_557.setTransform(311,226.8);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#055932").s().p("AheBDQAGgHAGgGQAEgDAEgDIACgCQAIgGAIgGQAEgDAFgDQAJgHANgGQAIgGAIgFQACgCACgBQAEgBABgDQAEgDADgEQABgCABgBQADgFACgFQACgFACgGQABgFABgGQAAgGAAgFQgBgKgEgGQgCgCgBgBQgGgHgGgDQgEgBgEAAQgJgBgIAEQAAAAAAAAQgGADgEAGQgBAAAAABQABAFACAEQABACABABQACAGABAGQAAABAAABQABAFgEAFQAAABAAAAQgEAFgJAAQAAAAAAAAQgHABgEgFQAAgBAAAAQgDgEABgJQAAAAAAgBQAAgEADgEQABgDADgEQABgDADgCQADgFAFgEQABAAAAAAQABgBABgBQAIgFALgEQACgBADgBQALgDAMgBQADABADAAQASAAAOAEQAOAEALAIQAPAKAFAPQAAABAAABQAAAFgBAIQgBAJgEAJQAAACgBABQgEAJgGAGQgCABgBABQgHAFgIAFQgDACgDABQgCABgCABQgNAGgNAGQgSAJgRAJQgNAIgJAGQAGABAFAAQAHAAAGABQAKABAMABQAPACAQABQAEAAAFAAQAJABAKABQgBAHgBAIQAAAHgBAHQgHAAgGABQgSAAgSgBQgsgBgsgCQgJgBgIgBQgEAAgEgBQgBgLAAgLIAAgB").cp();
	this.shape_558.setTransform(311.1,227);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#045932").s().p("AheBGQAGgGAGgHQAFgDAEgDIACgCQAIgGAJgGQAEgDAFgEQAKgHANgGQAIgGAJgGQACgBACgBQACgDADgCQAEgDADgEQABgCACgBQADgFACgGQACgFABgGQABgFABgGQAAgGAAgGQgBgKgFgHQgBgCgCgBQgGgHgJgDQgDgBgEAAQgJgCgJAFQgBAAAAAAQgHADgEAGQgBABAAABQACAFABAFQABABABACQACAGABAGQAAABAAABQABAGgEAFQgBABAAAAQgEAFgJAAQAAAAgBAAQgHABgEgGQgBAAAAgBQgDgEABgJQAAgBAAAAQAAgFACgEQACgEADgDQABgDADgDQADgFAFgEQABAAABgBQABgBAAAAQAJgGALgEQACgBADgBQANgEALAAQADAAADAAQATAAAPAFQAOAEALAIQAQALAFAQQAAAAAAABQABAGgBAIQgBAKgEAJQgBACAAABQgEAJgHAHQgBABgBABQgIAFgIAFQgDACgEACQgBABgCAAQgOAHgNAGQgTAJgSAKQgNAIgKAHQAHAAAGAAQAHAAAGABQALABANABQARABARABQAFABAEAAQALAAALABQgBAIgBAIQgBAHAAAHQgHABgHAAQgSAAgTAAQgugBgtgCQgJgBgJgBQgEAAgEAAQgBgMAAgLIAAgC").cp();
	this.shape_559.setTransform(311.3,227.1);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#035933").s().p("AhfBKQAHgHAHgHQAEgDAFgDIACgCQAJgGAJgGQAEgEAFgDQAKgIAOgGQAJgGAJgGQABgBABgCQAEgDAEgBQADgEAEgEQABgCABgBQADgFACgGQACgFABgHQABgFABgHQAAgGAAgGQgBgLgGgHQgBgCgCgBQgHgIgKgDQgCgBgGAAQgJgBgKAFQAAAAAAAAQgIAEgFAGQAAABgBABQACAFABAFQABACABABQACAHABAGQAAABAAABQAAAGgEAGQAAAAAAABQgFAFgKAAQAAAAAAAAQgJABgEgGQAAgBgBAAQgDgFABgKQAAAAAAgBQAAgEACgFQACgEACgEQACgDADgDQADgFAGgEQAAgBABAAQABgBABgBQAIgGAMgEQACgBADgBQANgEANgBQADABACAAQAUAAAQAEQAPAFALAIQAQALAFARQAAABAAAAQABAHgBAIQgBAKgDAKQgBACAAABQgEAKgHAHQgCABgBAAQgHAGgJAGQgEACgDABQgCABgCABQgOAHgOAGQgTAKgTAKQgOAIgJAHQAGAAAHABQAHAAAIAAQAMABAOABQASABASABQAFAAAFAAQALABAMAAQgBAIAAAJQgBAHgBAIQgGAAgHABQgUAAgTgBQgvAAgwgCQgJgBgJAAQgFgBgEAAQAAgMgBgMIAAgB").cp();
	this.shape_560.setTransform(311.4,227.3);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#035A33").s().p("AhfBNQAHgHAHgHQAFgDAFgDIACgCQAJgGAJgHQAFgDAFgEQAKgHAPgHQAJgGAHgGQADgCACgBQAEgDAEgDQADgDAEgEQABgCACgBQACgGADgGQACgFABgHQABgGAAgHQAAgGAAgGQgBgMgHgHQgBgCgCgBQgHgIgMgDQgCgBgGAAQgKgBgKAFQgBAAAAAAQgIAEgFAHQgBABgBAAQACAGACAFQAAACABACQACAHABAGQAAABAAABQAAAHgEAGQgBAAAAABQgFAFgKAAQgBAAAAAAQgJABgEgHQgBAAAAgBQgEgFABgKQAAgBAAAAQAAgFACgFQACgEACgEQACgEADgDQAEgFAFgFQAAAAABgBQABAAABgBQAJgHALgEQAEgCADgBQANgDANgBQADAAADAAQAUAAAQAFQAQAEALAJQAQALAGASQAAABAAABQABAGAAAJQgBALgEAKQAAACgBABQgEAKgHAHQgBABgCAAQgHAIgJAFQgEACgEACQgCABgCABQgOAHgOAHQgUAKgTAKQgPAIgKAIQAHAAAHAAQAIAAAIAAQAOABAOABQATABAUAAQAFAAAFAAQANABAMABQAAAIgBAIQAAAJgBAIQgHAAgHAAQgUAAgUAAQgxAAgxgCQgKAAgKgBQgEAAgEAAQgBgNAAgMIAAgC").cp();
	this.shape_561.setTransform(311.6,227.4);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#025A33").s().p("AhfBRQAHgHAIgIQAEgDAFgDIADgCQAJgHAKgGQAFgEAFgEQALgHAPgHQAKgGAHgHQACgBADgBQAEgEAEgDQAEgCADgFQACgCABgBQADgGACgGQACgGABgHQABgGAAgHQABgHgBgGQgCgMgGgIQgCgBgCgCQgIgIgMgDQgEgBgFAAQgLgBgLAFQAAAAgBAAQgIAFgGAHQgBAAgBABQACAGACAGQAAABABACQACAIABAGQAAABAAACQAAAGgFAGQAAABgBAAQgFAGgLAAQgBAAAAAAQgJABgFgHQgBgBAAAAQgEgGABgLQAAAAAAgBQgBgFADgFQABgFADgEQACgDADgEQAEgFAFgFQABgBABAAQAAgBABgBQAKgHALgEQAEgCADgBQANgEAOgBQADAAADAAQAVAAARAFQAQAFAMAJQAQAMAGASQAAABAAABQACAHgBAJQAAALgEALQgBACAAABQgEALgHAHQgCAAgBABQgIAIgKAGQgDACgEACQgCABgCABQgPAHgPAHQgTAKgVALQgQAJgKAHQAIAAAIAAQAIAAAIABQAQAAAPAAQAUABAVABQAFAAAGAAQANAAAOABQgBAJAAAIQAAAJgBAIQgHABgHAAQgVAAgVAAQgzgBgzgBQgKAAgKgBQgEAAgFAAQAAgNAAgNIAAgB").cp();
	this.shape_562.setTransform(311.7,227.6);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#015A33").s().p("AhhBUQAIgHAIgHQAFgEAFgDIACgCQAKgHALgHQAFgDAFgEQALgIAQgHQAKgGAIgHQACgBACgCQAEgDAFgEQAEgCADgFQACgCABgCQADgFACgHQACgFABgIQABgGAAgIQAAgHAAgGQgCgNgHgIQgCgBgCgCQgJgJgNgDQgEgBgFAAQgMAAgMAFQAAAAgBAAQgJAFgGAHQgBABgBABQACAGABAGQABACAAACQACAIABAGQAAABAAACQAAAHgFAGQAAABgBAAQgFAGgMAAQgBAAAAAAQgKABgFgIQgBAAAAgBQgEgGAAgLQAAgBAAAAQAAgGACgGQACgEADgFQACgDADgEQADgFAGgGQABAAAAAAQABgBABgBQAKgIAMgFQADgBAEgBQAOgEAQgBQABAAADAAQAWAAARAFQARAEAMAKQARAMAGATQAAABgBABQADAIgBAJQAAAMgEALQAAACgBACQgEAKgHAHQgCABgBABQgIAIgKAGQgEADgEABQgCABgCABQgPAIgPAHQgUALgXAKQgQAKgKAHQAIAAAJABQAIAAAJAAQARAAAQAAQAWABAWAAQAFAAAGAAQAPABAOAAQAAAJgBAJQAAAJAAAJQgIAAgHAAQgWAAgWAAQgzAAg2gBQgKAAgKAAQgFAAgEgBQgBgNAAgNIAAgC").cp();
	this.shape_563.setTransform(312,227.8);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#015B34").s().p("AhkBYQAIgIAJgHQAFgEAFgDIADgCQAKgHALgHQAFgEAFgEQAMgIAQgGQALgHAIgHQACgCADgBQAEgEAEgEQAEgDAEgEQACgCABgCQADgFACgHQACgGABgIQABgGAAgIQAAgHgBgHQgCgNgIgIQgCgCgBgCQgKgJgOgDQgDgBgHAAQgNgBgMAGQAAAAgBAAQgKAFgGAIQgBABgBABQABAGACAGQAAACABACQACAIABAHQAAACAAABQAAAHgGAHQAAAAgBABQgGAGgMAAQgBAAAAAAQgLABgFgIQgBgBAAAAQgEgHAAgMQAAAAAAgBQgBgGADgGQABgEADgFQACgEADgEQAEgGAGgFQAAAAABgBQABgBABgBQAKgHANgGQADgBADgBQAPgFAQgBQAEAAADAAQAVAAARAFQARAFANAKQASANAFAUQAAABAAAAQACAIAAAKQAAAMgEAMQAAACgBACQgEALgHAGQgCACgBABQgJAIgKAHQgEACgEACQgCABgCABQgQAIgPAHQgVALgXALQgRAKgKAIQAJAAAIAAQAKAAAJAAQASAAARAAQAXABAXAAQAGAAAGAAQAQAAAPAAQAAAKgBAJQAAAJAAAKQgIAAgHAAQgXAAgWAAQg1AAg4gBQgKAAgLAAQgFAAgEAAQgBgOAAgNIAAgC").cp();
	this.shape_564.setTransform(312.4,227.9);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#005B34").s().p("AAbhZQAQANAAAbQAAASgEALQgDAKgFAHQgIAIgJAHIgYASQgRAHgMAIIguAfIgRAPIAAAeIDNAAIAAgnIioAAQAKgIASgKIBRgoQAQgIALgMQAKgHAFgOQAFgOAAgPQAAgjgagTQgagVgsABQgVAAgSAFQgRAGgNALQgMAKgGAMQgIAMABAMQAAANAFAHQAHAJAKgBQAOAAAHgGQAHgIAAgIQAAgIgDgKIgDgRQAHgKAMgGQAOgGANABQAWAAAOANIAAAA").cp();
	this.shape_565.setTransform(312.8,228.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_541}]}).to({state:[{t:this.shape_542}]},32).to({state:[{t:this.shape_543}]},1).to({state:[{t:this.shape_544}]},1).to({state:[{t:this.shape_545}]},1).to({state:[{t:this.shape_546}]},1).to({state:[{t:this.shape_547}]},1).to({state:[{t:this.shape_548}]},1).to({state:[{t:this.shape_549}]},1).to({state:[{t:this.shape_550}]},1).to({state:[{t:this.shape_551}]},1).to({state:[{t:this.shape_552}]},1).to({state:[{t:this.shape_553}]},1).to({state:[{t:this.shape_554}]},1).to({state:[{t:this.shape_555}]},1).to({state:[{t:this.shape_556}]},1).to({state:[{t:this.shape_557}]},1).to({state:[{t:this.shape_558}]},1).to({state:[{t:this.shape_559}]},1).to({state:[{t:this.shape_560}]},1).to({state:[{t:this.shape_561}]},1).to({state:[{t:this.shape_562}]},1).to({state:[{t:this.shape_563}]},1).to({state:[{t:this.shape_564}]},1).to({state:[{t:this.shape_565}]},1).wait(17));

	// 1
	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#537352").s().p("ABdgHQgXgDgOAFQgSAFgSAKQgSANgMAHQgZANgXgDQgZgDgHgPQgFgLAEgLQAEgKAOgMQAUgQAcgCQAbgCArAOQAkAMAMAJIAAAA").cp();
	this.shape_566.setTransform(387,314.1);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#537352").s().p("ABGgDQAGABAEACQAEABADADQADABABACQgZgDgQAFQgQAFgQAHQgDABgDABIAAAAQgGAGgFAEQgBABAAABQgDABgCABQgDABgCAAQgXAHgVgIQgMgEgIgHQgHgEgEgGQgEgFgBgGQAAgFABgEQACgDACgDQAGgHAKgHQABgBABgBQAHgFAGgEQAFgCAGgCQALgCANACQAYAFAnAUQABAAABABQAEACAEABQADACADABQAFACAFACIAAAA").cp();
	this.shape_567.setTransform(387.3,314.1);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#537352").s().p("AhZABQABgBABgCQAAgDABgCQACgDACgCQAEgEAEgDQAFgEAFgEQABgBABgBQAAAAAAAAQAFgDAEgDQACgBADgBQAEgCAGgBQAKAAAMADQAUAHAfASQADACAFADQABAAABABQABAAABABQAEACAEABQABABABAAQACABACAAQAEAAADACQACABACAAQACABABABQADAAADACQADADACACQACACACABQgbgCgRAEQgFACgFABQgDABgDABQgHACgHADQgBABgDABQAAAAgBAAQAAAAAAAAQgBABgBABQgCACgCACQgCABgCABQgBABAAAAQgCABgDAAQgCABgCAAQgWAEgUgKQgFgCgDgCQgHgDgGgFQgHgDgFgGQAAAAAAAAQgDgFgCgFIAAgC").cp();
	this.shape_568.setTransform(387.3,314.1);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#537352").s().p("AhXAAQABgDABgCQABgCABgDQACgDADgCQADgDAFgEQAFgEAGgEQABgBABgCQAAAAAAAAQAFgCAEgCQADgCACAAQAEgBAFgBQAKACAMAEQATAKAcAUQAEADAEACQABAAACAAQABABABABQAEABAEACQABAAACABQACABACAAQADACAEABQACABACABQACABABAAQACABACACQADACACADQABABABACQgbgDgTAFQgFABgGABQgDAAgDABQgFACgGADQgBAAgCABQAAAAgBABQAAAAAAgBQgBABAAABQgDABgBABQgCABgCABQgBABAAAAQgCAAgCAAQgDAAgBAAQgVABgTgLQgEgDgEgDQgIgDgFgEQgIgEgFgFQAAAAAAAAQgDgFgCgFIAAAA").cp();
	this.shape_569.setTransform(387.4,314.1);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#537352").s().p("AhVgEQABgDABgCQACgDABgCQACgCADgDQAEgDAGgEQAFgEAGgEQABgCABgBQAAAAAAAAQAFgCAFgDQACAAACgBQAFAAAEAAQAKADALAFQARAOAbAVQAEACAEADQABABABABQACABABABQAEABAFACQABAAABABQACABADAAQADABAEACQACABABABQACABABABQACABACABQACADABACQABABAAACQgcgDgVAFQgFABgFABQgDAAgDAAQgFACgEACQgBABgBAAQgBABAAAAQAAAAAAgBQAAABgBAAQgCACgCAAQgBAAgCAAQgBABAAAAQgCAAgCgBQgCAAgCgBQgTgBgSgNQgEgDgEgEQgIgDgGgDQgIgEgGgFQAAAAAAAAQgDgFgBgEIAAgB").cp();
	this.shape_570.setTransform(387.5,314.2);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#537352").s().p("AhTgJQABgCACgDQABgCACgCQADgCADgDQAEgDAGgEQAGgEAFgEQACgCABgBQAAAAAAAAQAFgDAGgCQACAAACAAQAEABAEAAQAJAFAKAGQAQAQAaAXQADAEAEADQACABABABQABABACABQAEABAFACQABAAABABQADABACAAQAEABAEACQACABABABQACACABABQABABABABQABACABACQABABgBACQgdgCgWAEQgGABgFABQgDgBgDAAQgDABgDADQgBAAgBABQAAAAAAAAQAAAAAAgBQAAABgBAAQgBABgCAAQgBAAgCgBQgBABAAgBQgBAAgCgCQgCAAgCgBQgSgEgRgPQgEgEgDgEQgJgCgHgEQgIgDgGgFQAAAAAAAAQgDgEgBgGIAAgB").cp();
	this.shape_571.setTransform(387.6,314.3);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#537352").s().p("AhSgNQACgDACgCQACgCABgCQADgCAEgDQAFgDAFgEQAHgEAGgFQACgBABgCQAAAAAAAAQAFgCAGgCQACAAACABQADABAFABQAIAGAJAIQAPATAYAZQADAEAFADQABACACABQABAAABABQAEACAGACQABAAABAAQADABACABQAEABAFACQABABACABQABACABABQABABAAABQABACAAACQAAABgBACQgegCgYADQgGABgGACQgCgCgDgBQgCACgCACQAAAAAAABQAAAAAAAAQAAAAAAgBQAAAAgBAAQgBABgBgBQgCAAgBgBQgBAAAAgBQgBgBgCgCQgCgBgCgBQgRgGgQgSQgDgDgDgFQgJgCgIgEQgJgDgGgCQAAAAAAAAQgDgGgBgGIAAgB").cp();
	this.shape_572.setTransform(387.7,314.5);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#537352").s().p("AhRgSQACgCACgDQACgBACgCQAEgCAEgDQAFgDAGgEQAHgEAGgFQACgCABgBQAAAAAAAAQAGgDAGgBQACAAABABQAEACAEACQAHAHAIAJQAPAWAWAcQADAEAEADQACACACABQABABABABQAEACAGABQACABABAAQADABACAAQAEACAFABQABACACABQABACABABQAAABAAABQAAACgBACQAAABgBABQgggCgZAEQgGABgGABQgDgCgCgBQgBABgBACQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQgBAAgBgBQgBgCgCgBQAAAAAAgBQgCgCgBgCQgCgBgCgCQgQgJgOgTQgEgEgDgFQgJgDgJgDQgJAAgGgFQAAAAAAAAQgDgGgBgGIAAgB").cp();
	this.shape_573.setTransform(387.8,314.6);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#537352").s().p("AhRgYQADgCACgCQACgCADgBQADgCAEgDQAGgDAGgEQAIgEAGgGQACgBACgCQAAAAAAAAQAGgCAGgCQABABACACQADACAEACQAHAJAGALQAPAZAUAeQADAEAEAEQACACACABQABABABABQAFACAGABQABAAACABQADABACAAQAEABAFACQABACACABQABACABACQgBAAAAABQgBACgBACQgBABgCABQgggCgbAEQgGABgHABQgCgDgCgCQAAABAAACQABAAABAAQAAAAABAAQAAAAAAgBQAAAAAAAAQgBAAgBgCQgBgCAAgBQAAgBgBgBQgCgCgCgDQgBgBgCgCQgPgMgNgVQgDgFgDgFQgKAAgJgDQgJgDgHgEQAAAAgBAAQgCgGgBgHIAAgB").cp();
	this.shape_574.setTransform(388.1,314.9);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#537352").s().p("AhRgeQADgCADgCQACgBADgCQAEgCAEgCQAGgDAHgEQAIgFAGgFQACgCACgCQAAAAAAAAQAGgCAHgBQABABACACQADADADADQAGAKAGAMQAOAcASAgQADAFAEAEQABACADACQABAAABABQAFADAHABQABAAACAAQACABADABQAFABAEABQABACACACQABACABACQgBABgCABQgBABgCACQgBABgCABQghgCgdADQgGABgFABQgCgDgDgCQACABACABQABAAAAAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAgBgBgDQAAgCgBgCQgBgBgBgBQgBgDgCgDQgBgCgCgCQgNgPgNgXQgDgEgCgEQgLgDgKgCQgJgDgHgDQgBAAAAAAQgCgHgBgHIAAgB").cp();
	this.shape_575.setTransform(388.3,315.1);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#537352").s().p("AhRgkQADgBAEgCQACgBADgCQAFgCAEgCQAGgDAHgEQAJgFAGgGQADgCABgBQAAAAAAAAQAHgCAHgBQABABABACQADAEADAEQAGALAFANQAMAfASAjQACAFAEAEQABACADACQABABACABQAEACAHABQACABABAAQADABADAAQAFACAFABQABACABACQABACABACQgCABgCABQgCABgCACQgCABgCABQgjgCgdADQgGABgHAAQgCgDgCgDQADABADABQACAAABAAQABAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAgDQgBgDgCgDQAAgBgBgBQgCgDgBgEQgBgCgBgDQgNgRgMgYQgCgFgDgGQgLgCgKgCQgKgCgIgEQAAAAAAAAQgCgHgBgHIAAgB").cp();
	this.shape_576.setTransform(388.5,315.4);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#537352").s().p("AhRgqQAEgBADgCQADgBADgBQAFgCAFgCQAHgDAHgEQAJgFAHgGQACgCACgCQAAAAAAAAQAHgCAHgBQABACABADQADAEACAEQAEANAGAPQALAiAQAlQACAFAEAEQABADADACQABABACABQAFACAHABQABAAACABQADAAADABQAFABAFABQABADABACQABACABADQgDAAgCABQgCABgDACQgDAAgDABQgjgBgfACQgGABgHABQgCgEgCgDQAEAAAEABQACAAACAAQABAAABgBQAAAAAAgBQABAAAAgBQABgBgBgEQgBgDgBgDQgBgCgBgCQgBgDgBgEQgBgDgBgDQgMgUgKgYQgDgHgCgGQgMgCgKgCQgKgCgJgDQAAAAAAAAQgCgHgBgIIAAgB").cp();
	this.shape_577.setTransform(388.8,315.6);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#537352").s().p("AhRgvQAEgCAEgBQADgBAEgCQAFgBAFgDQAHgDAHgEQAKgFAHgGQACgCACgCQAAAAAAAAQAHgBAIgBQABACABADQACAFACAFQADAOAGAQQAKAkAOApQACAFAEAFQABACADACQACABABABQAFADAIABQABAAACAAQADABADAAQAFACAFABQABADABACQABACABADQgDAAgDABQgDABgEABQgDABgDABQglgBgeACQgIABgIAAQgBgEgCgEQAFAAAFABQADAAACAAQABgBABAAQABAAAAgBQABgBAAgBQABgBgBgFQgBgDgBgEQAAgCgBgCQgBgEgBgEQgBgDgBgEQgLgWgJgbQgCgGgCgHQgMgCgMgCQgKgCgJgDQAAAAAAAAQgCgHgBgIIAAAA").cp();
	this.shape_578.setTransform(389,315.9);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#537352").s().p("AhQg1QAEgCAEgBQADgBAEgBQAFgCAGgCQAHgDAIgEQAKgFAHgGQACgCACgDQAAAAAAAAQAIgBAIgBQABADABAEQAAAFACAGQAEAQAFARQAJAlAMAsQACAGAEAFQABADADACQACABABABQAFACAIABQACABACAAQADABADAAQAFABAFABQABADABADQABADAAACQgDABgEAAQgDABgEABQgEABgEABQglgBggACQgIAAgIABQgCgFgBgEQAGAAAHAAQACAAADAAQACgBABgBQAAAAAAAAQABgBABgBQABgCgBgGQAAgDgBgEQgBgCAAgDQgBgEgBgFQgBgEgBgEQgJgZgJgcQgCgHgBgIQgNgBgMgCQgLgCgJgCQAAAAAAAAQgCgIAAgIIAAAA").cp();
	this.shape_579.setTransform(389.3,316.1);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#537352").s().p("AhQg7QAEgBAFgBQADgBAEgBQAGgCAFgCQAIgDAIgEQALgFAHgHQADgCACgCQAAAAAAAAQAIgBAGgBQAAADABAEQACAGACAGQADASAFASQAHApALAuQACAGAEAFQABADADACQACABABABQAGADAIABQABAAACAAQAEABADABQAFABAGABQAAADABADQABADAAACQgEABgEAAQgEABgFABQgEABgEAAQgngBghACQgJABgIAAQgBgFgBgFQAHAAAIAAQADAAADgBQACAAABgBQABAAAAgBQABgBAAgBQACgCAAgGQgBgFgBgEQAAgCgBgDQgBgFgBgFQAAgEgBgEQgIgcgIgfQgBgHgCgIQgNgBgNgCQgKgBgKgCQAAAAgBAAQgBgIAAgJIAAAA").cp();
	this.shape_580.setTransform(389.5,316.4);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#537352").s().p("AhQhBQAFgBAEgBQAEgBAEgBQAGgBAGgCQAIgDAIgEQALgGAIgGQADgDACgCQAAAAAAAAQAIgBAGgBQABAEABAEQABAHACAHQADATAEATQAGAsAJAxQACAGAEAFQABAEADACQACABACABQAFADAIABQACAAACAAQAEABADAAQAFABAGACQABADAAADQABADAAADQgEAAgFAAQgFABgFABQgFABgEAAQgogBgjACQgJAAgJABQgBgGgBgFQAJgBAJAAQAEAAADgBQACAAACgCQAAAAAAAAQABgBABgCQACgCAAgHQgBgFAAgFQgBgCAAgDQgBgGgBgGQgBgEAAgEQgHgegGghQgCgIgBgIQgOgBgNgCQgLgBgKgCQAAAAgBAAQgBgIAAgJIAAAA").cp();
	this.shape_581.setTransform(389.7,316.7);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#537352").s().p("AhQhHQAFgBAFAAQAEgBAFgBQAGgBAGgCQAJgDAIgEQALgGAIgHQADgCACgDQAAAAAAAAQAIAAAHgBQABAEABAFQABAHABAIQADAUADAVQAFAuAHAzQACAHAEAGQABADADACQACACACABQAFACAJABQACABACAAQADAAAEABQAGABAFABQABAEAAADQABADAAADQgFAAgFABQgGAAgGABQgFAAgFABQgpgBgkABQgJABgJAAQgBgGgBgGQAKgBAKAAQAEAAAEgBQACgBACgBQAAAAABAAQABgCABgBQADgDgBgIQAAgFgBgFQAAgDgBgDQAAgGgBgHQgBgEAAgFQgGghgFgiQgBgJgBgJQgPgBgOgBQgLgBgKgBQgBAAAAAAQgBgJAAgJIAAAA").cp();
	this.shape_582.setTransform(390,316.9);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#537352").s().p("AhQhNQAFAAAGgBQAEgBAFAAQAGgBAHgCQAJgDAIgFQAMgFAJgHQADgDACgCQAAAAAAAAQAHgBAIgBQABAFAAAFQABAIACAIQABAWACAWQAFAyAFA1QACAHAEAGQABAEADACQACABACABQAGADAJABQACAAACAAQADABAEAAQAGABAGACQAAADAAAEQABADAAADQgGAAgFABQgGAAgHABQgGAAgFAAQgqAAgmABQgJAAgKABQAAgHgBgGQALgBALgBQAFAAAEgBQADgBABgBQABAAAAgBQACgBABgCQADgDgBgIQAAgGgBgGQAAgDAAgEQgBgGAAgHQgBgFAAgFQgFgjgEglQgBgJgBgJQgPgBgOgBQgLAAgLgCQgBAAAAAAQgBgJAAgJIAAAA").cp();
	this.shape_583.setTransform(390.2,317.2);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#537352").s().p("AhQhTQAGAAAGgBQAEAAAFgBQAHgBAHgCQAJgCAJgFQAMgGAJgHQADgCACgDQAAAAAAAAQAHgBAJAAQABAFAAAGQABAIABAJQABAXABAYQADA0AEA4QACAHAEAGQABAEADADQACABACABQAGADAJABQACAAACAAQAEAAAEABQAGABAGABQAAAEAAAEQABADAAADQgGABgHAAQgGAAgHABQgGAAgHAAQgqAAgoAAQgKABgJAAQgBgHAAgHQAMgBANgBQAEgBAFAAQADgBACgCQAAAAABAAQABgCABgCQAEgEAAgIQgBgGAAgGQAAgEgBgEQAAgHAAgHQgBgFAAgGQgDgkgEgoQAAgKgBgJQgPgBgPgBQgMAAgLgBQgBAAAAAAQgBgJAAgJIAAgB").cp();
	this.shape_584.setTransform(390.5,317.4);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#537352").s().p("AhQhZQAGAAAGAAQAFAAAFgBQAIgBAHgCQAJgCAJgFQANgGAJgHQADgDABgDQAAAAAAAAQAJAAAJAAQABAFAAAGQAAAJABAJQABAZAAAZQACA3ADA6QABAIADAGQACAEAEADQABACACABQAGACAKABQACAAACABQAEAAAEABQAGABAGABQAAAEABADQAAAEAAAEQgHAAgHAAQgHAAgIABQgGAAgHAAQgqAAgrAAQgKAAgKAAQAAgHAAgHQANgCAOgBQAFgBAFAAQADgBACgCQABAAAAgBQACgBABgCQAEgFAAgJQAAgGgBgHQAAgEAAgEQAAgHAAgIQgBgGAAgGQgCgmgCgqQgBgLAAgKQgQAAgQAAQgMgBgMAAQAAAAAAAAQgBgKAAgJIAAgB").cp();
	this.shape_585.setTransform(390.7,317.7);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#537352").s().p("AhQheQAHgBAGAAQAFAAAGAAQAHgBAHgCQALgDAJgEQANgGAJgIQABgDADgDQAAAAAAAAQAKAAAJAAQAAAGABAGQAAAKAAAKQAAAaAAAaQABA6ABA9QABAIADAHQACAEAEADQACABACABQAFADALABQACAAACAAQAEABAEAAQAGABAGABQABAFAAADQAAAEAAAEQgIAAgHAAQgIAAgIAAQgHAAgHABQgrgBgtABQgKAAgKAAQAAgIgBgIQAPgCAPgBQAGgBAFgBQADgBADgBQAAAAABgBQACgCABgCQAEgFAAgKQAAgHAAgHQAAgEAAgEQAAgIgBgIQAAgGAAgGQgBgqgBgsQAAgKAAgLQgRAAgQAAQgNgBgMAAQAAAAgBAAQAAgKAAgJIAAAA").cp();
	this.shape_586.setTransform(390.9,317.9);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#537352").s().p("AAHiCQgHAKgUAKQgVAKgZAAIgOAAIAAAUIA8AAIAACmQAAAKgEAFQgEAGgHACIgsAGIAAAQICgAAIAAgQIgVgDQgOgBgGgDQgIgDgDgHQgDgHgBgIIACjVIgUAA").cp();
	this.shape_587.setTransform(391.2,318.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_566}]}).to({state:[{t:this.shape_567}]},36).to({state:[{t:this.shape_568}]},1).to({state:[{t:this.shape_569}]},1).to({state:[{t:this.shape_570}]},1).to({state:[{t:this.shape_571}]},1).to({state:[{t:this.shape_572}]},1).to({state:[{t:this.shape_573}]},1).to({state:[{t:this.shape_574}]},1).to({state:[{t:this.shape_575}]},1).to({state:[{t:this.shape_576}]},1).to({state:[{t:this.shape_577}]},1).to({state:[{t:this.shape_578}]},1).to({state:[{t:this.shape_579}]},1).to({state:[{t:this.shape_580}]},1).to({state:[{t:this.shape_581}]},1).to({state:[{t:this.shape_582}]},1).to({state:[{t:this.shape_583}]},1).to({state:[{t:this.shape_584}]},1).to({state:[{t:this.shape_585}]},1).to({state:[{t:this.shape_586}]},1).to({state:[{t:this.shape_587}]},1).wait(16));

	// division symbol
	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#10532D").s().p("Ag4gFQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLQgUgQgdgCQgbgCgrAOQgkAMgMAJIAOgBQAPAAAIADIAAAA").cp();
	this.shape_588.setTransform(524,193.1);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#0F542E").s().p("AhRgIIgMAAQAEgCAEgCQgBAAAAAAQAKgJAigLQAdgKAUgCQAiACAOAGQAIAEAGAGQACABACACQABABACABQABABACABQAKALAEAJQAAACAAACQABAJgEAHQgCAFgEADQgHAMgVADQgWADgYgMQgDgBgDgCQgQgLgHgFQgIgEgIgEQgJgFgIgDQgIgBgOgBQgGABgGAAQADgDAGgDQgCAAgCgBIAAAA").cp();
	this.shape_589.setTransform(524,193.1);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#0E552F").s().p("AhdgIQADgCAFgCQgBAAAAAAQALgJAhgKQAdgJAUgCQAiACAPAGQAHAEAHAFQACABABACQACABACAAQABABACACQACACACADQAHAIACAGQAAADABACQAAAFgBAFQgBADgCACQgDAEgDAEQgIALgUADQgXADgXgLQgDgCgDgCQgQgKgHgEQgIgEgIgEQgJgFgJgCQgIgCgOAAQgDAAgDAAQgDAAgDAAQAEgDAFgDQgCgBgBAAIgMgBIAAAAAhZgEQADgBAEgCQAJgKAggLQAcgKATgBQAjACAMAGQANAIABABQAFAEABABQANANADAIQAAADABACQAAAFgCAGQgBACgBACQgCAEgDADQgHAMgUADQgEABgEAAQgRABgTgKQgDgBgDgCQgEgEgGgDQgHgFgFgCQgHgFgIgEQgJgEgIgDQgBAAgCgBQgHgCgLgBQgGAAgGAAQAEgBAFgDQgCAAgBAAQgGAAgGgBAhZgKQADgCAEgCQAJgJAdgKQAfgLAUgCQAiACAMAGQAMAHACACQAHAGACACQAKAKADALQAAAAABACQAAADgBAEQAAAEgDAEQgCAEgDAEQgHAMgUACQgBAAgBAAQgUAEgWgLQgDgCgDgCQgEgCgBgCQgLgHgGgDQgIgEgHgEQgJgFgHgBQgBAAAAAAQgHgDgOgBQgGABgGgBQAEgDAFgCQgCgBgBAAQgFAAgFAAIgCAA").cp();
	this.shape_590.setTransform(524,193);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#0D552F").s().p("AhdgIQADgCAEgCQAAAAAAAAQAMgIAggKQAdgJAUgBQAiABAPAGQAIAEAGAFQACABACABQACABABABQACABABABQADACACADQAGAIACAHQAAACABACQAAAFgBAFQgBADgCADQgDADgDADQgJALgUADQgWADgXgLQgEgBgDgCQgPgKgIgEQgIgEgIgDQgJgEgJgDQgIgDgOAAQgDAAgDAAQgDAAgCAAQADgCAFgEQgCAAgBAAIgLgCIAAAAAhVAAQADgBAEgCQAIgKAfgKQAagKATgCQAhACAMAGQAMAIABABQAFAEABABQAMAMAEAJQAAACAAACQAAAFgBAGQgBABgBACQgCAEgDADQgHAMgTADQgEABgDAAQgRABgSgJQgDgBgDgCQgEgEgFgDQgIgEgEgCQgHgEgIgEQgIgEgIgDQgBgBgBAAQgHgDgLgBQgGABgFgBQADgDAFgCQgCAAgBAAQgGAAgFAAAhVgNQADgCAEgCQAIgJAcgKQAdgLATgBQAhACAMAGQALAHACACQAHAGACABQAJAKAEAKQAAADAAABQAAACAAADQgBAEgCAEQgCAEgEADQgGAMgTADQgBAAgBAAQgTADgVgKQgDgBgDgCQgEgCgBgCQgLgHgFgDQgIgEgHgEQgIgDgHgCQgBAAAAAAQgHgDgNgBQgGAAgFAAQADgDAFgDQgCAAgBAAQgFgBgEAAIgCAA").cp();
	this.shape_591.setTransform(524.1,193);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#0D5630").s().p("AhdgIQADgCAEgCQAAAAAAAAQAMgHAggKQAdgIAVgBQAhABAQAFQAHAEAHAEQACACACABQABABACABQABAAACACQADACACACQAGAIACAHQAAACAAADQABAFgCAFQgBACgCADQgDADgDADQgJAKgUACQgWADgYgKQgDgBgDgCQgPgJgJgEQgIgDgIgEQgJgDgJgDQgIgDgOAAQgDAAgDAAQgCAAgDgBQADgBAFgEQgCgBgBAAIgKgCIAAAAAhRADQACgCAEgBQAIgJAdgKQAZgKASgBQAgACAMAGQALAHABABQAFAEABABQAMAKADAKQAAACAAACQABAFgCAFQgBACgBACQgCADgDADQgGAMgSADQgDABgEAAQgQABgRgIQgDgBgCgBQgFgEgFgDQgHgEgEgCQgHgEgHgEQgJgEgHgDQgBAAgBgBQgHgCgKgBQgGAAgFAAQADgDAFgDQgCgBgBAAQgFAAgFAAAhRgQQACgBAEgCQAIgJAbgKQAcgLASgBQAfACAMAGQALAGABACQAHAGACABQAJAKADAKQAAACAAACQAAADAAABQAAAEgDAEQgCAEgDADQgGALgSADQgBAAgBAAQgSAEgUgKQgDgBgDgBQgEgCgBgDQgKgFgFgDQgIgEgHgEQgHgCgHgDQgBAAAAAAQgHgDgMgBQgGAAgFgBQADgCAFgDQgCgBgBAAQgFAAgEgBIgBAA").cp();
	this.shape_592.setTransform(524.1,192.9);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#0C5730").s().p("AhegIQAEgCAEgCQAAAAAAAAQANgHAggJQAcgHAVgBQAhABAQAFQAIADAGAEQACABACABQACABABABQACABACABQACACADACQAFAIACAHQAAADAAACQABAFgBAFQgCACgCADQgDADgDACQgKAKgUACQgWADgXgKQgEgBgCgBQgQgJgJgDQgIgEgIgDQgJgDgJgDQgIgDgOAAQgDAAgDAAQgCAAgCgBQACgBAFgEQgCgBgBAAIgKgDIAAAAAhOAHQADgCADgCQAIgIAbgKQAZgJARgCQAeACAMAGQALAHAAABQAFAEABABQALAJADAKQAAACABACQAAAFgBAFQgBABgBACQgCAEgDADQgGALgRADQgDABgDAAQgQACgQgIQgDgBgCgBQgFgEgEgCQgHgEgEgCQgHgEgHgDQgIgEgHgDQgBgBgBAAQgHgDgJgBQgFAAgFAAQACgDAFgDQgCAAgBAAQgFgBgFAAAhOgSQADgCADgCQAHgJAagKQAbgKARgBQAeABAMAGQAKAHACACQAGAFACACQAIAJADAJQAAADABABQAAADgBADQAAACgCAEQgCADgDADQgGALgRADQgBABgBAAQgRADgUgIQgDgBgCgCQgEgCgBgCQgKgFgFgDQgHgEgHgCQgHgDgHgDQAAAAAAAAQgHgEgMgBQgEAAgFAAQACgDAFgDQgCAAgBAAQgEgBgEAAIgCAA").cp();
	this.shape_593.setTransform(524.2,192.9);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#0B5831").s().p("AhegJQADgBAFgCQAAAAgBAAQAPgGAfgIQAcgIAVgBQAgABASAFQAHADAHAEQACABACABQABABACABQACAAABABQADACACACQAGAJABAHQAAACABACQAAAFgBAFQgCACgCADQgDACgDADQgKAJgUACQgWACgYgIQgDgBgDgCQgPgIgJgDQgIgDgJgDQgJgDgIgDQgJgCgOgBQgDABgDAAQgCgBgCgBQACgCAFgDQgCgBgBgBIgJgDIAAgBAhKALQACgCADgCQAIgIAagKQAXgJAQgBQAeABAKAGQALAHABABQAEAEABABQALAJADAJQAAACAAACQAAAFgBAEQgBACgBABQgBAEgDADQgGALgQADQgDABgDAAQgOACgRgHQgCgBgCgBQgFgDgEgDQgGgDgEgCQgHgEgHgDQgHgEgHgDQgBAAgBgBQgGgCgJgBQgFAAgFgBQADgDAEgDQgCAAgBAAQgFgBgEAAAhKgVQACgCADgCQAHgJAZgJQAZgKARgBQAcABAMAGQAJAGACACQAGAGACABQAIAJADAJQAAACAAACQAAACAAADQgBAEgCACQgBADgDADQgGALgQADQgBAAgBAAQgRAEgSgIQgDgBgCgBQgEgCgBgCQgJgFgFgDQgHgDgGgCQgHgDgHgDQAAAAAAAAQgHgEgLgBQgEAAgFgBQADgCAEgDQgCgBgBAAQgEAAgDgBIgCAA").cp();
	this.shape_594.setTransform(524.2,192.8);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#0A5831").s().p("AhegJQADgBAFgCQgBAAAAAAQAPgGAfgHQAcgHAWgBQAfABASAEQAHADAHAEQACABACABQACAAACABQABABACABQADABACACQAFAJACAHQAAACAAADQAAAFgBAFQgCACgCACQgDACgDADQgLAIgTACQgXACgXgIQgEgBgCgBQgPgIgKgDQgIgDgIgCQgKgDgIgCQgJgDgOAAQgDAAgDAAQgCgBgCgBQADgDAEgDQgCgBgBAAIgIgEIAAgBAhGAPQACgCADgCQAGgKAZgHQAWgJAQgCQAcACAKAGQAKAGABABQAEACABABQAKAKADAKQAAACAAABQABAEgCAFQAAABgBACQgCADgCADQgGALgPADQgDABgDAAQgNACgQgGQgCAAgCgCQgFgDgEgCQgGgDgEgCQgGgDgGgDQgIgEgGgDQgBAAgBgBQgGgCgJgCQgEAAgEgBQACgDAEgCQgCgBgBAAQgEgBgEAAAhGgYQACgBADgCQAGgJAXgKQAYgKAQgBQAbACAMAGQAJAGABABQAGAGACABQAHAJADAJQAAACAAABQAAADAAACQAAAEgCADQgCACgCACQgGALgPADQgBAAgBABQgQAEgRgIQgDgBgCgBQgEgBgBgCQgJgFgEgCQgHgCgGgDQgHgDgGgDQAAAAgBAAQgGgEgKgBQgEAAgEgBQACgDAEgDQgCAAgBAAQgEgBgDgBIgBAA").cp();
	this.shape_595.setTransform(524.3,192.8);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#095932").s().p("AhegJQADgBAEgCQAAAAAAAAQAQgGAegGQAcgGAWgBQAfABASAEQAIACAHADQACABACABQACABABAAQACABACABQADACACABQAEAJACAHQAAADAAACQABAFgBAFQgCACgDABQgDADgDACQgMAIgTABQgWACgXgHQgEgBgDgBQgPgHgKgDQgIgCgIgDQgJgDgJgBQgJgCgOgBQgDABgDAAQgBgCgCgBQACgEADgCQgBgBgBgBIgHgEIAAgBAhCASQABgBADgCQAGgKAXgHQAVgJAPgBQAbABAKAGQAJAFABAAQAEAEABABQAKAKACAJQAAACABABQAAAEgBAEQgBACgBABQgBADgCADQgGALgOADQgDABgCAAQgNADgPgGQgCAAgCgCQgFgCgDgCQgGgDgEgCQgGgDgGgDQgHgDgGgDQgBgBgBAAQgGgDgIgBQgEgBgEgBQACgCADgDQgBgBgBAAQgEgBgDgBAhCgaQABgCADgCQAGgJAWgJQAXgKAPgBQAaABAKAGQAJAGABACQAGAFACACQAHAIACAIQAAACABACQAAACgBACQAAAEgCADQgBADgDADQgFAIgOAEQgBAAgBAAQgPAEgQgGQgDgBgCgCQgDgBgBgBQgJgFgFAAQgGgDgGgDQgGgEgGgDQAAAAgBAAQgFgDgKgBQgEgBgEgBQACgDADgCQgBgBgBAAQgDgBgDAAIgBAA").cp();
	this.shape_596.setTransform(524.3,192.7);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#085A32").s().p("AhfgKQAEgBAEgBQAAAAAAAAQARgFAdgGQAcgGAWgBQAfABATAEQAHACAHADQACABACABQACAAACABQACAAABABQADACADABQAEAJABAHQAAADAAACQABAFgBAFQgCACgDABQgDADgDACQgMAHgTABQgXACgXgHQgDgBgDgBQgPgGgLgCQgIgDgIgCQgJgDgJgBQgJgCgOAAQgDAAgDAAQgBgCgCgBQACgEADgCQgBgBgBgBIgHgGIAAgBAg/AWQACgBACgCQAGgKAWgJQATgHAPgBQAZABAKAGQAJAEAAABQAEADABABQAJAKADAJQAAACAAABQAAAEgBADQAAACgBACQgBACgDADQgEAKgOAEQgCABgDAAQgMADgOgFQgCAAgCgCQgFgCgDgCQgFgDgEgBQgGgDgGgDQgGgDgGgDQgBAAgBgBQgFgCgIgCQgEgBgDgBQABgCADgDQgBAAgBgBQgDAAgEgCAg/gdQACgCACgCQAGgJAUgJQAWgJAPgBQAYABAKAGQAIAFACACQAFAGACABQAGAHADAJQAAACAAABQAAACAAACQgBADgBAEQgCADgCACQgFAIgNAEQgBAAgBAAQgOAFgQgGQgCgBgCgBQgDgBgBgCQgIgCgFgCQgGgDgGgDQgGgDgFgDQAAAAgBAAQgFgDgJgCQgEAAgDgCQABgCADgDQgBAAgBAAQgDgBgDgBIgBAA").cp();
	this.shape_597.setTransform(524.3,192.7);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#085B33").s().p("AhfgKQAEgBAEgBQAAAAAAAAQARgFAdgFQAcgFAWgBQAeABAUADQAIACAHADQACABACAAQACABABAAQACABACABQADABADABQADAJABAIQAAACABACQAAAFgBAFQgCACgDABQgDACgEACQgMAGgTACQgWABgXgGQgEAAgDgBQgOgGgLgCQgJgCgIgCQgJgDgJgBQgKgCgNAAQgDAAgDAAQgBgBgCgCQACgEADgDQgBgBgBgBIgGgGIAAgBAg7AaQABgBADgCQAFgKAUgJQASgGAOgBQAYABAKADQAIAGABABQADADABABQAJAKACAIQAAACAAABQAAAEgBADQAAABgBACQgBADgCACQgEAKgNAEQgCABgDAAQgLADgNgEQgDAAgBgBQgFgCgCgCQgGgDgDgBQgGgDgFgCQgHgDgFgDQgBgBgBAAQgFgDgHgCQgEAAgDgCQABgCADgDQgBAAgBAAQgDgBgDgCAg7ggQABgCADgBQAFgJATgJQAUgKAOAAQAXABAKAGQAIAFABABQAFAGABABQAHAHACAIQAAACAAACQAAABAAACQAAADgCAEQgBACgCADQgFAJgMACQgBAAgBABQgNAEgPgFQgCgBgCgBQgDAAgBAAQgIgDgEgDQgGgCgFgDQgGgDgFgDQgBAAAAAAQgFgDgIgCQgEgBgDgBQABgDADgCQgBgBgBAAQgDgBgCgBIgBAA").cp();
	this.shape_598.setTransform(524.4,192.7);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#075B33").s().p("AhfgKQAEgBAEgBQAAAAAAAAQASgEAdgFQAbgFAXAAQAdAAAVADQAHACAHADQACAAADABQABAAACABQACAAACABQADABADABQADAJABAIQAAACAAADQAAAFAAAFQgDABgCABQgEACgEACQgMAFgTABQgWACgYgGQgDAAgDgBQgPgFgLgCQgIgCgJgCQgJgCgJgBQgKgCgMAAQgDAAgDAAQgCgBgBgCQABgEADgDQgBgBgBgBIgFgHIAAgBAg3AeQABgBACgCQAFgKATgIQAQgJAOAAQAWAAAKAGQAHAFABABQADADABABQAIAJACAIQAAACABABQAAADgBADQgBACAAABQgBADgCACQgEAKgMAEQgCABgCAAQgLADgMgDQgDAAgBgBQgFgCgCgCQgFgCgDgBQgGgCgFgDQgGgDgFgDQgBAAgBgBQgFgCgGgCQgDgBgEgCQACgCACgCQgBgBgBAAQgDgBgCgCAg3gjQABgBACgCQAFgJARgJQATgJAOgBQAVABAKAGQAHAFABACQAFAFABABQAGAHACAIQAAACABABQAAACgBABQAAADgBADQgBADgCACQgEAJgMAEQgBABAAAAQgNADgOgDQgCAAgCgBQgDgBgBgBQgHgDgFgCQgFgDgFgCQgFgDgFgDQgBAAAAAAQgFgEgHgCQgEAAgDgCQACgCACgDQgBAAgBAAQgCgCgCgBIgBAA").cp();
	this.shape_599.setTransform(524.4,192.6);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#065C34").s().p("AhfgLQADAAAFgBQAAAAAAAAQATgEAcgEQAbgEAXgBQAdABAVADQAIABAHACQACABACAAQACABACAAQACABABAAQADABADABQADAKABAHQAAADAAACQAAAFAAAFQgDABgCABQgEACgEABQgNAFgSABQgXABgXgEQgEgBgCgBQgPgEgMgCQgIgCgIgBQgKgCgJgBQgKgBgMgBQgDABgDAAQgCgCgBgCQACgFACgDQgBgBgBgBIgEgHIAAgCAg0AiQACgCABgBQAFgKARgIQAQgIAMgCQAVABAJAGQAIAFAAABQADADABABQAIAJACAHQAAACAAABQAAADgBADQAAABgBABQAAADgCACQgEAKgLAEQgCABgCAAQgKAEgMgDQgCAAgBgBQgEgCgCgBQgFgCgDgBQgGgCgFgDQgFgCgFgDQgBgBgBAAQgEgDgGgCQgDgBgDgCQABgCACgCQgBgBgBAAQgCgBgDgCAg0glQACgCABgCQAEgJARgIQARgJANgBQAUABAKAGQAGAFACABQAEAFABACQAGAGACAHQAAACAAABQAAACAAABQgBADgBADQgBACgBADQgEAJgLAEQgBAAAAAAQgMAFgOgDQgCgBgBgBQgDgBgBAAQgHgDgEgCQgFgCgFgDQgFgDgFgDQAAAAAAAAQgFgDgHgCQgCgBgDgBQABgDACgCQgBgBgBAAQgCgBgCgBIgBAA").cp();
	this.shape_600.setTransform(524.5,192.6);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#055D34").s().p("AhggLQAEgBAEAAQAAAAABAAQATgEAcgDQAbgEAXAAQAdAAAVADQAIABAHACQACAAADABQABAAACAAQACABACAAQADABADABQACAKABAHQAAADAAACQABAFgBAFQgDABgCABQgEABgEABQgOAFgSAAQgWACgYgEQgDgBgCgBQgPgDgNgCQgIgBgIgCQgKgBgJgBQgKgBgMAAQgDAAgDAAQgBgCgBgCQABgFACgEQgBAAgBgCIgEgIIAAgBAgwAmQABgCACgBQADgKAQgIQAPgIAMgBQATAAAJAGQAHAFAAAAQADAEABABQAHAIACAHQAAACAAABQAAADAAACQgBABAAACQgBACgBACQgEAJgKAFQgCABgBAAQgKAEgLgCQgCgBgBAAQgEgBgCgCQgEgBgEgBQgFgCgEgDQgGgCgEgDQgBgBgBAAQgEgDgFgCQgDgBgDgCQABgCACgCQgBgBgBAAQgCgBgCgCAgwgoQABgCACgCQADgJAPgIQARgJAMAAQASAAAKAGQAGAFABABQAEAFABACQAFAGACAHQAAABAAACQAAABAAABQAAADgBADQgBACgCACQgDAJgKAEQgBAAAAAAQgLAFgNgCQgCgBgBgBQgDAAgBgBQgGgCgEgCQgFgCgFgCQgEgDgFgDQAAAAAAAAQgFgDgGgCQgCgCgDgBQABgDACgCQgBAAgBgBQgCgBgBgBIgBAA").cp();
	this.shape_601.setTransform(524.5,192.6);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#045D35").s().p("AhggLQAEgBAEgBQAAAAABAAQAUgCAbgDQAbgDAYAAQAcAAAWACQAHABAIABQACABACAAQACAAACABQACAAACAAQADABADABQACAKABAHQAAADAAACQAAAFgBAFQgCABgDABQgEABgEABQgOADgSABQgXABgXgDQgDgBgCAAQgPgDgNgCQgJgBgIgBQgJgBgKgBQgKgBgMAAQgDAAgDAAQgBgCgBgCQABgFACgFQgBAAAAgBIgEgJIAAgBAgsAqQABgCABgCQADgJAPgIQANgIALgBQASAAAJAGQAGAFABAAQADAEAAABQAHAHABAIQAAABAAABQABACgBACQAAACgBABQAAACgCACQgDAJgJAFQgBAAgCABQgJAEgKgCQgCAAgBAAQgEgBgCgBQgEgBgDgCQgEgBgFgCQgFgDgEgDQgBAAgBgBQgEgCgEgCQgDgCgCgCQAAgCACgCQgBgBAAAAQgCgBgCgCAgsgrQABgCABgCQADgJAOgIQAPgIAMgBQARABAJAGQAFAEABABQAEAGABABQAFAGABAGQAAACAAABQAAABAAABQAAADgBACQgBACgBACQgDAJgJAEQgBAAAAABQgKAFgMgCQgCgBgBAAQgDgBgBAAQgFgCgEgCQgFgCgEgCQgFgCgEgDQAAAAAAAAQgEgEgGgCQgCgBgCgCQAAgCACgDQgBAAAAAAQgCgCgCgBIAAAA").cp();
	this.shape_602.setTransform(524.5,192.5);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#035E35").s().p("AhggMQAEAAAEgBQAAAAAAAAQAWgCAagCQAbgDAYAAQAbAAAXACQAIABAHABQACAAADABQACAAACAAQABAAACABQAEAAADABQABAKABAHQAAADAAACQAAAFAAAFQgDABgDABQgEAAgEABQgPADgRABQgXAAgXgCQgEgBgBAAQgQgDgNgBQgIgBgJAAQgJgBgJgBQgLgBgMAAQgDAAgDAAQgBgCgBgDQABgFACgFQgBAAAAgBIgDgJIAAgCAgoAuQAAgCABgCQADgJANgIQAMgIALgBQARABAIAFQAFAEABABQADADAAABQAGAIACAHQAAABAAABQAAACgBACQAAABAAABQgBACgBACQgDAJgIAFQgBAAgCABQgHAEgKgBQgCAAgBAAQgEgBgBgBQgEgBgDgBQgEgBgEgCQgFgCgEgDQgBgBgBAAQgDgDgEgCQgDgCgCgCQABgCABgCQgBgBAAAAQgCgCgBgBAgoguQAAgCABgBQADgJAMgIQAOgJALAAQAQAAAJAGQAFAEAAABQAEAGABABQAEAFACAHQAAABAAABQAAABAAABQAAACgBADQgBACgBACQgDAIgIAEQgBAAAAABQgKAFgKgBQgCgBgBAAQgDAAgBgBQgFgBgEgCQgEgBgEgCQgEgDgEgDQAAAAAAAAQgEgDgFgCQgCgCgCgCQABgCABgCQgBgBAAAAQgCgCgBgBIAAAA").cp();
	this.shape_603.setTransform(524.6,192.5);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#025F36").s().p("AhggNQAEAAAEAAQAAAAAAAAQAWgCAagCQAbgBAYgBQAbABAYABQAHAAAIABQACABACAAQACAAACAAQACAAACABQADAAAEAAQABAKAAAIQAAADAAACQAAAFAAAFQgDABgDAAQgEABgEAAQgPACgSABQgXAAgXgCQgDAAgCAAQgPgCgOgBQgIAAgJgBQgJgBgJAAQgLgBgMAAQgDAAgDAAQgBgCAAgDQAAgFABgGQAAAAAAgBIgCgKIAAgCAglAxQABgBABgCQACgKALgHQALgIALgBQAPABAIAFQAFAEAAABQADADAAABQAGAHABAGQAAACAAABQAAABAAACQAAABgBABQAAACgBACQgCAIgIAFQgBABgBAAQgHAFgJAAQgCAAgBAAQgDgBgCAAQgDgBgDgBQgEgBgEgCQgFgCgDgDQgBgBgBAAQgDgDgDgCQgDgCgBgCQAAgCAAgCQAAgBAAAAQgCgCgBgCAglgxQABgCABgBQACgJALgIQAMgJALAAQAOABAIAGQAFADABABQADAGABABQAEAFABAGQAAABAAABQAAABAAAAQAAADgBACQAAACgBACQgDAHgHAFQgBAAAAABQgJAFgKAAQgBgBgBAAQgDAAgBAAQgEgBgEgCQgEgBgEgCQgEgCgDgDQAAAAAAAAQgEgDgEgDQgCgCgBgCQAAgCAAgCQAAgBAAAAQgCgCAAgBIgBAA").cp();
	this.shape_604.setTransform(524.6,192.5);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#026036").s().p("AhhgNQAEgBAEAAQABAAAAAAQAXgBAagBQAagBAYAAQAbAAAYABQAIAAAHABQACAAADAAQACAAACAAQACAAACAAQADABADAAQABAKAAAIQAAADAAACQABAFgBAFQgDAAgDABQgEAAgEABQgQABgRAAQgXABgXgCQgEAAgBAAQgPgBgPgBQgIAAgIgBQgKAAgJgBQgLAAgMAAQgDAAgDAAQAAgDgBgCQABgGAAgFQAAgBAAgBIgCgLIAAgBAghA1QAAgCABgBQACgKAKgHQAJgIALgBQANAAAHAGQAFAEAAAAQADADAAABQAFAHABAGQAAABAAABQAAACAAABQAAABAAABQAAACgBABQgCAIgHAGQgBABgBAAQgGAFgJAAQgBABgBgBQgDAAgCAAQgCgBgDAAQgEgBgEgCQgEgCgDgDQgBAAgBgBQgDgCgCgDQgCgCgCgCQAAgCAAgCQAAgBAAAAQgBgCgBgCAghg0QAAgCABgCQACgJAJgHQAMgIAJAAQANAAAIAGQAEADABABQADAGABABQADAEABAGQAAABAAABQAAABAAAAQAAACAAADQgBABgBACQgCAHgGAFQgBAAAAABQgIAGgJAAQgBgBgBAAQgDAAgBAAQgEgBgDgBQgEgBgEgCQgDgCgDgDQAAAAAAAAQgEgDgDgDQgCgBgBgDQAAgCAAgCQAAAAAAgBQgBgCgBgBIAAAA").cp();
	this.shape_605.setTransform(524.7,192.5);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#016037").s().p("AhhgOQAEAAAEAAQABAAAAAAQAYgBAZAAQAagBAZAAQAaAAAZAAQAHABAIAAQACAAACAAQACAAACAAQACAAACAAQAEAAADABQABAKAAAIQAAACAAADQAAAFAAAFQgEAAgDAAQgEAAgEABQgQAAgSAAQgXABgXgBQgDAAgCAAQgPgBgOAAQgJAAgIgBQgKAAgJAAQgLAAgMAAQgDAAgDAAQAAgDAAgDQAAgFAAgGQAAgBAAgBIgBgLIAAgCAgdA4QAAgBAAgCQACgJAIgIQAIgHALgBQALAAAHAGQAEADABABQACADAAABQAFAGABAGQAAABAAABQAAABAAABQAAABgBABQAAABAAACQgCAIgGAGQgBAAAAABQgGAEgIACQgBAAgBAAQgDAAgCAAQgCAAgCgBQgEgBgDgBQgEgCgDgDQgBAAgBgBQgCgCgCgDQgCgCgBgCQgBgDAAgCQAAAAAAgBQgBgBAAgDAgdg4QAAgBAAgCQACgJAIgHQAKgIAJAAQALAAAIAGQAEADAAABQADAFABABQADAFABAFQAAABAAABQAAAAAAABQAAACgBACQAAACgBABQgCAHgFAFQgBAAAAABQgHAGgIAAQgBAAgBAAQgDABgBgBQgDAAgEgBQgDgBgDgCQgEgCgCgDQAAAAAAAAQgEgDgCgDQgCgBAAgDQgBgCAAgCQAAAAAAgBQgBgCAAgCIAAAA").cp();
	this.shape_606.setTransform(524.7,192.5);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#006137").s().p("AhhASIAAghIDDAAIAAAhIjDAAAAAAgQALAAAIAIQAIAIAAAMQAAALgIAIQgIAIgLAAQgKAAgHgIQgJgIAAgLQAAgMAJgIQAHgIAKAAIAAAAAgRgoQgJgIAAgLQAAgLAJgIQAHgIAKAAQALAAAIAIQAIAIAAALQAAALgIAIQgIAIgLAAQgKAAgHgIIAAAA").cp();
	this.shape_607.setTransform(524.8,192.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_588}]}).to({state:[{t:this.shape_589}]},34).to({state:[{t:this.shape_590}]},1).to({state:[{t:this.shape_591}]},1).to({state:[{t:this.shape_592}]},1).to({state:[{t:this.shape_593}]},1).to({state:[{t:this.shape_594}]},1).to({state:[{t:this.shape_595}]},1).to({state:[{t:this.shape_596}]},1).to({state:[{t:this.shape_597}]},1).to({state:[{t:this.shape_598}]},1).to({state:[{t:this.shape_599}]},1).to({state:[{t:this.shape_600}]},1).to({state:[{t:this.shape_601}]},1).to({state:[{t:this.shape_602}]},1).to({state:[{t:this.shape_603}]},1).to({state:[{t:this.shape_604}]},1).to({state:[{t:this.shape_605}]},1).to({state:[{t:this.shape_606}]},1).to({state:[{t:this.shape_607}]},1).wait(20));

	// minus sign
	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#6DBE56").s().p("ABKgWQgUgQgdgCQgbgCgrAOQgkAMgMAJIAOgBQAPAAAIADQASAFASAKQAIAFAXAPQAZANAXgDQAZgDAHgPQAEgLgDgLQgEgLgOgLIAAAA").cp();
	this.shape_608.setTransform(496,349.6);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#6DBE56").s().p("ABXgKQAEAGACAEQAAADABACQAAAIgEAIQgIAOgYADQgYADgZgMQgWgOgJgFQgSgKgSgDQgHgCgLgBQgCAAgDgBIgMAAQANgIAjgLQArgMAcABQAcACAVAPQAHAFAFAFIAAAA").cp();
	this.shape_609.setTransform(496.1,349.6);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#6DBE56").s().p("AhdgHQANgIAjgKQArgMAcABQAdACAVAOQAGAFAGAFQAAAAAAAAQAEAGABAEQABADAAACQAAABAAAAQAAAHgEAHQgIAOgYACQgYADgZgLQgWgOgKgEQgSgJgSgEQgGgBgJgBQgBAAgCAAQgCgBgDAAIgLgB").cp();
	this.shape_610.setTransform(496.1,349.7);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#6DBE56").s().p("AhegHQAPgIAigJQAqgLAdABQAdACAVANQAHAEAGAFQAAAAAAAAQADAGACAEQAAADABACQAAABAAAAQgBAHgEAHQgJAMgYADQgYACgZgKQgWgNgKgEQgTgJgSgDQgGgBgJgBQgBAAgBAAQgCgBgDgBIgLgB").cp();
	this.shape_611.setTransform(496.2,349.7);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#6DBE56").s().p("AhegHQAPgHAigJQAqgLAeABQAcACAWAMQAHAFAFAEQAAAAAAAAQAEAGABAFQABACAAADQAAAAAAABQgBAGgEAGQgKAMgXACQgYADgagKQgVgMgLgEQgTgIgSgDQgGgBgJgBQgBAAgCAAQgCgBgCgBIgKgC").cp();
	this.shape_612.setTransform(496.2,349.7);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#6DBE56").s().p("AhfgHQAQgHAigIQAqgKAeABQAcABAWAMQAHAEAGAEQAAAAAAAAQADAHACAEQAAACABADQAAAAAAABQgCAGgEAGQgLALgXACQgYACgZgJQgWgLgLgEQgTgIgTgCQgGgBgJgBQgBAAgBgBQgCgBgCgBIgKgC").cp();
	this.shape_613.setTransform(496.3,349.7);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#6DBE56").s().p("AhfgIQARgGAhgIQAqgJAeABQAcACAXAKQAHAEAGAEQAAAAAAAAQADAHABAEQABADAAACQAAABAAAAQgCAGgFAFQgLALgWABQgZADgZgJQgVgLgMgDQgUgHgSgDQgGAAgJgBQgBAAgBgBQgCgBgCgBIgJgE").cp();
	this.shape_614.setTransform(496.3,349.8);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#6DBE56").s().p("AhggIQASgGAhgHQApgIAfABQAdABAXAKQAHADAGAEQAAAAAAAAQADAHABAEQAAADABACQAAABAAAAQgDAFgFAGQgLAJgXACQgYACgagIQgVgKgNgDQgTgHgTgDQgGAAgJAAQgBgBgBAAQgBgBgCgCIgJgE").cp();
	this.shape_615.setTransform(496.4,349.8);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#6DBE56").s().p("AhggIQASgFAggHQAqgIAgABQAcACAXAJQAHADAHADQAAAAAAAAQACAHABAEQABADAAADQAAAAAAABQgDAEgFAFQgMAJgWABQgZACgagHQgUgJgOgDQgTgGgTgEQgHAAgIAAQgBAAgBAAQgCgCgBgBIgIgF").cp();
	this.shape_616.setTransform(496.4,349.8);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#6DBE56").s().p("AhggIQASgFAggGQAqgHAgABQAcABAYAIQAHADAGADQAAAAAAAAQADAHABAFQAAACAAADQAAAAAAABQgDAEgFAEQgNAJgWABQgZACgZgHQgVgIgOgDQgUgGgTgDQgGgBgJAAQAAAAgBAAQgCgBgCgBIgGgG").cp();
	this.shape_617.setTransform(496.5,349.8);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#6DBE56").s().p("AhhgIQAUgFAfgFQAqgHAgABQAcABAYAIQAIACAGADQAAAAAAABQACAGABAFQABADAAACQAAABAAAAQgEAEgGAEQgNAHgVACQgZABgagGQgVgHgOgDQgUgFgTgDQgHgBgIAAQgBgBgBAAQgBAAgCgCIgGgG").cp();
	this.shape_618.setTransform(496.6,349.9);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#6DBE56").s().p("AhhgIQAUgEAfgFQApgGAhABQAcABAZAGQAHADAHACQAAAAAAABQACAGABAFQAAADAAACQAAABAAAAQgEAEgGADQgOAHgVABQgZACgagGQgUgHgPgCQgUgFgUgCQgGgBgJAAQAAgBgBgBQgBAAgCgBIgFgH").cp();
	this.shape_619.setTransform(496.6,349.9);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#6DBE56").s().p("AhigIQAVgEAfgEQApgGAhABQAdABAZAGQAHACAHACQAAABAAAAQACAHAAAEQABADAAACQAAABAAAAQgFAEgGADQgOAGgVABQgaABgZgFQgVgGgQgCQgUgEgTgCQgHgBgIAAQgBgBAAgBQgBgBgCgBIgFgH").cp();
	this.shape_620.setTransform(496.7,349.9);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#6DBE56").s().p("AhigIQAWgEAegDQApgFAiABQAcAAAZAGQAIABAHACQAAABAAAAQABAHABAEQAAADAAADQAAAAAAABQgFACgGADQgPAFgVABQgZABgagEQgUgFgRgCQgUgEgUgCQgHAAgIAAQAAgBgBgBQgBgCgBAAIgEgI").cp();
	this.shape_621.setTransform(496.7,349.9);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#6DBE56").s().p("AhjgJQAXgCAegEQAogDAjAAQAcABAaAEQAHACAHABQAAABAAAAQACAHAAAFQAAACABADQAAAAAAABQgGACgGADQgQAEgVABQgZABgagEQgUgEgRgCQgUgDgUgCQgHAAgIgBQgBAAAAgBQgBgCgBgBIgEgJ").cp();
	this.shape_622.setTransform(496.8,350);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#6DBE56").s().p("AhjgJQAXgCAdgDQApgDAjAAQAcABAaAEQAIABAHABQAAABAAAAQABAHABAFQAAADAAACQAAABAAAAQgGACgHACQgQAEgUAAQgaABgZgDQgUgEgSgBQgVgCgUgCQgHAAgIgBQAAAAAAgBQgBgDgBgBIgDgJ").cp();
	this.shape_623.setTransform(496.8,350);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#6DBE56").s().p("AhkgJQAZgCAcgCQApgCAjAAQAcAAAbADQAIABAHABQAAABAAAAQABAHAAAFQAAADABACQAAABAAAAQgHACgHACQgRACgUABQgZABgZgDQgVgDgSgBQgVgCgUgBQgHAAgIgBQgBAAAAgCQAAgCgBgCIgDgJ").cp();
	this.shape_624.setTransform(496.9,350);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#6DBE56").s().p("AhkgJQAZgBAcgCQApgCAkAAQAcABAaACQAIABAIABQAAAAAAAAQAAAHABAFQAAADAAADQAAAAAAABQgHABgHABQgRACgUABQgaAAgYgCQgWgCgTgBQgUgBgVgBQgHAAgIgBQAAAAAAgCQgBgCAAgDIgCgJ").cp();
	this.shape_625.setTransform(497,350);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#6DBE56").s().p("AhkgJQAZgBAcgBQAogBAlAAQAcAAAbACQAIAAAIABQAAAAAAABQAAAGAAAFQAAADAAADQAAAAAAABQgHABgHAAQgSACgUAAQgZAAgZgBQgVgBgUgBQgVgBgUAAQgIgBgHAAQAAgBgBgBQAAgDAAgCIgBgK").cp();
	this.shape_626.setTransform(497,350.1);

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#6DBE56").s().p("AhlgJQAagBAcAAQAogBAlAAQAcAAAcABQAIAAAHABQAAAAAAABQABAHAAAFQAAADAAACQAAABAAAAQgIAAgIABQgSABgTAAQgaAAgZgBQgVgBgUAAQgVAAgVgBQgHAAgIAAQAAgBAAgBQAAgDAAgDIgBgK").cp();
	this.shape_627.setTransform(497.1,350.1);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#6DBE56").s().p("ABmgJIjLAAIAAATIDLAAIAAgT").cp();
	this.shape_628.setTransform(497.1,350.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_608}]}).to({state:[{t:this.shape_609}]},39).to({state:[{t:this.shape_610}]},1).to({state:[{t:this.shape_611}]},1).to({state:[{t:this.shape_612}]},1).to({state:[{t:this.shape_613}]},1).to({state:[{t:this.shape_614}]},1).to({state:[{t:this.shape_615}]},1).to({state:[{t:this.shape_616}]},1).to({state:[{t:this.shape_617}]},1).to({state:[{t:this.shape_618}]},1).to({state:[{t:this.shape_619}]},1).to({state:[{t:this.shape_620}]},1).to({state:[{t:this.shape_621}]},1).to({state:[{t:this.shape_622}]},1).to({state:[{t:this.shape_623}]},1).to({state:[{t:this.shape_624}]},1).to({state:[{t:this.shape_625}]},1).to({state:[{t:this.shape_626}]},1).to({state:[{t:this.shape_627}]},1).to({state:[{t:this.shape_628}]},1).wait(14));

	// tree trunk
	this.instance_45 = new lib.treetrunk();
	this.instance_45.setTransform(454.8,347.1,1,1,0,0,0,-0.3,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_45}]}).wait(72));

	// tree shadow
	this.instance_46 = new lib.treetrunkshadow();
	this.instance_46.setTransform(408.6,436.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_46}]}).wait(72));

	// morning ground
	this.instance_47 = new lib.groundday();
	this.instance_47.setTransform(450.2,507);
	this.instance_47.alpha = 0.238;
	this.instance_47._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(13).to({_off:false},0).to({alpha:1},11).wait(48));

	// morning sky
	this.instance_48 = new lib.skydaytime();
	this.instance_48.setTransform(449,302.5);
	this.instance_48.alpha = 0;
	this.instance_48._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_48).wait(13).to({_off:false},0).to({alpha:0.891},11).wait(48));

	// night ground
	this.instance_49 = new lib.groundnight();
	this.instance_49.setTransform(449,507);

	this.timeline.addTween(cjs.Tween.get(this.instance_49).to({alpha:0.75},24).to({_off:true},1).wait(47));

	// night sky
	this.instance_50 = new lib.skynight();
	this.instance_50.setTransform(450,302.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_50).to({alpha:0},24).to({_off:true},1).wait(47));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(19,21,862,602.7);
p.frameBounds = [rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect=new cjs.Rectangle(18,21,863.2,602.7), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect];


// symbols:
(lib.Bitmap10 = function() {
	this.initialize(img.Bitmap10);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,13,13);


(lib.Bitmap11 = function() {
	this.initialize(img.Bitmap11);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,16,17);


(lib.Bitmap12 = function() {
	this.initialize(img.Bitmap12);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,39,23);


(lib.Bitmap13 = function() {
	this.initialize(img.Bitmap13);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,46,18);


(lib.Bitmap14 = function() {
	this.initialize(img.Bitmap14);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,34,25);


(lib.Bitmap15 = function() {
	this.initialize(img.Bitmap15);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,116,26);


(lib.Bitmap16 = function() {
	this.initialize(img.Bitmap16);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,57,23);


(lib.Bitmap17 = function() {
	this.initialize(img.Bitmap17);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,176,26);


(lib.Bitmap18 = function() {
	this.initialize(img.Bitmap18);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,22,17);


(lib.Bitmap19 = function() {
	this.initialize(img.Bitmap19);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,25,23);


(lib.Bitmap2 = function() {
	this.initialize(img.Bitmap2);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,27,186);


(lib.Bitmap3 = function() {
	this.initialize(img.Bitmap3);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,48,108);


(lib.Bitmap4 = function() {
	this.initialize(img.Bitmap4);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,14,14);


(lib.Bitmap5 = function() {
	this.initialize(img.Bitmap5);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,17,16);


(lib.Bitmap6 = function() {
	this.initialize(img.Bitmap6);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,27,186);


(lib.Bitmap7 = function() {
	this.initialize(img.Bitmap7);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,13,13);


(lib.Bitmap8 = function() {
	this.initialize(img.Bitmap8);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,17,17);


(lib.Bitmap9 = function() {
	this.initialize(img.Bitmap9);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,109);


(lib.DataCollaborative = function() {
	this.initialize(img.DataCollaborative);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,328,42);


(lib.FlashAICB = function() {
	this.initialize(img.FlashAICB);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,328,42);


(lib.FlashAICB_1 = function() {
	this.initialize(img.FlashAICB_1);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,339,48);


(lib.FlashAICB_2 = function() {
	this.initialize(img.FlashAICB_2);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,862,563);


(lib.FlashAICB_3 = function() {
	this.initialize(img.FlashAICB_3);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,7);


(lib.FlashAICB_4 = function() {
	this.initialize(img.FlashAICB_4);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,7);


(lib.FlashAICB_5 = function() {
	this.initialize(img.FlashAICB_5);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,7);


(lib.FlashAICB_6 = function() {
	this.initialize(img.FlashAICB_6);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,7);


(lib.FlashAICB_7 = function() {
	this.initialize(img.FlashAICB_7);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,7);


(lib.FlashAICB_8 = function() {
	this.initialize(img.FlashAICB_8);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,7);


(lib.FlashAICB_9 = function() {
	this.initialize(img.FlashAICB_9);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,7);


(lib.MathFluency = function() {
	this.initialize(img.MathFluency);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,339,48);


(lib.splash_tree_sun = function() {
	this.initialize(img.splash_tree_sun);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,600);


(lib.treetrunkshadow = function() {
	this.initialize(img.treetrunkshadow);
}).prototype = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,95,187);


(lib.unccharlottenight = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("UNC Charlotte", "bold 13px Adobe Garamond Pro", "#9997D2");
	this.text.textAlign = "center";
	this.text.lineHeight = 15;
	this.text.setTransform(-1.9,-9.7);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-43.2,-9.7,86.6,19.7);
p.frameBounds = [rect];


(lib.unccharlotteday = function() {
	this.initialize();

	// Layer 1
	this.text_1 = new cjs.Text("UNC Charlotte", "bold 13px Adobe Garamond Pro", "#CB9F6C");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 15;
	this.text_1.setTransform(-1.9,-9.7);

	this.addChild(this.text_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-43.2,-9.7,86.6,19.7);
p.frameBounds = [rect];


(lib.treetrunk = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#65421F").s("#65421F").ss(1.7).p("AA6gFQADAWgPATQgPATgZADQgWADgTgPQgUgQgCgYQgDgXAQgTQAPgTAYgDQAXgCATAPQATAPACAZIAAAA").cp();
	this.shape.setTransform(-40.9,85.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#65421F").s().p("AjZoIQANBogODdQgODTASBvQALBFAhBDQAhBBAwA1QA5A9BUAmQBGAfBiASQAOADgXgrQgPgbgCgDQgPgVgLgCQhagQg8gYQhPgggygzQgcgdgMhAQgIgqgChEQgDhEAMjQQAJiugOhpQgCgXgjgrQgHgJgHgGQgLgIACAOIAAAA").cp();
	this.shape_1.setTransform(24.3,40.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#65421F").s("#65421F").ss(1.7).p("AA6gFQADAWgPATQgPATgZADQgWADgTgPQgUgQgCgYQgDgXAQgTQAPgTAYgDQAXgCATAPQATAPACAZIAAAA").cp();
	this.shape_2.setTransform(-17.9,-86.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#65421F").s().p("ABwuSQgEAFgTABQgTABgFAGQiPCdgbD5QgUC2AsENQAHAsASBDQAYBbAFAXQAKAtAWBWQAUBNADA5QAEBVgCAoQgDBDgQA4QgPA1giA9QgVAlgvBGQAEgFAUgCQAVgBADgFQAog7AVgpQAgg4ATgzQAVg4ADhJQABgegDhnQgCg2gThIQgXhRgKgqIgch5QgThHgIgxQgskKAUi4QAbj6COidIAAAA").cp();
	this.shape_3.setTransform(-28.9,-1.5);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-46.8,-93,93.9,186.2);
p.frameBounds = [rect];


(lib.thepghsciencenight = function() {
	this.initialize();

	// Layer 1
	this.text_2 = new cjs.Text("The Pittsburgh Science", "bold 13px Adobe Garamond Pro", "#9997D2");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 15;
	this.text_2.setTransform(-1.9,-9.7);

	this.addChild(this.text_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-63.6,-9.7,127.4,19.7);
p.frameBounds = [rect];


(lib.thepghscienceday = function() {
	this.initialize();

	// Layer 1
	this.text_3 = new cjs.Text("The Pittsburgh Science", "bold 13px Adobe Garamond Pro", "#CB9F6C");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 15;
	this.text_3.setTransform(-1.9,-9.7);

	this.addChild(this.text_3);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-63.6,-9.7,127.4,19.7);
p.frameBounds = [rect];


(lib.skydaytime = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.FlashAICB_2();
	this.instance.setTransform(-430.9,-281.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-430.9,-281.4,862,563);
p.frameBounds = [rect];


(lib.playpowernight = function() {
	this.initialize();

	// Layer 1
	this.text_4 = new cjs.Text("PlayPower", "bold 15px Adobe Garamond Pro", "#D8D8EC");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 17;
	this.text_4.setTransform(-1.9,-10.9);

	this.addChild(this.text_4);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-34.2,-10.9,68.6,22);
p.frameBounds = [rect];


(lib.playpowerday = function() {
	this.initialize();

	// Layer 1
	this.text_5 = new cjs.Text("PlayPower", "bold 15px Adobe Garamond Pro", "#FFFDE8");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 17;
	this.text_5.setTransform(-1.9,-10.9);

	this.addChild(this.text_5);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-34.2,-10.9,68.6,22);
p.frameBounds = [rect];


(lib.pellissippinight = function() {
	this.initialize();

	// Layer 1
	this.text_6 = new cjs.Text("Pellissippi State", "bold 15px Adobe Garamond Pro", "#D8D8EC");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 17;
	this.text_6.setTransform(-1.9,-10.9);

	this.addChild(this.text_6);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-50.1,-10.9,100.4,22);
p.frameBounds = [rect];


(lib.pellissippiday = function() {
	this.initialize();

	// Layer 1
	this.text_7 = new cjs.Text("Pellissippi State", "bold 15px Adobe Garamond Pro", "#FFFDE8");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 17;
	this.text_7.setTransform(-1.9,-10.9);

	this.addChild(this.text_7);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-50.1,-10.9,100.4,22);
p.frameBounds = [rect];


(lib.ollaborativeblack = function() {
	this.initialize();

	// Layer 1
	this.text_8 = new cjs.Text("ollaborative", "32px Adobe Garamond Pro");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 34;
	this.text_8.setTransform(-1.9,-21.1);

	this.addChild(this.text_8);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-81.4,-21.1,163,42.4);
p.frameBounds = [rect];


(lib.oflearningcenternight = function() {
	this.initialize();

	// Layer 1
	this.text_9 = new cjs.Text("of Learning Center", "bold 13px Adobe Garamond Pro", "#9997D2");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 15;
	this.text_9.setTransform(-1.9,-9.7);

	this.addChild(this.text_9);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-52.4,-9.7,104.9,19.7);
p.frameBounds = [rect];


(lib.oflearningcenterday = function() {
	this.initialize();

	// Layer 1
	this.text_10 = new cjs.Text("of Learning Center", "bold 13px Adobe Garamond Pro", "#CB9F6C");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 15;
	this.text_10.setTransform(-1.9,-9.7);

	this.addChild(this.text_10);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-52.4,-9.7,104.9,19.7);
p.frameBounds = [rect];


(lib.M = function() {
	this.initialize();

	// Layer 1
	this.text_11 = new cjs.Text("M", "bold 32px Adobe Garamond Pro");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 34;
	this.text_11.setTransform(-1.9,-21.1);

	this.addChild(this.text_11);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-17.2,-21.1,34.5,42.4);
p.frameBounds = [rect];


(lib.mfdcnight = function() {
	this.initialize();

	// Layer 1
	this.text_12 = new cjs.Text("MFDC", "85px Adobe Garamond Pro", "#D8D8EC");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 87;
	this.text_12.setTransform(-1.9,-52.3);

	this.addChild(this.text_12);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-124.9,-52.3,250,104.8);
p.frameBounds = [rect];


(lib.mfdcday = function() {
	this.initialize();

	// Layer 1
	this.text_13 = new cjs.Text("MFDC", "85px Adobe Garamond Pro", "#656565");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 87;
	this.text_13.setTransform(-1.9,-52.3);

	this.addChild(this.text_13);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-124.9,-52.3,250,104.8);
p.frameBounds = [rect];


(lib.mathfluencyshadow = function() {
	this.initialize();

	// Layer 1
	this.instance_1 = new lib.FlashAICB_1();
	this.instance_1.setTransform(-163.5,-23.9,0.965,1);

	this.addChild(this.instance_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-163.5,-23.9,327.3,48);
p.frameBounds = [rect];


(lib.learnlabnight = function() {
	this.initialize();

	// Layer 1
	this.text_14 = new cjs.Text("LearnLab", "bold 15px Adobe Garamond Pro", "#D8D8EC");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 17;
	this.text_14.setTransform(-1.9,-10.9);

	this.addChild(this.text_14);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-31.3,-10.9,62.8,22);
p.frameBounds = [rect];


(lib.learnlabday = function() {
	this.initialize();

	// Layer 1
	this.text_15 = new cjs.Text("LearnLab", "bold 15px Adobe Garamond Pro", "#FFFDE8");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 17;
	this.text_15.setTransform(-1.9,-10.9);

	this.addChild(this.text_15);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-31.3,-10.9,62.8,22);
p.frameBounds = [rect];


(lib.learninginstitutenight = function() {
	this.initialize();

	// Layer 1
	this.text_16 = new cjs.Text("Learning Institute", "bold 15px Adobe Garamond Pro", "#D8D8EC");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 17;
	this.text_16.setTransform(-1.9,-10.9);

	this.addChild(this.text_16);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-57.5,-10.9,115.1,22);
p.frameBounds = [rect];


(lib.learninginstituteday = function() {
	this.initialize();

	// Layer 1
	this.text_17 = new cjs.Text("Learning Institute", "bold 15px Adobe Garamond Pro", "#FFFDE8");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 17;
	this.text_17.setTransform(-1.9,-10.9);

	this.addChild(this.text_17);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-57.5,-10.9,115.1,22);
p.frameBounds = [rect];


(lib.groundnight = function() {
	this.initialize();

	// Layer 1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#4A4661","#484355","#463D43","#453A38","#443935","#171312","#000000"],[0.008,0.051,0.129,0.212,0.302,0.686,0.875],-0.4,-76.9,-0.4,77).s().p("EBDQgMBIAAYDMiGfAAAIAA4DMCGfAAA").cp();
	this.shape_4.setTransform(0.5,0);

	this.addChild(this.shape_4);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-429.9,-76.9,861,154);
p.frameBounds = [rect];


(lib.groundday = function() {
	this.initialize();

	// Layer 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFF5D9","#D9C8B0","#BAA48F","#A48A78","#967B6A","#927565","#8A7060","#776052","#56453C","#29211D","#000000"],[0,0.067,0.129,0.192,0.243,0.286,0.38,0.514,0.675,0.855,1],0,-76.9,0,77).s().p("EBDWAMCMiGrAAAIAA4DMCGrAAAIAAYD").cp();

	this.addChild(this.shape_5);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-430.9,-76.9,862,154);
p.frameBounds = [rect];


(lib.gamesfornight = function() {
	this.initialize();

	// Layer 1
	this.text_18 = new cjs.Text("Games for", "bold 15px Adobe Garamond Pro", "#D8D8EC");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 17;
	this.text_18.setTransform(-1.9,-10.9);

	this.addChild(this.text_18);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-33.4,-10.9,67,22);
p.frameBounds = [rect];


(lib.gamesforday = function() {
	this.initialize();

	// Layer 1
	this.text_19 = new cjs.Text("Games for", "bold 15px Adobe Garamond Pro", "#FFFDE8");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 17;
	this.text_19.setTransform(-1.9,-10.9);

	this.addChild(this.text_19);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-33.4,-10.9,67,22);
p.frameBounds = [rect];


(lib.game2learnnight = function() {
	this.initialize();

	// Layer 1
	this.text_20 = new cjs.Text("Game2Learn", "bold 15px Adobe Garamond Pro", "#D8D8EC");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 17;
	this.text_20.setTransform(-1.9,-10.9);

	this.addChild(this.text_20);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-41.5,-10.9,83.2,22);
p.frameBounds = [rect];


(lib.game2learnday = function() {
	this.initialize();

	// Layer 1
	this.text_21 = new cjs.Text("Game2Learn", "bold 15px Adobe Garamond Pro", "#FFFDE8");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 17;
	this.text_21.setTransform(-1.9,-10.9);

	this.addChild(this.text_21);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-41.5,-10.9,83.2,22);
p.frameBounds = [rect];


(lib.nightsky = function() {
	this.initialize();

	// Layer 1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["rgba(13,8,147,0.6)","rgba(9,6,123,0.745)","rgba(7,4,105,0.859)","rgba(6,3,98,0.898)","rgba(5,3,85,0.922)","rgba(5,1,60,0.965)","rgba(6,1,45,0.988)","#060128"],[0.035,0.118,0.204,0.263,0.298,0.384,0.459,0.518],-2.3,97,0,-98.9,96,724.7).s().p("EBDWAr/MiGrAAAMAAAhX9MCGrAAAMAAABX9").cp();
	this.shape_6.setTransform(431,281.5);

	this.addChild(this.shape_6);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(0,0,862,563);
p.frameBounds = [rect];


(lib.F = function() {
	this.initialize();

	// Layer 1
	this.text_22 = new cjs.Text("F", "bold 32px Adobe Garamond Pro");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 34;
	this.text_22.setTransform(-1.9,-21.1);

	this.addChild(this.text_22);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-11.4,-21.1,22.9,42.4);
p.frameBounds = [rect];


(lib.D = function() {
	this.initialize();

	// Layer 1
	this.text_23 = new cjs.Text("D", "bold 32px Adobe Garamond Pro");
	this.text_23.textAlign = "center";
	this.text_23.lineHeight = 34;
	this.text_23.setTransform(-1.9,-21.1);

	this.addChild(this.text_23);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-15.3,-21.1,30.8,42.4);
p.frameBounds = [rect];


(lib.datacollaborativeshadow = function() {
	this.initialize();

	// Layer 1
	this.instance_2 = new lib.FlashAICB();
	this.instance_2.setTransform(-163.9,-20.9);

	this.addChild(this.instance_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-163.9,-20.9,328,42);
p.frameBounds = [rect];


(lib.C = function() {
	this.initialize();

	// Layer 1
	this.text_24 = new cjs.Text("C", "bold 32px Adobe Garamond Pro");
	this.text_24.textAlign = "center";
	this.text_24.lineHeight = 34;
	this.text_24.setTransform(-1.9,-21.1);

	this.addChild(this.text_24);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-13.7,-21.1,27.5,42.4);
p.frameBounds = [rect];


(lib.communitynight = function() {
	this.initialize();

	// Layer 1
	this.text_25 = new cjs.Text("Community College", "bold 13px Adobe Garamond Pro", "#9997D2");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 15;
	this.text_25.setTransform(-1.9,-9.7);

	this.addChild(this.text_25);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-56,-9.7,112.2,19.7);
p.frameBounds = [rect];


(lib.communityday = function() {
	this.initialize();

	// Layer 1
	this.text_26 = new cjs.Text("Community College", "bold 13px Adobe Garamond Pro", "#CB9F6C");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 15;
	this.text_26.setTransform(-1.9,-9.7);

	this.addChild(this.text_26);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-56,-9.7,112.2,19.7);
p.frameBounds = [rect];


(lib.collegeofcomputingnight = function() {
	this.initialize();

	// Layer 1
	this.text_27 = new cjs.Text("College of Computing", "bold 13px Adobe Garamond Pro", "#9997D2");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 15;
	this.text_27.setTransform(-1.9,-9.7);

	this.addChild(this.text_27);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-61.4,-9.7,123,19.7);
p.frameBounds = [rect];


(lib.collegeofcomputingday = function() {
	this.initialize();

	// Layer 1
	this.text_28 = new cjs.Text("College of Computing", "bold 13px Adobe Garamond Pro", "#CB9F6C");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 15;
	this.text_28.setTransform(-1.9,-9.7);

	this.addChild(this.text_28);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-61.4,-9.7,123,19.7);
p.frameBounds = [rect];


(lib.carnegienight = function() {
	this.initialize();

	// Layer 1
	this.text_29 = new cjs.Text("Carnegie Learning", "bold 15px Adobe Garamond Pro", "#D8D8EC");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 17;
	this.text_29.setTransform(-1.9,-10.9);

	this.addChild(this.text_29);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-58.5,-10.9,117.2,22);
p.frameBounds = [rect];


(lib.carnegieday = function() {
	this.initialize();

	// Layer 1
	this.text_30 = new cjs.Text("Carnegie Learning", "bold 15px Adobe Garamond Pro", "#FFFDE8");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 17;
	this.text_30.setTransform(-1.9,-10.9);

	this.addChild(this.text_30);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-58.5,-10.9,117.2,22);
p.frameBounds = [rect];


(lib.boxyellow = function() {
	this.initialize();

	// Layer 1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFB62F").s("#000000").ss(1,1,1).p("AAtgiIAABFIhZAAIAAhFIBZAA").cp();

	this.addChild(this.shape_7);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-4.4,-3.4,9,7);
p.frameBounds = [rect];


(lib.boxred = function() {
	this.initialize();

	// Layer 1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EF3E31").s("#000000").ss(1,1,1).p("AAtgiIAABFIhZAAIAAhFIBZAA").cp();

	this.addChild(this.shape_8);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-4.4,-3.4,9,7);
p.frameBounds = [rect];


(lib.boxpink = function() {
	this.initialize();

	// Layer 1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E81266").s("#000000").ss(1,1,1).p("AAtgiIAABFIhZAAIAAhFIBZAA").cp();

	this.addChild(this.shape_9);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-4.4,-3.4,9,7);
p.frameBounds = [rect];


(lib.boxorange = function() {
	this.initialize();

	// Layer 1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E56620").s("#000000").ss(1,1,1).p("AAtgiIAABFIhZAAIAAhFIBZAA").cp();

	this.addChild(this.shape_10);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-4.4,-3.4,9,7);
p.frameBounds = [rect];


(lib.boxgreen = function() {
	this.initialize();

	// Layer 1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00814C").s("#000000").ss(1,1,1).p("AAtgiIAABFIhZAAIAAhFIBZAA").cp();

	this.addChild(this.shape_11);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-4.4,-3.4,9,7);
p.frameBounds = [rect];


(lib.boxblue = function() {
	this.initialize();

	// Layer 1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C4D8F7").s("#000000").ss(1,1,1).p("AAtgiIAABFIhZAAIAAhFIBZAA").cp();

	this.addChild(this.shape_12);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-4.4,-3.4,9,7);
p.frameBounds = [rect];


(lib.athluencyblack = function() {
	this.initialize();

	// Layer 1
	this.text_31 = new cjs.Text("ath", "32px Adobe Garamond Pro");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 34;
	this.text_31.setTransform(-42.4,-21.1);

	this.addChild(this.text_31);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-64,-21.1,47.2,42.4);
p.frameBounds = [rect];


(lib.atablack = function() {
	this.initialize();

	// Layer 1
	this.text_32 = new cjs.Text("ata", "32px Adobe Garamond Pro");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 34;
	this.text_32.setTransform(-70.4,-21.1);

	this.addChild(this.text_32);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-90.2,-21.1,43.6,42.4);
p.frameBounds = [rect];


(lib.atnyunight = function() {
	this.initialize();

	// Layer 1
	this.text_33 = new cjs.Text("at New York University", "bold 13px Adobe Garamond Pro", "#9997D2");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 15;
	this.text_33.setTransform(-1.9,-9.7);

	this.addChild(this.text_33);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-62.9,-9.7,125.9,19.7);
p.frameBounds = [rect];


(lib.atnyuday = function() {
	this.initialize();

	// Layer 1
	this.text_34 = new cjs.Text("at New York University", "bold 13px Adobe Garamond Pro", "#CB9F6C");
	this.text_34.textAlign = "center";
	this.text_34.lineHeight = 15;
	this.text_34.setTransform(-1.9,-9.7);

	this.addChild(this.text_34);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-62.9,-9.7,125.9,19.7);
p.frameBounds = [rect];


(lib.andinfomaticsnight = function() {
	this.initialize();

	// Layer 1
	this.text_35 = new cjs.Text("and Infomatics", "bold 13px Adobe Garamond Pro", "#9997D2");
	this.text_35.textAlign = "center";
	this.text_35.lineHeight = 15;
	this.text_35.setTransform(-1.9,-9.7);

	this.addChild(this.text_35);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-42,-9.7,84.1,19.7);
p.frameBounds = [rect];


(lib.andinfomaticsday = function() {
	this.initialize();

	// Layer 1
	this.text_36 = new cjs.Text("and Infomatics", "bold 13px Adobe Garamond Pro", "#CB9F6C");
	this.text_36.textAlign = "center";
	this.text_36.lineHeight = 15;
	this.text_36.setTransform(-1.9,-9.7);

	this.addChild(this.text_36);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-42,-9.7,84.1,19.7);
p.frameBounds = [rect];


(lib.skynight = function() {
	this.initialize();

	// Layer 1
	this.instance_3 = new lib.nightsky();
	this.instance_3.setTransform(0,0,1,1,0,0,0,431,281.5);
	this.instance_3.alpha = 0.699;

	this.addChild(this.instance_3);
}).prototype = p = new cjs.Container();
p.nominalBounds = rect = new cjs.Rectangle(-430.9,-281.4,862,563);
p.frameBounds = [rect];

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;